-- DocIntelPro Complete Database Schema with BFSI Enhancement
-- Execute this in PgAdmin4 to create all required tables for the project
-- Database: RND (PostgreSQL)
-- Date: August 28, 2025

-- ===============================================
-- 0. CREATE BASE TABLES FIRST
-- ===============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Check if users table already exists and has correct structure
DO $$
BEGIN
    -- If users table exists with integer id, we need to handle this carefully
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users') THEN
        -- Check if id column is integer type
        IF EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'users' AND column_name = 'id' AND data_type = 'integer') THEN
            RAISE NOTICE 'Users table exists with integer ID. Creating new UUID-based users table as users_new.';
            
            -- Create the new users table with UUID
            DROP TABLE IF EXISTS users_new CASCADE;
            CREATE TABLE users_new (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                organization_id UUID NOT NULL,
                username VARCHAR(100) NOT NULL UNIQUE,
                email VARCHAR(255) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                first_name VARCHAR(100),
                last_name VARCHAR(100),
                role VARCHAR(50) DEFAULT 'user',
                permissions JSONB DEFAULT '[]'::jsonb,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT true,
                created_at TIMESTAMP DEFAULT NOW(),
                updated_at TIMESTAMP DEFAULT NOW()
            );
            
            -- Copy existing data if any (with UUID generation)
            INSERT INTO users_new (username, email, password, first_name, last_name, role, is_active, created_at)
            SELECT username, email, COALESCE(password, 'temp_password'), first_name, last_name, 
                   COALESCE(role, 'user'), COALESCE(is_active, true), COALESCE(created_at, NOW())
            FROM users;
            
            -- Drop old table and rename new one
            DROP TABLE users CASCADE;
            ALTER TABLE users_new RENAME TO users;
        ELSE
            RAISE NOTICE 'Users table exists with correct UUID structure.';
        END IF;
    END IF;
END $$;

-- Organizations table
CREATE TABLE IF NOT EXISTS organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    domain VARCHAR(100) NOT NULL DEFAULT 'bfsi',
    industry VARCHAR(100) DEFAULT 'financial_services',
    country VARCHAR(10) DEFAULT 'US',
    settings JSONB DEFAULT '{}'::jsonb,
    subscription_plan VARCHAR(50) DEFAULT 'basic',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    role VARCHAR(50) DEFAULT 'user', -- admin, manager, user, viewer
    permissions JSONB DEFAULT '[]'::jsonb,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Document sources table (base structure)
CREATE TABLE IF NOT EXISTS document_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL, -- network_folder, sharepoint, database, ftp, cloud_storage, sftp, api_integration, core_banking, loan_management
    connection_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    authentication_config JSONB DEFAULT '{}'::jsonb,
    scan_schedule VARCHAR(100) DEFAULT 'manual', -- manual, hourly, daily, weekly
    last_scan TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active', -- active, inactive, error
    error_message TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Documents table (base structure)
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    source_id UUID REFERENCES document_sources(id) ON DELETE SET NULL,
    file_name VARCHAR(500) NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT,
    file_type VARCHAR(50),
    mime_type VARCHAR(100),
    file_hash VARCHAR(128), -- SHA-256 hash for deduplication
    original_text TEXT,
    processed_text TEXT,
    classification_status VARCHAR(50) DEFAULT 'pending', -- pending, processing, classified, failed
    classification_confidence DECIMAL(5,4),
    classification_level VARCHAR(50), -- public, internal, confidential, restricted
    contains_pii BOOLEAN DEFAULT false,
    pii_entities JSONB DEFAULT '[]'::jsonb,
    extraction_status VARCHAR(50) DEFAULT 'pending',
    processing_start_time TIMESTAMP,
    processed_at TIMESTAMP,
    error_message TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Processing jobs table
CREATE TABLE IF NOT EXISTS processing_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    source_id UUID REFERENCES document_sources(id) ON DELETE SET NULL,
    job_type VARCHAR(50) NOT NULL, -- scan, classify, extract, index
    status VARCHAR(50) DEFAULT 'pending', -- pending, running, completed, failed, cancelled
    priority INTEGER DEFAULT 100,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    progress DECIMAL(5,2) DEFAULT 0.00,
    error_message TEXT,
    job_config JSONB DEFAULT '{}'::jsonb,
    result JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Classification results table
CREATE TABLE IF NOT EXISTS classification_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    classifier_name VARCHAR(100) NOT NULL,
    classification_type VARCHAR(100) NOT NULL,
    confidence DECIMAL(5,4) NOT NULL,
    classification_data JSONB DEFAULT '{}'::jsonb,
    processing_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);

-- OCR results table
CREATE TABLE IF NOT EXISTS ocr_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    ocr_provider VARCHAR(50) NOT NULL, -- paddleocr, azure_di, google_vision, aws_textract
    extracted_text TEXT,
    confidence DECIMAL(5,4),
    bounding_boxes JSONB DEFAULT '[]'::jsonb,
    processing_time_ms INTEGER,
    provider_response JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Document vectors table (for vector search)
CREATE TABLE IF NOT EXISTS document_vectors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chunk_id VARCHAR(255) NOT NULL UNIQUE,
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    embedding BYTEA, -- Serialized vector embedding
    chunk_number INTEGER,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- PII detection results table
CREATE TABLE IF NOT EXISTS pii_detection_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    entity_type VARCHAR(100) NOT NULL,
    entity_value TEXT NOT NULL,
    start_position INTEGER,
    end_position INTEGER,
    confidence DECIMAL(5,4),
    context TEXT,
    anonymized_value TEXT,
    detection_method VARCHAR(50), -- presidio, spacy, custom
    created_at TIMESTAMP DEFAULT NOW()
);

-- Audit log table
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    document_id UUID REFERENCES documents(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Drop existing foreign key constraint if it exists and recreate properly
DO $$
BEGIN
    -- Drop constraint if it exists
    IF EXISTS (SELECT 1 FROM information_schema.table_constraints 
               WHERE constraint_name = 'audit_logs_user_id_fkey' 
               AND table_name = 'audit_logs') THEN
        ALTER TABLE audit_logs DROP CONSTRAINT audit_logs_user_id_fkey;
    END IF;
    
    -- Add constraint back with proper handling
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users') THEN
        ALTER TABLE audit_logs ADD CONSTRAINT audit_logs_user_id_fkey 
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        -- If there's still an error, we'll skip the constraint for now
        RAISE NOTICE 'Could not add user_id foreign key constraint: %', SQLERRM;
END $$;

-- System settings table
CREATE TABLE IF NOT EXISTS system_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    setting_key VARCHAR(255) NOT NULL,
    setting_value JSONB NOT NULL,
    setting_type VARCHAR(50) DEFAULT 'string',
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(organization_id, setting_key)
);

-- API keys table
CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    key_name VARCHAR(255) NOT NULL,
    key_hash VARCHAR(255) NOT NULL UNIQUE,
    key_prefix VARCHAR(20),
    permissions JSONB DEFAULT '[]'::jsonb,
    last_used TIMESTAMP,
    usage_count BIGINT DEFAULT 0,
    rate_limit INTEGER DEFAULT 1000,
    expires_at TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'info', -- info, warning, error, success
    is_read BOOLEAN DEFAULT false,
    related_resource_type VARCHAR(50),
    related_resource_id UUID,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ===============================================
-- 1. UPDATE document_sources table for BFSI
-- ===============================================

-- Add new columns to document_sources table
ALTER TABLE document_sources 
ADD COLUMN IF NOT EXISTS domain VARCHAR(50) DEFAULT 'bfsi',
ADD COLUMN IF NOT EXISTS document_types JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS compliance_level VARCHAR(20) DEFAULT 'internal';

-- Update existing source types to include BFSI-specific types
-- Note: This will not affect existing data, just allows new values
COMMENT ON COLUMN document_sources.type IS 'Source types: network_folder, sharepoint, database, ftp, cloud_storage, sftp, api_integration, core_banking, loan_management';

-- ===============================================
-- 2. CREATE BFSI Document Types Configuration Table
-- ===============================================

CREATE TABLE IF NOT EXISTS bfsi_document_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type_key VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(100) NOT NULL,
    classification VARCHAR(20) NOT NULL DEFAULT 'internal',
    description TEXT,
    required_fields JSONB DEFAULT '[]'::jsonb,
    pii_fields JSONB DEFAULT '[]'::jsonb,
    retention_period VARCHAR(50) DEFAULT '7_years',
    compliance_flags JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Insert BFSI document types
INSERT INTO bfsi_document_types (type_key, name, category, classification, description, required_fields, pii_fields, retention_period, compliance_flags) VALUES
-- Loan & Credit Documents
('LOAN_APPLICATION', 'Loan Application', 'lending', 'confidential', 'Personal and business loan applications', '["applicant_name", "loan_amount", "purpose"]'::jsonb, '["ssn", "income", "employment_details"]'::jsonb, '7_years', '["SOX", "Fair_Lending_Act"]'::jsonb),
('CREDIT_REPORT', 'Credit Report', 'lending', 'confidential', 'Credit bureau reports and scores', '["credit_score", "report_date", "bureau"]'::jsonb, '["ssn", "credit_history", "debt_information"]'::jsonb, '7_years', '["FCRA", "GLBA"]'::jsonb),
('LOAN_AGREEMENT', 'Loan Agreement', 'lending', 'confidential', 'Signed loan contracts and agreements', '["loan_amount", "interest_rate", "terms"]'::jsonb, '["borrower_info", "collateral_details"]'::jsonb, '7_years', '["SOX", "TILA"]'::jsonb),

-- KYC & Compliance Documents
('KYC_DOCUMENT', 'KYC Document', 'compliance', 'restricted', 'Know Your Customer verification documents', '["customer_id", "document_type", "verification_status"]'::jsonb, '["government_id", "address", "phone", "email"]'::jsonb, '5_years', '["BSA", "AML", "PATRIOT_Act"]'::jsonb),
('AML_REPORT', 'AML Report', 'compliance', 'restricted', 'Anti-Money Laundering reports and investigations', '["transaction_id", "suspicious_activity", "investigation_status"]'::jsonb, '["customer_info", "transaction_details"]'::jsonb, '5_years', '["BSA", "AML", "FinCEN"]'::jsonb),
('SAR_FILING', 'SAR Filing', 'compliance', 'confidential', 'Suspicious Activity Reports', '["filing_date", "activity_type", "amount"]'::jsonb, '["subject_info", "transaction_details"]'::jsonb, '5_years', '["BSA", "FinCEN"]'::jsonb),

-- Financial Statements & Reports
('FINANCIAL_STATEMENT', 'Financial Statement', 'financial_reporting', 'internal', 'Balance sheets, income statements, cash flow', '["statement_type", "period", "prepared_by"]'::jsonb, '["financial_data"]'::jsonb, '7_years', '["SOX", "GAAP"]'::jsonb),
('AUDIT_REPORT', 'Audit Report', 'financial_reporting', 'restricted', 'Internal and external audit reports', '["audit_type", "auditor", "findings"]'::jsonb, '["financial_details"]'::jsonb, '7_years', '["SOX", "PCAOB"]'::jsonb),
('TAX_DOCUMENT', 'Tax Document', 'financial_reporting', 'confidential', 'Tax returns and related documentation', '["tax_year", "entity_type", "jurisdiction"]'::jsonb, '["tax_id", "financial_data"]'::jsonb, '7_years', '["IRS", "State_Tax"]'::jsonb),

-- Insurance Documents
('INSURANCE_POLICY', 'Insurance Policy', 'insurance', 'internal', 'Insurance policies and coverage details', '["policy_number", "coverage_type", "premium"]'::jsonb, '["policyholder_info", "beneficiary_info"]'::jsonb, '7_years', '["State_Insurance"]'::jsonb),
('INSURANCE_CLAIM', 'Insurance Claim', 'insurance', 'restricted', 'Insurance claims and settlements', '["claim_number", "incident_date", "claim_amount"]'::jsonb, '["claimant_info", "medical_info"]'::jsonb, '7_years', '["State_Insurance", "HIPAA"]'::jsonb),

-- Investment & Securities
('INVESTMENT_AGREEMENT', 'Investment Agreement', 'securities', 'confidential', 'Investment contracts and agreements', '["investment_type", "amount", "terms"]'::jsonb, '["investor_info", "financial_status"]'::jsonb, '7_years', '["SEC", "FINRA"]'::jsonb),
('PROSPECTUS', 'Prospectus', 'securities', 'public', 'Investment prospectus and offering documents', '["offering_type", "securities_details", "risks"]'::jsonb, '[]'::jsonb, '7_years', '["SEC", "Securities_Act"]'::jsonb),

-- Transaction Documents
('WIRE_TRANSFER', 'Wire Transfer', 'transactions', 'restricted', 'Wire transfer instructions and confirmations', '["amount", "sender", "receiver", "purpose"]'::jsonb, '["account_numbers", "customer_info"]'::jsonb, '5_years', '["BSA", "OFAC"]'::jsonb),
('TRANSACTION_RECORD', 'Transaction Record', 'transactions', 'internal', 'General transaction records and logs', '["transaction_id", "amount", "date", "type"]'::jsonb, '["account_info", "customer_info"]'::jsonb, '7_years', '["BSA", "Record_Keeping"]'::jsonb);

-- ===============================================
-- 3. CREATE Compliance Frameworks Reference Table
-- ===============================================

CREATE TABLE IF NOT EXISTS compliance_frameworks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    industry VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Insert compliance frameworks
INSERT INTO compliance_frameworks (code, name, description, industry) VALUES
('SOX', 'Sarbanes-Oxley Act', 'Financial reporting and corporate governance', 'Financial Services'),
('BSA', 'Bank Secrecy Act', 'Anti-money laundering requirements', 'Banking'),
('AML', 'Anti-Money Laundering', 'Money laundering prevention', 'Financial Services'),
('GLBA', 'Gramm-Leach-Bliley Act', 'Financial privacy protection', 'Financial Services'),
('FCRA', 'Fair Credit Reporting Act', 'Credit reporting accuracy and privacy', 'Financial Services'),
('TILA', 'Truth in Lending Act', 'Credit terms disclosure', 'Banking'),
('PATRIOT_Act', 'USA PATRIOT Act', 'Terrorism financing prevention', 'Financial Services'),
('FinCEN', 'Financial Crimes Enforcement Network', 'Financial intelligence reporting', 'Financial Services'),
('SEC', 'Securities and Exchange Commission', 'Securities regulation', 'Securities'),
('FINRA', 'Financial Industry Regulatory Authority', 'Broker-dealer regulation', 'Securities'),
('OFAC', 'Office of Foreign Assets Control', 'Economic sanctions enforcement', 'Financial Services'),
('PCAOB', 'Public Company Accounting Oversight Board', 'Audit oversight', 'Financial Services'),
('GAAP', 'Generally Accepted Accounting Principles', 'Accounting standards', 'Financial Services'),
('HIPAA', 'Health Insurance Portability and Accountability Act', 'Healthcare privacy (for insurance)', 'Healthcare/Insurance'),
('Fair_Lending_Act', 'Fair Lending Act', 'Equal credit opportunity', 'Banking'),
('Securities_Act', 'Securities Act of 1933', 'Securities registration and disclosure', 'Securities'),
('Record_Keeping', 'Record Keeping Requirements', 'Document retention obligations', 'All Industries'),
('State_Insurance', 'State Insurance Regulations', 'State-level insurance oversight', 'Insurance'),
('State_Tax', 'State Tax Regulations', 'State taxation compliance', 'All Industries'),
('IRS', 'Internal Revenue Service', 'Federal tax compliance', 'All Industries');

-- ===============================================
-- 4. CREATE BFSI Processing Rules Table
-- ===============================================

CREATE TABLE IF NOT EXISTS bfsi_processing_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    source_id UUID REFERENCES document_sources(id),
    document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
    rule_name VARCHAR(200) NOT NULL,
    rule_type VARCHAR(50) NOT NULL, -- classification, pii_detection, compliance_check, retention
    rule_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    priority INTEGER DEFAULT 100,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===============================================
-- 5. UPDATE documents table for enhanced BFSI tracking
-- ===============================================

-- Add BFSI-specific columns to documents table
ALTER TABLE documents 
ADD COLUMN IF NOT EXISTS document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
ADD COLUMN IF NOT EXISTS compliance_status VARCHAR(50) DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS compliance_score DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS risk_score DECIMAL(5,2),
ADD COLUMN IF NOT EXISTS retention_date DATE,
ADD COLUMN IF NOT EXISTS regulatory_flags JSONB DEFAULT '[]'::jsonb;

-- ===============================================
-- 6. CREATE BFSI Analytics Views
-- ===============================================

-- View for BFSI document processing metrics
CREATE OR REPLACE VIEW bfsi_processing_metrics AS
SELECT 
    d.organization_id,
    bdt.category,
    bdt.classification,
    COUNT(*) as document_count,
    AVG(d.classification_confidence) as avg_confidence,
    COUNT(CASE WHEN d.contains_pii = true THEN 1 END) as pii_documents,
    COUNT(CASE WHEN d.compliance_status = 'compliant' THEN 1 END) as compliant_documents,
    COUNT(CASE WHEN d.compliance_status = 'non_compliant' THEN 1 END) as non_compliant_documents,
    AVG(d.risk_score) as avg_risk_score
FROM documents d
LEFT JOIN bfsi_document_types bdt ON d.document_type_key = bdt.type_key
WHERE d.created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY d.organization_id, bdt.category, bdt.classification;

-- View for compliance framework coverage
CREATE OR REPLACE VIEW bfsi_compliance_coverage AS
SELECT 
    d.organization_id,
    cf.code as framework_code,
    cf.name as framework_name,
    COUNT(d.id) as documents_covered,
    COUNT(CASE WHEN d.compliance_status = 'compliant' THEN 1 END) as compliant_count,
    (COUNT(CASE WHEN d.compliance_status = 'compliant' THEN 1 END) * 100.0 / COUNT(d.id)) as compliance_percentage
FROM documents d
JOIN bfsi_document_types bdt ON d.document_type_key = bdt.type_key
JOIN compliance_frameworks cf ON cf.code = ANY(
    SELECT jsonb_array_elements_text(bdt.compliance_flags)
)
WHERE d.created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY d.organization_id, cf.code, cf.name;

-- ===============================================
-- 7. UPDATE dashboard_metrics function (if exists)
-- ===============================================

-- Function to calculate BFSI-specific dashboard metrics
CREATE OR REPLACE FUNCTION get_bfsi_dashboard_metrics(org_id UUID)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'total_processed', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND processed_at IS NOT NULL
        ),
        'todays_processed', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND DATE(processed_at) = CURRENT_DATE
        ),
        'completed_today', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND DATE(processed_at) = CURRENT_DATE 
            AND classification_status = 'classified'
        ),
        'accuracy', (
            SELECT AVG(classification_confidence) FROM documents 
            WHERE organization_id = org_id 
            AND classification_confidence IS NOT NULL
        ),
        'active_sources', (
            SELECT COUNT(*) FROM document_sources 
            WHERE organization_id = org_id 
            AND is_active = true
        ),
        'queue_size', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND classification_status = 'pending'
        ),
        'classification_breakdown', (
            SELECT json_agg(
                json_build_object(
                    'level', classification_level,
                    'count', doc_count,
                    'percentage', ROUND((doc_count * 100.0 / total_docs), 1)
                )
            )
            FROM (
                SELECT 
                    classification_level,
                    COUNT(*) as doc_count,
                    (SELECT COUNT(*) FROM documents WHERE organization_id = org_id) as total_docs
                FROM documents 
                WHERE organization_id = org_id 
                AND classification_level IS NOT NULL
                GROUP BY classification_level
            ) breakdown
        )
    ) INTO result;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- ===============================================
-- 8. CREATE indexes for performance
-- ===============================================

-- Indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_documents_org_type_key ON documents(organization_id, document_type_key);
CREATE INDEX IF NOT EXISTS idx_documents_compliance_status ON documents(compliance_status);
CREATE INDEX IF NOT EXISTS idx_documents_classification_level ON documents(classification_level);
CREATE INDEX IF NOT EXISTS idx_documents_processed_date ON documents(DATE(processed_at));
CREATE INDEX IF NOT EXISTS idx_bfsi_document_types_category ON bfsi_document_types(category);
CREATE INDEX IF NOT EXISTS idx_document_sources_domain ON document_sources(domain);

-- ===============================================
-- 9. Sample data for testing (optional)
-- ===============================================

-- Insert sample organization if not exists
INSERT INTO organizations (id, name, domain, settings) 
VALUES (
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Demo BFSI Organization',
    'bfsi',
    '{"industry": "banking", "country": "US", "compliance_frameworks": ["SOX", "BSA", "AML"]}'::jsonb
) ON CONFLICT (id) DO NOTHING;

-- Insert sample user if not exists
INSERT INTO users (id, username, email, password, first_name, last_name, role, organization_id)
VALUES (
    '3761d7a3-eace-492a-8cf2-eab83c28fd2f',
    'bfsi_admin',
    'admin@bfsidemo.com',
    '$2b$10$example_hashed_password',
    'BFSI',
    'Administrator',
    'admin',
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b'
) ON CONFLICT (id) DO NOTHING;

-- ===============================================
-- 10. Grant permissions (adjust as needed)
-- ===============================================

-- Grant permissions to application user (replace 'app_user' with your actual DB user)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;

-- ===============================================
-- End of Migration Script
-- ===============================================

-- Verify the migration
SELECT 'BFSI Migration completed successfully!' as status,
       COUNT(*) as document_types_created
FROM bfsi_document_types;

-- Check compliance frameworks
SELECT 'Compliance frameworks loaded:' as status, 
       COUNT(*) as frameworks_count
FROM compliance_frameworks;

-- Display new columns in document_sources
SELECT column_name, data_type, column_default
FROM information_schema.columns 
WHERE table_name = 'document_sources' 
AND column_name IN ('domain', 'document_types', 'compliance_level');

-- ===============================================
-- 11. CREATE ADDITIONAL MICROSERVICES TABLES
-- ===============================================

-- ML Model configurations table
CREATE TABLE IF NOT EXISTS ml_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_name VARCHAR(255) NOT NULL UNIQUE,
    model_type VARCHAR(100) NOT NULL, -- classification, ocr, ner, embedding
    model_version VARCHAR(50) NOT NULL,
    model_path TEXT,
    model_config JSONB DEFAULT '{}'::jsonb,
    performance_metrics JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Service health monitoring table
CREATE TABLE IF NOT EXISTS service_health (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_name VARCHAR(100) NOT NULL,
    service_version VARCHAR(50),
    status VARCHAR(50) NOT NULL, -- healthy, degraded, unhealthy
    response_time_ms INTEGER,
    cpu_usage DECIMAL(5,2),
    memory_usage DECIMAL(5,2),
    error_count INTEGER DEFAULT 0,
    dependencies JSONB DEFAULT '{}'::jsonb,
    last_check TIMESTAMP DEFAULT NOW()
);

-- Document workflow states table
CREATE TABLE IF NOT EXISTS document_workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    workflow_name VARCHAR(255) NOT NULL,
    current_stage VARCHAR(100) NOT NULL,
    stages_completed JSONB DEFAULT '[]'::jsonb,
    stage_results JSONB DEFAULT '{}'::jsonb,
    total_stages INTEGER DEFAULT 0,
    progress DECIMAL(5,2) DEFAULT 0.00,
    started_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    error_stage VARCHAR(100),
    error_message TEXT
);

-- Vector search indexes table
CREATE TABLE IF NOT EXISTS vector_search_indexes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    index_name VARCHAR(255) NOT NULL UNIQUE,
    index_type VARCHAR(50) DEFAULT 'faiss', -- faiss, qdrant, chroma
    embedding_model VARCHAR(255) NOT NULL,
    dimension INTEGER NOT NULL,
    document_count BIGINT DEFAULT 0,
    index_size_bytes BIGINT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT NOW(),
    index_config JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true
);

-- Search queries log table
CREATE TABLE IF NOT EXISTS search_queries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    query_text TEXT NOT NULL,
    search_type VARCHAR(50), -- semantic, keyword, hybrid
    filters JSONB DEFAULT '{}'::jsonb,
    results_count INTEGER,
    response_time_ms INTEGER,
    relevance_scores JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Compliance audit trails table
CREATE TABLE IF NOT EXISTS compliance_audit_trails (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    compliance_framework VARCHAR(100) NOT NULL,
    audit_type VARCHAR(100) NOT NULL, -- retention_check, pii_scan, classification_review
    audit_result VARCHAR(50) NOT NULL, -- passed, failed, warning
    findings JSONB DEFAULT '[]'::jsonb,
    recommendations JSONB DEFAULT '[]'::jsonb,
    auditor_id UUID REFERENCES users(id),
    audit_date TIMESTAMP DEFAULT NOW()
);

-- Data retention policies table
CREATE TABLE IF NOT EXISTS data_retention_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    policy_name VARCHAR(255) NOT NULL,
    document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
    retention_period_days INTEGER NOT NULL,
    auto_delete BOOLEAN DEFAULT false,
    archive_before_delete BOOLEAN DEFAULT true,
    legal_hold_exception BOOLEAN DEFAULT false,
    policy_rules JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Scheduled deletion queue table
CREATE TABLE IF NOT EXISTS deletion_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    scheduled_deletion_date DATE NOT NULL,
    retention_policy_id UUID REFERENCES data_retention_policies(id),
    deletion_reason VARCHAR(255),
    legal_hold BOOLEAN DEFAULT false,
    deletion_status VARCHAR(50) DEFAULT 'scheduled', -- scheduled, processing, completed, failed, cancelled
    processed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Integration webhooks table
CREATE TABLE IF NOT EXISTS integration_webhooks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    webhook_name VARCHAR(255) NOT NULL,
    webhook_url TEXT NOT NULL,
    event_types JSONB NOT NULL DEFAULT '[]'::jsonb, -- document_processed, classification_completed, etc.
    authentication_config JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    last_triggered TIMESTAMP,
    success_count BIGINT DEFAULT 0,
    failure_count BIGINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Webhook delivery attempts table
CREATE TABLE IF NOT EXISTS webhook_deliveries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_id UUID NOT NULL REFERENCES integration_webhooks(id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    delivery_status VARCHAR(50) DEFAULT 'pending', -- pending, delivered, failed, retrying
    response_status_code INTEGER,
    response_body TEXT,
    attempt_count INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    next_retry_at TIMESTAMP,
    delivered_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Document templates table (for BFSI document generation)
CREATE TABLE IF NOT EXISTS document_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    template_name VARCHAR(255) NOT NULL,
    template_type VARCHAR(100) NOT NULL, -- report, letter, form, compliance_document
    document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
    template_content TEXT NOT NULL,
    template_variables JSONB DEFAULT '[]'::jsonb,
    output_format VARCHAR(50) DEFAULT 'pdf', -- pdf, docx, html
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===============================================
-- 12. CREATE COMPREHENSIVE INDEXES
-- ===============================================

-- Primary performance indexes
CREATE INDEX IF NOT EXISTS idx_documents_org_id ON documents(organization_id);
CREATE INDEX IF NOT EXISTS idx_documents_source_id ON documents(source_id);
CREATE INDEX IF NOT EXISTS idx_documents_file_hash ON documents(file_hash);
CREATE INDEX IF NOT EXISTS idx_documents_classification_status ON documents(classification_status);
CREATE INDEX IF NOT EXISTS idx_documents_processed_at ON documents(processed_at);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents(created_at);

-- BFSI-specific indexes
CREATE INDEX IF NOT EXISTS idx_documents_org_type_key ON documents(organization_id, document_type_key);
CREATE INDEX IF NOT EXISTS idx_documents_compliance_status ON documents(compliance_status);
CREATE INDEX IF NOT EXISTS idx_documents_classification_level ON documents(classification_level);
CREATE INDEX IF NOT EXISTS idx_documents_contains_pii ON documents(contains_pii);
CREATE INDEX IF NOT EXISTS idx_documents_retention_date ON documents(retention_date);

-- Processing job indexes
CREATE INDEX IF NOT EXISTS idx_processing_jobs_status ON processing_jobs(status);
CREATE INDEX IF NOT EXISTS idx_processing_jobs_org_id ON processing_jobs(organization_id);
CREATE INDEX IF NOT EXISTS idx_processing_jobs_document_id ON processing_jobs(document_id);
CREATE INDEX IF NOT EXISTS idx_processing_jobs_created_at ON processing_jobs(created_at);

-- Vector search indexes
CREATE INDEX IF NOT EXISTS idx_document_vectors_document_id ON document_vectors(document_id);
CREATE INDEX IF NOT EXISTS idx_document_vectors_chunk_id ON document_vectors(chunk_id);

-- PII detection indexes
CREATE INDEX IF NOT EXISTS idx_pii_detection_document_id ON pii_detection_results(document_id);
CREATE INDEX IF NOT EXISTS idx_pii_detection_entity_type ON pii_detection_results(entity_type);

-- Audit and compliance indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_org_id ON audit_logs(organization_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_compliance_audit_org_id ON compliance_audit_trails(organization_id);
CREATE INDEX IF NOT EXISTS idx_compliance_audit_framework ON compliance_audit_trails(compliance_framework);

-- Search performance indexes
CREATE INDEX IF NOT EXISTS idx_search_queries_org_id ON search_queries(organization_id);
CREATE INDEX IF NOT EXISTS idx_search_queries_created_at ON search_queries(created_at);

-- Source and user indexes
CREATE INDEX IF NOT EXISTS idx_document_sources_org_id ON document_sources(organization_id);
CREATE INDEX IF NOT EXISTS idx_document_sources_type ON document_sources(type);
CREATE INDEX IF NOT EXISTS idx_document_sources_domain ON document_sources(domain);
CREATE INDEX IF NOT EXISTS idx_users_org_id ON users(organization_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- BFSI reference table indexes
CREATE INDEX IF NOT EXISTS idx_bfsi_document_types_category ON bfsi_document_types(category);
CREATE INDEX IF NOT EXISTS idx_bfsi_document_types_classification ON bfsi_document_types(classification);
CREATE INDEX IF NOT EXISTS idx_bfsi_processing_rules_org_id ON bfsi_processing_rules(organization_id);
CREATE INDEX IF NOT EXISTS idx_bfsi_processing_rules_doc_type ON bfsi_processing_rules(document_type_key);

-- ===============================================
-- 13. CREATE ADDITIONAL FUNCTIONS
-- ===============================================

-- Function to automatically update document retention dates
CREATE OR REPLACE FUNCTION update_document_retention_date()
RETURNS TRIGGER AS $$
BEGIN
    -- Set retention date based on document type
    IF NEW.document_type_key IS NOT NULL THEN
        SELECT INTO NEW.retention_date 
            CURRENT_DATE + INTERVAL '1 day' * 
            CASE 
                WHEN bdt.retention_period = '5_years' THEN 1825
                WHEN bdt.retention_period = '7_years' THEN 2555
                WHEN bdt.retention_period = '10_years' THEN 3650
                ELSE 2555 -- Default to 7 years
            END
        FROM bfsi_document_types bdt 
        WHERE bdt.type_key = NEW.document_type_key;
    END IF;
    
    -- Update timestamps
    NEW.updated_at = NOW();
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for retention date updates
DROP TRIGGER IF EXISTS trigger_update_document_retention ON documents;
CREATE TRIGGER trigger_update_document_retention
    BEFORE UPDATE ON documents
    FOR EACH ROW
    EXECUTE FUNCTION update_document_retention_date();

-- Function to log audit events
CREATE OR REPLACE FUNCTION log_audit_event(
    p_organization_id UUID,
    p_user_id UUID,
    p_action VARCHAR(100),
    p_resource_type VARCHAR(50),
    p_resource_id UUID,
    p_old_values JSONB DEFAULT NULL,
    p_new_values JSONB DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    audit_id UUID;
BEGIN
    INSERT INTO audit_logs (
        organization_id, user_id, action, resource_type, resource_id,
        old_values, new_values
    ) VALUES (
        p_organization_id, p_user_id, p_action, p_resource_type, p_resource_id,
        p_old_values, p_new_values
    ) RETURNING id INTO audit_id;
    
    RETURN audit_id;
END;
$$ LANGUAGE plpgsql;

-- Function to check compliance status
CREATE OR REPLACE FUNCTION check_document_compliance(p_document_id UUID)
RETURNS JSON AS $$
DECLARE
    doc_record RECORD;
    compliance_result JSON;
    pii_count INTEGER;
    classification_valid BOOLEAN;
    retention_valid BOOLEAN;
BEGIN
    -- Get document details
    SELECT d.*, bdt.compliance_flags, bdt.retention_period
    INTO doc_record
    FROM documents d
    LEFT JOIN bfsi_document_types bdt ON d.document_type_key = bdt.type_key
    WHERE d.id = p_document_id;
    
    IF NOT FOUND THEN
        RETURN json_build_object('error', 'Document not found');
    END IF;
    
    -- Check PII handling
    SELECT COUNT(*) INTO pii_count
    FROM pii_detection_results
    WHERE document_id = p_document_id;
    
    -- Check classification validity
    classification_valid := (doc_record.classification_level IS NOT NULL 
                            AND doc_record.classification_confidence > 0.7);
    
    -- Check retention policy
    retention_valid := (doc_record.retention_date IS NOT NULL 
                       AND doc_record.retention_date > CURRENT_DATE);
    
    -- Build compliance result
    SELECT json_build_object(
        'document_id', p_document_id,
        'compliance_score', CASE 
            WHEN classification_valid AND retention_valid AND pii_count = 0 THEN 100
            WHEN classification_valid AND retention_valid THEN 85
            WHEN classification_valid OR retention_valid THEN 60
            ELSE 30
        END,
        'classification_valid', classification_valid,
        'retention_valid', retention_valid,
        'pii_detected', pii_count > 0,
        'pii_count', pii_count,
        'applicable_frameworks', doc_record.compliance_flags,
        'checked_at', NOW()
    ) INTO compliance_result;
    
    RETURN compliance_result;
END;
$$ LANGUAGE plpgsql;

-- ===============================================
-- 14. INSERT INITIAL ML MODELS CONFIGURATION
-- ===============================================

-- Insert ML model configurations
INSERT INTO ml_models (model_name, model_type, model_version, model_config, is_active) VALUES
('en_core_web_sm', 'ner', '3.6.0', '{"provider": "spacy", "language": "en"}'::jsonb, true),
('all-MiniLM-L6-v2', 'embedding', '1.0.0', '{"provider": "sentence-transformers", "dimension": 384}'::jsonb, true),
('distilbert-base-uncased', 'classification', '1.0.0', '{"provider": "huggingface", "task": "text-classification"}'::jsonb, true),
('paddleocr', 'ocr', '2.7.0', '{"provider": "paddleocr", "languages": ["en"], "use_gpu": false}'::jsonb, true),
('presidio-analyzer', 'ner', '2.2.0', '{"provider": "presidio", "supported_languages": ["en"]}'::jsonb, true)
ON CONFLICT (model_name) DO NOTHING;

-- ===============================================
-- 15. CREATE SAMPLE DATA RETENTION POLICIES
-- ===============================================

INSERT INTO data_retention_policies (
    organization_id, policy_name, document_type_key, retention_period_days, 
    auto_delete, archive_before_delete, policy_rules
) 
SELECT 
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b'::uuid,
    'BFSI ' || name || ' Retention',
    type_key,
    CASE 
        WHEN retention_period = '5_years' THEN 1825
        WHEN retention_period = '7_years' THEN 2555 
        WHEN retention_period = '10_years' THEN 3650
        ELSE 2555
    END,
    false, -- Don't auto-delete by default
    true,  -- Archive before deletion
    json_build_object(
        'legal_hold_check', true,
        'approval_required', classification = 'restricted',
        'notification_days', 30
    )::jsonb
FROM bfsi_document_types
WHERE is_active = true
ON CONFLICT DO NOTHING;

-- ===============================================
-- 16. CREATE SAMPLE INTEGRATION WEBHOOKS
-- ===============================================

INSERT INTO integration_webhooks (
    organization_id, webhook_name, webhook_url, event_types, is_active
) VALUES 
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Document Processing Webhook',
    'https://api.example.com/webhooks/document-processed',
    '["document_processed", "classification_completed", "pii_detected", "compliance_check_completed"]'::jsonb,
    false -- Disabled by default
),
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Compliance Alert Webhook', 
    'https://compliance.example.com/alerts',
    '["compliance_violation", "retention_policy_triggered", "audit_required"]'::jsonb,
    false -- Disabled by default
) ON CONFLICT DO NOTHING;

-- ===============================================
-- 17. CREATE SAMPLE DOCUMENT TEMPLATES
-- ===============================================

INSERT INTO document_templates (
    organization_id, template_name, template_type, document_type_key, 
    template_content, template_variables, output_format
) VALUES 
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Loan Application Summary Report',
    'report',
    'LOAN_APPLICATION',
    '<html><body><h1>Loan Application Summary</h1><p>Applicant: {{applicant_name}}</p><p>Amount: {{loan_amount}}</p><p>Status: {{application_status}}</p></body></html>',
    '["applicant_name", "loan_amount", "application_status", "credit_score", "approval_date"]'::jsonb,
    'pdf'
),
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Compliance Audit Report',
    'compliance_document',
    NULL,
    '<html><body><h1>Compliance Audit Report</h1><p>Organization: {{org_name}}</p><p>Audit Period: {{audit_period}}</p><p>Findings: {{findings_summary}}</p></body></html>',
    '["org_name", "audit_period", "findings_summary", "compliance_score", "recommendations"]'::jsonb,
    'pdf'
) ON CONFLICT DO NOTHING;

-- ===============================================
-- 18. CREATE SAMPLE BFSI PROCESSING RULES
-- ===============================================

INSERT INTO bfsi_processing_rules (
    organization_id, rule_name, rule_type, rule_config, priority
) VALUES 
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'High-Risk Document Classification',
    'classification',
    json_build_object(
        'confidence_threshold', 0.85,
        'escalate_on_low_confidence', true,
        'required_reviewers', 2,
        'auto_classify_threshold', 0.95
    ),
    1
),
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'PII Detection for Financial Documents',
    'pii_detection',
    json_build_object(
        'enable_masking', true,
        'sensitive_entities', '["CREDIT_CARD", "SSN", "BANK_ACCOUNT", "PHONE_NUMBER"]',
        'confidence_threshold', 0.8,
        'notify_on_detection', true
    ),
    2
),
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'SOX Compliance Check',
    'compliance_check',
    json_build_object(
        'required_fields', '["document_type", "classification_level", "retention_date"]',
        'validation_rules', '{"classification_level": ["confidential", "restricted"]}',
        'auto_remediation', false
    ),
    3
) ON CONFLICT DO NOTHING;

-- ===============================================
-- 19. CREATE ADDITIONAL UTILITY FUNCTIONS
-- ===============================================

-- Function to get processing statistics
CREATE OR REPLACE FUNCTION get_processing_statistics(org_id UUID, days INTEGER DEFAULT 30)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'period_days', days,
        'total_documents', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND created_at >= CURRENT_DATE - INTERVAL '1 day' * days
        ),
        'processed_documents', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND processed_at IS NOT NULL
            AND created_at >= CURRENT_DATE - INTERVAL '1 day' * days
        ),
        'failed_documents', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND classification_status = 'failed'
            AND created_at >= CURRENT_DATE - INTERVAL '1 day' * days
        ),
        'pii_documents', (
            SELECT COUNT(*) FROM documents 
            WHERE organization_id = org_id 
            AND contains_pii = true
            AND created_at >= CURRENT_DATE - INTERVAL '1 day' * days
        ),
        'avg_processing_time', (
            SELECT AVG(EXTRACT(EPOCH FROM (processed_at - processing_start_time))) 
            FROM documents 
            WHERE organization_id = org_id 
            AND processed_at IS NOT NULL 
            AND processing_start_time IS NOT NULL
            AND created_at >= CURRENT_DATE - INTERVAL '1 day' * days
        ),
        'document_types_breakdown', (
            SELECT json_agg(
                json_build_object(
                    'document_type', COALESCE(document_type_key, 'unclassified'),
                    'count', doc_count
                )
            )
            FROM (
                SELECT 
                    document_type_key,
                    COUNT(*) as doc_count
                FROM documents 
                WHERE organization_id = org_id 
                AND created_at >= CURRENT_DATE - INTERVAL '1 day' * days
                GROUP BY document_type_key
                ORDER BY doc_count DESC
            ) breakdown
        )
    ) INTO result;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Function to cleanup old audit logs
CREATE OR REPLACE FUNCTION cleanup_old_audit_logs(retention_days INTEGER DEFAULT 365)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM audit_logs 
    WHERE created_at < CURRENT_DATE - INTERVAL '1 day' * retention_days;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function to get compliance dashboard data
CREATE OR REPLACE FUNCTION get_compliance_dashboard(org_id UUID)
RETURNS JSON AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'total_documents', (
            SELECT COUNT(*) FROM documents WHERE organization_id = org_id
        ),
        'compliance_status', (
            SELECT json_object_agg(compliance_status, status_count)
            FROM (
                SELECT 
                    COALESCE(compliance_status, 'unknown') as compliance_status,
                    COUNT(*) as status_count
                FROM documents 
                WHERE organization_id = org_id
                GROUP BY compliance_status
            ) compliance_breakdown
        ),
        'risk_distribution', (
            SELECT json_object_agg(risk_level, risk_count)
            FROM (
                SELECT 
                    CASE 
                        WHEN risk_score >= 80 THEN 'high'
                        WHEN risk_score >= 50 THEN 'medium' 
                        WHEN risk_score IS NOT NULL THEN 'low'
                        ELSE 'unassessed'
                    END as risk_level,
                    COUNT(*) as risk_count
                FROM documents 
                WHERE organization_id = org_id
                GROUP BY risk_level
            ) risk_breakdown
        ),
        'pii_summary', (
            SELECT json_build_object(
                'documents_with_pii', COUNT(DISTINCT d.id),
                'total_pii_entities', COUNT(pdr.id),
                'entity_types', json_agg(DISTINCT pdr.entity_type)
            )
            FROM documents d
            LEFT JOIN pii_detection_results pdr ON d.id = pdr.document_id
            WHERE d.organization_id = org_id AND d.contains_pii = true
        ),
        'retention_alerts', (
            SELECT COUNT(*)
            FROM documents 
            WHERE organization_id = org_id 
            AND retention_date <= CURRENT_DATE + INTERVAL '30 days'
            AND retention_date > CURRENT_DATE
        )
    ) INTO result;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- ===============================================
-- 20. CREATE SAMPLE NOTIFICATIONS
-- ===============================================

INSERT INTO notifications (
    organization_id, title, message, type, related_resource_type
) VALUES 
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Welcome to DocIntelPro BFSI',
    'Your BFSI document intelligence platform has been successfully configured with 15 document types and comprehensive compliance frameworks.',
    'success',
    'system'
),
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Database Migration Completed',
    'All required tables for DocIntelPro have been created successfully. You can now start configuring document sources and processing workflows.',
    'info',
    'system'
) ON CONFLICT DO NOTHING;

-- ===============================================
-- 21. CREATE SUMMARY VIEWS FOR MONITORING
-- ===============================================

-- View for overall system health
CREATE OR REPLACE VIEW system_health_summary AS
SELECT 
    'DocIntelPro BFSI' as system_name,
    COUNT(DISTINCT o.id) as total_organizations,
    COUNT(DISTINCT u.id) as total_users,
    COUNT(DISTINCT ds.id) as total_sources,
    COUNT(DISTINCT d.id) as total_documents,
    COUNT(CASE WHEN d.classification_status = 'classified' THEN 1 END) as processed_documents,
    COUNT(CASE WHEN d.contains_pii = true THEN 1 END) as pii_documents,
    AVG(d.classification_confidence) as avg_classification_confidence,
    COUNT(CASE WHEN d.created_at >= CURRENT_DATE THEN 1 END) as documents_today
FROM organizations o
LEFT JOIN users u ON o.id = u.organization_id
LEFT JOIN document_sources ds ON o.id = ds.organization_id  
LEFT JOIN documents d ON o.id = d.organization_id;

-- View for document processing pipeline status
CREATE OR REPLACE VIEW processing_pipeline_status AS
SELECT 
    pj.job_type,
    pj.status,
    COUNT(*) as job_count,
    AVG(pj.progress) as avg_progress,
    AVG(EXTRACT(EPOCH FROM (pj.completed_at - pj.started_at))) as avg_duration_seconds
FROM processing_jobs pj
WHERE pj.created_at >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY pj.job_type, pj.status
ORDER BY pj.job_type, pj.status;

-- ===============================================
-- 22. FINAL VERIFICATION AND CLEANUP
-- ===============================================

-- Final verification with better error handling
DO $$
DECLARE
    table_count INTEGER;
    expected_tables TEXT[] := ARRAY[
        'organizations', 'users', 'document_sources', 'documents', 'processing_jobs',
        'classification_results', 'ocr_results', 'document_vectors', 'pii_detection_results',
        'audit_logs', 'system_settings', 'api_keys', 'notifications', 'bfsi_document_types',
        'compliance_frameworks', 'bfsi_processing_rules', 'ml_models', 'service_health',
        'document_workflows', 'vector_search_indexes', 'search_queries', 'compliance_audit_trails',
        'data_retention_policies', 'deletion_queue', 'integration_webhooks', 'webhook_deliveries',
        'document_templates'
    ];
BEGIN
    SELECT COUNT(*) INTO table_count
    FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = ANY(expected_tables);
    
    RAISE NOTICE 'Created % out of % expected tables', table_count, array_length(expected_tables, 1);
    
    -- Try to log completion, but don't fail if audit_logs has issues
    BEGIN
        INSERT INTO audit_logs (action, resource_type, new_values)
        VALUES (
            'database_migration_completed',
            'system',
            json_build_object(
                'migration_script', '001_bfsi_enhancement.sql',
                'tables_created', table_count,
                'completion_time', NOW()
            )
        );
    EXCEPTION
        WHEN OTHERS THEN
            RAISE NOTICE 'Could not log to audit_logs: %', SQLERRM;
    END;
END $$;

-- ===============================================
-- MIGRATION COMPLETED SUCCESSFULLY
-- ===============================================

SELECT 
    'DocIntelPro BFSI Database Migration Completed!' as status,
    'All ' || COUNT(*) || ' tables created successfully' as message,
    NOW() as completion_time
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN (
    'organizations', 'users', 'document_sources', 'documents', 'processing_jobs',
    'classification_results', 'ocr_results', 'document_vectors', 'pii_detection_results',
    'audit_logs', 'system_settings', 'api_keys', 'notifications', 'bfsi_document_types',
    'compliance_frameworks', 'bfsi_processing_rules', 'ml_models', 'service_health',
    'document_workflows', 'vector_search_indexes', 'search_queries', 'compliance_audit_trails',
    'data_retention_policies', 'deletion_queue', 'integration_webhooks', 'webhook_deliveries',
    'document_templates'
);

-- Show next steps
SELECT 
    'Next Steps:' as action,
    '1. Run this script in PgAdmin4 on your RND PostgreSQL database' as step_1,
    '2. Configure Python environment: cd python-services && python setup_dev_environment.py' as step_2,
    '3. Start microservices: docker-compose -f docker-compose.yml up -d' as step_3,
    '4. Access dashboard at http://localhost:5173' as step_4,
    '5. Configure your first document source via the UI' as step_5;
