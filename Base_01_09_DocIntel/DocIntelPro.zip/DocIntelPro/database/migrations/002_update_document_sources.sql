-- Update document_sources table to support HR, BFSI, and Generic document types
-- This migration adds support for the new source types and document domains

-- First, let's update the type column to support new source types
ALTER TABLE document_sources 
  ALTER COLUMN type TYPE varchar(50),
  ALTER COLUMN domain TYPE varchar(50);

-- Add a comment to clarify supported types
COMMENT ON COLUMN document_sources.type IS 'Supported types: network_folder, sharepoint, database, ftp, cloud_storage, hr_documents, bfsi_documents, generic_source';
COMMENT ON COLUMN document_sources.domain IS 'Supported domains: hr, bfsi, general';

-- Update any existing records to have proper defaults
UPDATE document_sources 
SET domain = 'bfsi' 
WHERE domain IS NULL OR domain = '';

-- Ensure document_types column has proper default
ALTER TABLE document_sources 
  ALTER COLUMN document_types SET DEFAULT '[]'::jsonb;

-- Ensure connection_config has proper default
ALTER TABLE document_sources 
  ALTER COLUMN connection_config SET DEFAULT '{}'::jsonb;
