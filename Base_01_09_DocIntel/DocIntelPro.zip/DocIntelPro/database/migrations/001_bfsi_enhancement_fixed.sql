-- DocIntelPro Complete Database Schema with BFSI Enhancement - FIXED VERSION
-- Execute this in PgAdmin4 to create all required tables for the project
-- Database: RND (PostgreSQL)
-- Date: August 28, 2025
-- This version handles existing tables and foreign key conflicts

-- ===============================================
-- 0. CLEAN SETUP WITH PROPER ERROR HANDLING
-- ===============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Drop problematic constraints first
DO $$
BEGIN
    -- Drop audit_logs table if it has constraint issues
    IF EXISTS (SELECT 1 FROM information_schema.table_constraints 
               WHERE constraint_name = 'audit_logs_user_id_fkey' 
               AND table_name = 'audit_logs') THEN
        ALTER TABLE audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Constraint cleanup: %', SQLERRM;
END $$;

-- Organizations table
CREATE TABLE IF NOT EXISTS organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    domain VARCHAR(100) NOT NULL DEFAULT 'bfsi',
    industry VARCHAR(100) DEFAULT 'financial_services',
    country VARCHAR(10) DEFAULT 'US',
    settings JSONB DEFAULT '{}'::jsonb,
    subscription_plan VARCHAR(50) DEFAULT 'basic',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Handle users table - recreate with UUID if needed
DO $$
BEGIN
    -- Check if users table exists with integer id
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'users' AND column_name = 'id' AND data_type = 'integer') THEN
        -- Rename existing table
        ALTER TABLE users RENAME TO users_old;
    END IF;
    
    -- Create new users table with UUID
    CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
        username VARCHAR(100) NOT NULL UNIQUE,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        first_name VARCHAR(100),
        last_name VARCHAR(100),
        role VARCHAR(50) DEFAULT 'user',
        permissions JSONB DEFAULT '[]'::jsonb,
        last_login TIMESTAMP,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Users table setup: %', SQLERRM;
END $$;

-- Document sources table
CREATE TABLE IF NOT EXISTS document_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    connection_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    authentication_config JSONB DEFAULT '{}'::jsonb,
    scan_schedule VARCHAR(100) DEFAULT 'manual',
    last_scan TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active',
    error_message TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    domain VARCHAR(50) DEFAULT 'bfsi',
    document_types JSONB DEFAULT '[]'::jsonb,
    compliance_level VARCHAR(20) DEFAULT 'internal'
);

-- Documents table
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    source_id UUID REFERENCES document_sources(id) ON DELETE SET NULL,
    file_name VARCHAR(500) NOT NULL,
    file_path TEXT NOT NULL,
    file_size BIGINT,
    file_type VARCHAR(50),
    mime_type VARCHAR(100),
    file_hash VARCHAR(128),
    original_text TEXT,
    processed_text TEXT,
    classification_status VARCHAR(50) DEFAULT 'pending',
    classification_confidence DECIMAL(5,4),
    classification_level VARCHAR(50),
    contains_pii BOOLEAN DEFAULT false,
    pii_entities JSONB DEFAULT '[]'::jsonb,
    extraction_status VARCHAR(50) DEFAULT 'pending',
    processing_start_time TIMESTAMP,
    processed_at TIMESTAMP,
    error_message TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    document_type_key VARCHAR(100),
    compliance_status VARCHAR(50) DEFAULT 'pending',
    compliance_score DECIMAL(5,2),
    risk_score DECIMAL(5,2),
    retention_date DATE,
    regulatory_flags JSONB DEFAULT '[]'::jsonb
);

-- Processing jobs table
CREATE TABLE IF NOT EXISTS processing_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    source_id UUID REFERENCES document_sources(id) ON DELETE SET NULL,
    job_type VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    priority INTEGER DEFAULT 100,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    progress DECIMAL(5,2) DEFAULT 0.00,
    error_message TEXT,
    job_config JSONB DEFAULT '{}'::jsonb,
    result JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Classification results table
CREATE TABLE IF NOT EXISTS classification_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    classifier_name VARCHAR(100) NOT NULL,
    classification_type VARCHAR(100) NOT NULL,
    confidence DECIMAL(5,4) NOT NULL,
    classification_data JSONB DEFAULT '{}'::jsonb,
    processing_time_ms INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);

-- OCR results table
CREATE TABLE IF NOT EXISTS ocr_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    ocr_provider VARCHAR(50) NOT NULL,
    extracted_text TEXT,
    confidence DECIMAL(5,4),
    bounding_boxes JSONB DEFAULT '[]'::jsonb,
    processing_time_ms INTEGER,
    provider_response JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Document vectors table
CREATE TABLE IF NOT EXISTS document_vectors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chunk_id VARCHAR(255) NOT NULL UNIQUE,
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    embedding BYTEA,
    chunk_number INTEGER,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- PII detection results table
CREATE TABLE IF NOT EXISTS pii_detection_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    entity_type VARCHAR(100) NOT NULL,
    entity_value TEXT NOT NULL,
    start_position INTEGER,
    end_position INTEGER,
    confidence DECIMAL(5,4),
    context TEXT,
    anonymized_value TEXT,
    detection_method VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Audit log table (with safe constraint handling)
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID,
    user_id UUID,
    document_id UUID,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Add foreign key constraints safely
DO $$
BEGIN
    -- Add organization constraint
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'audit_logs_organization_id_fkey') THEN
        ALTER TABLE audit_logs ADD CONSTRAINT audit_logs_organization_id_fkey 
        FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE;
    END IF;
    
    -- Add user constraint
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'audit_logs_user_id_fkey') THEN
        ALTER TABLE audit_logs ADD CONSTRAINT audit_logs_user_id_fkey 
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;
    END IF;
    
    -- Add document constraint
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'audit_logs_document_id_fkey') THEN
        ALTER TABLE audit_logs ADD CONSTRAINT audit_logs_document_id_fkey 
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL;
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Foreign key constraint error: %', SQLERRM;
END $$;

-- System settings table
CREATE TABLE IF NOT EXISTS system_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    setting_key VARCHAR(255) NOT NULL,
    setting_value JSONB NOT NULL,
    setting_type VARCHAR(50) DEFAULT 'string',
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(organization_id, setting_key)
);

-- API keys table
CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    key_name VARCHAR(255) NOT NULL,
    key_hash VARCHAR(255) NOT NULL UNIQUE,
    key_prefix VARCHAR(20),
    permissions JSONB DEFAULT '[]'::jsonb,
    last_used TIMESTAMP,
    usage_count BIGINT DEFAULT 0,
    rate_limit INTEGER DEFAULT 1000,
    expires_at TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'info',
    is_read BOOLEAN DEFAULT false,
    related_resource_type VARCHAR(50),
    related_resource_id UUID,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ===============================================
-- BFSI SPECIFIC TABLES
-- ===============================================

-- BFSI Document Types table
CREATE TABLE IF NOT EXISTS bfsi_document_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type_key VARCHAR(100) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(100) NOT NULL,
    classification VARCHAR(20) NOT NULL DEFAULT 'internal',
    description TEXT,
    required_fields JSONB DEFAULT '[]'::jsonb,
    pii_fields JSONB DEFAULT '[]'::jsonb,
    retention_period VARCHAR(50) DEFAULT '7_years',
    compliance_flags JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Add foreign key for documents to bfsi_document_types
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name = 'documents_document_type_key_fkey') THEN
        ALTER TABLE documents ADD CONSTRAINT documents_document_type_key_fkey 
        FOREIGN KEY (document_type_key) REFERENCES bfsi_document_types(type_key);
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Document type foreign key error: %', SQLERRM;
END $$;

-- Compliance frameworks table
CREATE TABLE IF NOT EXISTS compliance_frameworks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    industry VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- BFSI processing rules table
CREATE TABLE IF NOT EXISTS bfsi_processing_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id),
    source_id UUID REFERENCES document_sources(id),
    document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
    rule_name VARCHAR(200) NOT NULL,
    rule_type VARCHAR(50) NOT NULL,
    rule_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    priority INTEGER DEFAULT 100,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===============================================
-- MICROSERVICES TABLES
-- ===============================================

-- ML Models table
CREATE TABLE IF NOT EXISTS ml_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_name VARCHAR(255) NOT NULL UNIQUE,
    model_type VARCHAR(100) NOT NULL,
    model_version VARCHAR(50) NOT NULL,
    model_path TEXT,
    model_config JSONB DEFAULT '{}'::jsonb,
    performance_metrics JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Service health table
CREATE TABLE IF NOT EXISTS service_health (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_name VARCHAR(100) NOT NULL,
    service_version VARCHAR(50),
    status VARCHAR(50) NOT NULL,
    response_time_ms INTEGER,
    cpu_usage DECIMAL(5,2),
    memory_usage DECIMAL(5,2),
    error_count INTEGER DEFAULT 0,
    dependencies JSONB DEFAULT '{}'::jsonb,
    last_check TIMESTAMP DEFAULT NOW()
);

-- Document workflows table
CREATE TABLE IF NOT EXISTS document_workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    workflow_name VARCHAR(255) NOT NULL,
    current_stage VARCHAR(100) NOT NULL,
    stages_completed JSONB DEFAULT '[]'::jsonb,
    stage_results JSONB DEFAULT '{}'::jsonb,
    total_stages INTEGER DEFAULT 0,
    progress DECIMAL(5,2) DEFAULT 0.00,
    started_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    error_stage VARCHAR(100),
    error_message TEXT
);

-- Vector search indexes table
CREATE TABLE IF NOT EXISTS vector_search_indexes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    index_name VARCHAR(255) NOT NULL UNIQUE,
    index_type VARCHAR(50) DEFAULT 'faiss',
    embedding_model VARCHAR(255) NOT NULL,
    dimension INTEGER NOT NULL,
    document_count BIGINT DEFAULT 0,
    index_size_bytes BIGINT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT NOW(),
    index_config JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true
);

-- Search queries table
CREATE TABLE IF NOT EXISTS search_queries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    query_text TEXT NOT NULL,
    search_type VARCHAR(50),
    filters JSONB DEFAULT '{}'::jsonb,
    results_count INTEGER,
    response_time_ms INTEGER,
    relevance_scores JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Compliance audit trails table
CREATE TABLE IF NOT EXISTS compliance_audit_trails (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    compliance_framework VARCHAR(100) NOT NULL,
    audit_type VARCHAR(100) NOT NULL,
    audit_result VARCHAR(50) NOT NULL,
    findings JSONB DEFAULT '[]'::jsonb,
    recommendations JSONB DEFAULT '[]'::jsonb,
    auditor_id UUID REFERENCES users(id),
    audit_date TIMESTAMP DEFAULT NOW()
);

-- Data retention policies table
CREATE TABLE IF NOT EXISTS data_retention_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    policy_name VARCHAR(255) NOT NULL,
    document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
    retention_period_days INTEGER NOT NULL,
    auto_delete BOOLEAN DEFAULT false,
    archive_before_delete BOOLEAN DEFAULT true,
    legal_hold_exception BOOLEAN DEFAULT false,
    policy_rules JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Deletion queue table
CREATE TABLE IF NOT EXISTS deletion_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    scheduled_deletion_date DATE NOT NULL,
    retention_policy_id UUID REFERENCES data_retention_policies(id),
    deletion_reason VARCHAR(255),
    legal_hold BOOLEAN DEFAULT false,
    deletion_status VARCHAR(50) DEFAULT 'scheduled',
    processed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Integration webhooks table
CREATE TABLE IF NOT EXISTS integration_webhooks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    webhook_name VARCHAR(255) NOT NULL,
    webhook_url TEXT NOT NULL,
    event_types JSONB NOT NULL DEFAULT '[]'::jsonb,
    authentication_config JSONB DEFAULT '{}'::jsonb,
    is_active BOOLEAN DEFAULT true,
    last_triggered TIMESTAMP,
    success_count BIGINT DEFAULT 0,
    failure_count BIGINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Webhook deliveries table
CREATE TABLE IF NOT EXISTS webhook_deliveries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_id UUID REFERENCES integration_webhooks(id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    delivery_status VARCHAR(50) DEFAULT 'pending',
    response_status_code INTEGER,
    response_body TEXT,
    attempt_count INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    next_retry_at TIMESTAMP,
    delivered_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Document templates table
CREATE TABLE IF NOT EXISTS document_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    template_name VARCHAR(255) NOT NULL,
    template_type VARCHAR(100) NOT NULL,
    document_type_key VARCHAR(100) REFERENCES bfsi_document_types(type_key),
    template_content TEXT NOT NULL,
    template_variables JSONB DEFAULT '[]'::jsonb,
    output_format VARCHAR(50) DEFAULT 'pdf',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ===============================================
-- INSERT SAMPLE DATA
-- ===============================================

-- Insert BFSI document types
INSERT INTO bfsi_document_types (type_key, name, category, classification, description, required_fields, pii_fields, retention_period, compliance_flags) VALUES
('LOAN_APPLICATION', 'Loan Application', 'lending', 'confidential', 'Personal and business loan applications', '["applicant_name", "loan_amount", "purpose"]'::jsonb, '["ssn", "income", "employment_details"]'::jsonb, '7_years', '["SOX", "Fair_Lending_Act"]'::jsonb),
('CREDIT_REPORT', 'Credit Report', 'lending', 'confidential', 'Credit bureau reports and scores', '["credit_score", "report_date", "bureau"]'::jsonb, '["ssn", "credit_history", "debt_information"]'::jsonb, '7_years', '["FCRA", "GLBA"]'::jsonb),
('LOAN_AGREEMENT', 'Loan Agreement', 'lending', 'confidential', 'Signed loan contracts and agreements', '["loan_amount", "interest_rate", "terms"]'::jsonb, '["borrower_info", "collateral_details"]'::jsonb, '7_years', '["SOX", "TILA"]'::jsonb),
('KYC_DOCUMENT', 'KYC Document', 'compliance', 'restricted', 'Know Your Customer verification documents', '["customer_id", "document_type", "verification_status"]'::jsonb, '["government_id", "address", "phone", "email"]'::jsonb, '5_years', '["BSA", "AML", "PATRIOT_Act"]'::jsonb),
('AML_REPORT', 'AML Report', 'compliance', 'restricted', 'Anti-Money Laundering reports and investigations', '["transaction_id", "suspicious_activity", "investigation_status"]'::jsonb, '["customer_info", "transaction_details"]'::jsonb, '5_years', '["BSA", "AML", "FinCEN"]'::jsonb),
('SAR_FILING', 'SAR Filing', 'compliance', 'confidential', 'Suspicious Activity Reports', '["filing_date", "activity_type", "amount"]'::jsonb, '["subject_info", "transaction_details"]'::jsonb, '5_years', '["BSA", "FinCEN"]'::jsonb),
('FINANCIAL_STATEMENT', 'Financial Statement', 'financial_reporting', 'internal', 'Balance sheets, income statements, cash flow', '["statement_type", "period", "prepared_by"]'::jsonb, '["financial_data"]'::jsonb, '7_years', '["SOX", "GAAP"]'::jsonb),
('AUDIT_REPORT', 'Audit Report', 'financial_reporting', 'restricted', 'Internal and external audit reports', '["audit_type", "auditor", "findings"]'::jsonb, '["financial_details"]'::jsonb, '7_years', '["SOX", "PCAOB"]'::jsonb),
('TAX_DOCUMENT', 'Tax Document', 'financial_reporting', 'confidential', 'Tax returns and related documentation', '["tax_year", "entity_type", "jurisdiction"]'::jsonb, '["tax_id", "financial_data"]'::jsonb, '7_years', '["IRS", "State_Tax"]'::jsonb),
('INSURANCE_POLICY', 'Insurance Policy', 'insurance', 'internal', 'Insurance policies and coverage details', '["policy_number", "coverage_type", "premium"]'::jsonb, '["policyholder_info", "beneficiary_info"]'::jsonb, '7_years', '["State_Insurance"]'::jsonb),
('INSURANCE_CLAIM', 'Insurance Claim', 'insurance', 'restricted', 'Insurance claims and settlements', '["claim_number", "incident_date", "claim_amount"]'::jsonb, '["claimant_info", "medical_info"]'::jsonb, '7_years', '["State_Insurance", "HIPAA"]'::jsonb),
('INVESTMENT_AGREEMENT', 'Investment Agreement', 'securities', 'confidential', 'Investment contracts and agreements', '["investment_type", "amount", "terms"]'::jsonb, '["investor_info", "financial_status"]'::jsonb, '7_years', '["SEC", "FINRA"]'::jsonb),
('PROSPECTUS', 'Prospectus', 'securities', 'public', 'Investment prospectus and offering documents', '["offering_type", "securities_details", "risks"]'::jsonb, '[]'::jsonb, '7_years', '["SEC", "Securities_Act"]'::jsonb),
('WIRE_TRANSFER', 'Wire Transfer', 'transactions', 'restricted', 'Wire transfer instructions and confirmations', '["amount", "sender", "receiver", "purpose"]'::jsonb, '["account_numbers", "customer_info"]'::jsonb, '5_years', '["BSA", "OFAC"]'::jsonb),
('TRANSACTION_RECORD', 'Transaction Record', 'transactions', 'internal', 'General transaction records and logs', '["transaction_id", "amount", "date", "type"]'::jsonb, '["account_info", "customer_info"]'::jsonb, '7_years', '["BSA", "Record_Keeping"]'::jsonb)
ON CONFLICT (type_key) DO NOTHING;

-- Insert compliance frameworks
INSERT INTO compliance_frameworks (code, name, description, industry) VALUES
('SOX', 'Sarbanes-Oxley Act', 'Financial reporting and corporate governance', 'Financial Services'),
('BSA', 'Bank Secrecy Act', 'Anti-money laundering requirements', 'Banking'),
('AML', 'Anti-Money Laundering', 'Money laundering prevention', 'Financial Services'),
('GLBA', 'Gramm-Leach-Bliley Act', 'Financial privacy protection', 'Financial Services'),
('FCRA', 'Fair Credit Reporting Act', 'Credit reporting accuracy and privacy', 'Financial Services'),
('TILA', 'Truth in Lending Act', 'Credit terms disclosure', 'Banking'),
('PATRIOT_Act', 'USA PATRIOT Act', 'Terrorism financing prevention', 'Financial Services'),
('FinCEN', 'Financial Crimes Enforcement Network', 'Financial intelligence reporting', 'Financial Services'),
('SEC', 'Securities and Exchange Commission', 'Securities regulation', 'Securities'),
('FINRA', 'Financial Industry Regulatory Authority', 'Broker-dealer regulation', 'Securities'),
('OFAC', 'Office of Foreign Assets Control', 'Economic sanctions enforcement', 'Financial Services'),
('PCAOB', 'Public Company Accounting Oversight Board', 'Audit oversight', 'Financial Services'),
('GAAP', 'Generally Accepted Accounting Principles', 'Accounting standards', 'Financial Services'),
('HIPAA', 'Health Insurance Portability and Accountability Act', 'Healthcare privacy (for insurance)', 'Healthcare/Insurance'),
('Fair_Lending_Act', 'Fair Lending Act', 'Equal credit opportunity', 'Banking'),
('Securities_Act', 'Securities Act of 1933', 'Securities registration and disclosure', 'Securities'),
('Record_Keeping', 'Record Keeping Requirements', 'Document retention obligations', 'All Industries'),
('State_Insurance', 'State Insurance Regulations', 'State-level insurance oversight', 'Insurance'),
('State_Tax', 'State Tax Regulations', 'State taxation compliance', 'All Industries'),
('IRS', 'Internal Revenue Service', 'Federal tax compliance', 'All Industries')
ON CONFLICT (code) DO NOTHING;

-- Insert ML model configurations
INSERT INTO ml_models (model_name, model_type, model_version, model_config, is_active) VALUES
('en_core_web_sm', 'ner', '3.6.0', '{"provider": "spacy", "language": "en"}'::jsonb, true),
('all-MiniLM-L6-v2', 'embedding', '1.0.0', '{"provider": "sentence-transformers", "dimension": 384}'::jsonb, true),
('distilbert-base-uncased', 'classification', '1.0.0', '{"provider": "huggingface", "task": "text-classification"}'::jsonb, true),
('paddleocr', 'ocr', '2.7.0', '{"provider": "paddleocr", "languages": ["en"], "use_gpu": false}'::jsonb, true),
('presidio-analyzer', 'ner', '2.2.0', '{"provider": "presidio", "supported_languages": ["en"]}'::jsonb, true)
ON CONFLICT (model_name) DO NOTHING;

-- Insert sample organization
INSERT INTO organizations (id, name, domain, settings) VALUES 
(
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
    'Demo BFSI Organization',
    'bfsi',
    '{"industry": "banking", "country": "US", "compliance_frameworks": ["SOX", "BSA", "AML"]}'::jsonb
) ON CONFLICT (id) DO NOTHING;

-- Insert sample user
INSERT INTO users (id, username, email, password, first_name, last_name, role, organization_id) VALUES 
(
    '3761d7a3-eace-492a-8cf2-eab83c28fd2f',
    'bfsi_admin',
    'admin@bfsidemo.com',
    '$2b$10$example_hashed_password',
    'BFSI',
    'Administrator',
    'admin',
    'f5a5744d-f922-4918-b5ae-0d9a430b9b0b'
) ON CONFLICT (id) DO NOTHING;

-- ===============================================
-- CREATE INDEXES FOR PERFORMANCE
-- ===============================================

CREATE INDEX IF NOT EXISTS idx_documents_org_id ON documents(organization_id);
CREATE INDEX IF NOT EXISTS idx_documents_source_id ON documents(source_id);
CREATE INDEX IF NOT EXISTS idx_documents_file_hash ON documents(file_hash);
CREATE INDEX IF NOT EXISTS idx_documents_classification_status ON documents(classification_status);
CREATE INDEX IF NOT EXISTS idx_documents_processed_at ON documents(processed_at);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents(created_at);
CREATE INDEX IF NOT EXISTS idx_documents_org_type_key ON documents(organization_id, document_type_key);
CREATE INDEX IF NOT EXISTS idx_documents_compliance_status ON documents(compliance_status);
CREATE INDEX IF NOT EXISTS idx_documents_classification_level ON documents(classification_level);
CREATE INDEX IF NOT EXISTS idx_documents_contains_pii ON documents(contains_pii);
CREATE INDEX IF NOT EXISTS idx_documents_retention_date ON documents(retention_date);

CREATE INDEX IF NOT EXISTS idx_processing_jobs_status ON processing_jobs(status);
CREATE INDEX IF NOT EXISTS idx_processing_jobs_org_id ON processing_jobs(organization_id);
CREATE INDEX IF NOT EXISTS idx_processing_jobs_document_id ON processing_jobs(document_id);
CREATE INDEX IF NOT EXISTS idx_processing_jobs_created_at ON processing_jobs(created_at);

CREATE INDEX IF NOT EXISTS idx_document_vectors_document_id ON document_vectors(document_id);
CREATE INDEX IF NOT EXISTS idx_document_vectors_chunk_id ON document_vectors(chunk_id);

CREATE INDEX IF NOT EXISTS idx_pii_detection_document_id ON pii_detection_results(document_id);
CREATE INDEX IF NOT EXISTS idx_pii_detection_entity_type ON pii_detection_results(entity_type);

CREATE INDEX IF NOT EXISTS idx_audit_logs_org_id ON audit_logs(organization_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);

CREATE INDEX IF NOT EXISTS idx_document_sources_org_id ON document_sources(organization_id);
CREATE INDEX IF NOT EXISTS idx_document_sources_type ON document_sources(type);
CREATE INDEX IF NOT EXISTS idx_document_sources_domain ON document_sources(domain);

CREATE INDEX IF NOT EXISTS idx_users_org_id ON users(organization_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

CREATE INDEX IF NOT EXISTS idx_bfsi_document_types_category ON bfsi_document_types(category);
CREATE INDEX IF NOT EXISTS idx_bfsi_document_types_classification ON bfsi_document_types(classification);

-- ===============================================
-- FINAL VERIFICATION
-- ===============================================

DO $$
DECLARE
    table_count INTEGER;
    expected_tables TEXT[] := ARRAY[
        'organizations', 'users', 'document_sources', 'documents', 'processing_jobs',
        'classification_results', 'ocr_results', 'document_vectors', 'pii_detection_results',
        'audit_logs', 'system_settings', 'api_keys', 'notifications', 'bfsi_document_types',
        'compliance_frameworks', 'bfsi_processing_rules', 'ml_models', 'service_health',
        'document_workflows', 'vector_search_indexes', 'search_queries', 'compliance_audit_trails',
        'data_retention_policies', 'deletion_queue', 'integration_webhooks', 'webhook_deliveries',
        'document_templates'
    ];
BEGIN
    SELECT COUNT(*) INTO table_count
    FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = ANY(expected_tables);
    
    RAISE NOTICE 'Successfully created % out of % expected tables', table_count, array_length(expected_tables, 1);
END $$;

-- Success message
SELECT 
    'DocIntelPro BFSI Database Setup Completed Successfully!' as status,
    'All tables created with proper foreign key relationships' as message,
    NOW() as completion_time;
