#!/usr/bin/env python3
"""
Enhanced Startup Script for DocIntelPro with Dynamic Port Allocation
Starts all services with automatically discovered available ports
"""

import os
import sys
import json
import time
import subprocess
import signal
from pathlib import Path
from typing import Dict, List, Optional
from workflow_engine.port_manager import PortManager


class ServiceManager:
    """Manages the startup and coordination of all DocIntelPro services"""
    
    def __init__(self):
        self.port_manager = PortManager()
        self.services = []
        self.ports = {}
        
    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        def signal_handler(signum, frame):
            print('\n🛑 Received shutdown signal, stopping all services...')
            self.stop_all_services()
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    def allocate_ports(self) -> Dict[str, int]:
        """Allocate dynamic ports for all services"""
        print('🔍 Allocating dynamic ports...')
        self.ports = self.port_manager.get_dynamic_ports()
        
        # Update configurations
        self.port_manager.update_environment(self.ports)
        self.port_manager.generate_docker_compose(self.ports)
        
        return self.ports
    
    def start_infrastructure(self) -> bool:
        """Start infrastructure services (PostgreSQL, Redis)"""
        print('🐳 Starting infrastructure services...')
        
        try:
            # Check if Docker is available
            subprocess.run(['docker', '--version'], check=True, capture_output=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            print('❌ Docker is not available. Please install Docker to run infrastructure services.')
            return False
        
        # Start infrastructure with Docker Compose
        compose_cmd = [
            'docker-compose',
            '-f', 'workflow_engine/docker-compose.yml',
            'up', '-d',
            'postgres', 'redis'
        ]
        
        try:
            result = subprocess.run(compose_cmd, check=True, capture_output=True, text=True)
            print('✅ Infrastructure services started successfully')
            return True
        except subprocess.CalledProcessError as e:
            print(f'❌ Failed to start infrastructure: {e.stderr}')
            return False
    
    def start_node_server(self) -> Optional[subprocess.Popen]:
        """Start the Node.js server with dynamic port allocation"""
        print('🟢 Starting Node.js server...')
        
        try:
            # The Node.js server will handle its own port allocation
            process = subprocess.Popen(
                ['npm', 'run', 'dev'],
                cwd=Path.cwd(),
                env=dict(os.environ, **{
                    'GATEWAY_PORT': str(self.ports['gateway']),
                    'AIRFLOW_PORT': str(self.ports['airflow'])
                })
            )
            
            # Give it a moment to start
            time.sleep(3)
            
            if process.poll() is None:
                self.services.append(('node-server', process))
                print('✅ Node.js server started successfully')
                return process
            else:
                print('❌ Node.js server failed to start')
                return None
                
        except Exception as e:
            print(f'❌ Error starting Node.js server: {e}')
            return None
    
    def start_python_gateway(self) -> Optional[subprocess.Popen]:
        """Start the FastAPI Gateway"""
        print('🔧 Starting FastAPI Gateway...')
        
        try:
            process = subprocess.Popen([
                'python', '-m', 'uvicorn',
                'gateway.main:app',
                '--host', '0.0.0.0',
                '--port', str(self.ports['gateway']),
                '--reload'
            ], cwd=Path('workflow_engine'))
            
            # Give it a moment to start
            time.sleep(2)
            
            if process.poll() is None:
                self.services.append(('gateway', process))
                print('✅ FastAPI Gateway started successfully')
                return process
            else:
                print('❌ FastAPI Gateway failed to start')
                return None
                
        except Exception as e:
            print(f'❌ Error starting FastAPI Gateway: {e}')
            return None
    
    def start_airflow(self) -> bool:
        """Start Airflow services"""
        print('⚡ Starting Airflow services...')
        
        try:
            # Start Airflow with Docker Compose
            compose_cmd = [
                'docker-compose',
                '-f', 'workflow_engine/docker-compose.yml',
                'up', '-d',
                'airflow-webserver', 'airflow-scheduler'
            ]
            
            result = subprocess.run(compose_cmd, check=True, capture_output=True, text=True)
            print('✅ Airflow services started successfully')
            return True
            
        except subprocess.CalledProcessError as e:
            print(f'❌ Failed to start Airflow: {e.stderr}')
            return False
    
    def wait_for_services(self) -> None:
        """Wait for all services to be ready"""
        print('⏳ Waiting for services to be ready...')
        
        # Check service health
        import requests
        import time
        
        max_retries = 30
        services_to_check = [
            ('Gateway', f"http://localhost:{self.ports['gateway']}/health"),
            ('Airflow', f"http://localhost:{self.ports['airflow']}/health")
        ]
        
        for service_name, url in services_to_check:
            for attempt in range(max_retries):
                try:
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        print(f'✅ {service_name} is ready')
                        break
                except:
                    if attempt < max_retries - 1:
                        time.sleep(2)
                    else:
                        print(f'⚠️ {service_name} may not be fully ready')
    
    def display_dashboard(self) -> None:
        """Display the service dashboard"""
        node_port = os.environ.get('PORT', 'dynamic')
        
        print('\n' + '🚀 DocIntelPro Platform Started Successfully!' + '\n')
        print('=' * 60)
        print(f"📊 Main Application:      http://localhost:{node_port}")
        print(f"🔧 API Gateway:           http://localhost:{self.ports['gateway']}")
        print(f"⚡ Airflow Web UI:        http://localhost:{self.ports['airflow']}")
        print(f"📖 API Documentation:    http://localhost:{self.ports['gateway']}/docs")
        print(f"💚 Health Checks:        http://localhost:{self.ports['gateway']}/health")
        print('=' * 60)
        print('💡 All services are running with dynamic port allocation')
        print('🔄 Use Ctrl+C to stop all services')
        print('📝 Port configuration saved to ports.json\n')
    
    def stop_all_services(self) -> None:
        """Stop all running services"""
        print('🛑 Stopping all services...')
        
        # Stop Python processes
        for service_name, process in self.services:
            try:
                print(f'   Stopping {service_name}...')
                process.terminate()
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
            except Exception as e:
                print(f'   Warning: Could not stop {service_name}: {e}')
        
        # Stop Docker services
        try:
            subprocess.run([
                'docker-compose',
                '-f', 'workflow_engine/docker-compose.yml',
                'down'
            ], check=True, capture_output=True)
            print('✅ All services stopped successfully')
        except subprocess.CalledProcessError as e:
            print(f'⚠️ Warning: Could not stop Docker services: {e.stderr}')
    
    def run(self) -> None:
        """Main entry point to start all services"""
        self.setup_signal_handlers()
        
        try:
            # Step 1: Allocate ports
            self.allocate_ports()
            
            # Step 2: Start infrastructure
            if not self.start_infrastructure():
                print('❌ Failed to start infrastructure services')
                return
            
            # Step 3: Start Node.js server (in background)
            node_process = self.start_node_server()
            if not node_process:
                print('❌ Failed to start Node.js server')
                return
            
            # Step 4: Start Python Gateway
            gateway_process = self.start_python_gateway()
            if not gateway_process:
                print('❌ Failed to start Python Gateway')
                return
            
            # Step 5: Start Airflow
            if not self.start_airflow():
                print('❌ Failed to start Airflow services')
                return
            
            # Step 6: Wait for services to be ready
            self.wait_for_services()
            
            # Step 7: Display dashboard
            self.display_dashboard()
            
            # Keep the script running
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
                
        except Exception as e:
            print(f'❌ Unexpected error: {e}')
        finally:
            self.stop_all_services()


def main():
    """Main function"""
    print('🔥 DocIntelPro Dynamic Startup Manager')
    print('=' * 50)
    
    service_manager = ServiceManager()
    service_manager.run()


if __name__ == '__main__':
    main()
