# Document Intelligence Platform

## Overview

A modern full-stack document processing and intelligence platform designed for enterprise environments, particularly targeting BFSI (Banking, Financial Services, and Insurance) and healthcare sectors. The system provides automated document classification, PII detection, OCR processing, and compliance monitoring with real-time WebSocket updates and multi-tenant architecture.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type-safe development
- **Vite** as the build tool for fast development and optimized production builds
- **Wouter** for lightweight client-side routing
- **Tailwind CSS** with shadcn/ui component library for consistent design system
- **TanStack Query** for server state management and caching
- **React Hook Form** with Zod validation for form handling
- Real-time updates via WebSocket connection for live processing status

### Backend Architecture
- **Express.js** server with TypeScript for API endpoints
- **Multi-tenant architecture** with organization-based data isolation
- **RESTful API design** with proper error handling and middleware
- **WebSocket service** for real-time communication between client and server
- **Modular service layer** including OpenAI integration for document classification and PII detection
- **Session-based middleware** for request logging and monitoring

### Database Layer
- **PostgreSQL** as the primary database with Neon serverless hosting
- **Drizzle ORM** for type-safe database operations and migrations
- **Multi-tenant data model** with organizations, users, document sources, and processing jobs
- **Audit logging** for compliance and tracking document processing activities
- **Connection pooling** for efficient database resource management

### AI and Processing Services
- **OpenAI GPT integration** for intelligent document classification
- **Domain-specific processing** for BFSI and healthcare document types
- **PII detection and classification** with configurable sensitivity levels
- **Document type recognition** with confidence scoring
- **Batch processing** capabilities for handling large document volumes

### Authentication and Security
- **Organization-based access control** with role-based permissions (admin, manager, analyst, viewer)
- **JWT token-based authentication** (implementation ready)
- **Secure credential management** for document source connections
- **Compliance framework** supporting GDPR, HIPAA, and PCI DSS requirements

### External Integration Architecture
- **Flexible document source connectors** supporting network folders, SharePoint, databases, FTP, and cloud storage
- **Configurable connection management** with encrypted credential storage
- **Source-specific processing rules** and document type mapping
- **Scheduled synchronization** with last sync tracking

## External Dependencies

### Database Services
- **Neon PostgreSQL** - Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit** - Database migration and schema management tools

### AI and Machine Learning
- **OpenAI API** - GPT models for document classification, PII detection, and content analysis
- **Document processing models** - Configured for BFSI and healthcare domain expertise

### UI and Component Libraries
- **Radix UI** - Comprehensive set of accessible, unstyled React components including dialogs, dropdowns, navigation menus, form controls, and data display components
- **Lucide React** - Modern icon library for consistent iconography
- **Class Variance Authority** - Type-safe CSS class composition utilities

### Development and Build Tools
- **TypeScript** - Static type checking and enhanced developer experience
- **Vite** - Fast build tool with HMR and optimized production builds
- **ESBuild** - Fast JavaScript bundler for server-side code
- **Tailwind CSS** - Utility-first CSS framework with custom design tokens

### Real-time Communication
- **WebSocket (ws)** - Real-time bidirectional communication for processing updates
- **Custom WebSocket service** - Organized by tenant with message routing and connection management

### Form and Validation
- **React Hook Form** - Performant form library with minimal re-renders
- **Zod** - Schema validation for type-safe form handling and API validation
- **Hookform Resolvers** - Integration between React Hook Form and Zod schemas

### Date and Utility Libraries
- **Date-fns** - Modern date utility library for formatting and manipulation
- **clsx** and **tailwind-merge** - Conditional CSS class composition utilities