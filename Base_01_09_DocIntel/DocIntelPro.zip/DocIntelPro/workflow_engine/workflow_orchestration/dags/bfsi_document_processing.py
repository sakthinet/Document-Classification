"""
Apache Airflow DAGs for DocIntelPro BFSI Document Processing.
Python-native workflow orchestration with enhanced processing pipeline.
"""

import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.dummy import DummyOperator
from airflow.sensors.filesystem import FileSensor
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import Variable
from airflow.utils.dates import days_ago
from airflow.utils.task_group import TaskGroup
import structlog

# Configure logging
logger = structlog.get_logger(__name__)

# DAG Configuration
DEFAULT_ARGS = {
    'owner': 'docintel-pro',
    'depends_on_past': False,
    'start_date': days_ago(1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'max_active_runs': 5,
}

# BFSI Document Processing Pipeline DAG
bfsi_processing_dag = DAG(
    'bfsi_document_processing_pipeline',
    default_args=DEFAULT_ARGS,
    description='BFSI Document Intelligence Processing Pipeline',
    schedule_interval='@daily',  # Can be configured per organization
    catchup=False,
    max_active_runs=3,
    tags=['bfsi', 'document-processing', 'ml', 'compliance'],
)


def get_pending_documents(**context) -> List[Dict[str, Any]]:
    """
    Get pending documents from PostgreSQL database.
    
    Returns:
        List of document dictionaries to process
    """
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    
    # Query for pending documents
    sql = """
    SELECT 
        d.id,
        d.organization_id,
        d.filename,
        d.file_path,
        d.file_size,
        d.mime_type,
        d.file_hash,
        d.classification,
        d.bfsi_document_type,
        d.metadata,
        o.name as organization_name,
        o.tenant_id
    FROM documents d
    JOIN organizations o ON d.organization_id = o.id
    LEFT JOIN processing_jobs pj ON d.id = pj.document_id 
        AND pj.status IN ('pending', 'in_progress', 'processing')
    WHERE pj.id IS NULL  -- No active processing jobs
        AND d.classification IS NULL  -- Not yet classified
        AND o.is_active = true
    ORDER BY d.created_at
    LIMIT 100;
    """
    
    records = pg_hook.get_records(sql)
    columns = [desc[0] for desc in pg_hook.get_conn().cursor().description]
    
    documents = []
    for record in records:
        doc = dict(zip(columns, record))
        documents.append(doc)
    
    logger.info("Retrieved pending documents", count=len(documents))
    return documents


def create_processing_jobs(documents: List[Dict[str, Any]], **context) -> List[str]:
    """
    Create processing jobs for documents.
    
    Args:
        documents: List of documents to process
        
    Returns:
        List of job IDs created
    """
    if not documents:
        logger.info("No documents to process")
        return []
    
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    job_ids = []
    
    for doc in documents:
        # Create processing job
        sql = """
        INSERT INTO processing_jobs (
            organization_id, document_id, created_by, job_type, 
            status, priority, parameters
        ) VALUES (
            %(organization_id)s, %(document_id)s, %(created_by)s, 
            'document_processing', 'pending', 5, %(parameters)s
        ) RETURNING id;
        """
        
        parameters = {
            'document_path': doc['file_path'],
            'document_type': doc['bfsi_document_type'],
            'pipeline_steps': ['ingestion', 'ocr', 'classification', 'compliance', 'output'],
            'organization_config': doc['metadata'].get('organization_config', {})
        }
        
        result = pg_hook.get_first(sql, parameters={
            'organization_id': doc['organization_id'],
            'document_id': doc['id'],
            'created_by': '3761d7a3-eace-492a-8cf2-eab83c28fd2f',  # System user
            'parameters': parameters
        })
        
        if result:
            job_ids.append(str(result[0]))
    
    logger.info("Created processing jobs", count=len(job_ids))
    return job_ids


def ingestion_worker(job_id: str, **context) -> Dict[str, Any]:
    """
    Document ingestion worker - validates and prepares documents.
    
    Args:
        job_id: Processing job ID
        
    Returns:
        Processing results
    """
    import aiofiles
    import hashlib
    import mimetypes
    from pathlib import Path
    
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    
    # Get job details
    sql = """
    SELECT pj.*, d.file_path, d.filename, d.file_size, d.mime_type
    FROM processing_jobs pj
    JOIN documents d ON pj.document_id = d.id
    WHERE pj.id = %s;
    """
    
    job_data = pg_hook.get_first(sql, parameters=[job_id])
    if not job_data:
        raise ValueError(f"Job {job_id} not found")
    
    file_path = job_data[7]  # d.file_path
    
    # Validate file exists and is readable
    if not Path(file_path).exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    # Verify file integrity
    with open(file_path, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    
    # Update job status
    pg_hook.run("""
        UPDATE processing_jobs 
        SET status = 'in_progress', 
            started_at = NOW(),
            progress = 20.0,
            result_data = %s
        WHERE id = %s;
    """, parameters=[
        {'ingestion': {'status': 'completed', 'file_hash': file_hash}},
        job_id
    ])
    
    logger.info("Ingestion completed", job_id=job_id, file_path=file_path)
    return {'status': 'completed', 'file_hash': file_hash}


def ocr_ai_worker(job_id: str, **context) -> Dict[str, Any]:
    """
    OCR & AI extraction worker - extracts text and metadata.
    
    Args:
        job_id: Processing job ID
        
    Returns:
        Extracted text and metadata
    """
    import cv2
    import numpy as np
    from PIL import Image
    import pytesseract
    # import paddleocr  # Uncomment when PaddleOCR is installed
    
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    
    # Get job and document details
    sql = """
    SELECT pj.*, d.file_path, d.mime_type, d.filename
    FROM processing_jobs pj
    JOIN documents d ON pj.document_id = d.id
    WHERE pj.id = %s;
    """
    
    job_data = pg_hook.get_first(sql, parameters=[job_id])
    file_path = job_data[7]
    mime_type = job_data[8]
    
    extracted_text = ""
    metadata = {}
    
    try:
        if mime_type.startswith('image/'):
            # Image OCR processing
            image = cv2.imread(file_path)
            
            # Preprocess image for better OCR
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            denoised = cv2.fastNlMeansDenoising(gray)
            
            # Extract text using Tesseract
            extracted_text = pytesseract.image_to_string(denoised)
            
            # Get additional metadata
            data = pytesseract.image_to_data(denoised, output_type=pytesseract.Output.DICT)
            confidence_scores = [int(conf) for conf in data['conf'] if int(conf) > 0]
            avg_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0
            
            metadata = {
                'ocr_confidence': avg_confidence,
                'text_blocks': len([text for text in data['text'] if text.strip()]),
                'image_dimensions': {'width': image.shape[1], 'height': image.shape[0]}
            }
            
        elif mime_type == 'application/pdf':
            # PDF processing (would use PyPDF2 or similar)
            extracted_text = "PDF processing not implemented in demo"
            metadata = {'pages': 1}
            
        else:
            extracted_text = "Unsupported file type for OCR"
            metadata = {'supported': False}
        
        # Update document with extracted text
        pg_hook.run("""
            UPDATE documents 
            SET extracted_text = %s,
                metadata = metadata || %s
            WHERE id = (SELECT document_id FROM processing_jobs WHERE id = %s);
        """, parameters=[extracted_text, metadata, job_id])
        
        # Update job progress
        pg_hook.run("""
            UPDATE processing_jobs 
            SET progress = 50.0,
                result_data = result_data || %s
            WHERE id = %s;
        """, parameters=[
            {'ocr': {'status': 'completed', 'text_length': len(extracted_text), 'metadata': metadata}},
            job_id
        ])
        
        logger.info("OCR completed", job_id=job_id, text_length=len(extracted_text))
        return {'status': 'completed', 'extracted_text': extracted_text, 'metadata': metadata}
        
    except Exception as e:
        logger.error("OCR failed", job_id=job_id, error=str(e))
        pg_hook.run("""
            UPDATE processing_jobs 
            SET status = 'failed',
                error_message = %s
            WHERE id = %s;
        """, parameters=[str(e), job_id])
        raise


def classification_worker(job_id: str, **context) -> Dict[str, Any]:
    """
    AI Classification worker - classifies documents using ML models.
    
    Args:
        job_id: Processing job ID
        
    Returns:
        Classification results
    """
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.naive_bayes import MultinomialNB
    import numpy as np
    
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    
    # Get document text
    sql = """
    SELECT d.extracted_text, d.filename, d.metadata, pj.parameters
    FROM processing_jobs pj
    JOIN documents d ON pj.document_id = d.id
    WHERE pj.id = %s;
    """
    
    job_data = pg_hook.get_first(sql, parameters=[job_id])
    extracted_text = job_data[0] or ""
    filename = job_data[1]
    
    # Simple classification logic (in production, use trained models)
    classification = "internal"  # Default
    bfsi_document_type = "financial_statement"  # Default
    confidence = 0.75
    
    # Rule-based classification for demo
    text_lower = extracted_text.lower()
    filename_lower = filename.lower()
    
    # BFSI Document Type Classification
    if any(term in text_lower for term in ['loan', 'credit', 'borrower']):
        bfsi_document_type = "loan_application"
    elif any(term in text_lower for term in ['kyc', 'know your customer', 'identity']):
        bfsi_document_type = "kyc_document"
    elif any(term in text_lower for term in ['balance sheet', 'income statement', 'financial']):
        bfsi_document_type = "financial_statement"
    elif any(term in text_lower for term in ['compliance', 'regulatory', 'audit']):
        bfsi_document_type = "compliance_report"
    elif any(term in text_lower for term in ['insurance', 'claim', 'policy']):
        bfsi_document_type = "insurance_claim"
    
    # Security Classification
    if any(term in text_lower for term in ['confidential', 'secret', 'private']):
        classification = "confidential"
    elif any(term in text_lower for term in ['restricted', 'internal use']):
        classification = "restricted"
    elif any(term in text_lower for term in ['public', 'external']):
        classification = "public"
    
    # Update document classification
    pg_hook.run("""
        UPDATE documents 
        SET classification = %s,
            bfsi_document_type = %s,
            metadata = metadata || %s
        WHERE id = (SELECT document_id FROM processing_jobs WHERE id = %s);
    """, parameters=[
        classification,
        bfsi_document_type,
        {'classification_confidence': confidence, 'auto_classified': True},
        job_id
    ])
    
    # Update job progress
    pg_hook.run("""
        UPDATE processing_jobs 
        SET progress = 75.0,
            result_data = result_data || %s
        WHERE id = %s;
    """, parameters=[
        {
            'classification': {
                'status': 'completed',
                'classification': classification,
                'bfsi_type': bfsi_document_type,
                'confidence': confidence
            }
        },
        job_id
    ])
    
    logger.info("Classification completed", job_id=job_id, 
                classification=classification, bfsi_type=bfsi_document_type)
    
    return {
        'status': 'completed',
        'classification': classification,
        'bfsi_document_type': bfsi_document_type,
        'confidence': confidence
    }


def compliance_check_worker(job_id: str, **context) -> Dict[str, Any]:
    """
    Compliance check worker - validates against regulatory frameworks.
    
    Args:
        job_id: Processing job ID
        
    Returns:
        Compliance check results
    """
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    
    # Get document and classification info
    sql = """
    SELECT d.classification, d.bfsi_document_type, d.metadata, 
           o.industry, o.settings
    FROM processing_jobs pj
    JOIN documents d ON pj.document_id = d.id
    JOIN organizations o ON d.organization_id = o.id
    WHERE pj.id = %s;
    """
    
    job_data = pg_hook.get_first(sql, parameters=[job_id])
    classification = job_data[0]
    bfsi_type = job_data[1]
    org_settings = job_data[4] or {}
    
    # Compliance framework mapping
    compliance_frameworks = {
        'loan_application': ['sox', 'aml_bsa', 'glba'],
        'kyc_document': ['aml_bsa', 'gdpr', 'ccpa'],
        'financial_statement': ['sox', 'basel_iii', 'coso'],
        'compliance_report': ['sox', 'coso', 'nist'],
        'insurance_claim': ['nist', 'gdpr']
    }
    
    applicable_frameworks = compliance_frameworks.get(bfsi_type, ['nist'])
    
    # Simulate compliance checks
    compliance_results = {}
    overall_compliant = True
    
    for framework in applicable_frameworks:
        # In production, this would run actual compliance validation
        compliance_score = np.random.uniform(0.85, 0.98)  # Demo scores
        is_compliant = compliance_score >= 0.90
        
        compliance_results[framework] = {
            'compliant': is_compliant,
            'score': compliance_score,
            'checked_at': datetime.utcnow().isoformat(),
            'requirements_met': ['data_encryption', 'access_control', 'audit_trail']
        }
        
        if not is_compliant:
            overall_compliant = False
    
    # Update job progress and complete
    pg_hook.run("""
        UPDATE processing_jobs 
        SET progress = 100.0,
            status = 'completed',
            completed_at = NOW(),
            result_data = result_data || %s
        WHERE id = %s;
    """, parameters=[
        {
            'compliance': {
                'status': 'completed',
                'overall_compliant': overall_compliant,
                'frameworks': compliance_results
            }
        },
        job_id
    ])
    
    logger.info("Compliance check completed", job_id=job_id, 
                compliant=overall_compliant, frameworks=applicable_frameworks)
    
    return {
        'status': 'completed',
        'overall_compliant': overall_compliant,
        'frameworks': compliance_results
    }


def output_routing_worker(job_id: str, **context) -> Dict[str, Any]:
    """
    Output routing worker - routes documents to appropriate storage.
    
    Args:
        job_id: Processing job ID
        
    Returns:
        Routing results
    """
    pg_hook = PostgresHook(postgres_conn_id='docintel_postgres')
    
    # Get final document info
    sql = """
    SELECT d.classification, d.file_path, d.filename, o.tenant_id
    FROM processing_jobs pj
    JOIN documents d ON pj.document_id = d.id
    JOIN organizations o ON d.organization_id = o.id
    WHERE pj.id = %s;
    """
    
    job_data = pg_hook.get_first(sql, parameters=[job_id])
    classification = job_data[0]
    file_path = job_data[1]
    filename = job_data[2]
    tenant_id = job_data[3]
    
    # Routing logic based on classification
    storage_locations = []
    
    if classification == 'confidential':
        storage_locations = ['local_nas_encrypted']
    elif classification == 'restricted':
        storage_locations = ['local_nas_encrypted', 'cloud_backup_encrypted']
    elif classification == 'internal':
        storage_locations = ['local_nas', 'cloud_selective_sync']
    elif classification == 'public':
        storage_locations = ['local_nas', 'cloud_full_sync', 'cdn']
    
    # Simulate document routing
    routing_results = {}
    for location in storage_locations:
        # In production, this would actually move/copy files
        routing_results[location] = {
            'status': 'completed',
            'path': f"/{location}/{tenant_id}/{filename}",
            'completed_at': datetime.utcnow().isoformat()
        }
    
    # Log audit event
    pg_hook.run("""
        INSERT INTO audit_logs (
            organization_id, event_type, resource_type, resource_id,
            action, details
        ) SELECT 
            d.organization_id, 'document_classification', 'document', d.id::text,
            'automated_processing_completed', %s
        FROM processing_jobs pj
        JOIN documents d ON pj.document_id = d.id
        WHERE pj.id = %s;
    """, parameters=[
        {
            'classification': classification,
            'storage_locations': storage_locations,
            'processing_completed': True
        },
        job_id
    ])
    
    logger.info("Output routing completed", job_id=job_id, 
                classification=classification, locations=storage_locations)
    
    return {
        'status': 'completed',
        'classification': classification,
        'storage_locations': storage_locations,
        'routing_results': routing_results
    }


# Task definitions
with bfsi_processing_dag:
    
    # Start of pipeline
    start_task = DummyOperator(
        task_id='start_pipeline',
        doc_md="Start of BFSI document processing pipeline"
    )
    
    # Get pending documents
    get_documents_task = PythonOperator(
        task_id='get_pending_documents',
        python_callable=get_pending_documents,
        doc_md="Retrieve pending documents from database"
    )
    
    # Create processing jobs
    create_jobs_task = PythonOperator(
        task_id='create_processing_jobs',
        python_callable=create_processing_jobs,
        op_args=["{{ ti.xcom_pull(task_ids='get_pending_documents') }}"],
        doc_md="Create processing jobs for pending documents"
    )
    
    # Processing pipeline with task groups
    with TaskGroup("document_processing_pipeline") as processing_group:
        
        # Ingestion stage
        ingestion_task = PythonOperator(
            task_id='ingestion_worker',
            python_callable=ingestion_worker,
            op_args=["{{ ti.xcom_pull(task_ids='create_processing_jobs')[0] }}"],
            doc_md="Document ingestion and validation"
        )
        
        # OCR & AI extraction stage
        ocr_task = PythonOperator(
            task_id='ocr_ai_worker',
            python_callable=ocr_ai_worker,
            op_args=["{{ ti.xcom_pull(task_ids='create_processing_jobs')[0] }}"],
            doc_md="OCR and AI text extraction"
        )
        
        # Classification stage
        classification_task = PythonOperator(
            task_id='classification_worker',
            python_callable=classification_worker,
            op_args=["{{ ti.xcom_pull(task_ids='create_processing_jobs')[0] }}"],
            doc_md="AI-powered document classification"
        )
        
        # Compliance check stage
        compliance_task = PythonOperator(
            task_id='compliance_check_worker',
            python_callable=compliance_check_worker,
            op_args=["{{ ti.xcom_pull(task_ids='create_processing_jobs')[0] }}"],
            doc_md="Regulatory compliance validation"
        )
        
        # Output routing stage
        output_task = PythonOperator(
            task_id='output_routing_worker',
            python_callable=output_routing_worker,
            op_args=["{{ ti.xcom_pull(task_ids='create_processing_jobs')[0] }}"],
            doc_md="Intelligent document routing"
        )
        
        # Define processing pipeline dependencies
        ingestion_task >> ocr_task >> classification_task >> compliance_task >> output_task
    
    # End of pipeline
    end_task = DummyOperator(
        task_id='end_pipeline',
        doc_md="End of BFSI document processing pipeline"
    )
    
    # Pipeline dependencies
    start_task >> get_documents_task >> create_jobs_task >> processing_group >> end_task


# Real-time processing DAG for urgent documents
realtime_processing_dag = DAG(
    'bfsi_realtime_document_processing',
    default_args=DEFAULT_ARGS,
    description='Real-time BFSI Document Processing for Urgent Documents',
    schedule_interval=None,  # Triggered manually or by external systems
    catchup=False,
    max_active_runs=10,
    tags=['bfsi', 'realtime', 'urgent', 'document-processing'],
)

# The real-time DAG would have similar tasks but optimized for speed
# and would be triggered by external events (file uploads, API calls, etc.)


if __name__ == "__main__":
    # This allows testing the functions independently
    print("DocIntelPro BFSI Airflow DAGs loaded successfully")
    print(f"Main DAG: {bfsi_processing_dag.dag_id}")
    print(f"Real-time DAG: {realtime_processing_dag.dag_id}")
