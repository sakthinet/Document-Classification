"""
Airflow configuration for DocIntelPro BFSI Platform.
Custom configuration to ensure proper port and settings.
"""

import os
from airflow import configuration as conf

# Set custom Airflow configuration
def configure_airflow():
    """Configure Airflow with custom settings."""
    
    # Webserver configuration
    conf.set('webserver', 'web_server_port', '8083')
    conf.set('webserver', 'base_url', 'http://localhost:8083')
    conf.set('webserver', 'secret_key', os.getenv('AIRFLOW__WEBSERVER__SECRET_KEY', 'your-secret-key-here'))
    
    # Core configuration
    conf.set('core', 'dags_folder', '/opt/airflow/dags')
    conf.set('core', 'load_examples', 'False')
    conf.set('core', 'dags_are_paused_at_creation', 'True')
    conf.set('core', 'executor', 'LocalExecutor')
    
    # Database configuration
    db_url = os.getenv(
        'AIRFLOW__DATABASE__SQL_ALCHEMY_CONN',
        'postgresql+psycopg2://postgres:RND_Admin123!@postgres:5432/docintel_pro_rnd'
    )
    conf.set('database', 'sql_alchemy_conn', db_url)
    
    # Logging configuration
    conf.set('logging', 'logging_level', 'INFO')
    conf.set('logging', 'fab_logging_level', 'WARN')
    
    # Scheduler configuration
    conf.set('scheduler', 'dag_dir_list_interval', '30')
    conf.set('scheduler', 'catchup_by_default', 'False')
    
    print("✓ Airflow configured for DocIntelPro on port 8083")

if __name__ == "__main__":
    configure_airflow()
