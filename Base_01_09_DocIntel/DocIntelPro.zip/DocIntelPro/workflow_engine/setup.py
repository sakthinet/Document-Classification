#!/usr/bin/env python3
"""
Setup script for DocIntelPro Python Services.
Initializes the environment and starts all services.
"""

import os
import sys
import subprocess
import asyncio
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DocIntelProSetup:
    """Setup and management for DocIntelPro Python services."""
    
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.services = [
            'gateway',
            'workers', 
            'airflow-webserver',
            'airflow-scheduler'
        ]
    
    def check_prerequisites(self):
        """Check if required tools are installed."""
        logger.info("Checking prerequisites...")
        
        required_tools = ['docker', 'docker-compose', 'python3']
        missing_tools = []
        
        for tool in required_tools:
            try:
                subprocess.run([tool, '--version'], check=True, capture_output=True)
                logger.info(f"✓ {tool} is available")
            except (subprocess.CalledProcessError, FileNotFoundError):
                missing_tools.append(tool)
                logger.error(f"✗ {tool} is not available")
        
        if missing_tools:
            logger.error(f"Missing required tools: {', '.join(missing_tools)}")
            sys.exit(1)
        
        logger.info("All prerequisites satisfied")
    
    def setup_environment(self):
        """Set up environment variables."""
        logger.info("Setting up environment...")
        
        env_file = self.project_root / '.env'
        if not env_file.exists():
            env_content = """
# Database Configuration
DATABASE_URL=postgresql+asyncpg://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd
DB_ECHO=false
DB_POOL_SIZE=20
DB_MAX_OVERFLOW=30

# Redis Configuration
REDIS_URL=redis://localhost:6379
CELERY_BROKER_URL=redis://localhost:6379
CELERY_RESULT_BACKEND=redis://localhost:6379

# Gateway Configuration
GATEWAY_HOST=0.0.0.0
GATEWAY_PORT=8000
DEBUG=true
CORS_ORIGINS=http://localhost:3000,http://localhost:5000
JWT_SECRET=your-secret-key-change-in-production

# Service URLs
USER_SERVICE_URL=http://localhost:8001
PROCESSING_SERVICE_URL=http://localhost:8002
ANALYTICS_SERVICE_URL=http://localhost:8003
WORKFLOW_SERVICE_URL=http://localhost:8004
AIRFLOW_SERVICE_URL=http://localhost:8083

# Airflow Configuration
AIRFLOW__CORE__EXECUTOR=LocalExecutor
AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=postgresql+psycopg2://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd
AIRFLOW__CORE__FERNET_KEY=your-fernet-key-here
AIRFLOW__WEBSERVER__SECRET_KEY=your-secret-key-here
AIRFLOW__CORE__DAGS_ARE_PAUSED_AT_CREATION=true
AIRFLOW__CORE__LOAD_EXAMPLES=false
AIRFLOW__WEBSERVER__WEB_SERVER_PORT=8083

# Processing Configuration
MAX_FILE_SIZE=104857600
PROCESSING_PATH=/data/processing
QUARANTINE_PATH=/data/quarantine
BACKUP_PATH=/data/backup

# AI/ML Configuration
ENABLE_GPU=false
MODEL_CACHE_DIR=/models/cache
CONFIDENCE_THRESHOLD=60.0
"""
            with open(env_file, 'w') as f:
                f.write(env_content.strip())
            logger.info("Created .env file with default configuration")
        else:
            logger.info(".env file already exists")
    
    def create_directories(self):
        """Create necessary directories."""
        logger.info("Creating directories...")
        
        directories = [
            'data/processing',
            'data/quarantine', 
            'data/backup',
            'data/models/cache',
            'logs',
            'workflow_orchestration/logs'
        ]
        
        for directory in directories:
            dir_path = self.project_root / directory
            dir_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"Created directory: {directory}")
    
    def install_dependencies(self):
        """Install Python dependencies."""
        logger.info("Installing Python dependencies...")
        
        try:
            subprocess.run([
                sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'
            ], check=True, cwd=self.project_root)
            logger.info("✓ Python dependencies installed")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to install dependencies: {e}")
            sys.exit(1)
    
    def start_database(self):
        """Start PostgreSQL and Redis using Docker."""
        logger.info("Starting database services...")
        
        try:
            subprocess.run([
                'docker-compose', 'up', '-d', 'postgres', 'redis'
            ], check=True, cwd=self.project_root)
            logger.info("✓ Database services started")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to start database services: {e}")
            sys.exit(1)
    
    async def initialize_database(self):
        """Initialize database tables."""
        logger.info("Initializing database...")
        
        try:
            # Import database initialization
            sys.path.append(str(self.project_root / 'shared'))
            from database import init_db
            
            await init_db()
            logger.info("✓ Database initialized")
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            # Don't exit here, as database might already be initialized
    
    def start_services(self):
        """Start all Python services."""
        logger.info("Starting Python services...")
        
        try:
            subprocess.run([
                'docker-compose', 'up', '-d'
            ], check=True, cwd=self.project_root)
            logger.info("✓ All services started")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to start services: {e}")
            sys.exit(1)
    
    def show_status(self):
        """Show status of all services."""
        logger.info("Service status:")
        
        try:
            result = subprocess.run([
                'docker-compose', 'ps'
            ], capture_output=True, text=True, cwd=self.project_root)
            print(result.stdout)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get service status: {e}")
    
    def show_logs(self, service=None):
        """Show logs for services."""
        if service:
            logger.info(f"Showing logs for {service}...")
            cmd = ['docker-compose', 'logs', '-f', service]
        else:
            logger.info("Showing logs for all services...")
            cmd = ['docker-compose', 'logs', '-f']
        
        try:
            subprocess.run(cmd, cwd=self.project_root)
        except KeyboardInterrupt:
            logger.info("Log viewing stopped")
    
    def stop_services(self):
        """Stop all services."""
        logger.info("Stopping services...")
        
        try:
            subprocess.run([
                'docker-compose', 'down'
            ], check=True, cwd=self.project_root)
            logger.info("✓ All services stopped")
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to stop services: {e}")
    
    async def setup_complete_environment(self):
        """Complete setup process."""
        logger.info("Starting DocIntelPro Python Services setup...")
        
        self.check_prerequisites()
        self.setup_environment()
        self.create_directories()
        self.install_dependencies()
        self.start_database()
        
        # Wait a bit for database to be ready
        import time
        logger.info("Waiting for database to be ready...")
        time.sleep(10)
        
        await self.initialize_database()
        self.start_services()
        
        logger.info("✓ Setup completed successfully!")
        logger.info("")
        logger.info("Services available at:")
        logger.info("  - FastAPI Gateway: http://localhost:8000")
        logger.info("  - Apache Airflow: http://localhost:8083 (admin/admin)")
        logger.info("  - API Documentation: http://localhost:8000/docs")
        logger.info("")
        logger.info("Use 'python setup.py status' to check service status")
        logger.info("Use 'python setup.py logs' to view logs")
        logger.info("Use 'python setup.py stop' to stop all services")


async def main():
    """Main setup function."""
    setup = DocIntelProSetup()
    
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'setup':
            await setup.setup_complete_environment()
        elif command == 'start':
            setup.start_services()
        elif command == 'stop':
            setup.stop_services()
        elif command == 'status':
            setup.show_status()
        elif command == 'logs':
            service = sys.argv[2] if len(sys.argv) > 2 else None
            setup.show_logs(service)
        elif command == 'db-init':
            await setup.initialize_database()
        else:
            print("Available commands:")
            print("  setup    - Complete environment setup")
            print("  start    - Start all services")
            print("  stop     - Stop all services") 
            print("  status   - Show service status")
            print("  logs     - Show service logs")
            print("  db-init  - Initialize database")
    else:
        await setup.setup_complete_environment()


if __name__ == "__main__":
    asyncio.run(main())
