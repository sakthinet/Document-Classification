"""
Shared Pydantic models for DocIntelPro BFSI platform.
Common data structures used across all Python services.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Union
from uuid import UUID
from pydantic import BaseModel, Field, ConfigDict


class TimestampMixin:
    """Base mixin for models with timestamps."""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class BfsiDocumentType(str, Enum):
    """BFSI Document Types Enumeration."""
    LOAN_APPLICATION = "loan_application"
    KYC_DOCUMENT = "kyc_document"
    FINANCIAL_STATEMENT = "financial_statement"
    COMPLIANCE_REPORT = "compliance_report"
    INSURANCE_CLAIM = "insurance_claim"
    CREDIT_REPORT = "credit_report"
    AUDIT_REPORT = "audit_report"
    REGULATORY_FILING = "regulatory_filing"
    RISK_ASSESSMENT = "risk_assessment"
    CUSTOMER_ONBOARDING = "customer_onboarding"


class DocumentClassification(str, Enum):
    """Document Classification Levels."""
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    INTERNAL = "internal"
    PUBLIC = "public"


class ProcessingStatus(str, Enum):
    """Document Processing Status."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ComplianceFramework(str, Enum):
    """Compliance Framework Types."""
    SOX = "sox"
    AML_BSA = "aml_bsa"
    PCI_DSS = "pci_dss"
    GLBA = "glba"
    GDPR = "gdpr"
    CCPA = "ccpa"
    BASEL_III = "basel_iii"
    COSO = "coso"
    NIST = "nist"


# Organization Models
class OrganizationBase(BaseModel):
    """Base organization model."""
    name: str = Field(..., min_length=1, max_length=255)
    domain: str = Field(..., min_length=1, max_length=100)
    industry: str = Field(..., min_length=1, max_length=100)
    tenant_id: str = Field(..., min_length=1, max_length=100)
    is_active: bool = True
    settings: Dict[str, Any] = Field(default_factory=dict)


class OrganizationCreate(OrganizationBase):
    """Organization creation model."""
    pass


class OrganizationUpdate(BaseModel):
    """Organization update model."""
    name: Optional[str] = None
    domain: Optional[str] = None
    industry: Optional[str] = None
    is_active: Optional[bool] = None
    settings: Optional[Dict[str, Any]] = None


class Organization(OrganizationBase):
    """Complete organization model."""
    model_config = ConfigDict(from_attributes=True)
    
    id: UUID
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    
# User Models
class UserRole(str, Enum):
    """User Role Types."""
    ADMIN = "admin"
    MANAGER = "manager"
    ANALYST = "analyst"
    VIEWER = "viewer"
    AUDITOR = "auditor"


class UserBase(BaseModel):
    """Base user model."""
    email: str = Field(..., min_length=1, max_length=255)
    full_name: str = Field(..., min_length=1, max_length=255)
    role: UserRole
    department: Optional[str] = None
    is_active: bool = True


class UserCreate(UserBase):
    """User creation model."""
    password: str = Field(..., min_length=8)
    organization_id: UUID


class UserUpdate(BaseModel):
    """User update model."""
    email: Optional[str] = None
    full_name: Optional[str] = None
    role: Optional[UserRole] = None
    department: Optional[str] = None
    is_active: Optional[bool] = None


class User(UserBase):
    """Complete user model."""
    model_config = ConfigDict(from_attributes=True)
    
    id: UUID
    organization_id: UUID
    last_login: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Document Source Models
class DocumentSourceType(str, Enum):
    """Document Source Types."""
    LOCAL_FOLDER = "local_folder"
    NETWORK_SHARE = "network_share"
    EMAIL_INTEGRATION = "email_integration"
    API_ENDPOINT = "api_endpoint"
    CLOUD_STORAGE = "cloud_storage"
    DATABASE_CONNECTOR = "database_connector"


class DocumentSourceBase(BaseModel):
    """Base document source model."""
    name: str = Field(..., min_length=1, max_length=255)
    source_type: DocumentSourceType
    connection_config: Dict[str, Any]
    is_active: bool = True
    sync_schedule: Optional[str] = None  # Cron expression


class DocumentSourceCreate(DocumentSourceBase):
    """Document source creation model."""
    organization_id: UUID


class DocumentSourceUpdate(BaseModel):
    """Document source update model."""
    name: Optional[str] = None
    connection_config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None
    sync_schedule: Optional[str] = None


class DocumentSource(DocumentSourceBase):
    """Complete document source model."""
    model_config = ConfigDict(from_attributes=True)
    
    id: UUID
    organization_id: UUID
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Document Models
class DocumentBase(BaseModel):
    """Base document model."""
    filename: str = Field(..., min_length=1, max_length=500)
    file_path: str = Field(..., min_length=1, max_length=1000)
    file_size: int = Field(..., gt=0)
    mime_type: str = Field(..., min_length=1, max_length=100)
    file_hash: str = Field(..., min_length=1, max_length=64)
    classification: Optional[DocumentClassification] = None
    bfsi_document_type: Optional[BfsiDocumentType] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DocumentCreate(DocumentBase):
    """Document creation model."""
    organization_id: UUID
    source_id: Optional[UUID] = None
    uploaded_by: UUID


class DocumentUpdate(BaseModel):
    """Document update model."""
    classification: Optional[DocumentClassification] = None
    bfsi_document_type: Optional[BfsiDocumentType] = None
    metadata: Optional[Dict[str, Any]] = None


class Document(DocumentBase):
    """Complete document model."""
    model_config = ConfigDict(from_attributes=True)
    
    id: UUID
    organization_id: UUID
    source_id: Optional[UUID] = None
    uploaded_by: UUID
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Processing Job Models
class ProcessingJobBase(BaseModel):
    """Base processing job model."""
    job_type: str = Field(..., min_length=1, max_length=100)
    status: ProcessingStatus = ProcessingStatus.PENDING
    priority: int = Field(default=5, ge=1, le=10)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    progress: float = Field(default=0.0, ge=0.0, le=100.0)
    error_message: Optional[str] = None
    result_data: Optional[Dict[str, Any]] = None


class ProcessingJobCreate(ProcessingJobBase):
    """Processing job creation model."""
    organization_id: UUID
    document_id: UUID
    created_by: UUID


class ProcessingJobUpdate(BaseModel):
    """Processing job update model."""
    status: Optional[ProcessingStatus] = None
    progress: Optional[float] = None
    error_message: Optional[str] = None
    result_data: Optional[Dict[str, Any]] = None


class ProcessingJob(ProcessingJobBase):
    """Complete processing job model."""
    model_config = ConfigDict(from_attributes=True)
    
    id: UUID
    organization_id: UUID
    document_id: UUID
    created_by: UUID
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# Audit Log Models
class AuditEventType(str, Enum):
    """Audit Event Types."""
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    DOCUMENT_UPLOAD = "document_upload"
    DOCUMENT_ACCESS = "document_access"
    DOCUMENT_CLASSIFICATION = "document_classification"
    CONFIGURATION_CHANGE = "configuration_change"
    PROCESSING_JOB_STARTED = "processing_job_started"
    PROCESSING_JOB_COMPLETED = "processing_job_completed"
    COMPLIANCE_CHECK = "compliance_check"
    DATA_EXPORT = "data_export"


class AuditLogBase(BaseModel):
    """Base audit log model."""
    event_type: AuditEventType
    resource_type: str = Field(..., min_length=1, max_length=100)
    resource_id: str = Field(..., min_length=1, max_length=100)
    action: str = Field(..., min_length=1, max_length=255)
    details: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None


class AuditLogCreate(AuditLogBase):
    """Audit log creation model."""
    organization_id: UUID
    user_id: Optional[UUID] = None


class AuditLog(AuditLogBase):
    """Complete audit log model."""
    model_config = ConfigDict(from_attributes=True)
    
    id: UUID
    organization_id: UUID
    user_id: Optional[UUID] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# Dashboard Models
class DashboardMetrics(BaseModel):
    """Dashboard metrics model."""
    documents_processed: int = 0
    classification_accuracy: float = 0.0
    active_sources: int = 0
    queue_status: int = 0
    processing_jobs: Dict[str, int] = Field(default_factory=dict)
    compliance_scores: Dict[str, float] = Field(default_factory=dict)
    recent_activity: List[Dict[str, Any]] = Field(default_factory=list)


# API Response Models
class APIResponse(BaseModel):
    """Standard API response model."""
    success: bool = True
    message: Optional[str] = None
    data: Optional[Any] = None
    errors: Optional[List[str]] = None


class PaginatedResponse(BaseModel):
    """Paginated response model."""
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int


# Workflow Models
class WorkflowStepType(str, Enum):
    """Workflow Step Types."""
    INGESTION = "ingestion"
    OCR_EXTRACTION = "ocr_extraction"
    AI_CLASSIFICATION = "ai_classification"
    COMPLIANCE_CHECK = "compliance_check"
    OUTPUT_ROUTING = "output_routing"
    NOTIFICATION = "notification"


class WorkflowStep(BaseModel):
    """Workflow step model."""
    step_id: str
    step_type: WorkflowStepType
    step_name: str
    depends_on: List[str] = Field(default_factory=list)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    retry_config: Dict[str, Any] = Field(default_factory=dict)
    timeout_seconds: int = 300


class WorkflowDefinition(BaseModel):
    """Workflow definition model."""
    workflow_id: str
    workflow_name: str
    description: Optional[str] = None
    steps: List[WorkflowStep]
    triggers: Dict[str, Any] = Field(default_factory=dict)
    schedule: Optional[str] = None  # Cron expression
    is_active: bool = True


class WorkflowExecution(BaseModel):
    """Workflow execution model."""
    model_config = ConfigDict(from_attributes=True)
    
    execution_id: UUID
    workflow_id: str
    organization_id: UUID
    status: ProcessingStatus
    triggered_by: Optional[UUID] = None
    input_data: Dict[str, Any] = Field(default_factory=dict)
    step_results: Dict[str, Any] = Field(default_factory=dict)
    error_details: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
