"""
Document Ingestion Worker for DocIntelPro BFSI Platform.
High-performance async document ingestion with validation and preprocessing.
"""

import os
import asyncio
import hashlib
import mimetypes
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, BinaryIO
import aiofiles
import aiohttp
from pydantic import BaseModel
import structlog
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
import magic

# Import shared models and database
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))
from database import get_db, AsyncSessionLocal
from db_models import Document, ProcessingJob, Organization
from models import ProcessingStatus, DocumentClassification, BfsiDocumentType

logger = structlog.get_logger(__name__)


class IngestionConfig(BaseModel):
    """Ingestion worker configuration."""
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    supported_mime_types: List[str] = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'image/tiff',
        'image/bmp',
        'text/plain',
        'text/csv',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ]
    quarantine_path: str = "/data/quarantine"
    processing_path: str = "/data/processing"
    backup_path: str = "/data/backup"
    enable_virus_scan: bool = True
    enable_content_scan: bool = True


class IngestionResult(BaseModel):
    """Ingestion operation result."""
    success: bool
    document_id: str
    file_hash: str
    file_size: int
    mime_type: str
    validation_results: Dict[str, Any]
    processing_path: Optional[str] = None
    error_message: Optional[str] = None


class DocumentIngestionWorker:
    """
    High-performance document ingestion worker.
    Handles file validation, security scanning, and preprocessing.
    """
    
    def __init__(self, config: IngestionConfig = None):
        self.config = config or IngestionConfig()
        self.magic = magic.Magic(mime=True)
        self._setup_directories()
        
    def _setup_directories(self):
        """Create necessary directories."""
        for path in [self.config.quarantine_path, self.config.processing_path, self.config.backup_path]:
            Path(path).mkdir(parents=True, exist_ok=True)
    
    async def validate_file_security(self, file_path: str) -> Dict[str, Any]:
        """
        Perform security validation on uploaded file.
        
        Args:
            file_path: Path to file to validate
            
        Returns:
            Validation results
        """
        results = {
            'virus_scan': {'clean': True, 'scanner': 'none'},
            'content_scan': {'safe': True, 'issues': []},
            'file_integrity': {'valid': True, 'hash_verified': True}
        }
        
        try:
            # File integrity check
            if not Path(file_path).exists():
                results['file_integrity']['valid'] = False
                return results
            
            # Basic virus scan simulation (in production, integrate with ClamAV or similar)
            if self.config.enable_virus_scan:
                # This would integrate with actual antivirus
                results['virus_scan'] = await self._mock_virus_scan(file_path)
            
            # Content-based security scan
            if self.config.enable_content_scan:
                results['content_scan'] = await self._content_security_scan(file_path)
            
        except Exception as e:
            logger.error("Security validation failed", file_path=file_path, error=str(e))
            results['virus_scan']['clean'] = False
            results['content_scan']['safe'] = False
            
        return results
    
    async def _mock_virus_scan(self, file_path: str) -> Dict[str, Any]:
        """Mock virus scan (replace with real antivirus integration)."""
        # Simulate scan delay
        await asyncio.sleep(0.1)
        
        # Check for suspicious file patterns
        suspicious_patterns = ['.exe', '.bat', '.cmd', '.scr', '.pif']
        filename = Path(file_path).name.lower()
        
        is_clean = not any(pattern in filename for pattern in suspicious_patterns)
        
        return {
            'clean': is_clean,
            'scanner': 'mock_av',
            'scan_time': datetime.utcnow().isoformat(),
            'threats_found': [] if is_clean else ['suspicious_extension']
        }
    
    async def _content_security_scan(self, file_path: str) -> Dict[str, Any]:
        """Scan file content for security issues."""
        issues = []
        
        try:
            # Check file size
            file_size = Path(file_path).stat().st_size
            if file_size > self.config.max_file_size:
                issues.append(f"File too large: {file_size} bytes")
            
            # MIME type validation
            detected_mime = self.magic.from_file(file_path)
            if detected_mime not in self.config.supported_mime_types:
                issues.append(f"Unsupported MIME type: {detected_mime}")
            
            # Basic content inspection for text files
            if detected_mime.startswith('text/'):
                async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = await f.read(1024)  # Read first 1KB
                    
                    # Check for potential malicious content
                    malicious_patterns = ['<script>', 'javascript:', 'vbscript:', 'onload=']
                    for pattern in malicious_patterns:
                        if pattern.lower() in content.lower():
                            issues.append(f"Suspicious content pattern: {pattern}")
            
        except Exception as e:
            issues.append(f"Content scan error: {str(e)}")
        
        return {
            'safe': len(issues) == 0,
            'issues': issues,
            'scan_time': datetime.utcnow().isoformat()
        }
    
    async def calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of file."""
        hash_sha256 = hashlib.sha256()
        
        async with aiofiles.open(file_path, 'rb') as f:
            while chunk := await f.read(8192):
                hash_sha256.update(chunk)
        
        return hash_sha256.hexdigest()
    
    async def detect_document_type(self, file_path: str, filename: str) -> Dict[str, Any]:
        """
        Detect document type and potential BFSI classification.
        
        Args:
            file_path: Path to file
            filename: Original filename
            
        Returns:
            Document type analysis
        """
        analysis = {
            'mime_type': self.magic.from_file(file_path),
            'file_extension': Path(filename).suffix.lower(),
            'suggested_bfsi_type': None,
            'confidence': 0.0,
            'features': []
        }
        
        # Simple filename-based classification
        filename_lower = filename.lower()
        
        if any(term in filename_lower for term in ['loan', 'credit', 'application']):
            analysis['suggested_bfsi_type'] = BfsiDocumentType.LOAN_APPLICATION
            analysis['confidence'] = 0.7
            analysis['features'].append('filename_pattern_loan')
        
        elif any(term in filename_lower for term in ['kyc', 'identity', 'verification']):
            analysis['suggested_bfsi_type'] = BfsiDocumentType.KYC_DOCUMENT
            analysis['confidence'] = 0.8
            analysis['features'].append('filename_pattern_kyc')
        
        elif any(term in filename_lower for term in ['financial', 'statement', 'balance']):
            analysis['suggested_bfsi_type'] = BfsiDocumentType.FINANCIAL_STATEMENT
            analysis['confidence'] = 0.6
            analysis['features'].append('filename_pattern_financial')
        
        elif any(term in filename_lower for term in ['compliance', 'audit', 'regulatory']):
            analysis['suggested_bfsi_type'] = BfsiDocumentType.COMPLIANCE_REPORT
            analysis['confidence'] = 0.7
            analysis['features'].append('filename_pattern_compliance')
        
        elif any(term in filename_lower for term in ['insurance', 'claim', 'policy']):
            analysis['suggested_bfsi_type'] = BfsiDocumentType.INSURANCE_CLAIM
            analysis['confidence'] = 0.7
            analysis['features'].append('filename_pattern_insurance')
        
        return analysis
    
    async def prepare_for_processing(self, source_path: str, document_id: str) -> str:
        """
        Prepare document for processing pipeline.
        
        Args:
            source_path: Original file path
            document_id: Document ID
            
        Returns:
            Processing file path
        """
        # Create processing directory structure
        processing_dir = Path(self.config.processing_path) / document_id[:2] / document_id[2:4]
        processing_dir.mkdir(parents=True, exist_ok=True)
        
        # Determine target filename
        source_file = Path(source_path)
        target_path = processing_dir / f"{document_id}{source_file.suffix}"
        
        # Copy file to processing location
        async with aiofiles.open(source_path, 'rb') as src:
            async with aiofiles.open(target_path, 'wb') as dst:
                while chunk := await src.read(8192):
                    await dst.write(chunk)
        
        logger.info("File prepared for processing", 
                   source=source_path, target=str(target_path))
        
        return str(target_path)
    
    async def ingest_document(
        self, 
        file_path: str, 
        organization_id: str,
        uploaded_by: str,
        original_filename: str,
        source_id: Optional[str] = None
    ) -> IngestionResult:
        """
        Main ingestion method - processes a single document.
        
        Args:
            file_path: Path to uploaded file
            organization_id: Organization UUID
            uploaded_by: User UUID who uploaded
            original_filename: Original filename
            source_id: Optional source ID
            
        Returns:
            Ingestion result
        """
        try:
            logger.info("Starting document ingestion", 
                       file_path=file_path, filename=original_filename)
            
            # Basic file validation
            if not Path(file_path).exists():
                return IngestionResult(
                    success=False,
                    document_id="",
                    file_hash="",
                    file_size=0,
                    mime_type="",
                    validation_results={},
                    error_message="File not found"
                )
            
            # Get file metadata
            file_size = Path(file_path).stat().st_size
            mime_type = self.magic.from_file(file_path)
            file_hash = await self.calculate_file_hash(file_path)
            
            # Security validation
            security_results = await self.validate_file_security(file_path)
            if not security_results['virus_scan']['clean'] or not security_results['content_scan']['safe']:
                # Move to quarantine
                quarantine_path = Path(self.config.quarantine_path) / f"{file_hash}_{original_filename}"
                await aiofiles.os.rename(file_path, quarantine_path)
                
                return IngestionResult(
                    success=False,
                    document_id="",
                    file_hash=file_hash,
                    file_size=file_size,
                    mime_type=mime_type,
                    validation_results=security_results,
                    error_message="File failed security validation"
                )
            
            # Document type analysis
            doc_type_analysis = await self.detect_document_type(file_path, original_filename)
            
            # Create document record in database
            async with AsyncSessionLocal() as session:
                try:
                    # Check for duplicate based on hash
                    existing_doc = await session.execute(
                        select(Document).where(
                            Document.file_hash == file_hash,
                            Document.organization_id == organization_id
                        )
                    )
                    existing = existing_doc.scalar_one_or_none()
                    
                    if existing:
                        logger.warning("Duplicate document detected", 
                                     file_hash=file_hash, existing_id=str(existing.id))
                        return IngestionResult(
                            success=False,
                            document_id=str(existing.id),
                            file_hash=file_hash,
                            file_size=file_size,
                            mime_type=mime_type,
                            validation_results=security_results,
                            error_message="Duplicate document"
                        )
                    
                    # Create new document
                    document = Document(
                        organization_id=organization_id,
                        source_id=source_id,
                        uploaded_by=uploaded_by,
                        filename=original_filename,
                        file_path=file_path,
                        file_size=file_size,
                        mime_type=mime_type,
                        file_hash=file_hash,
                        bfsi_document_type=doc_type_analysis.get('suggested_bfsi_type'),
                        metadata={
                            'ingestion': {
                                'ingested_at': datetime.utcnow().isoformat(),
                                'security_validation': security_results,
                                'type_analysis': doc_type_analysis,
                                'original_path': file_path
                            }
                        }
                    )
                    
                    session.add(document)
                    await session.flush()  # Get the ID
                    
                    # Prepare file for processing
                    processing_path = await self.prepare_for_processing(file_path, str(document.id))
                    
                    # Update document with processing path
                    document.file_path = processing_path
                    document.metadata['ingestion']['processing_path'] = processing_path
                    
                    await session.commit()
                    
                    logger.info("Document ingested successfully", 
                               document_id=str(document.id), 
                               file_hash=file_hash)
                    
                    return IngestionResult(
                        success=True,
                        document_id=str(document.id),
                        file_hash=file_hash,
                        file_size=file_size,
                        mime_type=mime_type,
                        validation_results=security_results,
                        processing_path=processing_path
                    )
                    
                except Exception as e:
                    await session.rollback()
                    logger.error("Database error during ingestion", error=str(e))
                    raise
        
        except Exception as e:
            logger.error("Ingestion failed", file_path=file_path, error=str(e))
            return IngestionResult(
                success=False,
                document_id="",
                file_hash="",
                file_size=0,
                mime_type="",
                validation_results={},
                error_message=str(e)
            )
    
    async def batch_ingest_documents(
        self, 
        file_paths: List[str],
        organization_id: str,
        uploaded_by: str,
        source_id: Optional[str] = None
    ) -> List[IngestionResult]:
        """
        Batch ingestion of multiple documents.
        
        Args:
            file_paths: List of file paths to ingest
            organization_id: Organization UUID
            uploaded_by: User UUID
            source_id: Optional source ID
            
        Returns:
            List of ingestion results
        """
        logger.info("Starting batch ingestion", count=len(file_paths))
        
        # Process documents concurrently
        tasks = []
        for file_path in file_paths:
            filename = Path(file_path).name
            task = self.ingest_document(
                file_path=file_path,
                organization_id=organization_id,
                uploaded_by=uploaded_by,
                original_filename=filename,
                source_id=source_id
            )
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle exceptions
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error("Batch ingestion error", 
                           file_path=file_paths[i], error=str(result))
                processed_results.append(IngestionResult(
                    success=False,
                    document_id="",
                    file_hash="",
                    file_size=0,
                    mime_type="",
                    validation_results={},
                    error_message=str(result)
                ))
            else:
                processed_results.append(result)
        
        successful = sum(1 for r in processed_results if r.success)
        logger.info("Batch ingestion completed", 
                   total=len(file_paths), successful=successful)
        
        return processed_results


# API endpoint for testing
async def test_ingestion():
    """Test ingestion worker."""
    worker = DocumentIngestionWorker()
    
    # Test file (create a small test file)
    test_file = "/tmp/test_document.txt"
    async with aiofiles.open(test_file, 'w') as f:
        await f.write("This is a test financial statement document.")
    
    result = await worker.ingest_document(
        file_path=test_file,
        organization_id="f5a5744d-f922-4918-b5ae-0d9a430b9b0b",
        uploaded_by="3761d7a3-eace-492a-8cf2-eab83c28fd2f",
        original_filename="test_financial_statement.txt"
    )
    
    print(f"Ingestion result: {result}")


if __name__ == "__main__":
    asyncio.run(test_ingestion())
