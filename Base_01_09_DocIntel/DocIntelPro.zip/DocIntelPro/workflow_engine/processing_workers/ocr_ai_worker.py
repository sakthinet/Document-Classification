"""
OCR & AI Worker for DocIntelPro BFSI Platform.
High-performance document text extraction and AI processing.
"""

import os
import asyncio
import cv2
import numpy as np
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Union
import aiofiles
from PIL import Image
import pytesseract
import torch
import torchvision.transforms as transforms
from transformers import pipeline, AutoTokenizer, AutoModel
import structlog
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from pydantic import BaseModel

# Import shared models and database
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'shared'))
from database import get_db, AsyncSessionLocal
from db_models import Document, ProcessingJob
from models import ProcessingStatus, BfsiDocumentType

logger = structlog.get_logger(__name__)


class OCRConfig(BaseModel):
    """OCR worker configuration."""
    tesseract_config: str = '--oem 3 --psm 6'
    enable_preprocessing: bool = True
    enable_gpu: bool = torch.cuda.is_available()
    confidence_threshold: float = 60.0
    
    # PaddleOCR settings (if available)
    use_paddle_ocr: bool = True
    paddle_languages: List[str] = ['en', 'ch']
    
    # Image preprocessing settings
    enhance_contrast: bool = True
    denoise_image: bool = True
    deskew_image: bool = True
    
    # Text extraction settings
    extract_tables: bool = True
    extract_forms: bool = True
    extract_signatures: bool = True


class AIConfig(BaseModel):
    """AI processing configuration."""
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    model_cache_dir: str = "/models/cache"
    
    # NLP models
    classification_model: str = "microsoft/DialoGPT-medium"
    extraction_model: str = "dbmdz/bert-large-cased-finetuned-conll03-english"
    sentiment_model: str = "cardiffnlp/twitter-roberta-base-sentiment-latest"
    
    # Document analysis
    max_text_length: int = 512000  # 512KB
    chunk_size: int = 1000
    overlap_size: int = 100


class ExtractionResult(BaseModel):
    """OCR and AI extraction result."""
    success: bool
    extracted_text: str
    confidence_score: float
    text_blocks: List[Dict[str, Any]]
    entities: List[Dict[str, Any]]
    tables: List[Dict[str, Any]]
    forms: List[Dict[str, Any]]
    metadata: Dict[str, Any]
    processing_time: float
    error_message: Optional[str] = None


class DocumentOCRAIWorker:
    """
    High-performance OCR and AI worker for document processing.
    """
    
    def __init__(self, ocr_config: OCRConfig = None, ai_config: AIConfig = None):
        self.ocr_config = ocr_config or OCRConfig()
        self.ai_config = ai_config or AIConfig()
        
        # Initialize AI models
        self._init_ai_models()
        
        # Initialize OCR engines
        self._init_ocr_engines()
    
    def _init_ai_models(self):
        """Initialize AI models for text processing."""
        try:
            logger.info("Initializing AI models", device=self.ai_config.device)
            
            # Named Entity Recognition
            self.ner_pipeline = pipeline(
                "ner",
                model=self.ai_config.extraction_model,
                device=0 if self.ai_config.device == "cuda" else -1,
                aggregation_strategy="simple"
            )
            
            # Text classification
            self.classifier = pipeline(
                "text-classification",
                model="microsoft/DialoGPT-medium",  # Replace with actual BFSI classifier
                device=0 if self.ai_config.device == "cuda" else -1
            )
            
            # Sentiment analysis
            self.sentiment_analyzer = pipeline(
                "sentiment-analysis",
                model=self.ai_config.sentiment_model,
                device=0 if self.ai_config.device == "cuda" else -1
            )
            
            logger.info("AI models initialized successfully")
            
        except Exception as e:
            logger.error("Failed to initialize AI models", error=str(e))
            # Fallback to basic processing
            self.ner_pipeline = None
            self.classifier = None
            self.sentiment_analyzer = None
    
    def _init_ocr_engines(self):
        """Initialize OCR engines."""
        try:
            # Initialize PaddleOCR if available
            if self.ocr_config.use_paddle_ocr:
                try:
                    from paddleocr import PaddleOCR
                    self.paddle_ocr = PaddleOCR(
                        use_angle_cls=True,
                        lang='en',
                        use_gpu=self.ocr_config.enable_gpu
                    )
                    logger.info("PaddleOCR initialized successfully")
                except ImportError:
                    logger.warning("PaddleOCR not available, using Tesseract only")
                    self.paddle_ocr = None
            else:
                self.paddle_ocr = None
            
            # Configure Tesseract
            if hasattr(pytesseract, 'pytesseract'):
                # Set Tesseract path if needed (Windows)
                if os.name == 'nt':
                    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
            
            logger.info("OCR engines initialized")
            
        except Exception as e:
            logger.error("Failed to initialize OCR engines", error=str(e))
    
    async def preprocess_image(self, image_path: str) -> np.ndarray:
        """
        Preprocess image for better OCR results.
        
        Args:
            image_path: Path to image file
            
        Returns:
            Preprocessed image as numpy array
        """
        # Read image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not read image: {image_path}")
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        if self.ocr_config.enable_preprocessing:
            # Denoise
            if self.ocr_config.denoise_image:
                gray = cv2.fastNlMeansDenoising(gray)
            
            # Enhance contrast
            if self.ocr_config.enhance_contrast:
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                gray = clahe.apply(gray)
            
            # Deskew (simple rotation correction)
            if self.ocr_config.deskew_image:
                gray = self._deskew_image(gray)
            
            # Apply threshold for better text detection
            _, gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        return gray
    
    def _deskew_image(self, image: np.ndarray) -> np.ndarray:
        """Apply deskewing to correct document rotation."""
        coords = np.column_stack(np.where(image > 0))
        if len(coords) == 0:
            return image
        
        angle = cv2.minAreaRect(coords)[-1]
        
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        
        # Only apply correction for significant skew
        if abs(angle) > 0.5:
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            image = cv2.warpAffine(image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
        
        return image
    
    async def extract_text_tesseract(self, image: np.ndarray) -> Dict[str, Any]:
        """
        Extract text using Tesseract OCR.
        
        Args:
            image: Preprocessed image
            
        Returns:
            Extraction results
        """
        try:
            # Extract text
            text = pytesseract.image_to_string(image, config=self.ocr_config.tesseract_config)
            
            # Get detailed data
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            # Calculate confidence
            confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            # Extract text blocks with positions
            text_blocks = []
            for i in range(len(data['text'])):
                if int(data['conf'][i]) > self.ocr_config.confidence_threshold:
                    text_blocks.append({
                        'text': data['text'][i].strip(),
                        'confidence': int(data['conf'][i]),
                        'bbox': {
                            'x': int(data['left'][i]),
                            'y': int(data['top'][i]),
                            'width': int(data['width'][i]),
                            'height': int(data['height'][i])
                        }
                    })
            
            return {
                'text': text.strip(),
                'confidence': avg_confidence,
                'text_blocks': text_blocks,
                'method': 'tesseract'
            }
            
        except Exception as e:
            logger.error("Tesseract OCR failed", error=str(e))
            return {
                'text': '',
                'confidence': 0.0,
                'text_blocks': [],
                'method': 'tesseract',
                'error': str(e)
            }
    
    async def extract_text_paddle(self, image_path: str) -> Dict[str, Any]:
        """
        Extract text using PaddleOCR.
        
        Args:
            image_path: Path to image file
            
        Returns:
            Extraction results
        """
        if not self.paddle_ocr:
            return {'text': '', 'confidence': 0.0, 'text_blocks': [], 'method': 'paddle_unavailable'}
        
        try:
            # Run PaddleOCR
            result = self.paddle_ocr.ocr(image_path, cls=True)
            
            if not result or not result[0]:
                return {'text': '', 'confidence': 0.0, 'text_blocks': [], 'method': 'paddle'}
            
            # Process results
            extracted_text = []
            text_blocks = []
            confidences = []
            
            for line in result[0]:
                bbox = line[0]
                text_info = line[1]
                text = text_info[0]
                confidence = text_info[1]
                
                extracted_text.append(text)
                confidences.append(confidence)
                
                text_blocks.append({
                    'text': text,
                    'confidence': confidence,
                    'bbox': {
                        'points': bbox,
                        'x': min(point[0] for point in bbox),
                        'y': min(point[1] for point in bbox),
                        'width': max(point[0] for point in bbox) - min(point[0] for point in bbox),
                        'height': max(point[1] for point in bbox) - min(point[1] for point in bbox)
                    }
                })
            
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0
            
            return {
                'text': '\n'.join(extracted_text),
                'confidence': avg_confidence * 100,  # Convert to percentage
                'text_blocks': text_blocks,
                'method': 'paddle'
            }
            
        except Exception as e:
            logger.error("PaddleOCR failed", error=str(e))
            return {
                'text': '',
                'confidence': 0.0,
                'text_blocks': [],
                'method': 'paddle',
                'error': str(e)
            }
    
    async def extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract named entities from text using AI models.
        
        Args:
            text: Input text
            
        Returns:
            List of extracted entities
        """
        if not self.ner_pipeline or not text.strip():
            return []
        
        try:
            # Chunk text if too long
            chunks = self._chunk_text(text)
            all_entities = []
            
            for chunk in chunks:
                entities = self.ner_pipeline(chunk)
                
                # Process and clean entities
                for entity in entities:
                    all_entities.append({
                        'text': entity['word'],
                        'label': entity['entity_group'],
                        'confidence': entity['score'],
                        'start': entity.get('start', 0),
                        'end': entity.get('end', 0)
                    })
            
            # Remove duplicates and low confidence entities
            filtered_entities = []
            seen_entities = set()
            
            for entity in all_entities:
                entity_key = (entity['text'].lower(), entity['label'])
                if entity_key not in seen_entities and entity['confidence'] > 0.5:
                    seen_entities.add(entity_key)
                    filtered_entities.append(entity)
            
            return filtered_entities
            
        except Exception as e:
            logger.error("Entity extraction failed", error=str(e))
            return []
    
    def _chunk_text(self, text: str) -> List[str]:
        """Split text into chunks for processing."""
        if len(text) <= self.ai_config.chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.ai_config.chunk_size
            
            # Try to break at sentence boundary
            if end < len(text):
                last_period = text.rfind('.', start, end)
                if last_period > start + self.ai_config.chunk_size // 2:
                    end = last_period + 1
            
            chunks.append(text[start:end])
            start = end - self.ai_config.overlap_size
        
        return chunks
    
    async def detect_tables(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Detect and extract table structures from image.
        
        Args:
            image: Input image
            
        Returns:
            List of detected tables
        """
        tables = []
        
        try:
            # Simple table detection using contours
            contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > 1000:  # Minimum table size
                    x, y, w, h = cv2.boundingRect(contour)
                    
                    # Basic table characteristics
                    aspect_ratio = w / h
                    if 0.5 < aspect_ratio < 3.0:  # Reasonable table dimensions
                        tables.append({
                            'bbox': {'x': int(x), 'y': int(y), 'width': int(w), 'height': int(h)},
                            'area': float(area),
                            'confidence': 0.7  # Simple heuristic
                        })
            
        except Exception as e:
            logger.error("Table detection failed", error=str(e))
        
        return tables
    
    async def process_document(self, document_id: str) -> ExtractionResult:
        """
        Main processing method for a document.
        
        Args:
            document_id: Document ID to process
            
        Returns:
            Extraction result
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            # Get document from database
            async with AsyncSessionLocal() as session:
                result = await session.execute(
                    select(Document).where(Document.id == document_id)
                )
                document = result.scalar_one_or_none()
                
                if not document:
                    return ExtractionResult(
                        success=False,
                        extracted_text="",
                        confidence_score=0.0,
                        text_blocks=[],
                        entities=[],
                        tables=[],
                        forms=[],
                        metadata={},
                        processing_time=0.0,
                        error_message="Document not found"
                    )
                
                file_path = document.file_path
                mime_type = document.mime_type
            
            logger.info("Processing document", document_id=document_id, file_path=file_path)
            
            # Initialize results
            extracted_text = ""
            confidence_score = 0.0
            text_blocks = []
            entities = []
            tables = []
            forms = []
            metadata = {'processing_method': 'unknown'}
            
            # Process based on file type
            if mime_type.startswith('image/'):
                # Image processing
                preprocessed_image = await self.preprocess_image(file_path)
                
                # Try PaddleOCR first, fallback to Tesseract
                paddle_result = await self.extract_text_paddle(file_path)
                tesseract_result = await self.extract_text_tesseract(preprocessed_image)
                
                # Choose best result
                if paddle_result['confidence'] > tesseract_result['confidence']:
                    ocr_result = paddle_result
                else:
                    ocr_result = tesseract_result
                
                extracted_text = ocr_result['text']
                confidence_score = ocr_result['confidence']
                text_blocks = ocr_result['text_blocks']
                metadata['ocr_method'] = ocr_result['method']
                
                # Detect tables
                if self.ocr_config.extract_tables:
                    tables = await self.detect_tables(preprocessed_image)
                
            elif mime_type == 'application/pdf':
                # PDF processing (simplified for demo)
                extracted_text = "PDF processing not fully implemented in demo"
                confidence_score = 100.0
                metadata['processing_method'] = 'pdf_text_extraction'
                
            elif mime_type.startswith('text/'):
                # Text file processing
                async with aiofiles.open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    extracted_text = await f.read()
                confidence_score = 100.0
                metadata['processing_method'] = 'direct_text_read'
            
            # Extract entities from text
            if extracted_text.strip():
                entities = await self.extract_entities(extracted_text)
            
            # Update document with extracted text
            async with AsyncSessionLocal() as session:
                await session.execute(
                    update(Document)
                    .where(Document.id == document_id)
                    .values(
                        extracted_text=extracted_text,
                        metadata=Document.metadata.op('||')({
                            'extraction': {
                                'processed_at': datetime.utcnow().isoformat(),
                                'confidence': confidence_score,
                                'entities_count': len(entities),
                                'tables_count': len(tables),
                                'method': metadata.get('ocr_method', metadata.get('processing_method'))
                            }
                        })
                    )
                )
                await session.commit()
            
            processing_time = asyncio.get_event_loop().time() - start_time
            
            logger.info("Document processing completed", 
                       document_id=document_id,
                       text_length=len(extracted_text),
                       entities_count=len(entities),
                       processing_time=processing_time)
            
            return ExtractionResult(
                success=True,
                extracted_text=extracted_text,
                confidence_score=confidence_score,
                text_blocks=text_blocks,
                entities=entities,
                tables=tables,
                forms=forms,
                metadata=metadata,
                processing_time=processing_time
            )
            
        except Exception as e:
            processing_time = asyncio.get_event_loop().time() - start_time
            logger.error("Document processing failed", 
                        document_id=document_id, error=str(e))
            
            return ExtractionResult(
                success=False,
                extracted_text="",
                confidence_score=0.0,
                text_blocks=[],
                entities=[],
                tables=[],
                forms=[],
                metadata={},
                processing_time=processing_time,
                error_message=str(e)
            )


# Test function
async def test_ocr_worker():
    """Test OCR worker."""
    worker = DocumentOCRAIWorker()
    
    # This would test with an actual document ID from the database
    test_document_id = "test-document-id"
    result = await worker.process_document(test_document_id)
    
    print(f"OCR Result: {result}")


if __name__ == "__main__":
    asyncio.run(test_ocr_worker())
