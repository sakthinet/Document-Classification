#!/usr/bin/env python3
"""
Health check script for DocIntelPro Python Services.
Verifies all services are running on correct ports.
"""

import asyncio
import aiohttp
import time
from typing import Dict, List

class ServiceHealthChecker:
    """Check health of all DocIntelPro services."""
    
    def __init__(self):
        self.services = {
            "FastAPI Gateway": "http://localhost:8000/health",
            "Apache Airflow": "http://localhost:8083/health",
            "Node.js Server": "http://localhost:5000/api/health",
            "PostgreSQL": "postgresql://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd",
            "Redis": "redis://localhost:6379"
        }
    
    async def check_http_service(self, name: str, url: str) -> Dict[str, any]:
        """Check HTTP service health."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            "name": name,
                            "status": "✅ Healthy",
                            "url": url,
                            "response_time": f"{response.headers.get('X-Response-Time', 'N/A')}",
                            "details": data
                        }
                    else:
                        return {
                            "name": name,
                            "status": f"❌ Error (HTTP {response.status})",
                            "url": url,
                            "response_time": "N/A",
                            "details": None
                        }
        except asyncio.TimeoutError:
            return {
                "name": name,
                "status": "⏰ Timeout",
                "url": url,
                "response_time": "N/A",
                "details": None
            }
        except Exception as e:
            return {
                "name": name,
                "status": f"❌ Error: {str(e)}",
                "url": url,
                "response_time": "N/A",
                "details": None
            }
    
    async def check_database_service(self, name: str, url: str) -> Dict[str, any]:
        """Check database service health."""
        try:
            if url.startswith("postgresql://"):
                import asyncpg
                conn = await asyncpg.connect(url)
                result = await conn.fetchval("SELECT 1")
                await conn.close()
                return {
                    "name": name,
                    "status": "✅ Connected",
                    "url": url.replace("RND_Admin123!", "***"),
                    "response_time": "N/A",
                    "details": {"test_query": result}
                }
            elif url.startswith("redis://"):
                import aioredis
                redis = aioredis.from_url(url)
                await redis.ping()
                await redis.close()
                return {
                    "name": name,
                    "status": "✅ Connected",
                    "url": url,
                    "response_time": "N/A",
                    "details": {"ping": "PONG"}
                }
        except ImportError as e:
            return {
                "name": name,
                "status": f"❌ Missing dependency: {str(e)}",
                "url": url.replace("RND_Admin123!", "***"),
                "response_time": "N/A",
                "details": None
            }
        except Exception as e:
            return {
                "name": name,
                "status": f"❌ Error: {str(e)}",
                "url": url.replace("RND_Admin123!", "***"),
                "response_time": "N/A",
                "details": None
            }
    
    async def check_all_services(self) -> List[Dict[str, any]]:
        """Check all services."""
        print("🏥 DocIntelPro Services Health Check")
        print("=" * 50)
        
        results = []
        
        # Check HTTP services
        http_services = [
            ("FastAPI Gateway", "http://localhost:8000/health"),
            ("Apache Airflow", "http://localhost:8083/health"),
            ("Node.js Server", "http://localhost:5000/api/health")
        ]
        
        for name, url in http_services:
            print(f"Checking {name}...")
            result = await self.check_http_service(name, url)
            results.append(result)
            time.sleep(0.5)  # Small delay between checks
        
        # Check database services
        db_services = [
            ("PostgreSQL", "postgresql://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd"),
            ("Redis", "redis://localhost:6379")
        ]
        
        for name, url in db_services:
            print(f"Checking {name}...")
            result = await self.check_database_service(name, url)
            results.append(result)
            time.sleep(0.5)
        
        return results
    
    def print_results(self, results: List[Dict[str, any]]):
        """Print formatted results."""
        print("\n" + "=" * 50)
        print("📊 Health Check Results:")
        print("=" * 50)
        
        healthy_count = 0
        for result in results:
            print(f"\n🔍 {result['name']}")
            print(f"   Status: {result['status']}")
            print(f"   URL: {result['url']}")
            if result['response_time'] != 'N/A':
                print(f"   Response Time: {result['response_time']}")
            
            if result['details']:
                print(f"   Details: {result['details']}")
            
            if "✅" in result['status']:
                healthy_count += 1
        
        print(f"\n📈 Summary: {healthy_count}/{len(results)} services healthy")
        
        if healthy_count == len(results):
            print("🎉 All services are running correctly!")
            print("\n🌐 Service Access Points:")
            print("   • Frontend Dashboard: http://localhost:5000")
            print("   • FastAPI Gateway: http://localhost:8000")
            print("   • API Documentation: http://localhost:8000/docs")
            print("   • Apache Airflow: http://localhost:8083 (admin/admin)")
        else:
            print("⚠️  Some services need attention. Check the status above.")

async def main():
    """Main health check function."""
    checker = ServiceHealthChecker()
    results = await checker.check_all_services()
    checker.print_results(results)

if __name__ == "__main__":
    asyncio.run(main())
