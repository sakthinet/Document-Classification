#!/usr/bin/env python3
"""
Startup script for DocIntelPro with correct port     print("🛑 Stopping DocIntelPro Services...")
    print("=" * 50)
    
    workflow_engine_dir = Path(__file__).parent
    
    try:
        # Stop Docker Compose services
        subprocess.run([
            'docker-compose', 'down'
        ], cwd=workflow_engine_dir, check=True)ions.
Ensures all services start on the correct ports.
"""

import os
import subprocess
import time
import sys
from pathlib import Path

def start_services():
    """Start all DocIntelPro services with correct port configuration."""
    print("🚀 Starting DocIntelPro Services")
    print("=" * 50)
    
    # Set environment variables for correct ports
    env = os.environ.copy()
    env.update({
        'AIRFLOW__WEBSERVER__WEB_SERVER_PORT': '8083',
        'AIRFLOW_SERVICE_URL': 'http://localhost:8083',
        'GATEWAY_PORT': '8000',
        'NODE_SERVER_PORT': '5000'
    })
    
    project_root = Path(__file__).parent.parent
    workflow_engine_dir = Path(__file__).parent
    
    print("📊 Port Configuration:")
    print("   • Frontend Dashboard: http://localhost:5000")
    print("   • FastAPI Gateway: http://localhost:8000") 
    print("   • Apache Airflow: http://localhost:8083")
    print("   • PostgreSQL: localhost:5432")
    print("   • Redis: localhost:6379")
    print()
    
    try:
        # Start Node.js server (if not already running)
        print("1️⃣ Starting Node.js server...")
        node_process = subprocess.Popen(
            ['npm', 'run', 'dev'],
            cwd=project_root,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        time.sleep(3)
        
        # Start Python services with Docker Compose
        print("2️⃣ Starting Python services...")
        subprocess.run([
            'docker-compose', 'up', '-d'
        ], cwd=workflow_engine_dir, env=env, check=True)
        
        print("3️⃣ Waiting for services to be ready...")
        time.sleep(10)
        
        print("✅ All services started!")
        print()
        print("🌐 Access your services at:")
        print("   • Dashboard: http://localhost:5000")
        print("   • API Gateway: http://localhost:8000")
        print("   • API Docs: http://localhost:8000/docs")
        print("   • Airflow: http://localhost:8083 (admin/admin)")
        print()
        print("💡 Use 'python health_check.py' to verify all services are healthy")
        print("💡 Use 'docker-compose logs -f' to view service logs")
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error starting services: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n⏹️ Startup interrupted by user")
        sys.exit(1)

def stop_services():
    """Stop all services."""
    print("⏹️ Stopping DocIntelPro Services")
    print("=" * 50)
    
    workflow_engine_dir = Path(__file__).parent
    
    try:
        # Stop Docker Compose services
        subprocess.run([
            'docker-compose', 'down'
        ], cwd=workflow_engine_dir, check=True)
        
        print("✅ All services stopped!")
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error stopping services: {e}")
        sys.exit(1)

def show_status():
    """Show service status."""
    print("📊 DocIntelPro Service Status")
    print("=" * 50)
    
    workflow_engine_dir = Path(__file__).parent
    
    try:
        # Show Docker Compose status
        result = subprocess.run([
            'docker-compose', 'ps'
        ], cwd=workflow_engine_dir, capture_output=True, text=True)
        
        print("Docker Services:")
        print(result.stdout)
        
        # Check if Node.js server is running
        try:
            import requests
            response = requests.get('http://localhost:5000/api/health', timeout=2)
            if response.status_code == 200:
                print("✅ Node.js Server: Running on port 5000")
            else:
                print(f"⚠️  Node.js Server: Responding with status {response.status_code}")
        except:
            print("❌ Node.js Server: Not responding on port 5000")
        
        # Check Python Gateway
        try:
            import requests
            response = requests.get('http://localhost:8000/health', timeout=2)
            if response.status_code == 200:
                print("✅ FastAPI Gateway: Running on port 8000")
            else:
                print(f"⚠️  FastAPI Gateway: Responding with status {response.status_code}")
        except:
            print("❌ FastAPI Gateway: Not responding on port 8000")
        
        # Check Airflow
        try:
            import requests
            response = requests.get('http://localhost:8083/health', timeout=2)
            if response.status_code == 200:
                print("✅ Apache Airflow: Running on port 8083")
            else:
                print(f"⚠️  Apache Airflow: Responding with status {response.status_code}")
        except:
            print("❌ Apache Airflow: Not responding on port 8083")
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error checking status: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'start':
            start_services()
        elif command == 'stop':
            stop_services()
        elif command == 'status':
            show_status()
        elif command == 'restart':
            stop_services()
            time.sleep(2)
            start_services()
        else:
            print("Available commands:")
            print("  start    - Start all services")
            print("  stop     - Stop all services")
            print("  status   - Show service status")
            print("  restart  - Restart all services")
    else:
        start_services()
