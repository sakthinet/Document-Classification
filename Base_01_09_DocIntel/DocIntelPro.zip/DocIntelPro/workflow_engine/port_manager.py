#!/usr/bin/env python3
"""
Dynamic Port Management for DocIntelPro Python Services
Handles port discovery and dynamic allocation for FastAPI Gateway and Airflow
"""

import socket
import os
import sys
import json
import subprocess
from typing import Dict, Optional
from pathlib import Path


class PortManager:
    """Manages dynamic port allocation for Python services"""
    
    def __init__(self):
        self.preferred_ports = {
            'gateway': 8000,
            'airflow': 8083,
            'redis': 6379,
            'postgres': 5432
        }
        
    def is_port_available(self, port: int, host: str = 'localhost') -> bool:
        """Check if a port is available"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(1)
                result = sock.connect_ex((host, port))
                return result != 0
        except Exception:
            return False
    
    def find_available_port(self, start_port: int, max_attempts: int = 10) -> int:
        """Find the next available port starting from start_port"""
        for i in range(max_attempts):
            port = start_port + i
            if self.is_port_available(port):
                return port
        raise RuntimeError(f"No available port found starting from {start_port} (tried {max_attempts} ports)")
    
    def get_dynamic_ports(self) -> Dict[str, int]:
        """Get available ports for all services"""
        ports = {}
        
        # Find available ports for each service
        for service, preferred_port in self.preferred_ports.items():
            if service in ['redis', 'postgres']:
                # For infrastructure services, check if preferred port is available
                # If not, use Docker's dynamic allocation
                if self.is_port_available(preferred_port):
                    ports[service] = preferred_port
                else:
                    ports[service] = 0  # Let Docker handle it
            else:
                # For application services, find available port
                ports[service] = self.find_available_port(preferred_port)
        
        return ports
    
    def update_environment(self, ports: Dict[str, int]) -> None:
        """Update environment variables with dynamic ports"""
        env_updates = {
            'GATEWAY_PORT': str(ports['gateway']),
            'AIRFLOW_PORT': str(ports['airflow']),
            'GATEWAY_URL': f"http://localhost:{ports['gateway']}",
            'AIRFLOW_URL': f"http://localhost:{ports['airflow']}"
        }
        
        # Update current process environment
        os.environ.update(env_updates)
        
        # Write to .env file for persistence
        self.update_env_file(env_updates)
    
    def update_env_file(self, updates: Dict[str, str]) -> None:
        """Update .env file with new port configurations"""
        env_file = Path('.env')
        
        if env_file.exists():
            # Read existing .env file
            with open(env_file, 'r') as f:
                lines = f.readlines()
            
            # Update existing variables or add new ones
            updated_lines = []
            updated_keys = set()
            
            for line in lines:
                if '=' in line and not line.strip().startswith('#'):
                    key = line.split('=')[0].strip()
                    if key in updates:
                        updated_lines.append(f"{key}={updates[key]}\n")
                        updated_keys.add(key)
                    else:
                        updated_lines.append(line)
                else:
                    updated_lines.append(line)
            
            # Add new variables that weren't found
            for key, value in updates.items():
                if key not in updated_keys:
                    updated_lines.append(f"{key}={value}\n")
            
            # Write back to file
            with open(env_file, 'w') as f:
                f.writelines(updated_lines)
    
    def generate_docker_compose(self, ports: Dict[str, int]) -> None:
        """Update docker-compose.yml with dynamic ports"""
        compose_file = Path('workflow_engine/docker-compose.yml')
        
        if not compose_file.exists():
            print(f"❌ Docker compose file not found: {compose_file}")
            return
        
        # Read current compose file
        with open(compose_file, 'r') as f:
            content = f.read()
        
        # Replace port configurations
        replacements = {
            '"8000:8000"': f'"{ports["gateway"]}:8000"',
            '"8083:8083"': f'"{ports["airflow"]}:8083"',
            'AIRFLOW_WEBSERVER_PORT=8083': f'AIRFLOW_WEBSERVER_PORT={ports["airflow"]}',
            'GATEWAY_PORT=8000': f'GATEWAY_PORT={ports["gateway"]}'
        }
        
        for old, new in replacements.items():
            content = content.replace(old, new)
        
        # Write updated compose file
        with open(compose_file, 'w') as f:
            f.write(content)
        
        print(f"✅ Updated docker-compose.yml with dynamic ports")
    
    def display_service_info(self, ports: Dict[str, int]) -> None:
        """Display service URLs and information"""
        print('\n🐍 DocIntelPro Python Services')
        print('=' * 50)
        print(f"🔧 FastAPI Gateway:       http://localhost:{ports['gateway']}")
        print(f"⚡ Airflow Web UI:        http://localhost:{ports['airflow']}")
        print(f"📊 Gateway Health:        http://localhost:{ports['gateway']}/health")
        print(f"📖 API Documentation:    http://localhost:{ports['gateway']}/docs")
        print('=' * 50)
        print('💡 Python services configured with dynamic ports')
        print('🐳 Use docker-compose up to start all services\n')


def main():
    """Main function for dynamic port management"""
    try:
        print('🔍 Scanning for available ports...')
        port_manager = PortManager()
        
        # Get dynamic ports
        ports = port_manager.get_dynamic_ports()
        
        # Update environment and configuration files
        port_manager.update_environment(ports)
        port_manager.generate_docker_compose(ports)
        
        # Display service information
        port_manager.display_service_info(ports)
        
        # Save port configuration for other scripts
        with open('ports.json', 'w') as f:
            json.dump(ports, f, indent=2)
        
        print('✅ Dynamic port allocation completed successfully!')
        return ports
        
    except Exception as e:
        print(f'❌ Error in port allocation: {e}')
        sys.exit(1)


if __name__ == '__main__':
    main()
