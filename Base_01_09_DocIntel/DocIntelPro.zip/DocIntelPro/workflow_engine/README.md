# DocIntelPro Python Services

## 🐍 Python-Based Document Intelligence Platform

This directory contains the Python-based microservices for the DocIntelPro BFSI document intelligence platform, implementing the workflow orchestration and processing layer as described in the `python_based_architecture.md`.

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│             PYTHON SERVICES ARCHITECTURE                       │
│                                                                 │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐   │
│  │   FastAPI       │ │   Processing    │ │   Workflow      │   │
│  │   Gateway       │ │   Workers       │ │ Orchestration   │   │
│  │   (Port 8000)   │ │   (Celery)      │ │   (Airflow)     │   │
│  │                 │ │                 │ │   (Port 8080)   │   │
│  │ • API Gateway   │ │ • OCR/AI        │ │ • DAG Management│   │
│  │ • Auth & Proxy  │ │ • Classification│ │ • Task Scheduling│   │
│  │ • Rate Limiting │ │ • Compliance    │ │ • Monitoring    │   │
│  │ • Monitoring    │ │ • Document Proc │ │ • Retry Logic   │   │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                 Shared Components                      │   │
│  │ • Database Models (SQLAlchemy)                         │   │
│  │ • Pydantic Models                                      │   │
│  │ • Common Utilities                                     │   │
│  │ • Configuration Management                             │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## 📦 Services

### 1. FastAPI Gateway (`gateway/`)
- **Purpose**: High-performance API gateway and proxy
- **Port**: 8000
- **Features**:
  - Async request handling with 20,000+ RPS capacity
  - JWT authentication and authorization
  - Rate limiting and security middleware
  - Service discovery and load balancing
  - Prometheus metrics and monitoring
  - Automatic OpenAPI documentation

### 2. Processing Workers (`processing_workers/`)
- **Purpose**: Document processing pipeline workers
- **Technology**: Celery with Redis broker
- **Workers**:
  - **Ingestion Worker**: File validation, security scanning, preprocessing
  - **OCR/AI Worker**: Text extraction using Tesseract, PaddleOCR, and AI models
  - **Classification Worker**: ML-based document classification
  - **Compliance Worker**: Regulatory framework validation

### 3. Workflow Orchestration (`workflow_orchestration/`)
- **Purpose**: Apache Airflow-based workflow management
- **Port**: 8083
- **Features**:
  - Python-native DAGs for document processing
  - Real-time and batch processing workflows
  - Advanced retry logic and error handling
  - Resource-aware task scheduling
  - Integration with processing workers

### 4. Shared Components (`shared/`)
- **Database Models**: SQLAlchemy 2.0 async models
- **Pydantic Models**: Data validation and serialization
- **Common Utilities**: Logging, configuration, helpers

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Docker & Docker Compose
- PostgreSQL (running from Node.js setup)

### Option 1: Automated Setup
```bash
cd workflow_engine
python setup.py setup
```

### Option 2: Manual Setup
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set up environment
cp .env.example .env
# Edit .env with your configuration

# 3. Start services with Docker
docker-compose up -d

# 4. Initialize database
python setup.py db-init
```

## 🔧 Configuration

### Environment Variables
Create a `.env` file with the following configuration:

```env
# Database Configuration
DATABASE_URL=postgresql+asyncpg://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd
DB_ECHO=false
DB_POOL_SIZE=20

# Redis Configuration
REDIS_URL=redis://localhost:6379
CELERY_BROKER_URL=redis://localhost:6379

# Gateway Configuration
GATEWAY_HOST=0.0.0.0
GATEWAY_PORT=8000
DEBUG=true
JWT_SECRET=your-secret-key-change-in-production

# Airflow Configuration
AIRFLOW__CORE__EXECUTOR=LocalExecutor
AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=postgresql+psycopg2://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd
```

### Service URLs
- **FastAPI Gateway**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs
- **Apache Airflow**: http://localhost:8083 (admin/admin)
- **Prometheus Metrics**: http://localhost:8000/metrics

## 📋 Management Commands

```bash
# Check service status
python setup.py status

# View logs
python setup.py logs
python setup.py logs gateway  # Specific service

# Start/stop services
python setup.py start
python setup.py stop

# Initialize database
python setup.py db-init
```

## 🔄 Processing Pipeline

### BFSI Document Processing DAG
The main processing pipeline (`bfsi_document_processing_pipeline`) includes:

1. **Document Ingestion**
   - File validation and security scanning
   - Metadata extraction and storage
   - Duplicate detection

2. **OCR & AI Extraction**
   - Multi-engine OCR (Tesseract, PaddleOCR)
   - Image preprocessing and enhancement
   - AI-powered text extraction

3. **Classification**
   - ML-based document type classification
   - BFSI-specific categorization
   - Confidence scoring

4. **Compliance Check**
   - Regulatory framework validation
   - SOX, AML/BSA, GDPR compliance
   - Audit trail generation

5. **Output Routing**
   - Classification-based storage routing
   - Security level enforcement
   - Cloud/local distribution

### Real-time Processing
For urgent documents, use the `bfsi_realtime_document_processing` DAG:
- Triggered via API or file system events
- Optimized for speed over batch efficiency
- Priority queue management

## 🤖 AI/ML Models

### Supported Models
- **OCR**: Tesseract 5.x, PaddleOCR 2.7+
- **NLP**: Transformers (BERT, GPT-based models)
- **Classification**: scikit-learn, custom BFSI models
- **Entity Extraction**: spaCy, custom NER models

### GPU Support
Enable GPU acceleration by setting:
```env
ENABLE_GPU=true
```

Requires NVIDIA Docker runtime and CUDA-compatible GPUs.

## 📊 Monitoring & Metrics

### Prometheus Metrics
Available at `/metrics` endpoint:
- Request count and duration
- Processing job metrics
- Service health indicators
- Resource utilization

### Logging
Structured logging with configurable levels:
- JSON format for production
- Centralized log aggregation support
- Request tracing and correlation IDs

## 🔐 Security Features

### Authentication & Authorization
- JWT-based authentication
- Role-based access control (RBAC)
- Multi-tenant organization isolation

### File Security
- Virus scanning integration
- Content-based security validation
- Quarantine system for suspicious files

### Data Protection
- Encryption at rest and in transit
- PII detection and masking
- Audit logging for compliance

## 🐳 Docker Configuration

### Services
- **gateway**: FastAPI gateway service
- **workers**: Celery processing workers
- **airflow-webserver**: Airflow web interface
- **airflow-scheduler**: Airflow task scheduler
- **postgres**: PostgreSQL database (shared)
- **redis**: Redis cache and message broker

### Volumes
- `postgres_data`: Database persistence
- `redis_data`: Redis persistence
- `processing_data`: Document processing storage
- `airflow_logs`: Airflow execution logs

## 🔧 Development

### Running in Development Mode
```bash
# Start database services only
docker-compose up -d postgres redis

# Run services locally
export DATABASE_URL="postgresql+asyncpg://postgres:RND_Admin123!@localhost:5432/docintel_pro_rnd"
export REDIS_URL="redis://localhost:6379"

# Start gateway
cd gateway && python main.py

# Start workers
cd processing_workers && celery worker -A tasks --loglevel=info

# Start Airflow
cd workflow_orchestration && airflow standalone
```

### Testing
```bash
# Run unit tests
pytest tests/

# Run integration tests
pytest tests/integration/

# Load testing
locust -f tests/load/gateway_load_test.py
```

## 🚀 Performance Characteristics

### Expected Performance
- **Gateway**: 20,000+ requests/second
- **OCR Processing**: 10-50 documents/minute (depending on complexity)
- **Classification**: 100+ documents/second
- **Memory Usage**: 30-40% lower than .NET equivalent
- **I/O Performance**: 2-3x faster for file operations

### Scaling
- Horizontal scaling via Docker Swarm or Kubernetes
- Auto-scaling based on queue depth
- Resource-aware task distribution

## 🔗 Integration

### Node.js Server Integration
The Python services integrate with the existing Node.js server:
- Shared PostgreSQL database
- Common authentication system
- Unified API endpoints via gateway

### Frontend Integration
- Real-time updates via WebSocket
- RESTful API compatibility
- Standardized response formats

## 📝 API Documentation

### Gateway Endpoints
- `GET /health`: Health check
- `GET /metrics`: Prometheus metrics
- `POST /api/processing/*`: Processing service proxy
- `GET /api/analytics/*`: Analytics service proxy
- `POST /api/workflows/*`: Workflow service proxy

### Processing APIs
- Document upload and ingestion
- Processing job management
- Classification results
- Compliance reports

Full API documentation available at http://localhost:8000/docs when running.

## 🛠️ Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check if PostgreSQL is running
   docker-compose ps postgres
   
   # Restart database
   docker-compose restart postgres
   ```

2. **Import Errors**
   ```bash
   # Install missing dependencies
   pip install -r requirements.txt
   
   # Check Python path
   export PYTHONPATH="${PYTHONPATH}:/app/shared"
   ```

3. **OCR Not Working**
   ```bash
   # Install Tesseract
   apt-get install tesseract-ocr tesseract-ocr-eng
   
   # Check GPU availability
   python -c "import torch; print(torch.cuda.is_available())"
   ```

### Performance Tuning
- Adjust worker concurrency based on CPU cores
- Configure Redis memory settings
- Tune database connection pool sizes
- Enable GPU acceleration for AI models

## 📚 Additional Resources

- [Python Architecture Document](../python_based_architecture.md)
- [Processing Flow Documentation](../document_processing_flow_example.md)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [Apache Airflow Documentation](https://airflow.apache.org/docs/)
- [Celery Documentation](https://docs.celeryproject.org/)

## 🤝 Contributing

1. Follow PEP 8 style guidelines
2. Add type hints to all functions
3. Write comprehensive tests
4. Update documentation for new features
5. Use structured logging for debugging

## 📄 License

This project is part of the DocIntelPro BFSI platform. See the main project license for details.
