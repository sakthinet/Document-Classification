"""
FastAPI Gateway Service for DocIntelPro BFSI Platform.
High-performance Python gateway with async request handling.
"""

import os
import logging
from contextlib import asynccontextmanager
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, Depends, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
import httpx
import structlog
from pydantic import BaseModel
import uvicorn
from prometheus_client import Counter, Histogram, generate_latest
import time

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)

# Prometheus metrics
REQUEST_COUNT = Counter('gateway_requests_total', 'Total requests', ['method', 'endpoint', 'status'])
REQUEST_DURATION = Histogram('gateway_request_duration_seconds', 'Request duration')
BACKEND_REQUEST_COUNT = Counter('gateway_backend_requests_total', 'Backend requests', ['service', 'status'])


# Configuration
class GatewayConfig(BaseModel):
    """Gateway configuration."""
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:5000"]
    trusted_hosts: list[str] = ["localhost", "127.0.0.1"]
    
    # Service endpoints
    user_service_url: str = "http://localhost:8001"
    processing_service_url: str = "http://localhost:8002"
    analytics_service_url: str = "http://localhost:8003"
    workflow_service_url: str = "http://localhost:8004"
    airflow_service_url: str = "http://localhost:8083"
    
    # Security
    jwt_secret: str = "your-secret-key-change-in-production"
    jwt_algorithm: str = "HS256"
    
    # Rate limiting
    rate_limit_per_minute: int = 1000
    
    @classmethod
    def from_env(cls) -> "GatewayConfig":
        """Load configuration from environment variables."""
        return cls(
            host=os.getenv("GATEWAY_HOST", "0.0.0.0"),
            port=int(os.getenv("GATEWAY_PORT", "8000")),
            debug=os.getenv("DEBUG", "false").lower() == "true",
            cors_origins=os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5000").split(","),
            user_service_url=os.getenv("USER_SERVICE_URL", "http://localhost:8001"),
            processing_service_url=os.getenv("PROCESSING_SERVICE_URL", "http://localhost:8002"),
            analytics_service_url=os.getenv("ANALYTICS_SERVICE_URL", "http://localhost:8003"),
            workflow_service_url=os.getenv("WORKFLOW_SERVICE_URL", "http://localhost:8004"),
            airflow_service_url=os.getenv("AIRFLOW_SERVICE_URL", "http://localhost:8083"),
            jwt_secret=os.getenv("JWT_SECRET", "your-secret-key-change-in-production"),
        )


config = GatewayConfig.from_env()

# HTTP client for backend services
http_client: Optional[httpx.AsyncClient] = None

# Security
security = HTTPBearer()


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Get current user from JWT token."""
    # TODO: Implement JWT validation
    # For now, return a mock user
    return {
        "user_id": "3761d7a3-eace-492a-8cf2-eab83c28fd2f",
        "organization_id": "f5a5744d-f922-4918-b5ae-0d9a430b9b0b",
        "role": "admin"
    }


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    global http_client
    
    # Startup
    logger.info("Starting FastAPI Gateway", config=config.dict())
    
    # Initialize HTTP client
    http_client = httpx.AsyncClient(
        timeout=30.0,
        limits=httpx.Limits(max_keepalive_connections=20, max_connections=100)
    )
    
    yield
    
    # Shutdown
    logger.info("Shutting down FastAPI Gateway")
    if http_client:
        await http_client.aclose()


# Create FastAPI app
app = FastAPI(
    title="DocIntelPro BFSI Gateway",
    description="High-performance Python gateway for document intelligence platform",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if config.debug else None,
    redoc_url="/redoc" if config.debug else None,
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=config.trusted_hosts + ["*"] if config.debug else config.trusted_hosts
)


@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    """Collect request metrics."""
    start_time = time.time()
    
    response = await call_next(request)
    
    # Record metrics
    duration = time.time() - start_time
    REQUEST_COUNT.labels(
        method=request.method,
        endpoint=request.url.path,
        status=response.status_code
    ).inc()
    REQUEST_DURATION.observe(duration)
    
    # Add response headers
    response.headers["X-Response-Time"] = f"{duration:.3f}s"
    
    return response


@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    """Request logging middleware."""
    start_time = time.time()
    
    # Log request
    logger.info(
        "Request started",
        method=request.method,
        path=request.url.path,
        query=str(request.query_params),
        client_ip=request.client.host if request.client else None
    )
    
    response = await call_next(request)
    
    # Log response
    duration = time.time() - start_time
    logger.info(
        "Request completed",
        method=request.method,
        path=request.url.path,
        status_code=response.status_code,
        duration=f"{duration:.3f}s"
    )
    
    return response


# Routes
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "gateway",
        "version": "1.0.0",
        "timestamp": time.time()
    }


@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    return Response(generate_latest(), media_type="text/plain")


async def proxy_request(
    service_url: str,
    path: str,
    method: str,
    headers: Dict[str, str],
    query_params: Dict[str, Any] = None,
    json_data: Dict[str, Any] = None
) -> Dict[str, Any]:
    """Proxy request to backend service."""
    if not http_client:
        raise HTTPException(status_code=503, detail="HTTP client not initialized")
    
    url = f"{service_url}{path}"
    
    try:
        response = await http_client.request(
            method=method,
            url=url,
            headers=headers,
            params=query_params,
            json=json_data
        )
        
        BACKEND_REQUEST_COUNT.labels(
            service=service_url,
            status=response.status_code
        ).inc()
        
        if response.status_code >= 400:
            logger.warning(
                "Backend request failed",
                service=service_url,
                path=path,
                status_code=response.status_code,
                response=response.text
            )
        
        return {
            "status_code": response.status_code,
            "data": response.json() if response.headers.get("content-type", "").startswith("application/json") else response.text,
            "headers": dict(response.headers)
        }
        
    except httpx.RequestError as e:
        logger.error("Backend request error", service=service_url, path=path, error=str(e))
        BACKEND_REQUEST_COUNT.labels(service=service_url, status="error").inc()
        raise HTTPException(status_code=503, detail=f"Service unavailable: {str(e)}")


# User service routes
@app.api_route("/api/users/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def user_service_proxy(
    request: Request,
    path: str,
    current_user: dict = Depends(get_current_user)
):
    """Proxy requests to user service."""
    headers = dict(request.headers)
    headers["X-User-ID"] = current_user["user_id"]
    headers["X-Organization-ID"] = current_user["organization_id"]
    
    query_params = dict(request.query_params)
    json_data = await request.json() if request.headers.get("content-type", "").startswith("application/json") else None
    
    result = await proxy_request(
        service_url=config.user_service_url,
        path=f"/{path}",
        method=request.method,
        headers=headers,
        query_params=query_params,
        json_data=json_data
    )
    
    return JSONResponse(
        content=result["data"],
        status_code=result["status_code"]
    )


# Processing service routes
@app.api_route("/api/processing/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def processing_service_proxy(
    request: Request,
    path: str,
    current_user: dict = Depends(get_current_user)
):
    """Proxy requests to processing service."""
    headers = dict(request.headers)
    headers["X-User-ID"] = current_user["user_id"]
    headers["X-Organization-ID"] = current_user["organization_id"]
    
    query_params = dict(request.query_params)
    json_data = await request.json() if request.headers.get("content-type", "").startswith("application/json") else None
    
    result = await proxy_request(
        service_url=config.processing_service_url,
        path=f"/{path}",
        method=request.method,
        headers=headers,
        query_params=query_params,
        json_data=json_data
    )
    
    return JSONResponse(
        content=result["data"],
        status_code=result["status_code"]
    )


# Analytics service routes
@app.api_route("/api/analytics/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def analytics_service_proxy(
    request: Request,
    path: str,
    current_user: dict = Depends(get_current_user)
):
    """Proxy requests to analytics service."""
    headers = dict(request.headers)
    headers["X-User-ID"] = current_user["user_id"]
    headers["X-Organization-ID"] = current_user["organization_id"]
    
    query_params = dict(request.query_params)
    json_data = await request.json() if request.headers.get("content-type", "").startswith("application/json") else None
    
    result = await proxy_request(
        service_url=config.analytics_service_url,
        path=f"/{path}",
        method=request.method,
        headers=headers,
        query_params=query_params,
        json_data=json_data
    )
    
    return JSONResponse(
        content=result["data"],
        status_code=result["status_code"]
    )


# Workflow service routes
@app.api_route("/api/workflows/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def workflow_service_proxy(
    request: Request,
    path: str,
    current_user: dict = Depends(get_current_user)
):
    """Proxy requests to workflow service."""
    headers = dict(request.headers)
    headers["X-User-ID"] = current_user["user_id"]
    headers["X-Organization-ID"] = current_user["organization_id"]
    
    query_params = dict(request.query_params)
    json_data = await request.json() if request.headers.get("content-type", "").startswith("application/json") else None
    
    result = await proxy_request(
        service_url=config.workflow_service_url,
        path=f"/{path}",
        method=request.method,
        headers=headers,
        query_params=query_params,
        json_data=json_data
    )
    
    return JSONResponse(
        content=result["data"],
        status_code=result["status_code"]
    )


# Airflow service routes
@app.api_route("/api/airflow/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def airflow_service_proxy(
    request: Request,
    path: str,
    current_user: dict = Depends(get_current_user)
):
    """Proxy requests to Airflow service."""
    headers = dict(request.headers)
    headers["X-User-ID"] = current_user["user_id"]
    headers["X-Organization-ID"] = current_user["organization_id"]
    
    query_params = dict(request.query_params)
    json_data = await request.json() if request.headers.get("content-type", "").startswith("application/json") else None
    
    result = await proxy_request(
        service_url=config.airflow_service_url,
        path=f"/{path}",
        method=request.method,
        headers=headers,
        query_params=query_params,
        json_data=json_data
    )
    
    return JSONResponse(
        content=result["data"],
        status_code=result["status_code"]
    )
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions."""
    logger.warning(
        "HTTP exception",
        path=request.url.path,
        status_code=exc.status_code,
        detail=exc.detail
    )
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail}
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions."""
    logger.error(
        "Unhandled exception",
        path=request.url.path,
        error=str(exc),
        exc_info=True
    )
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error"}
    )


if __name__ == "__main__":
    # Configure uvicorn logging
    logging.getLogger("uvicorn.access").handlers = []
    
    uvicorn.run(
        "main:app",
        host=config.host,
        port=config.port,
        reload=config.debug,
        log_config=None,  # Disable uvicorn's default logging
        access_log=False,  # We handle access logging in middleware
    )
