"""
Simple test script to verify Python services setup.
"""

import asyncio
import sys
import os
from pathlib import Path

# Add shared modules to path
sys.path.append(str(Path(__file__).parent / 'shared'))

async def test_database_connection():
    """Test database connection."""
    try:
        from shared.database import engine
        
        async with engine.begin() as conn:
            result = await conn.execute("SELECT 1 as test")
            row = result.fetchone()
            print(f"✓ Database connection successful: {row}")
            return True
    except Exception as e:
        print(f"✗ Database connection failed: {e}")
        return False

def test_model_imports():
    """Test model imports."""
    try:
        from shared.models import Document, ProcessingJob, Organization
        from shared.db_models import User, BfsiDocumentTypeModel
        print("✓ Model imports successful")
        return True
    except Exception as e:
        print(f"✗ Model imports failed: {e}")
        return False

def test_basic_functionality():
    """Test basic functionality."""
    try:
        # Test Pydantic models
        from shared.models import DocumentCreate, BfsiDocumentType
        
        doc_data = {
            'filename': 'test.pdf',
            'file_path': '/path/to/test.pdf',
            'file_size': 1024,
            'mime_type': 'application/pdf',
            'file_hash': 'abc123',
            'organization_id': 'f5a5744d-f922-4918-b5ae-0d9a430b9b0b',
            'uploaded_by': '3761d7a3-eace-492a-8cf2-eab83c28fd2f'
        }
        
        doc = DocumentCreate(**doc_data)
        print(f"✓ Pydantic model validation successful: {doc.filename}")
        
        # Test enum
        doc_type = BfsiDocumentType.LOAN_APPLICATION
        print(f"✓ Enum handling successful: {doc_type}")
        
        return True
    except Exception as e:
        print(f"✗ Basic functionality test failed: {e}")
        return False

async def run_tests():
    """Run all tests."""
    print("🐍 DocIntelPro Python Services Test Suite")
    print("=" * 50)
    
    tests = [
        ("Model Imports", test_model_imports),
        ("Basic Functionality", test_basic_functionality),
        ("Database Connection", test_database_connection),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\nRunning {test_name}...")
        try:
            if asyncio.iscoroutinefunction(test_func):
                result = await test_func()
            else:
                result = test_func()
            results.append(result)
        except Exception as e:
            print(f"✗ {test_name} failed with exception: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("Test Summary:")
    passed = sum(results)
    total = len(results)
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 All tests passed! Python services are ready.")
        return True
    else:
        print("❌ Some tests failed. Check the setup.")
        return False

if __name__ == "__main__":
    try:
        success = asyncio.run(run_tests())
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\nTest interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Test suite failed: {e}")
        sys.exit(1)
