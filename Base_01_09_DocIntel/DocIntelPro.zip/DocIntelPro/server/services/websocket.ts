import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';

interface WebSocketMessage {
  type: string;
  data: any;
  organizationId?: string;
  timestamp: string;
}

export class DocumentIntelligenceWebSocket {
  private wss: WebSocketServer;
  private clients: Map<WebSocket, { organizationId: string; userId: string }> = new Map();

  constructor(server: Server) {
    this.wss = new WebSocketServer({ server, path: '/ws' });
    this.setupWebSocket();
  }

  private setupWebSocket() {
    this.wss.on('connection', (ws: WebSocket, request) => {
      console.log('New WebSocket connection established');

      ws.on('message', (data: string) => {
        try {
          const message = JSON.parse(data);
          this.handleMessage(ws, message);
        } catch (error) {
          console.error('Invalid WebSocket message:', error);
          this.sendError(ws, 'Invalid message format');
        }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
        console.log('WebSocket connection closed');
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        this.clients.delete(ws);
      });

      // Send welcome message
      this.sendMessage(ws, {
        type: 'connection',
        data: { status: 'connected', message: 'Welcome to Document Intelligence Platform' },
        timestamp: new Date().toISOString()
      });
    });
  }

  private handleMessage(ws: WebSocket, message: any) {
    switch (message.type) {
      case 'authenticate':
        this.handleAuthentication(ws, message);
        break;
      case 'subscribe':
        this.handleSubscription(ws, message);
        break;
      case 'ping':
        this.sendMessage(ws, {
          type: 'pong',
          data: { timestamp: new Date().toISOString() },
          timestamp: new Date().toISOString()
        });
        break;
      default:
        this.sendError(ws, `Unknown message type: ${message.type}`);
    }
  }

  private handleAuthentication(ws: WebSocket, message: any) {
    const { organizationId, userId } = message.data;
    
    if (!organizationId || !userId) {
      this.sendError(ws, 'Missing organizationId or userId');
      return;
    }

    // Store client information
    this.clients.set(ws, { organizationId, userId });

    this.sendMessage(ws, {
      type: 'authenticated',
      data: { organizationId, userId, status: 'authenticated' },
      timestamp: new Date().toISOString()
    });

    console.log(`WebSocket authenticated for user ${userId} in org ${organizationId}`);
  }

  private handleSubscription(ws: WebSocket, message: any) {
    const client = this.clients.get(ws);
    if (!client) {
      this.sendError(ws, 'Not authenticated');
      return;
    }

    // Handle subscription to specific data streams
    const { channel } = message.data;
    console.log(`Client subscribed to channel: ${channel}`);

    this.sendMessage(ws, {
      type: 'subscribed',
      data: { channel, status: 'subscribed' },
      timestamp: new Date().toISOString()
    });
  }

  private sendMessage(ws: WebSocket, message: WebSocketMessage) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }

  private sendError(ws: WebSocket, error: string) {
    this.sendMessage(ws, {
      type: 'error',
      data: { error },
      timestamp: new Date().toISOString()
    });
  }

  // Public methods for broadcasting updates
  public broadcastToOrganization(organizationId: string, message: WebSocketMessage) {
    this.clients.forEach((client, ws) => {
      if (client.organizationId === organizationId && ws.readyState === WebSocket.OPEN) {
        this.sendMessage(ws, { ...message, organizationId });
      }
    });
  }

  public broadcastProcessingUpdate(organizationId: string, jobData: any) {
    this.broadcastToOrganization(organizationId, {
      type: 'processing_update',
      data: jobData,
      timestamp: new Date().toISOString()
    });
  }

  public broadcastMetricsUpdate(organizationId: string, metrics: any) {
    this.broadcastToOrganization(organizationId, {
      type: 'metrics_update',
      data: metrics,
      timestamp: new Date().toISOString()
    });
  }

  public broadcastDocumentClassified(organizationId: string, documentData: any) {
    this.broadcastToOrganization(organizationId, {
      type: 'document_classified',
      data: documentData,
      timestamp: new Date().toISOString()
    });
  }

  public broadcastComplianceAlert(organizationId: string, alertData: any) {
    this.broadcastToOrganization(organizationId, {
      type: 'compliance_alert',
      data: alertData,
      timestamp: new Date().toISOString()
    });
  }

  public broadcastSystemNotification(organizationId: string, notification: any) {
    this.broadcastToOrganization(organizationId, {
      type: 'system_notification',
      data: notification,
      timestamp: new Date().toISOString()
    });
  }

  public getConnectedClients(organizationId?: string): number {
    if (organizationId) {
      return Array.from(this.clients.values()).filter(client => 
        client.organizationId === organizationId
      ).length;
    }
    return this.clients.size;
  }
}

export let wsService: DocumentIntelligenceWebSocket;

export function initializeWebSocket(server: Server): DocumentIntelligenceWebSocket {
  wsService = new DocumentIntelligenceWebSocket(server);
  return wsService;
}
