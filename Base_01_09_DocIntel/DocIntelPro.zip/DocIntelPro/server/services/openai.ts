import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "sk-your-key-here"
});

export interface DocumentClassificationResult {
  documentType: string;
  classificationLevel: 'confidential' | 'restricted' | 'internal' | 'public';
  confidence: number;
  reasoning: string;
  detectedPII: string[];
  domain: 'bfsi' | 'healthcare' | 'general';
}

export interface PIIDetectionResult {
  containsPii: boolean;
  piiTypes: string[];
  confidence: number;
  details: Array<{
    type: string;
    description: string;
    severity: 'high' | 'medium' | 'low';
  }>;
}

export async function classifyDocument(
  ocrText: string,
  fileName: string,
  domain: 'bfsi' | 'healthcare' | 'general' = 'general'
): Promise<DocumentClassificationResult> {
  try {
    const domainContext = {
      bfsi: `
        BFSI Document Types:
        - Loan Applications (confidential - contains financial data)
        - KYC Documents (confidential - contains personal identification)
        - Financial Statements (restricted - contains financial performance data)
        - Policy Documents (internal - insurance policies and terms)
        - Claims Processing (restricted - contains claim details and payouts)
        - Risk Assessments (internal - risk analysis and scoring)
        - Transaction Records (confidential - payment and transaction history)
        - Compliance Reports (internal - regulatory compliance documentation)
      `,
      healthcare: `
        Healthcare Document Types:
        - Medical Records (confidential - contains patient health information)
        - Lab Reports (confidential - contains test results and diagnoses)
        - Patient Consent Forms (restricted - contains patient agreements)
        - Insurance Claims (restricted - contains coverage and billing info)
        - Prescription Documents (confidential - contains medication information)
        - Clinical Notes (confidential - contains physician observations)
        - Discharge Summaries (confidential - contains treatment outcomes)
      `,
      general: 'General business documents with standard classification levels.'
    };

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an expert document classification AI specialized in ${domain.toUpperCase()} domain documents. 
          
          ${domainContext[domain]}
          
          Classification Levels:
          - CONFIDENTIAL: Contains highly sensitive data (PII, PHI, financial data) - Local storage only
          - RESTRICTED: Contains sensitive business data - Local storage + encrypted backup
          - INTERNAL: Contains internal business information - Local + selective cloud sync
          - PUBLIC: Contains public or non-sensitive information - Full cloud sync allowed
          
          Analyze the document content and filename to determine:
          1. Document type (specific to ${domain} domain)
          2. Classification level based on sensitivity
          3. Confidence score (0-100)
          4. Reasoning for the classification
          5. Any detected PII/PHI
          
          Respond with JSON in this exact format:
          {
            "documentType": "specific document type",
            "classificationLevel": "confidential|restricted|internal|public",
            "confidence": number,
            "reasoning": "explanation of classification decision",
            "detectedPII": ["array", "of", "pii", "types"],
            "domain": "${domain}"
          }`
        },
        {
          role: "user",
          content: `Classify this document:
          
          Filename: ${fileName}
          
          Content: ${ocrText.substring(0, 4000)}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      documentType: result.documentType || 'Unknown',
      classificationLevel: result.classificationLevel || 'internal',
      confidence: Math.max(0, Math.min(100, result.confidence || 0)),
      reasoning: result.reasoning || 'No reasoning provided',
      detectedPII: result.detectedPII || [],
      domain: result.domain || domain
    };
  } catch (error) {
    console.error('Document classification failed:', error);
    throw new Error(`Failed to classify document: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function detectPII(text: string, domain: 'bfsi' | 'healthcare' | 'general' = 'general'): Promise<PIIDetectionResult> {
  try {
    const domainPIITypes = {
      bfsi: `
        BFSI PII Types:
        - Social Security Numbers (SSN)
        - Account Numbers (Bank, Credit Card)
        - Routing Numbers
        - Driver's License Numbers
        - Tax ID Numbers
        - Credit Scores
        - Financial Account Balances
        - Income Information
        - Employment Details
        - Date of Birth
        - Full Names
        - Addresses
        - Phone Numbers
        - Email Addresses
      `,
      healthcare: `
        Healthcare PII/PHI Types:
        - Patient IDs
        - Medical Record Numbers
        - Social Security Numbers
        - Date of Birth
        - Full Names
        - Addresses
        - Phone Numbers
        - Email Addresses
        - Medical Diagnoses
        - Treatment Information
        - Prescription Details
        - Test Results
        - Insurance Information
        - Emergency Contacts
        - Physician Names
      `,
      general: 'Standard PII types: Names, addresses, phone numbers, email addresses, SSN, etc.'
    };

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a PII/PHI detection specialist for ${domain.toUpperCase()} documents.
          
          ${domainPIITypes[domain]}
          
          Analyze the text and identify any personally identifiable information (PII) or protected health information (PHI).
          
          Severity Levels:
          - HIGH: Direct identifiers (SSN, Medical Record Numbers, Account Numbers)
          - MEDIUM: Quasi-identifiers (Names + DOB, Addresses)
          - LOW: General identifiers (Email, Phone without context)
          
          Respond with JSON in this exact format:
          {
            "containsPii": boolean,
            "piiTypes": ["array", "of", "detected", "types"],
            "confidence": number,
            "details": [
              {
                "type": "PII type name",
                "description": "what was detected",
                "severity": "high|medium|low"
              }
            ]
          }`
        },
        {
          role: "user",
          content: `Analyze this text for PII/PHI:
          
          ${text.substring(0, 3000)}`
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.1
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      containsPii: result.containsPii || false,
      piiTypes: result.piiTypes || [],
      confidence: Math.max(0, Math.min(100, result.confidence || 0)),
      details: result.details || []
    };
  } catch (error) {
    console.error('PII detection failed:', error);
    throw new Error(`Failed to detect PII: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generateDocumentSummary(text: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a document summarization expert. Create concise, informative summaries that capture the key points and purpose of documents."
        },
        {
          role: "user",
          content: `Please summarize this document content concisely while maintaining key information:

          ${text.substring(0, 4000)}`
        }
      ],
      max_tokens: 200,
      temperature: 0.3
    });

    return response.choices[0].message.content || 'No summary available';
  } catch (error) {
    console.error('Document summarization failed:', error);
    throw new Error(`Failed to generate summary: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
