import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { randomUUID } from "crypto";

// Extend Express Request type to include our custom properties
interface AuthenticatedRequest extends Request {
  organizationId: string;
  userId: string;
}

export function registerRoutes(app: Express): Server {
  const httpServer = createServer(app);

  // Middleware for organization-based access control
  const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
    // TODO: Implement proper JWT authentication
    // For now, we'll use real UUIDs from the database
    const organizationId = req.headers['x-organization-id'] as string || 'f5a5744d-f922-4918-b5ae-0d9a430b9b0b';
    const userId = req.headers['x-user-id'] as string || '3761d7a3-eace-492a-8cf2-eab83c28fd2f';
    
    (req as AuthenticatedRequest).organizationId = organizationId;
    (req as AuthenticatedRequest).userId = userId;
    next();
  };

  // Health check endpoint
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      service: 'DocIntelPro BFSI API'
    });
  });

  // Dashboard metrics endpoint
  app.get('/api/dashboard/metrics', requireAuth, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const metrics = await storage.getDashboardMetrics(authReq.organizationId);
      res.json(metrics);
    } catch (error) {
      console.error('Failed to fetch dashboard metrics:', error);
      res.status(500).json({ message: 'Failed to fetch dashboard metrics' });
    }
  });

  // BFSI Document Types endpoints
  app.get('/api/bfsi/document-types', async (req: Request, res: Response) => {
    try {
      const documentTypes = await storage.getBfsiDocumentTypes();
      res.json(documentTypes);
    } catch (error) {
      console.error('Failed to fetch BFSI document types:', error);
      res.status(500).json({ message: 'Failed to fetch document types' });
    }
  });

  app.get('/api/bfsi/document-types/:typeKey', async (req: Request, res: Response) => {
    try {
      const { typeKey } = req.params;
      const documentType = await storage.getBfsiDocumentTypeByKey(typeKey);
      if (!documentType) {
        return res.status(404).json({ message: 'Document type not found' });
      }
      res.json(documentType);
    } catch (error) {
      console.error('Failed to fetch BFSI document type:', error);
      res.status(500).json({ message: 'Failed to fetch document type' });
    }
  });

  // Document Sources endpoints
  app.get('/api/sources', requireAuth, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const sources = await storage.getDocumentSourcesByOrganization(authReq.organizationId);
      res.json(sources);
    } catch (error) {
      console.error('Failed to fetch document sources:', error);
      res.status(500).json({ message: 'Failed to fetch document sources' });
    }
  });

  app.post('/api/sources', requireAuth, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      
      console.log('=== CREATE DOCUMENT SOURCE DEBUG ===');
      console.log('Raw request body:', JSON.stringify(req.body, null, 2));
      
      // Only include the fields that we know are safe and match the schema
      const sourceData = {
        organizationId: authReq.organizationId,
        name: req.body.name,
        type: req.body.type,
        connectionConfig: req.body.connectionConfig || {},
        authenticationConfig: req.body.authenticationConfig || {},
        scanSchedule: req.body.scanSchedule || 'manual',
        status: req.body.status || 'active',
        errorMessage: req.body.errorMessage || null,
        isActive: req.body.isActive !== undefined ? req.body.isActive : true,
        domain: req.body.domain || 'bfsi',
        documentTypes: req.body.documentTypes || [],
        complianceLevel: req.body.complianceLevel || 'internal',
        // lastScan should remain null for new sources
        lastScan: null
      };
      
      console.log('Cleaned source data:', JSON.stringify(sourceData, null, 2));
      console.log('=== END DEBUG ===');
      
      const source = await storage.createDocumentSource(sourceData);
      res.status(201).json(source);
    } catch (error) {
      console.error('Failed to create document source:', error);
      res.status(500).json({ message: 'Failed to create document source' });
    }
  });

  app.get('/api/sources/:id', requireAuth, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const source = await storage.getDocumentSource(id);
      if (!source) {
        return res.status(404).json({ message: 'Document source not found' });
      }
      res.json(source);
    } catch (error) {
      console.error('Failed to fetch document source:', error);
      res.status(500).json({ message: 'Failed to fetch document source' });
    }
  });

  app.put('/api/sources/:id', requireAuth, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const updates = {
        ...req.body
        // Don't manually set updatedAt - let the database handle it
      };
      
      // Remove timestamp fields that might cause issues
      delete updates.createdAt;
      delete updates.updatedAt;
      delete updates.lastSyncAt;
      delete updates.lastScan;
      
      const source = await storage.updateDocumentSource(id, updates);
      if (!source) {
        return res.status(404).json({ message: 'Document source not found' });
      }
      res.json(source);
    } catch (error) {
      console.error('Failed to update document source:', error);
      res.status(500).json({ message: 'Failed to update document source' });
    }
  });

  app.delete('/api/sources/:id', requireAuth, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteDocumentSource(id);
      if (!success) {
        return res.status(404).json({ message: 'Document source not found' });
      }
      res.status(204).send();
    } catch (error) {
      console.error('Failed to delete document source:', error);
      res.status(500).json({ message: 'Failed to delete document source' });
    }
  });

  app.post('/api/sources/:id/test', requireAuth, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const result = await storage.testDocumentSourceConnection(id);
      res.json(result);
    } catch (error) {
      console.error('Failed to test document source connection:', error);
      res.status(500).json({ message: 'Failed to test connection' });
    }
  });

  // Document Destinations endpoints (placeholder for now)
  app.get('/api/destinations', requireAuth, async (req: Request, res: Response) => {
    try {
      // For now, return an empty array - destinations will be implemented later
      res.json([]);
    } catch (error) {
      console.error('Failed to fetch destinations:', error);
      res.status(500).json({ message: 'Failed to fetch destinations' });
    }
  });

  // Processing Jobs endpoints
  app.get('/api/processing/jobs/active', requireAuth, async (req: Request, res: Response) => {
    try {
      const authReq = req as AuthenticatedRequest;
      const jobs = await storage.getProcessingJobsByOrganization(authReq.organizationId);
      res.json(jobs);
    } catch (error) {
      console.error('Failed to fetch active processing jobs:', error);
      res.status(500).json({ message: 'Failed to fetch active jobs' });
    }
  });

  // Organizations endpoints
  app.get('/api/organizations/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const organization = await storage.getOrganization(id);
      if (!organization) {
        return res.status(404).json({ message: 'Organization not found' });
      }
      res.json(organization);
    } catch (error) {
      console.error('Failed to fetch organization:', error);
      res.status(500).json({ message: 'Failed to fetch organization' });
    }
  });

  return httpServer;
}
