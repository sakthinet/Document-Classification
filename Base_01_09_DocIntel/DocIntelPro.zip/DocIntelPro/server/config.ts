// Load environment variables first, before any other imports
import dotenv from "dotenv";
dotenv.config();

// Database configuration for PostgreSQL RND
export const config = {
  database: {
    url: process.env.DATABASE_URL || "postgresql://postgres:password@localhost:5432/RND",
    maxConnections: parseInt(process.env.DB_MAX_CONNECTIONS || "20"),
    ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  },
  server: {
    port: parseInt(process.env.PORT || "5000"),
    host: process.env.HOST || "localhost",
    cors: {
      origin: process.env.CORS_ORIGIN || "http://localhost:5173",
      credentials: true,
    },
  },
  python: {
    gatewayUrl: process.env.PYTHON_GATEWAY_URL || "http://localhost:8000",
    ocrServiceUrl: process.env.OCR_SERVICE_URL || "http://localhost:8001",
    classificationServiceUrl: process.env.CLASSIFICATION_SERVICE_URL || "http://localhost:8002",
    vectorSearchServiceUrl: process.env.VECTOR_SEARCH_SERVICE_URL || "http://localhost:8003",
    piiDetectionServiceUrl: process.env.PII_DETECTION_SERVICE_URL || "http://localhost:8004",
  },
  bfsi: {
    defaultOrganizationId: process.env.DEFAULT_ORGANIZATION_ID || "f5a5744d-f922-4918-b5ae-0d9a430b9b0b",
    defaultUserId: process.env.DEFAULT_USER_ID || "3761d7a3-eace-492a-8cf2-eab83c28fd2f",
    defaultDocumentTypes: [
      "LOAN_APPLICATION",
      "CREDIT_REPORT", 
      "LOAN_AGREEMENT",
      "KYC_DOCUMENT",
      "AML_REPORT",
      "SAR_FILING",
      "FINANCIAL_STATEMENT",
      "AUDIT_REPORT",
      "TAX_DOCUMENT",
      "INSURANCE_POLICY",
      "INSURANCE_CLAIM",
      "INVESTMENT_AGREEMENT",
      "PROSPECTUS",
      "WIRE_TRANSFER",
      "TRANSACTION_RECORD"
    ],
    complianceFrameworks: [
      "SOX", "BSA", "AML", "GLBA", "FCRA", "TILA", "PATRIOT_Act",
      "FinCEN", "SEC", "FINRA", "OFAC", "PCAOB", "GAAP"
    ],
  },
};
