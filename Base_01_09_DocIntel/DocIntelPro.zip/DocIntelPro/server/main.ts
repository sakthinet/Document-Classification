import express from 'express';
import cors from 'cors';
import './config.js'; // Load environment variables
import { pool } from './db.js';

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173'
}));
app.use(express.json());

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'DocIntelPro API Server',
    version: '1.0.0'
  });
});

// Database test endpoint
app.get('/api/test-db', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW() as current_time, version() as version');
    client.release();
    res.json({ 
      status: 'success', 
      message: 'Database connection successful',
      current_time: result.rows[0].current_time,
      database_version: result.rows[0].version
    });
  } catch (err) {
    console.error('Database test error:', err);
    res.status(500).json({ 
      status: 'error', 
      message: 'Database connection failed',
      error: err.message 
    });
  }
});

// BFSI Document Types endpoint
app.get('/api/bfsi-document-types', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query(`
      SELECT id, name, description, compliance_frameworks, 
             required_fields, validation_rules, created_at 
      FROM bfsi_document_types 
      ORDER BY name
    `);
    client.release();
    res.json({ 
      status: 'success',
      count: result.rows.length,
      document_types: result.rows
    });
  } catch (err) {
    console.error('BFSI document types error:', err);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch BFSI document types',
      error: err.message 
    });
  }
});

// Organizations endpoint
app.get('/api/organizations', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query(`
      SELECT id, name, industry_type, compliance_framework, 
             contact_email, created_at 
      FROM organizations 
      ORDER BY name 
      LIMIT 20
    `);
    client.release();
    res.json({ 
      status: 'success',
      count: result.rows.length,
      organizations: result.rows
    });
  } catch (err) {
    console.error('Organizations error:', err);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch organizations',
      error: err.message 
    });
  }
});

// Dashboard metrics endpoint
app.get('/api/dashboard-metrics', async (req, res) => {
  try {
    const client = await pool.connect();
    
    // Get comprehensive metrics
    const queries = await Promise.all([
      client.query('SELECT COUNT(*) as count FROM documents'),
      client.query('SELECT COUNT(*) as count FROM organizations'),
      client.query('SELECT COUNT(*) as count FROM users'),
      client.query('SELECT COUNT(*) as count FROM bfsi_document_types'),
      client.query(`
        SELECT document_type, COUNT(*) as count 
        FROM documents 
        GROUP BY document_type 
        ORDER BY count DESC 
        LIMIT 5
      `),
      client.query(`
        SELECT compliance_status, COUNT(*) as count 
        FROM documents 
        WHERE compliance_status IS NOT NULL
        GROUP BY compliance_status
      `)
    ]);
    
    client.release();
    
    const [docCount, orgCount, userCount, bfsiTypeCount, topDocTypes, complianceStatus] = queries;
    
    res.json({ 
      status: 'success',
      metrics: {
        totals: {
          documents: parseInt(docCount.rows[0].count),
          organizations: parseInt(orgCount.rows[0].count),
          users: parseInt(userCount.rows[0].count),
          bfsi_document_types: parseInt(bfsiTypeCount.rows[0].count)
        },
        top_document_types: topDocTypes.rows,
        compliance_status_breakdown: complianceStatus.rows,
        generated_at: new Date().toISOString()
      }
    });
  } catch (err) {
    console.error('Dashboard metrics error:', err);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch dashboard metrics',
      error: err.message 
    });
  }
});

// Documents endpoint with pagination
app.get('/api/documents', async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = (page - 1) * limit;
    
    const client = await pool.connect();
    
    const [documentsResult, countResult] = await Promise.all([
      client.query(`
        SELECT d.id, d.filename, d.document_type, d.file_size, 
               d.compliance_status, d.uploaded_at, d.processed_at,
               o.name as organization_name, u.email as uploaded_by
        FROM documents d
        LEFT JOIN organizations o ON d.organization_id = o.id
        LEFT JOIN users u ON d.uploaded_by = u.id
        ORDER BY d.uploaded_at DESC
        LIMIT $1 OFFSET $2
      `, [limit, offset]),
      client.query('SELECT COUNT(*) as total FROM documents')
    ]);
    
    client.release();
    
    const total = parseInt(countResult.rows[0].total);
    const totalPages = Math.ceil(total / limit);
    
    res.json({
      status: 'success',
      documents: documentsResult.rows,
      pagination: {
        current_page: page,
        total_pages: totalPages,
        total_documents: total,
        limit,
        has_next: page < totalPages,
        has_prev: page > 1
      }
    });
  } catch (err) {
    console.error('Documents error:', err);
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch documents',
      error: err.message 
    });
  }
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    status: 'error',
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    status: 'error',
    message: 'Route not found',
    available_endpoints: [
      'GET /health',
      'GET /api/test-db',
      'GET /api/bfsi-document-types',
      'GET /api/organizations',
      'GET /api/dashboard-metrics',
      'GET /api/documents'
    ]
  });
});

// Start server with database connection test
async function startServer() {
  try {
    // Test database connection
    const client = await pool.connect();
    console.log('✅ Database connection successful');
    const result = await client.query('SELECT version()');
    console.log('📊 Database:', result.rows[0].version);
    client.release();
    
    // Start the server
    app.listen(port, () => {
      console.log(`\n🚀 DocIntelPro API Server running on http://localhost:${port}`);
      console.log('📋 Available API endpoints:');
      console.log(`   • GET  /health                    - Health check`);
      console.log(`   • GET  /api/test-db               - Database test`);
      console.log(`   • GET  /api/bfsi-document-types   - BFSI document types`);
      console.log(`   • GET  /api/organizations         - Organizations`);
      console.log(`   • GET  /api/dashboard-metrics     - Dashboard metrics`);
      console.log(`   • GET  /api/documents             - Documents with pagination`);
      console.log(`\n🌐 Frontend URL: ${process.env.CORS_ORIGIN}`);
      console.log('✅ Server ready for connections!\n');
    });
    
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down server gracefully...');
  try {
    await pool.end();
    console.log('✅ Database connections closed');
  } catch (err) {
    console.error('❌ Error closing database connections:', err);
  }
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('\n🛑 Received SIGTERM, shutting down...');
  try {
    await pool.end();
    console.log('✅ Database connections closed');
  } catch (err) {
    console.error('❌ Error closing database connections:', err);
  }
  process.exit(0);
});

// Start the application
startServer().catch(console.error);
