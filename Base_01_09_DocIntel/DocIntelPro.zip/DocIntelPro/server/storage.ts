import {
  organizations,
  users,
  documentSources,
  bfsiDocumentTypes,
  processingJobs,
  documents,
  auditLogs,
  type Organization,
  type User,
  type DocumentSource,
  type ProcessingJob,
  type Document,
  type AuditLog,
  type NewOrganization,
  type NewUser,
  type NewDocumentSource,
  type NewProcessingJob,
  type NewDocument,
  type NewAuditLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, count, isNull } from "drizzle-orm";

export interface IStorage {
  // Organizations
  getOrganization(id: string): Promise<Organization | undefined>;
  getOrganizationByDomain(domain: string): Promise<Organization | undefined>;
  createOrganization(org: NewOrganization): Promise<Organization>;

  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsersByOrganization(organizationId: string): Promise<User[]>;
  createUser(user: NewUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Document Sources
  getDocumentSource(id: string): Promise<DocumentSource | undefined>;
  getDocumentSourcesByOrganization(organizationId: string): Promise<DocumentSource[]>;
  createDocumentSource(source: NewDocumentSource): Promise<DocumentSource>;
  updateDocumentSource(id: string, updates: Partial<DocumentSource>): Promise<DocumentSource | undefined>;
  deleteDocumentSource(id: string): Promise<boolean>;
  testDocumentSourceConnection(id: string): Promise<{ success: boolean; message: string }>;

  // BFSI Document Types
  getBfsiDocumentTypes(): Promise<any[]>;
  getBfsiDocumentTypeByKey(typeKey: string): Promise<any | undefined>;
  getBfsiDocumentTypesByCategory(category: string): Promise<any[]>;

  // Documents
  getDocument(id: string): Promise<Document | undefined>;
  getDocumentsByOrganization(organizationId: string, limit?: number, offset?: number): Promise<Document[]>;
  getDocumentsBySource(sourceId: string): Promise<Document[]>;
  createDocument(doc: NewDocument): Promise<Document>;
  updateDocument(id: string, updates: Partial<Document>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<boolean>;

  // Processing Jobs
  getProcessingJob(id: string): Promise<ProcessingJob | undefined>;
  getProcessingJobsByOrganization(organizationId: string): Promise<ProcessingJob[]>;
  createProcessingJob(job: NewProcessingJob): Promise<ProcessingJob>;
  updateProcessingJob(id: string, updates: Partial<ProcessingJob>): Promise<ProcessingJob | undefined>;

  // Audit Logs
  createAuditLog(log: NewAuditLog): Promise<AuditLog>;
  getAuditLogsByOrganization(organizationId: string, limit?: number): Promise<AuditLog[]>;

  // Dashboard and Analytics
  getDashboardMetrics(organizationId: string): Promise<any>;
  getProcessingMetrics(organizationId: string): Promise<any>;
  getComplianceMetrics(organizationId: string): Promise<any>;
}

class Storage implements IStorage {
  // Organizations
  async getOrganization(id: string): Promise<Organization | undefined> {
    const result = await db.select().from(organizations).where(eq(organizations.id, id)).limit(1);
    return result[0];
  }

  async getOrganizationByDomain(domain: string): Promise<Organization | undefined> {
    const result = await db.select().from(organizations).where(eq(organizations.domain, domain)).limit(1);
    return result[0];
  }

  async createOrganization(org: NewOrganization): Promise<Organization> {
    const result = await db.insert(organizations).values(org).returning();
    return result[0];
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getUsersByOrganization(organizationId: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.organizationId, organizationId));
  }

  async createUser(user: NewUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return result[0];
  }

  // Document Sources
  async getDocumentSource(id: string): Promise<DocumentSource | undefined> {
    const result = await db.select().from(documentSources).where(eq(documentSources.id, id)).limit(1);
    return result[0];
  }

  async getDocumentSourcesByOrganization(organizationId: string): Promise<DocumentSource[]> {
    return await db.select().from(documentSources).where(eq(documentSources.organizationId, organizationId));
  }

  async createDocumentSource(source: NewDocumentSource): Promise<DocumentSource> {
    const result = await db.insert(documentSources).values(source).returning();
    return result[0];
  }

  async updateDocumentSource(id: string, updates: Partial<DocumentSource>): Promise<DocumentSource | undefined> {
    const result = await db.update(documentSources).set(updates).where(eq(documentSources.id, id)).returning();
    return result[0];
  }

  async deleteDocumentSource(id: string): Promise<boolean> {
    const result = await db.delete(documentSources).where(eq(documentSources.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async testDocumentSourceConnection(id: string): Promise<{ success: boolean; message: string }> {
    // TODO: Implement connection testing based on source type
    return { success: true, message: "Connection test not implemented yet" };
  }

  // BFSI Document Types
  async getBfsiDocumentTypes(): Promise<any[]> {
    return await db.select().from(bfsiDocumentTypes).where(eq(bfsiDocumentTypes.isActive, true));
  }

  async getBfsiDocumentTypeByKey(typeKey: string): Promise<any | undefined> {
    const result = await db.select().from(bfsiDocumentTypes).where(eq(bfsiDocumentTypes.typeKey, typeKey)).limit(1);
    return result[0];
  }

  async getBfsiDocumentTypesByCategory(category: string): Promise<any[]> {
    return await db.select().from(bfsiDocumentTypes)
      .where(and(eq(bfsiDocumentTypes.category, category), eq(bfsiDocumentTypes.isActive, true)));
  }

  // Documents
  async getDocument(id: string): Promise<Document | undefined> {
    const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
    return result[0];
  }

  async getDocumentsByOrganization(organizationId: string, limit = 50, offset = 0): Promise<Document[]> {
    return await db.select().from(documents)
      .where(eq(documents.organizationId, organizationId))
      .orderBy(desc(documents.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getDocumentsBySource(sourceId: string): Promise<Document[]> {
    return await db.select().from(documents).where(eq(documents.sourceId, sourceId));
  }

  async createDocument(doc: NewDocument): Promise<Document> {
    const result = await db.insert(documents).values(doc).returning();
    return result[0];
  }

  async updateDocument(id: string, updates: Partial<Document>): Promise<Document | undefined> {
    const result = await db.update(documents).set(updates).where(eq(documents.id, id)).returning();
    return result[0];
  }

  async deleteDocument(id: string): Promise<boolean> {
    const result = await db.delete(documents).where(eq(documents.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Processing Jobs
  async getProcessingJob(id: string): Promise<ProcessingJob | undefined> {
    const result = await db.select().from(processingJobs).where(eq(processingJobs.id, id)).limit(1);
    return result[0];
  }

  async getProcessingJobsByOrganization(organizationId: string): Promise<ProcessingJob[]> {
    return await db.select().from(processingJobs)
      .where(eq(processingJobs.organizationId, organizationId))
      .orderBy(desc(processingJobs.createdAt));
  }

  async createProcessingJob(job: NewProcessingJob): Promise<ProcessingJob> {
    const result = await db.insert(processingJobs).values(job).returning();
    return result[0];
  }

  async updateProcessingJob(id: string, updates: Partial<ProcessingJob>): Promise<ProcessingJob | undefined> {
    const result = await db.update(processingJobs).set(updates).where(eq(processingJobs.id, id)).returning();
    return result[0];
  }

  // Audit Logs
  async createAuditLog(log: NewAuditLog): Promise<AuditLog> {
    const result = await db.insert(auditLogs).values(log).returning();
    return result[0];
  }

  async getAuditLogsByOrganization(organizationId: string, limit = 100): Promise<AuditLog[]> {
    return await db.select().from(auditLogs)
      .where(eq(auditLogs.organizationId, organizationId))
      .orderBy(desc(auditLogs.createdAt))
      .limit(limit);
  }

  // Dashboard and Analytics
  async getDashboardMetrics(organizationId: string): Promise<any> {
    try {
      // Total documents
      const totalDocuments = await db.select({ count: count() })
        .from(documents)
        .where(eq(documents.organizationId, organizationId));

      // Documents by status
      const documentsByStatus = await db.select({
        status: documents.classificationStatus,
        count: count()
      })
        .from(documents)
        .where(eq(documents.organizationId, organizationId))
        .groupBy(documents.classificationStatus);

      // Processing jobs
      const processingJobsCount = await db.select({
        status: processingJobs.status,
        count: count()
      })
        .from(processingJobs)
        .where(eq(processingJobs.organizationId, organizationId))
        .groupBy(processingJobs.status);

      // Document sources
      const sourcesCount = await db.select({ count: count() })
        .from(documentSources)
        .where(and(
          eq(documentSources.organizationId, organizationId),
          eq(documentSources.isActive, true)
        ));

      return {
        totalDocuments: totalDocuments[0]?.count || 0,
        documentsByStatus: documentsByStatus || [],
        processingJobs: processingJobsCount || [],
        activeSources: sourcesCount[0]?.count || 0,
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching dashboard metrics:', error);
      return {
        totalDocuments: 0,
        documentsByStatus: [],
        processingJobs: [],
        activeSources: 0,
        lastUpdated: new Date().toISOString(),
        error: 'Failed to fetch metrics'
      };
    }
  }

  async getProcessingMetrics(organizationId: string): Promise<any> {
    try {
      const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
      
      const recentJobs = await db.select()
        .from(processingJobs)
        .where(and(
          eq(processingJobs.organizationId, organizationId),
          sql`${processingJobs.createdAt} >= ${last24Hours}`
        ))
        .orderBy(desc(processingJobs.createdAt));

      return {
        recentJobs: recentJobs || [],
        totalJobs: recentJobs.length,
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching processing metrics:', error);
      return {
        recentJobs: [],
        totalJobs: 0,
        lastUpdated: new Date().toISOString(),
        error: 'Failed to fetch processing metrics'
      };
    }
  }

  async getComplianceMetrics(organizationId: string): Promise<any> {
    try {
      // Documents by compliance status
      const complianceStatus = await db.select({
        status: documents.complianceStatus,
        count: count()
      })
        .from(documents)
        .where(eq(documents.organizationId, organizationId))
        .groupBy(documents.complianceStatus);

      // Documents with PII
      const piiDocuments = await db.select({ count: count() })
        .from(documents)
        .where(and(
          eq(documents.organizationId, organizationId),
          eq(documents.containsPii, true)
        ));

      return {
        complianceStatus: complianceStatus || [],
        documentsWithPii: piiDocuments[0]?.count || 0,
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching compliance metrics:', error);
      return {
        complianceStatus: [],
        documentsWithPii: 0,
        lastUpdated: new Date().toISOString(),
        error: 'Failed to fetch compliance metrics'
      };
    }
  }
}

export const storage = new Storage();
