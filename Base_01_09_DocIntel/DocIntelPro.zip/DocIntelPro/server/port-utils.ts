import { createServer } from 'net';

export interface PortConfig {
  server: number;
  gateway: number;
  airflow: number;
}

/**
 * Check if a port is available
 */
export function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = createServer();
    
    server.listen(port, () => {
      server.once('close', () => {
        resolve(true);
      });
      server.close();
    });
    
    server.on('error', () => {
      resolve(false);
    });
  });
}

/**
 * Find the next available port starting from a given port
 */
export async function findAvailablePort(startPort: number, maxAttempts: number = 10): Promise<number> {
  for (let i = 0; i < maxAttempts; i++) {
    const port = startPort + i;
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort} (tried ${maxAttempts} ports)`);
}

/**
 * Find available ports for all services
 */
export async function findAvailablePorts(): Promise<PortConfig> {
  const preferredPorts = {
    server: 5000,
    gateway: 8000,
    airflow: 8083  // Fixed port for Airflow
  };

  // Find dynamic ports for server and gateway, keep Airflow fixed
  const [serverPort, gatewayPort] = await Promise.all([
    findAvailablePort(preferredPorts.server),
    findAvailablePort(preferredPorts.gateway)
  ]);

  // Always use port 8083 for Airflow
  const airflowPort = preferredPorts.airflow;

  return {
    server: serverPort,
    gateway: gatewayPort,
    airflow: airflowPort
  };
}

/**
 * Update environment variables with dynamic ports
 */
export function updateEnvironmentPorts(ports: PortConfig): void {
  process.env.PORT = ports.server.toString();
  process.env.GATEWAY_PORT = ports.gateway.toString();
  process.env.AIRFLOW_PORT = ports.airflow.toString();
  
  // Update URLs for services
  process.env.GATEWAY_URL = `http://localhost:${ports.gateway}`;
  process.env.AIRFLOW_URL = `http://localhost:${ports.airflow}`;
}

/**
 * Display service URLs after startup
 */
export function displayServiceUrls(ports: PortConfig): void {
  console.log('\n🚀 DocIntelPro Services Started Successfully!');
  console.log('=' .repeat(50));
  console.log(`📊 Frontend & API Server: http://localhost:${ports.server} (dynamic)`);
  console.log(`🔧 API Gateway:           http://localhost:${ports.gateway} (dynamic)`);
  console.log(`⚡ Airflow Web UI:        http://localhost:${ports.airflow} (fixed)`);
  console.log('=' .repeat(50));
  console.log('💡 Frontend & Gateway use dynamic port allocation');
  console.log('📌 Airflow always runs on port 8083');
  console.log('🔄 Use Ctrl+C to stop all services\n');
}
