"""
Hybrid Vector Search Service
Combines semantic vector search with keyword-based search
Uses sentence-transformers for embedding generation and FAISS for vector storage
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from contextlib import asynccontextmanager
import asyncio
import logging
import numpy as np
import json
import os
from typing import Dict, List, Optional, Union, Tuple, Any
from datetime import datetime
import pickle
import hashlib

# Vector search libraries
try:
    import faiss
except ImportError:
    faiss = None

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

# Text processing
import re
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Database
import asyncpg
import asyncio

# Import shared modules
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.config import settings
from shared.models import (
    VectorSearchRequest, VectorSearchResult, SearchResult, 
    ServiceHealthCheck, BaseResponse, DocumentChunk, SimilarityScore
)

# Configure logging
logging.basicConfig(level=getattr(logging, settings.log_level))
logger = logging.getLogger(__name__)

# Global instances
embedding_model = None
vector_index = None
tfidf_vectorizer = None
document_store = {}  # In-memory store for development
db_pool = None

# Vector Search Configuration
VECTOR_CONFIG = {
    "embedding_model": "all-MiniLM-L6-v2",  # Fast and accurate
    "vector_dimension": 384,  # Dimension for all-MiniLM-L6-v2
    "index_type": "IndexFlatIP",  # Inner Product (cosine similarity)
    "chunk_size": 512,  # Token limit per chunk
    "chunk_overlap": 50,  # Overlap between chunks
    "similarity_threshold": 0.7,  # Minimum similarity score
    "max_results": 10
}

# BFSI-specific search optimization
BFSI_SEARCH_CONFIG = {
    "financial_terms": [
        "loan", "credit", "debit", "interest", "principal", "balance", "account",
        "transaction", "payment", "deposit", "withdrawal", "transfer", "mortgage",
        "collateral", "underwriting", "compliance", "regulatory", "aml", "kyc"
    ],
    "document_type_weights": {
        "LOAN_APPLICATION": 1.2,
        "FINANCIAL_STATEMENT": 1.1,
        "KYC_DOCUMENT": 1.3,
        "AML_REPORT": 1.4,
        "CREDIT_REPORT": 1.2
    },
    "compliance_boost": 1.5  # Boost compliance-related content
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize vector search components on startup"""
    global embedding_model, vector_index, tfidf_vectorizer, db_pool
    
    logger.info("Initializing vector search service...")
    
    try:
        # Initialize embedding model
        if SentenceTransformer:
            embedding_model = SentenceTransformer(VECTOR_CONFIG["embedding_model"])
            logger.info(f"Loaded embedding model: {VECTOR_CONFIG['embedding_model']}")
        else:
            logger.error("sentence-transformers not available")
        
        # Initialize FAISS index
        if faiss and embedding_model:
            vector_index = faiss.IndexFlatIP(VECTOR_CONFIG["vector_dimension"])
            logger.info("Initialized FAISS vector index")
        
        # Initialize TF-IDF vectorizer for keyword search
        tfidf_vectorizer = TfidfVectorizer(
            max_features=10000,
            stop_words='english',
            ngram_range=(1, 2),  # Unigrams and bigrams
            min_df=2,
            max_df=0.8
        )
        
        # Initialize database connection
        try:
            db_pool = await asyncpg.create_pool(
                host=settings.db_host,
                port=settings.db_port,
                user=settings.db_user,
                password=settings.db_password,
                database=settings.db_name,
                min_size=2,
                max_size=10
            )
            logger.info("Database connection pool initialized")
        except Exception as e:
            logger.warning(f"Database connection failed: {e}")
            db_pool = None
        
        # Load existing vectors if available
        await load_existing_vectors()
        
    except Exception as e:
        logger.error(f"Error initializing vector search service: {e}")
        raise
    
    yield
    
    # Cleanup
    if db_pool:
        await db_pool.close()
    logger.info("Vector search service cleanup completed")

# FastAPI app
app = FastAPI(
    title="Hybrid Vector Search Service",
    description="Semantic and keyword-based document search for BFSI documents",
    version=settings.app_version,
    lifespan=lifespan
)

class HybridSearchEngine:
    """Advanced hybrid search combining vector and keyword search"""
    
    def __init__(self):
        self.document_chunks = {}  # Store document chunks with metadata
        self.tfidf_matrix = None
        self.chunk_ids = []  # Maintain order for FAISS index
        
    async def index_document(
        self, 
        document_id: str, 
        content: str, 
        metadata: Dict,
        document_type: Optional[str] = None
    ) -> Dict:
        """Index a document for hybrid search"""
        try:
            # Split document into chunks
            chunks = await self._create_chunks(content, document_id, metadata)
            
            # Generate embeddings for each chunk
            embeddings = []
            chunk_texts = []
            
            for chunk in chunks:
                if embedding_model:
                    embedding = embedding_model.encode(chunk["text"])
                    embeddings.append(embedding)
                    chunk_texts.append(chunk["text"])
                    
                    # Store chunk metadata
                    chunk_id = chunk["chunk_id"]
                    self.document_chunks[chunk_id] = chunk
                    self.chunk_ids.append(chunk_id)
            
            # Add embeddings to FAISS index
            if embeddings and vector_index:
                embeddings_array = np.array(embeddings).astype('float32')
                # Normalize for cosine similarity
                faiss.normalize_L2(embeddings_array)
                vector_index.add(embeddings_array)
                logger.info(f"Added {len(embeddings)} vectors to index")
            
            # Update TF-IDF matrix
            await self._update_tfidf_index(chunk_texts)
            
            # Store in database if available
            if db_pool:
                await self._store_in_database(document_id, chunks, embeddings)
            
            return {
                "document_id": document_id,
                "chunks_created": len(chunks),
                "vectors_indexed": len(embeddings),
                "status": "indexed"
            }
            
        except Exception as e:
            logger.error(f"Document indexing error: {e}")
            raise HTTPException(status_code=500, detail=f"Indexing failed: {str(e)}")
    
    async def search(
        self, 
        query: str, 
        filters: Optional[Dict] = None,
        search_type: str = "hybrid",
        limit: int = 10
    ) -> List[SearchResult]:
        """Perform hybrid search combining vector and keyword search"""
        try:
            results = []
            
            if search_type in ["hybrid", "semantic"]:
                # Vector search
                vector_results = await self._vector_search(query, limit * 2)
                results.extend(vector_results)
            
            if search_type in ["hybrid", "keyword"]:
                # Keyword search
                keyword_results = await self._keyword_search(query, limit * 2)
                results.extend(keyword_results)
            
            # Combine and rank results
            if search_type == "hybrid":
                results = await self._hybrid_ranking(results, query)
            
            # Apply filters
            if filters:
                results = await self._apply_filters(results, filters)
            
            # Apply BFSI-specific boosting
            results = await self._apply_bfsi_boosting(results, query)
            
            # Sort by score and limit
            results.sort(key=lambda x: x.score, reverse=True)
            return results[:limit]
            
        except Exception as e:
            logger.error(f"Search error: {e}")
            raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")
    
    async def _create_chunks(
        self, 
        content: str, 
        document_id: str, 
        metadata: Dict
    ) -> List[Dict]:
        """Split document content into searchable chunks"""
        chunks = []
        
        # Simple sentence-based chunking (can be enhanced)
        sentences = re.split(r'[.!?]+', content)
        
        current_chunk = ""
        chunk_num = 0
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            # Check if adding sentence exceeds chunk size
            if len(current_chunk) + len(sentence) > VECTOR_CONFIG["chunk_size"]:
                if current_chunk:
                    # Create chunk
                    chunk_id = f"{document_id}_chunk_{chunk_num}"
                    chunks.append({
                        "chunk_id": chunk_id,
                        "document_id": document_id,
                        "text": current_chunk.strip(),
                        "chunk_number": chunk_num,
                        "metadata": metadata.copy()
                    })
                    chunk_num += 1
                
                # Start new chunk with overlap
                overlap_start = max(0, len(current_chunk) - VECTOR_CONFIG["chunk_overlap"])
                current_chunk = current_chunk[overlap_start:] + " " + sentence
            else:
                current_chunk += " " + sentence
        
        # Add final chunk
        if current_chunk.strip():
            chunk_id = f"{document_id}_chunk_{chunk_num}"
            chunks.append({
                "chunk_id": chunk_id,
                "document_id": document_id,
                "text": current_chunk.strip(),
                "chunk_number": chunk_num,
                "metadata": metadata.copy()
            })
        
        return chunks
    
    async def _vector_search(self, query: str, limit: int) -> List[SearchResult]:
        """Perform semantic vector search"""
        if not embedding_model or not vector_index:
            return []
        
        try:
            # Generate query embedding
            query_embedding = embedding_model.encode([query])
            query_embedding = query_embedding.astype('float32')
            faiss.normalize_L2(query_embedding)
            
            # Search FAISS index
            scores, indices = vector_index.search(query_embedding, limit)
            
            results = []
            for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
                if idx == -1:  # No more results
                    break
                
                if idx < len(self.chunk_ids):
                    chunk_id = self.chunk_ids[idx]
                    chunk = self.document_chunks.get(chunk_id)
                    
                    if chunk and score > VECTOR_CONFIG["similarity_threshold"]:
                        results.append(SearchResult(
                            document_id=chunk["document_id"],
                            chunk_id=chunk_id,
                            content=chunk["text"],
                            score=float(score),
                            search_type="semantic",
                            metadata=chunk["metadata"]
                        ))
            
            return results
            
        except Exception as e:
            logger.error(f"Vector search error: {e}")
            return []
    
    async def _keyword_search(self, query: str, limit: int) -> List[SearchResult]:
        """Perform keyword-based search using TF-IDF"""
        if not tfidf_vectorizer or self.tfidf_matrix is None:
            return []
        
        try:
            # Transform query
            query_vector = tfidf_vectorizer.transform([query])
            
            # Calculate similarities
            similarities = cosine_similarity(query_vector, self.tfidf_matrix).flatten()
            
            # Get top results
            top_indices = similarities.argsort()[-limit:][::-1]
            
            results = []
            for idx in top_indices:
                if similarities[idx] > 0.1:  # Minimum keyword relevance
                    if idx < len(self.chunk_ids):
                        chunk_id = self.chunk_ids[idx]
                        chunk = self.document_chunks.get(chunk_id)
                        
                        if chunk:
                            results.append(SearchResult(
                                document_id=chunk["document_id"],
                                chunk_id=chunk_id,
                                content=chunk["text"],
                                score=float(similarities[idx]),
                                search_type="keyword",
                                metadata=chunk["metadata"]
                            ))
            
            return results
            
        except Exception as e:
            logger.error(f"Keyword search error: {e}")
            return []
    
    async def _hybrid_ranking(self, results: List[SearchResult], query: str) -> List[SearchResult]:
        """Combine and re-rank semantic and keyword search results"""
        # Group results by document chunk
        result_groups = {}
        
        for result in results:
            key = result.chunk_id
            if key not in result_groups:
                result_groups[key] = []
            result_groups[key].append(result)
        
        # Combine scores for each chunk
        hybrid_results = []
        for chunk_id, chunk_results in result_groups.items():
            semantic_score = 0.0
            keyword_score = 0.0
            
            # Get best scores from each method
            for result in chunk_results:
                if result.search_type == "semantic":
                    semantic_score = max(semantic_score, result.score)
                elif result.search_type == "keyword":
                    keyword_score = max(keyword_score, result.score)
            
            # Hybrid scoring (weighted combination)
            hybrid_score = (semantic_score * 0.7) + (keyword_score * 0.3)
            
            # Use the first result as template
            base_result = chunk_results[0]
            hybrid_results.append(SearchResult(
                document_id=base_result.document_id,
                chunk_id=chunk_id,
                content=base_result.content,
                score=hybrid_score,
                search_type="hybrid",
                metadata=base_result.metadata
            ))
        
        return hybrid_results
    
    async def _apply_filters(self, results: List[SearchResult], filters: Dict) -> List[SearchResult]:
        """Apply search filters"""
        filtered_results = []
        
        for result in results:
            include = True
            
            # Document type filter
            if "document_type" in filters:
                doc_type = result.metadata.get("document_type")
                if doc_type not in filters["document_type"]:
                    include = False
            
            # Date range filter
            if "date_range" in filters and include:
                doc_date = result.metadata.get("date")
                if doc_date:
                    # Implement date range checking
                    pass
            
            # Classification level filter
            if "classification_level" in filters and include:
                classification = result.metadata.get("classification_level")
                if classification not in filters["classification_level"]:
                    include = False
            
            if include:
                filtered_results.append(result)
        
        return filtered_results
    
    async def _apply_bfsi_boosting(self, results: List[SearchResult], query: str) -> List[SearchResult]:
        """Apply BFSI-specific score boosting"""
        query_lower = query.lower()
        
        for result in results:
            boost_factor = 1.0
            
            # Boost financial terms
            financial_term_count = sum(
                1 for term in BFSI_SEARCH_CONFIG["financial_terms"]
                if term in query_lower or term in result.content.lower()
            )
            boost_factor += financial_term_count * 0.1
            
            # Boost by document type importance
            doc_type = result.metadata.get("document_type")
            if doc_type in BFSI_SEARCH_CONFIG["document_type_weights"]:
                boost_factor *= BFSI_SEARCH_CONFIG["document_type_weights"][doc_type]
            
            # Boost compliance-related content
            if any(term in result.content.lower() for term in ["compliance", "regulatory", "aml", "kyc"]):
                boost_factor *= BFSI_SEARCH_CONFIG["compliance_boost"]
            
            result.score *= boost_factor
        
        return results
    
    async def _update_tfidf_index(self, chunk_texts: List[str]):
        """Update TF-IDF index with new document chunks"""
        try:
            all_texts = list(self.document_chunks.values())
            all_chunk_texts = [chunk["text"] for chunk in all_texts]
            
            if len(all_chunk_texts) > 0:
                self.tfidf_matrix = tfidf_vectorizer.fit_transform(all_chunk_texts)
                logger.info(f"Updated TF-IDF index with {len(all_chunk_texts)} documents")
        except Exception as e:
            logger.error(f"TF-IDF update error: {e}")
    
    async def _store_in_database(self, document_id: str, chunks: List[Dict], embeddings: List):
        """Store document chunks and embeddings in database"""
        if not db_pool:
            return
        
        try:
            async with db_pool.acquire() as conn:
                # Insert document chunks
                for i, chunk in enumerate(chunks):
                    embedding_blob = pickle.dumps(embeddings[i]) if i < len(embeddings) else None
                    
                    await conn.execute("""
                        INSERT INTO document_vectors 
                        (chunk_id, document_id, content, embedding, metadata, created_at)
                        VALUES ($1, $2, $3, $4, $5, $6)
                        ON CONFLICT (chunk_id) DO UPDATE SET
                            content = EXCLUDED.content,
                            embedding = EXCLUDED.embedding,
                            metadata = EXCLUDED.metadata,
                            updated_at = NOW()
                    """, 
                    chunk["chunk_id"], 
                    document_id, 
                    chunk["text"],
                    embedding_blob,
                    json.dumps(chunk["metadata"]),
                    datetime.utcnow()
                    )
        except Exception as e:
            logger.error(f"Database storage error: {e}")

# Initialize search engine
search_engine = HybridSearchEngine()

async def load_existing_vectors():
    """Load existing vectors from database on startup"""
    if not db_pool:
        logger.info("No database connection - starting with empty index")
        return
    
    try:
        async with db_pool.acquire() as conn:
            rows = await conn.fetch("SELECT chunk_id, content, embedding, metadata FROM document_vectors")
            
            embeddings = []
            for row in rows:
                chunk_id = row['chunk_id']
                content = row['content']
                metadata = json.loads(row['metadata']) if row['metadata'] else {}
                
                # Reconstruct chunk
                search_engine.document_chunks[chunk_id] = {
                    "chunk_id": chunk_id,
                    "text": content,
                    "metadata": metadata
                }
                search_engine.chunk_ids.append(chunk_id)
                
                # Load embedding
                if row['embedding']:
                    embedding = pickle.loads(row['embedding'])
                    embeddings.append(embedding)
            
            # Rebuild FAISS index
            if embeddings and vector_index:
                embeddings_array = np.array(embeddings).astype('float32')
                faiss.normalize_L2(embeddings_array)
                vector_index.add(embeddings_array)
                logger.info(f"Loaded {len(embeddings)} vectors from database")
            
            # Rebuild TF-IDF index
            if search_engine.document_chunks:
                all_texts = [chunk["text"] for chunk in search_engine.document_chunks.values()]
                search_engine.tfidf_matrix = tfidf_vectorizer.fit_transform(all_texts)
                logger.info(f"Rebuilt TF-IDF index with {len(all_texts)} documents")
    
    except Exception as e:
        logger.error(f"Error loading existing vectors: {e}")

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/health", response_model=ServiceHealthCheck)
async def health_check():
    """Service health check"""
    components_status = {
        "embedding_model": "loaded" if embedding_model else "not_loaded",
        "faiss_index": "loaded" if vector_index else "not_loaded",
        "tfidf_vectorizer": "loaded" if tfidf_vectorizer else "not_loaded",
        "database": "connected" if db_pool else "disconnected"
    }
    
    return ServiceHealthCheck(
        service_name="vector-search-service",
        status="healthy" if embedding_model and vector_index else "degraded",
        version=settings.app_version,
        dependencies=components_status
    )

@app.post("/api/v1/index", response_model=BaseResponse)
async def index_document(
    document_id: str,
    content: str,
    metadata: Dict = {},
    document_type: Optional[str] = None
):
    """Index a document for vector and keyword search"""
    try:
        result = await search_engine.index_document(
            document_id, content, metadata, document_type
        )
        
        return BaseResponse(
            message=f"Document {document_id} indexed successfully",
            data=result
        )
        
    except Exception as e:
        logger.error(f"Document indexing error: {e}")
        raise HTTPException(status_code=500, detail=f"Indexing failed: {str(e)}")

@app.post("/api/v1/search", response_model=VectorSearchResult)
async def search_documents(request: VectorSearchRequest):
    """Search documents using hybrid vector and keyword search"""
    try:
        results = await search_engine.search(
            query=request.query,
            filters=request.filters,
            search_type=request.search_type,
            limit=request.limit
        )
        
        return VectorSearchResult(
            query=request.query,
            results=results,
            total_results=len(results),
            search_type=request.search_type
        )
        
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@app.get("/api/v1/similar/{document_id}")
async def find_similar_documents(
    document_id: str,
    limit: int = 5
):
    """Find documents similar to a specific document"""
    try:
        # Get document content
        doc_chunks = [
            chunk for chunk in search_engine.document_chunks.values()
            if chunk["document_id"] == document_id
        ]
        
        if not doc_chunks:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Use first chunk content as query
        query_text = doc_chunks[0]["text"]
        
        results = await search_engine.search(
            query=query_text,
            search_type="semantic",
            limit=limit + 5  # Get extra to filter out self
        )
        
        # Filter out the source document
        filtered_results = [
            result for result in results 
            if result.document_id != document_id
        ][:limit]
        
        return {
            "source_document_id": document_id,
            "similar_documents": filtered_results,
            "total_found": len(filtered_results)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Similar document search error: {e}")
        raise HTTPException(status_code=500, detail=f"Similar search failed: {str(e)}")

@app.get("/api/v1/stats")
async def get_search_stats():
    """Get vector search statistics"""
    return {
        "total_documents": len(set(chunk["document_id"] for chunk in search_engine.document_chunks.values())),
        "total_chunks": len(search_engine.document_chunks),
        "vector_index_size": vector_index.ntotal if vector_index else 0,
        "embedding_model": VECTOR_CONFIG["embedding_model"],
        "vector_dimension": VECTOR_CONFIG["vector_dimension"]
    }

@app.delete("/api/v1/index/{document_id}")
async def delete_document(document_id: str):
    """Remove a document from the search index"""
    try:
        # Find chunks to remove
        chunks_to_remove = [
            chunk_id for chunk_id, chunk in search_engine.document_chunks.items()
            if chunk["document_id"] == document_id
        ]
        
        if not chunks_to_remove:
            raise HTTPException(status_code=404, detail="Document not found")
        
        # Remove from memory store
        for chunk_id in chunks_to_remove:
            del search_engine.document_chunks[chunk_id]
            if chunk_id in search_engine.chunk_ids:
                search_engine.chunk_ids.remove(chunk_id)
        
        # Remove from database
        if db_pool:
            async with db_pool.acquire() as conn:
                await conn.execute(
                    "DELETE FROM document_vectors WHERE document_id = $1",
                    document_id
                )
        
        # Note: FAISS index cannot be easily updated, would need rebuilding
        # In production, consider using a more dynamic vector database
        
        return BaseResponse(
            message=f"Document {document_id} removed from index",
            data={"chunks_removed": len(chunks_to_remove)}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Document deletion error: {e}")
        raise HTTPException(status_code=500, detail=f"Deletion failed: {str(e)}")

# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.vector_search_host,
        port=settings.vector_search_port,
        reload=settings.debug,
        log_level=settings.log_level.lower()
    )
