# DocIntelPro Python Microservices

This is the Python-based microservices backend for DocIntelPro, a comprehensive Document Intelligence Platform optimized for BFSI (Banking, Financial Services, and Insurance) and Healthcare domains.

## 🏗️ Architecture Overview

The platform follows a microservices architecture with the following components:

### Core Services

1. **Gateway Service** (Port 8000)
   - Main API gateway and orchestrator
   - Handles document processing workflows
   - Coordinates between all microservices
   - WebSocket support for real-time updates

2. **OCR Service** (Port 8001)
   - Multi-provider OCR with agentic selection
   - Supports PaddleOCR (free) and Azure Document Intelligence
   - Quality assessment and optimization
   - Document layout analysis

3. **Classification Service** (Port 8002)
   - BFSI-specific document classification
   - Uses spaCy + BERT for high accuracy
   - Rule-based + semantic classification ensemble
   - Compliance framework mapping

4. **Vector Search Service** (Port 8003)
   - Hybrid vector + keyword search
   - Sentence-transformers embeddings
   - FAISS vector storage
   - BFSI-optimized search algorithms

5. **PII Detection Service** (Port 8004)
   - Microsoft Presidio-based PII detection
   - Custom BFSI entity recognizers
   - Advanced anonymization strategies
   - GDPR/CCPA compliance features

### Infrastructure Components

- **PostgreSQL Database**: Document metadata and processing results
- **Redis Cache**: Session management and task queuing
- **Prometheus + Grafana**: Monitoring and observability
- **Docker**: Containerized deployment

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- PostgreSQL 12+
- Redis 6+
- Docker & Docker Compose (optional)

### Option 1: Development Setup

#### Windows
```bash
# Run the setup script
setup_microservices.bat

# Start all services
start_dev.bat
```

#### Linux/macOS
```bash
# Make script executable and run setup
chmod +x setup_microservices.sh
./setup_microservices.sh

# Start all services
./start_dev.sh
```

### Option 2: Docker Setup

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

## 📚 API Documentation

Once services are running, access interactive API documentation:

- **Gateway API**: http://localhost:8000/docs
- **OCR Service**: http://localhost:8001/docs
- **Classification**: http://localhost:8002/docs
- **Vector Search**: http://localhost:8003/docs
- **PII Detection**: http://localhost:8004/docs

## 🎯 BFSI Features

### Document Types Supported

**Loan and Credit Documents**
- Loan Applications
- Credit Reports
- Loan Agreements
- Credit Approval Letters

**KYC and Compliance**
- KYC Documents
- AML Reports
- Due Diligence Reports
- Sanctions Screening Results

**Financial Documents**
- Financial Statements
- Bank Statements
- Balance Sheets
- Income Statements

**Transaction Documents**
- Wire Transfers
- Check Deposits
- Payment Instructions
- Transaction Reports

**Insurance Documents**
- Insurance Claims
- Policy Documents
- Premium Statements
- Claims Processing Forms

### Compliance Frameworks

- **SOX** (Sarbanes-Oxley Act)
- **BSA** (Bank Secrecy Act)
- **AML** (Anti-Money Laundering)
- **GLBA** (Gramm-Leach-Bliley Act)
- **FCRA** (Fair Credit Reporting Act)
- **TILA** (Truth in Lending Act)

## 🔧 Configuration

### Environment Variables

Key configuration options in `.env`:

```env
# Application
DEBUG=true
LOG_LEVEL=INFO
ENVIRONMENT=development

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=admin@12345
DB_NAME=RND

# Redis
REDIS_URL=redis://localhost:6379/0

# Azure Document Intelligence (Optional)
AZURE_DOCUMENT_INTELLIGENCE_KEY=your_key
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=your_endpoint

# Service Ports
GATEWAY_PORT=8000
OCR_PORT=8001
CLASSIFICATION_PORT=8002
VECTOR_SEARCH_PORT=8003
PII_DETECTION_PORT=8004
```

### Service Configuration

Each service can be configured through environment variables or the shared configuration in `shared/config.py`.

## 🧠 Machine Learning Models

### OCR Models
- **PaddleOCR**: Free, fast, supports 80+ languages
- **Azure Document Intelligence**: High accuracy, table extraction

### Classification Models
- **spaCy**: Fast NLP preprocessing and NER
- **DistilBERT**: Lightweight transformer for classification
- **Custom BFSI Rules**: Domain-specific classification logic

### Vector Search Models
- **sentence-transformers/all-MiniLM-L6-v2**: Fast, accurate embeddings
- **FAISS**: Efficient vector similarity search
- **TF-IDF**: Keyword-based search component

### PII Detection Models
- **Microsoft Presidio**: Enterprise-grade PII detection
- **Custom BFSI Patterns**: Banking-specific entity recognition
- **spaCy NER**: Additional entity recognition

## 📊 Monitoring & Observability

### Prometheus Metrics

- Request/response times
- Error rates
- Model inference times
- Resource utilization
- Custom business metrics

### Grafana Dashboards

- Service health overview
- Document processing pipeline
- ML model performance
- Infrastructure monitoring

### Logging

Structured logging with:
- Request tracing
- Error tracking
- Performance metrics
- Security events

## 🔒 Security Features

### PII Protection
- Automatic PII detection and masking
- GDPR-compliant anonymization
- Custom entity recognition for BFSI
- Secure data handling

### Access Control
- JWT-based authentication
- Role-based access control (RBAC)
- API rate limiting
- Request validation

### Data Encryption
- TLS/SSL for all communications
- Database encryption at rest
- Secure file storage
- Key management

## 🧪 Testing

### Health Checks
```bash
# Test all services
./test_services.sh

# Individual service tests
curl http://localhost:8000/health  # Gateway
curl http://localhost:8001/health  # OCR
curl http://localhost:8002/health  # Classification
curl http://localhost:8003/health  # Vector Search
curl http://localhost:8004/health  # PII Detection
```

### API Testing

Use the provided Swagger UI at each service's `/docs` endpoint for interactive testing.

### Sample Requests

#### Document Processing
```bash
curl -X POST "http://localhost:8000/api/v1/process" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@sample_document.pdf" \
  -F "document_type=LOAN_APPLICATION"
```

#### Vector Search
```bash
curl -X POST "http://localhost:8003/api/v1/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "loan application credit score",
    "search_type": "hybrid",
    "limit": 10
  }'
```

#### PII Detection
```bash
curl -X POST "http://localhost:8004/api/v1/detect" \
  -H "Content-Type: application/json" \
  -d '{
    "text": "John Doe SSN: 123-45-6789 Account: 1234567890",
    "entity_types": ["PERSON", "SSN", "ACCOUNT_NUMBER"]
  }'
```

## 📈 Performance Optimization

### Scaling Guidelines

**CPU-Intensive Services**
- Classification Service: Scale based on ML inference load
- OCR Service: Scale for concurrent document processing

**Memory-Intensive Services**
- Vector Search: Scale based on index size and query volume
- Gateway: Scale for concurrent user sessions

**I/O-Intensive Services**
- All services benefit from SSD storage
- Database connection pooling

### Caching Strategy

- **Redis**: Session data, frequent queries, ML model outputs
- **In-Memory**: Vector indices, classification rules
- **Database**: Processed document metadata

## 🚀 Deployment

### Development
```bash
# Single machine development
./start_dev.sh
```

### Staging/Production
```bash
# Docker Compose
docker-compose -f docker-compose.prod.yml up -d

# Kubernetes (coming soon)
kubectl apply -f k8s/
```

### Environment-Specific Configurations

- Development: Local storage, debug logging
- Staging: Cloud storage, performance testing
- Production: High availability, monitoring

## 🤝 Contributing

### Code Style
- Follow PEP 8 for Python code
- Use type hints
- Document all public APIs
- Write comprehensive tests

### Pull Request Process
1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass
5. Submit pull request with description

## 📝 Changelog

### Version 1.0.0
- Initial microservices implementation
- BFSI document processing pipeline
- Multi-provider OCR integration
- Hybrid vector search
- PII detection and anonymization
- Docker containerization
- Monitoring and observability

## 🆘 Troubleshooting

### Common Issues

**Service Won't Start**
- Check Python version (3.11+ required)
- Verify all dependencies installed
- Check port availability
- Review environment variables

**OCR Not Working**
- Verify PaddleOCR installation
- Check Azure credentials (if using)
- Ensure proper image formats

**Classification Issues**
- Download spaCy model: `python -m spacy download en_core_web_sm`
- Check available GPU/CPU resources
- Verify model loading in logs

**Database Connection**
- Verify PostgreSQL is running
- Check connection string
- Ensure database exists
- Run migration scripts

### Log Locations

- Development: Console output
- Docker: `docker-compose logs [service-name]`
- Production: `logs/` directory

## 📞 Support

For technical support:
1. Check the troubleshooting section
2. Review service logs
3. Check health endpoints
4. Contact the development team

## 📄 License

This project is proprietary software. All rights reserved.

---

**Built with ❤️ for BFSI Document Intelligence**
