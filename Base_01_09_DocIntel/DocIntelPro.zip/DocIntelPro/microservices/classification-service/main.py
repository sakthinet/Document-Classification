"""
BFSI Document Classification Service
Uses spaCy + transformers for high-accuracy document classification
Supports agentic model selection for optimal results
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from contextlib import asynccontextmanager
import asyncio
import logging
import torch
import spacy
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from transformers import pipeline
import numpy as np
from typing import Dict, List, Optional, Tuple
import json
import os
from datetime import datetime

# Import shared modules
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.config import settings
from shared.models import (
    ClassificationRequest, ClassificationResult, DocumentType, 
    ClassificationLevel, ServiceHealthCheck, BaseResponse, ErrorResponse
)

# Configure logging
logging.basicConfig(level=getattr(logging, settings.log_level))
logger = logging.getLogger(__name__)

# Global model instances
nlp_model = None
bert_classifier = None
document_classifier = None

# BFSI Document Classification Rules
BFSI_CLASSIFICATION_RULES = {
    # Loan and Credit Documents
    "LOAN_APPLICATION": {
        "keywords": [
            "loan application", "credit application", "borrower", "loan amount",
            "interest rate", "collateral", "credit score", "income verification",
            "employment verification", "debt-to-income", "loan purpose"
        ],
        "classification": ClassificationLevel.CONFIDENTIAL,
        "confidence_threshold": 0.75
    },
    
    "CREDIT_REPORT": {
        "keywords": [
            "credit report", "credit score", "fico", "experian", "equifax",
            "transunion", "credit history", "payment history", "credit utilization",
            "derogatory marks", "credit inquiries"
        ],
        "classification": ClassificationLevel.CONFIDENTIAL,
        "confidence_threshold": 0.80
    },
    
    # KYC and Compliance
    "KYC_DOCUMENT": {
        "keywords": [
            "know your customer", "kyc", "customer identification", "due diligence",
            "identity verification", "address verification", "beneficial ownership",
            "politically exposed person", "pep", "sanctions screening"
        ],
        "classification": ClassificationLevel.RESTRICTED,
        "confidence_threshold": 0.70
    },
    
    "AML_REPORT": {
        "keywords": [
            "anti-money laundering", "aml", "suspicious activity", "sar",
            "currency transaction report", "ctr", "suspicious transaction",
            "money laundering", "terrorist financing", "beneficial ownership"
        ],
        "classification": ClassificationLevel.RESTRICTED,
        "confidence_threshold": 0.85
    },
    
    # Financial Documents
    "FINANCIAL_STATEMENT": {
        "keywords": [
            "balance sheet", "income statement", "cash flow", "financial statement",
            "assets", "liabilities", "equity", "revenue", "expenses", "gaap",
            "audited", "unaudited", "quarterly", "annual"
        ],
        "classification": ClassificationLevel.INTERNAL,
        "confidence_threshold": 0.70
    },
    
    # Transaction Documents
    "WIRE_TRANSFER": {
        "keywords": [
            "wire transfer", "swift", "fedwire", "correspondent bank", "intermediary bank",
            "beneficiary bank", "remitter", "originator", "routing number", "iban",
            "transfer amount", "purpose of transfer"
        ],
        "classification": ClassificationLevel.RESTRICTED,
        "confidence_threshold": 0.80
    },
    
    # Insurance Documents
    "INSURANCE_CLAIM": {
        "keywords": [
            "insurance claim", "policy number", "claim number", "insured", "beneficiary",
            "coverage", "deductible", "premium", "claim amount", "adjuster",
            "loss date", "incident", "damage"
        ],
        "classification": ClassificationLevel.RESTRICTED,
        "confidence_threshold": 0.75
    }
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize ML models on startup"""
    global nlp_model, bert_classifier, document_classifier
    
    logger.info("Loading classification models...")
    
    try:
        # Load spaCy model for NER and text processing
        nlp_model = spacy.load("en_core_web_sm")
        logger.info("Loaded spaCy model successfully")
        
        # Load BERT model for document classification
        model_name = "distilbert-base-uncased-finetuned-sst-2-english"  # Start with this, can be fine-tuned
        bert_classifier = pipeline(
            "text-classification",
            model=model_name,
            tokenizer=model_name,
            device=0 if torch.cuda.is_available() else -1
        )
        logger.info("Loaded BERT classifier successfully")
        
        # Create document type classifier
        document_classifier = BFSIDocumentClassifier()
        await document_classifier.initialize()
        logger.info("Initialized BFSI document classifier")
        
    except Exception as e:
        logger.error(f"Error loading models: {e}")
        raise
    
    yield
    
    # Cleanup
    logger.info("Cleaning up classification service...")

# FastAPI app
app = FastAPI(
    title="BFSI Classification Service",
    description="High-accuracy document classification for BFSI domain",
    version=settings.app_version,
    lifespan=lifespan
)

class BFSIDocumentClassifier:
    """Advanced BFSI document classifier with agentic model selection"""
    
    def __init__(self):
        self.keyword_weights = {}
        self.confidence_threshold = 0.70
        
    async def initialize(self):
        """Initialize classifier with BFSI-specific rules"""
        # Build keyword weights from classification rules
        for doc_type, rules in BFSI_CLASSIFICATION_RULES.items():
            self.keyword_weights[doc_type] = {
                "keywords": rules["keywords"],
                "threshold": rules["confidence_threshold"],
                "classification": rules["classification"]
            }
        
        logger.info(f"Initialized classifier with {len(self.keyword_weights)} document types")
    
    async def classify_document(
        self, 
        text: str, 
        metadata: Dict
    ) -> Tuple[Optional[str], ClassificationLevel, float, str]:
        """
        Classify document using agentic approach:
        1. Rule-based keyword matching
        2. BERT-based semantic classification
        3. Ensemble decision making
        """
        
        # Step 1: Rule-based classification
        rule_based_result = await self._rule_based_classification(text)
        
        # Step 2: BERT-based classification
        bert_result = await self._bert_classification(text)
        
        # Step 3: Ensemble decision
        final_result = await self._ensemble_decision(rule_based_result, bert_result, metadata)
        
        return final_result
    
    async def _rule_based_classification(self, text: str) -> Dict:
        """Rule-based classification using keyword matching"""
        text_lower = text.lower()
        scores = {}
        
        for doc_type, rules in self.keyword_weights.items():
            keyword_count = 0
            total_keywords = len(rules["keywords"])
            
            for keyword in rules["keywords"]:
                if keyword.lower() in text_lower:
                    keyword_count += 1
            
            # Calculate confidence based on keyword matches
            confidence = keyword_count / total_keywords if total_keywords > 0 else 0.0
            
            if confidence > 0:
                scores[doc_type] = {
                    "confidence": confidence,
                    "threshold": rules["threshold"],
                    "classification": rules["classification"]
                }
        
        # Get best match
        if scores:
            best_type = max(scores.keys(), key=lambda x: scores[x]["confidence"])
            return {
                "document_type": best_type,
                "confidence": scores[best_type]["confidence"],
                "classification": scores[best_type]["classification"],
                "method": "rule-based"
            }
        
        return {
            "document_type": None,
            "confidence": 0.0,
            "classification": ClassificationLevel.INTERNAL,
            "method": "rule-based"
        }
    
    async def _bert_classification(self, text: str) -> Dict:
        """BERT-based semantic classification"""
        try:
            if not bert_classifier:
                return {"confidence": 0.0, "method": "bert"}
            
            # Use BERT for general document sentiment/type
            # Note: This would need fine-tuning for BFSI document types
            result = bert_classifier(text[:512])  # BERT input limit
            
            confidence = result[0]["score"] if result else 0.0
            
            # Map BERT results to BFSI document types (simplified)
            # In production, you would fine-tune BERT on BFSI documents
            document_type = await self._map_bert_to_bfsi(text, confidence)
            
            return {
                "document_type": document_type,
                "confidence": confidence * 0.8,  # Adjust confidence for domain adaptation
                "classification": ClassificationLevel.INTERNAL,
                "method": "bert"
            }
            
        except Exception as e:
            logger.error(f"BERT classification error: {e}")
            return {"confidence": 0.0, "method": "bert"}
    
    async def _map_bert_to_bfsi(self, text: str, confidence: float) -> Optional[str]:
        """Map BERT output to BFSI document types"""
        # Simplified mapping - in production, use fine-tuned BFSI model
        text_lower = text.lower()
        
        if any(word in text_lower for word in ["loan", "credit", "borrow"]):
            return "LOAN_APPLICATION"
        elif any(word in text_lower for word in ["kyc", "customer", "verification"]):
            return "KYC_DOCUMENT"
        elif any(word in text_lower for word in ["financial", "balance", "income"]):
            return "FINANCIAL_STATEMENT"
        elif any(word in text_lower for word in ["wire", "transfer", "payment"]):
            return "WIRE_TRANSFER"
        
        return None
    
    async def _ensemble_decision(
        self, 
        rule_result: Dict, 
        bert_result: Dict, 
        metadata: Dict
    ) -> Tuple[Optional[str], ClassificationLevel, float, str]:
        """Make ensemble decision from multiple classification methods"""
        
        # Weight the methods (can be adjusted based on performance)
        rule_weight = 0.7
        bert_weight = 0.3
        
        # If rule-based has high confidence, use it
        if rule_result["confidence"] > 0.7:
            return (
                rule_result["document_type"],
                rule_result["classification"],
                rule_result["confidence"],
                f"Rule-based classification with {rule_result['confidence']:.2f} confidence"
            )
        
        # If BERT has high confidence and rule-based agrees or is weak
        if bert_result.get("confidence", 0) > 0.6 and rule_result["confidence"] < 0.5:
            return (
                bert_result.get("document_type"),
                bert_result.get("classification", ClassificationLevel.INTERNAL),
                bert_result.get("confidence", 0.0),
                f"BERT-based classification with {bert_result.get('confidence', 0):.2f} confidence"
            )
        
        # Ensemble weighted average
        if rule_result["document_type"] and bert_result.get("document_type"):
            if rule_result["document_type"] == bert_result["document_type"]:
                # Both agree - high confidence
                ensemble_confidence = (
                    rule_result["confidence"] * rule_weight + 
                    bert_result.get("confidence", 0) * bert_weight
                )
                return (
                    rule_result["document_type"],
                    rule_result["classification"],
                    ensemble_confidence,
                    f"Ensemble agreement with {ensemble_confidence:.2f} confidence"
                )
        
        # Default to rule-based if available
        if rule_result["document_type"]:
            return (
                rule_result["document_type"],
                rule_result["classification"],
                rule_result["confidence"],
                f"Rule-based fallback with {rule_result['confidence']:.2f} confidence"
            )
        
        # Default classification
        return (
            None,
            ClassificationLevel.INTERNAL,
            0.0,
            "Unable to classify document with sufficient confidence"
        )

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/health", response_model=ServiceHealthCheck)
async def health_check():
    """Service health check"""
    model_status = {
        "spacy": "loaded" if nlp_model else "not_loaded",
        "bert": "loaded" if bert_classifier else "not_loaded",
        "bfsi_classifier": "loaded" if document_classifier else "not_loaded"
    }
    
    return ServiceHealthCheck(
        service_name="classification-service",
        status="healthy" if all(status == "loaded" for status in model_status.values()) else "degraded",
        version=settings.app_version,
        dependencies=model_status
    )

@app.post("/api/v1/classify", response_model=ClassificationResult)
async def classify_document(request: ClassificationRequest):
    """Classify a document using BFSI-specific models"""
    try:
        logger.info(f"Classifying document {request.document_id}")
        
        if not document_classifier:
            raise HTTPException(status_code=503, detail="Classification service not ready")
        
        # Perform classification
        doc_type, classification_level, confidence, reasoning = await document_classifier.classify_document(
            request.text_content,
            request.metadata
        )
        
        # Extract compliance flags
        compliance_flags = []
        if doc_type and doc_type in BFSI_CLASSIFICATION_RULES:
            # Add relevant compliance frameworks
            if doc_type in ["LOAN_APPLICATION", "CREDIT_REPORT"]:
                compliance_flags.extend(["SOX", "FCRA", "TILA"])
            elif doc_type in ["KYC_DOCUMENT", "AML_REPORT"]:
                compliance_flags.extend(["BSA", "AML", "PATRIOT_Act"])
            elif doc_type == "WIRE_TRANSFER":
                compliance_flags.extend(["BSA", "OFAC"])
        
        result = ClassificationResult(
            document_type=DocumentType(doc_type) if doc_type else None,
            classification_level=classification_level,
            confidence=confidence,
            reasoning=reasoning,
            compliance_flags=compliance_flags
        )
        
        logger.info(f"Classification complete for {request.document_id}: {doc_type} ({confidence:.2f})")
        return result
        
    except Exception as e:
        logger.error(f"Classification error for {request.document_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Classification failed: {str(e)}")

@app.get("/api/v1/document-types")
async def get_supported_document_types():
    """Get list of supported BFSI document types"""
    return {
        "document_types": list(BFSI_CLASSIFICATION_RULES.keys()),
        "total_count": len(BFSI_CLASSIFICATION_RULES)
    }

@app.post("/api/v1/batch-classify")
async def batch_classify_documents(requests: List[ClassificationRequest]):
    """Batch classify multiple documents"""
    try:
        results = []
        
        for request in requests:
            # Process each document
            doc_type, classification_level, confidence, reasoning = await document_classifier.classify_document(
                request.text_content,
                request.metadata
            )
            
            results.append({
                "document_id": request.document_id,
                "document_type": doc_type,
                "classification_level": classification_level.value if classification_level else None,
                "confidence": confidence,
                "reasoning": reasoning
            })
        
        return {"results": results, "total_processed": len(results)}
        
    except Exception as e:
        logger.error(f"Batch classification error: {e}")
        raise HTTPException(status_code=500, detail=f"Batch classification failed: {str(e)}")

# ============================================================================
# Model Management
# ============================================================================

@app.post("/api/v1/retrain")
async def retrain_models(background_tasks: BackgroundTasks):
    """Trigger model retraining (placeholder for MLOps pipeline)"""
    background_tasks.add_task(retrain_classification_models)
    return BaseResponse(message="Model retraining started")

async def retrain_classification_models():
    """Background task for model retraining"""
    logger.info("Starting model retraining process...")
    # TODO: Implement model retraining pipeline
    # This would involve:
    # 1. Collecting new training data
    # 2. Fine-tuning BERT on BFSI documents
    # 3. Updating keyword rules based on performance
    # 4. Model validation and deployment
    logger.info("Model retraining completed")

# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.classification_host,
        port=settings.classification_port,
        reload=settings.debug,
        log_level=settings.log_level.lower()
    )
