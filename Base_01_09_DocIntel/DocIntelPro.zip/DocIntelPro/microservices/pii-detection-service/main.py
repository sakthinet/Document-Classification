"""
PII Detection and Anonymization Service
Uses Microsoft Presidio for comprehensive PII detection and anonymization
Optimized for BFSI documents with custom patterns and entity types
"""
from fastapi import FastAPI, HTTPException, BackgroundTasks
from contextlib import asynccontextmanager
import asyncio
import logging
import json
import os
import re
from typing import Dict, List, Optional, Union, Tuple, Any
from datetime import datetime
from dataclasses import dataclass

# Presidio imports
try:
    from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer
    from presidio_anonymizer import AnonymizerEngine
    from presidio_anonymizer.entities import OperatorConfig
except ImportError:
    AnalyzerEngine = None
    AnonymizerEngine = None

# spaCy for NLP
try:
    import spacy
except ImportError:
    spacy = None

# Import shared modules
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.config import settings
from shared.models import (
    PIIDetectionRequest, PIIDetectionResult, PIIEntity, AnonymizationRequest,
    AnonymizationResult, ServiceHealthCheck, BaseResponse
)

# Configure logging
logging.basicConfig(level=getattr(logging, settings.log_level))
logger = logging.getLogger(__name__)

# Global instances
analyzer_engine = None
anonymizer_engine = None
nlp_model = None

# BFSI-specific PII patterns
BFSI_PII_PATTERNS = {
    "ACCOUNT_NUMBER": [
        Pattern(name="account_number_pattern", regex=r"\b\d{8,12}\b", score=0.8),
        Pattern(name="iban_pattern", regex=r"\b[A-Z]{2}\d{2}[A-Z0-9]{4}\d{7}([A-Z0-9]?){0,16}\b", score=0.9)
    ],
    "ROUTING_NUMBER": [
        Pattern(name="aba_routing", regex=r"\b[0-9]{9}\b", score=0.7),
        Pattern(name="swift_code", regex=r"\b[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?\b", score=0.8)
    ],
    "CREDIT_CARD_NUMBER": [
        Pattern(name="visa_card", regex=r"\b4[0-9]{12}(?:[0-9]{3})?\b", score=0.9),
        Pattern(name="mastercard", regex=r"\b5[1-5][0-9]{14}\b", score=0.9),
        Pattern(name="amex_card", regex=r"\b3[47][0-9]{13}\b", score=0.9),
        Pattern(name="discover_card", regex=r"\b6(?:011|5[0-9]{2})[0-9]{12}\b", score=0.9)
    ],
    "TAX_ID": [
        Pattern(name="ssn_pattern", regex=r"\b\d{3}-\d{2}-\d{4}\b", score=0.9),
        Pattern(name="ein_pattern", regex=r"\b\d{2}-\d{7}\b", score=0.8),
        Pattern(name="itin_pattern", regex=r"\b9\d{2}-\d{2}-\d{4}\b", score=0.8)
    ],
    "LOAN_NUMBER": [
        Pattern(name="loan_id", regex=r"\bLN\d{8,12}\b", score=0.8),
        Pattern(name="mortgage_id", regex=r"\bMTG\d{8,12}\b", score=0.8)
    ],
    "POLICY_NUMBER": [
        Pattern(name="insurance_policy", regex=r"\b[A-Z]{2,4}\d{8,12}\b", score=0.7)
    ]
}

# Entity confidence thresholds
ENTITY_CONFIDENCE_THRESHOLDS = {
    "PERSON": 0.8,
    "PHONE_NUMBER": 0.7,
    "EMAIL_ADDRESS": 0.9,
    "CREDIT_CARD": 0.9,
    "ACCOUNT_NUMBER": 0.8,
    "SSN": 0.9,
    "ADDRESS": 0.7,
    "DATE_TIME": 0.6,
    "ORGANIZATION": 0.7,
    "LOCATION": 0.6
}

# Anonymization strategies
ANONYMIZATION_STRATEGIES = {
    "mask": "replace",
    "redact": "redact", 
    "hash": "hash",
    "encrypt": "encrypt",
    "synthetic": "replace"
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize PII detection components on startup"""
    global analyzer_engine, anonymizer_engine, nlp_model
    
    logger.info("Initializing PII detection service...")
    
    try:
        # Load spaCy model
        if spacy:
            try:
                nlp_model = spacy.load("en_core_web_sm")
                logger.info("Loaded spaCy model successfully")
            except OSError:
                logger.warning("spaCy model 'en_core_web_sm' not found")
                nlp_model = None
        
        # Initialize Presidio Analyzer
        if AnalyzerEngine:
            analyzer_engine = AnalyzerEngine()
            
            # Add custom BFSI recognizers
            await _add_custom_recognizers()
            
            logger.info("Presidio Analyzer initialized with custom BFSI patterns")
        else:
            logger.error("Presidio Analyzer not available")
        
        # Initialize Presidio Anonymizer
        if AnonymizerEngine:
            anonymizer_engine = AnonymizerEngine()
            logger.info("Presidio Anonymizer initialized")
        
    except Exception as e:
        logger.error(f"Error initializing PII detection service: {e}")
        raise
    
    yield
    
    # Cleanup
    logger.info("PII detection service cleanup completed")

async def _add_custom_recognizers():
    """Add custom BFSI-specific PII recognizers to Presidio"""
    if not analyzer_engine:
        return
    
    # Account Number Recognizer
    account_recognizer = PatternRecognizer(
        supported_entity="ACCOUNT_NUMBER",
        patterns=BFSI_PII_PATTERNS["ACCOUNT_NUMBER"],
        name="account_number_recognizer"
    )
    analyzer_engine.registry.add_recognizer(account_recognizer)
    
    # Routing Number Recognizer
    routing_recognizer = PatternRecognizer(
        supported_entity="ROUTING_NUMBER", 
        patterns=BFSI_PII_PATTERNS["ROUTING_NUMBER"],
        name="routing_number_recognizer"
    )
    analyzer_engine.registry.add_recognizer(routing_recognizer)
    
    # Enhanced Credit Card Recognizer
    cc_recognizer = PatternRecognizer(
        supported_entity="CREDIT_CARD_ENHANCED",
        patterns=BFSI_PII_PATTERNS["CREDIT_CARD_NUMBER"],
        name="enhanced_credit_card_recognizer"
    )
    analyzer_engine.registry.add_recognizer(cc_recognizer)
    
    # Tax ID Recognizer
    tax_recognizer = PatternRecognizer(
        supported_entity="TAX_ID",
        patterns=BFSI_PII_PATTERNS["TAX_ID"],
        name="tax_id_recognizer"
    )
    analyzer_engine.registry.add_recognizer(tax_recognizer)
    
    # Loan Number Recognizer
    loan_recognizer = PatternRecognizer(
        supported_entity="LOAN_NUMBER",
        patterns=BFSI_PII_PATTERNS["LOAN_NUMBER"], 
        name="loan_number_recognizer"
    )
    analyzer_engine.registry.add_recognizer(loan_recognizer)
    
    # Policy Number Recognizer
    policy_recognizer = PatternRecognizer(
        supported_entity="POLICY_NUMBER",
        patterns=BFSI_PII_PATTERNS["POLICY_NUMBER"],
        name="policy_number_recognizer"
    )
    analyzer_engine.registry.add_recognizer(policy_recognizer)
    
    logger.info("Added custom BFSI PII recognizers")

# FastAPI app
app = FastAPI(
    title="PII Detection and Anonymization Service",
    description="Comprehensive PII detection for BFSI documents using Presidio",
    version=settings.app_version,
    lifespan=lifespan
)

class BFSIPIIProcessor:
    """Advanced PII processing for BFSI documents"""
    
    def __init__(self):
        self.entity_cache = {}  # Cache for frequent entities
    
    async def detect_pii(
        self, 
        text: str, 
        language: str = "en",
        entities: Optional[List[str]] = None,
        confidence_threshold: float = 0.5
    ) -> List[PIIEntity]:
        """Detect PII entities in text using Presidio with BFSI optimizations"""
        try:
            if not analyzer_engine:
                raise HTTPException(status_code=503, detail="PII analyzer not available")
            
            # Use default entities if none specified
            if not entities:
                entities = [
                    "PERSON", "PHONE_NUMBER", "EMAIL_ADDRESS", "CREDIT_CARD", 
                    "ACCOUNT_NUMBER", "ROUTING_NUMBER", "TAX_ID", "SSN",
                    "ADDRESS", "DATE_TIME", "ORGANIZATION", "LOCATION",
                    "LOAN_NUMBER", "POLICY_NUMBER", "CREDIT_CARD_ENHANCED"
                ]
            
            # Analyze text
            analyzer_results = analyzer_engine.analyze(
                text=text,
                entities=entities,
                language=language
            )
            
            # Convert to our format with BFSI-specific enhancements
            pii_entities = []
            for result in analyzer_results:
                # Apply confidence thresholds
                entity_threshold = ENTITY_CONFIDENCE_THRESHOLDS.get(
                    result.entity_type, confidence_threshold
                )
                
                if result.score >= entity_threshold:
                    # Extract the actual text
                    entity_text = text[result.start:result.end]
                    
                    # Apply BFSI-specific validation
                    if await self._validate_bfsi_entity(result.entity_type, entity_text):
                        pii_entity = PIIEntity(
                            entity_type=result.entity_type,
                            text=entity_text,
                            start=result.start,
                            end=result.end,
                            confidence=result.score,
                            context=await self._get_entity_context(text, result.start, result.end)
                        )
                        pii_entities.append(pii_entity)
            
            # Apply BFSI-specific post-processing
            pii_entities = await self._post_process_entities(pii_entities, text)
            
            return pii_entities
            
        except Exception as e:
            logger.error(f"PII detection error: {e}")
            raise HTTPException(status_code=500, detail=f"PII detection failed: {str(e)}")
    
    async def anonymize_text(
        self,
        text: str,
        entities: List[PIIEntity],
        strategy: str = "mask",
        custom_operators: Optional[Dict] = None
    ) -> Tuple[str, Dict]:
        """Anonymize text by replacing PII entities"""
        try:
            if not anonymizer_engine:
                raise HTTPException(status_code=503, detail="PII anonymizer not available")
            
            # Convert our entities to Presidio format
            presidio_entities = []
            for entity in entities:
                presidio_entities.append({
                    "entity_type": entity.entity_type,
                    "start": entity.start,
                    "end": entity.end,
                    "score": entity.confidence
                })
            
            # Prepare operators
            operators = {}
            
            if strategy == "mask":
                # Default masking strategy
                for entity in entities:
                    operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "[MASKED]"})
            
            elif strategy == "redact":
                # Redaction strategy
                for entity in entities:
                    operators[entity.entity_type] = OperatorConfig("redact")
            
            elif strategy == "hash":
                # Hashing strategy
                for entity in entities:
                    operators[entity.entity_type] = OperatorConfig("hash")
            
            elif strategy == "synthetic":
                # Replace with synthetic data
                operators = await self._get_synthetic_operators(entities)
            
            # Apply custom operators if provided
            if custom_operators:
                operators.update(custom_operators)
            
            # Anonymize text
            anonymized_result = anonymizer_engine.anonymize(
                text=text,
                analyzer_results=presidio_entities,
                operators=operators
            )
            
            # Create mapping of original to anonymized values
            anonymization_map = {}
            for item in anonymized_result.items:
                original_text = text[item.start:item.end]
                anonymized_text = item.text if hasattr(item, 'text') else "[REDACTED]"
                anonymization_map[original_text] = anonymized_text
            
            return anonymized_result.text, anonymization_map
            
        except Exception as e:
            logger.error(f"Text anonymization error: {e}")
            raise HTTPException(status_code=500, detail=f"Anonymization failed: {str(e)}")
    
    async def _validate_bfsi_entity(self, entity_type: str, entity_text: str) -> bool:
        """Apply BFSI-specific validation for detected entities"""
        
        # Credit card validation using Luhn algorithm
        if entity_type in ["CREDIT_CARD", "CREDIT_CARD_ENHANCED"]:
            return self._validate_credit_card(entity_text)
        
        # Account number validation (basic length check)
        if entity_type == "ACCOUNT_NUMBER":
            # Remove any spaces or hyphens
            clean_number = re.sub(r'[\s\-]', '', entity_text)
            return len(clean_number) >= 8 and clean_number.isdigit()
        
        # SSN validation
        if entity_type in ["SSN", "TAX_ID"]:
            return self._validate_ssn(entity_text)
        
        # Routing number validation
        if entity_type == "ROUTING_NUMBER":
            return self._validate_routing_number(entity_text)
        
        return True  # Default to valid for other entity types
    
    def _validate_credit_card(self, number: str) -> bool:
        """Validate credit card using Luhn algorithm"""
        # Remove spaces and hyphens
        number = re.sub(r'[\s\-]', '', number)
        
        if not number.isdigit() or len(number) < 13:
            return False
        
        # Luhn algorithm
        def luhn_check(card_num):
            def digits_of(n):
                return [int(d) for d in str(n)]
            
            digits = digits_of(card_num)
            odd_digits = digits[-1::-2]
            even_digits = digits[-2::-2]
            checksum = sum(odd_digits)
            for d in even_digits:
                checksum += sum(digits_of(d*2))
            return checksum % 10 == 0
        
        return luhn_check(number)
    
    def _validate_ssn(self, ssn: str) -> bool:
        """Validate SSN format and basic rules"""
        # Remove hyphens and spaces
        clean_ssn = re.sub(r'[\s\-]', '', ssn)
        
        if len(clean_ssn) != 9 or not clean_ssn.isdigit():
            return False
        
        # Basic SSN validation rules
        area = clean_ssn[:3]
        group = clean_ssn[3:5]
        serial = clean_ssn[5:]
        
        # Invalid area numbers
        if area in ['000', '666'] or area.startswith('9'):
            return False
        
        # Invalid group or serial
        if group == '00' or serial == '0000':
            return False
        
        return True
    
    def _validate_routing_number(self, routing: str) -> bool:
        """Validate ABA routing number"""
        # Remove spaces and hyphens
        clean_routing = re.sub(r'[\s\-]', '', routing)
        
        if len(clean_routing) != 9 or not clean_routing.isdigit():
            return False
        
        # ABA routing number checksum
        digits = [int(d) for d in clean_routing]
        checksum = (
            3 * (digits[0] + digits[3] + digits[6]) +
            7 * (digits[1] + digits[4] + digits[7]) +
            1 * (digits[2] + digits[5] + digits[8])
        ) % 10
        
        return checksum == 0
    
    async def _get_entity_context(self, text: str, start: int, end: int, window: int = 50) -> str:
        """Get context around detected entity"""
        context_start = max(0, start - window)
        context_end = min(len(text), end + window)
        
        context = text[context_start:context_end]
        # Highlight the entity in context
        entity_in_context = (
            context[:start-context_start] + 
            f"**{text[start:end]}**" + 
            context[end-context_start:]
        )
        
        return entity_in_context
    
    async def _post_process_entities(self, entities: List[PIIEntity], text: str) -> List[PIIEntity]:
        """Apply BFSI-specific post-processing to detected entities"""
        processed_entities = []
        
        # Remove duplicates and overlapping entities
        entities.sort(key=lambda x: (x.start, -x.confidence))
        
        for entity in entities:
            # Check for overlaps with already processed entities
            overlaps = False
            for processed in processed_entities:
                if (entity.start < processed.end and entity.end > processed.start):
                    # Keep the entity with higher confidence
                    if entity.confidence <= processed.confidence:
                        overlaps = True
                        break
                    else:
                        # Remove the lower confidence entity
                        processed_entities.remove(processed)
                        break
            
            if not overlaps:
                processed_entities.append(entity)
        
        return processed_entities
    
    async def _get_synthetic_operators(self, entities: List[PIIEntity]) -> Dict:
        """Generate synthetic replacement operators for entities"""
        operators = {}
        
        for entity in entities:
            if entity.entity_type == "PERSON":
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "John Doe"})
            elif entity.entity_type == "PHONE_NUMBER":
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "(555) 123-4567"})
            elif entity.entity_type == "EMAIL_ADDRESS":
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "user@example.com"})
            elif entity.entity_type == "ACCOUNT_NUMBER":
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "XXXX-XXXX-1234"})
            elif entity.entity_type in ["SSN", "TAX_ID"]:
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "XXX-XX-1234"})
            elif entity.entity_type == "CREDIT_CARD":
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "XXXX-XXXX-XXXX-1234"})
            else:
                operators[entity.entity_type] = OperatorConfig("replace", {"new_value": "[SYNTHETIC]"})
        
        return operators

# Initialize PII processor
pii_processor = BFSIPIIProcessor()

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/health", response_model=ServiceHealthCheck)
async def health_check():
    """Service health check"""
    components_status = {
        "presidio_analyzer": "loaded" if analyzer_engine else "not_loaded",
        "presidio_anonymizer": "loaded" if anonymizer_engine else "not_loaded",
        "spacy_model": "loaded" if nlp_model else "not_loaded"
    }
    
    return ServiceHealthCheck(
        service_name="pii-detection-service",
        status="healthy" if analyzer_engine and anonymizer_engine else "degraded",
        version=settings.app_version,
        dependencies=components_status
    )

@app.post("/api/v1/detect", response_model=PIIDetectionResult)
async def detect_pii(request: PIIDetectionRequest):
    """Detect PII entities in text"""
    try:
        entities = await pii_processor.detect_pii(
            text=request.text,
            language=request.language,
            entities=request.entity_types,
            confidence_threshold=request.confidence_threshold
        )
        
        # Calculate risk score based on detected entities
        risk_score = await _calculate_risk_score(entities)
        
        return PIIDetectionResult(
            text=request.text,
            entities=entities,
            total_entities=len(entities),
            risk_score=risk_score,
            processing_time=None  # Could add timing
        )
        
    except Exception as e:
        logger.error(f"PII detection error: {e}")
        raise HTTPException(status_code=500, detail=f"PII detection failed: {str(e)}")

@app.post("/api/v1/anonymize", response_model=AnonymizationResult)
async def anonymize_text(request: AnonymizationRequest):
    """Anonymize text by replacing PII entities"""
    try:
        # First detect PII if entities not provided
        if not request.entities:
            entities = await pii_processor.detect_pii(
                text=request.text,
                confidence_threshold=request.confidence_threshold
            )
        else:
            entities = request.entities
        
        # Anonymize text
        anonymized_text, anonymization_map = await pii_processor.anonymize_text(
            text=request.text,
            entities=entities,
            strategy=request.strategy,
            custom_operators=request.custom_operators
        )
        
        return AnonymizationResult(
            original_text=request.text,
            anonymized_text=anonymized_text,
            entities_anonymized=len(entities),
            anonymization_map=anonymization_map,
            strategy=request.strategy
        )
        
    except Exception as e:
        logger.error(f"Text anonymization error: {e}")
        raise HTTPException(status_code=500, detail=f"Anonymization failed: {str(e)}")

@app.get("/api/v1/entity-types")
async def get_supported_entity_types():
    """Get list of supported PII entity types"""
    standard_entities = [
        "PERSON", "PHONE_NUMBER", "EMAIL_ADDRESS", "CREDIT_CARD", 
        "SSN", "ADDRESS", "DATE_TIME", "ORGANIZATION", "LOCATION"
    ]
    
    bfsi_entities = [
        "ACCOUNT_NUMBER", "ROUTING_NUMBER", "TAX_ID", 
        "LOAN_NUMBER", "POLICY_NUMBER", "CREDIT_CARD_ENHANCED"
    ]
    
    return {
        "standard_entities": standard_entities,
        "bfsi_entities": bfsi_entities,
        "all_entities": standard_entities + bfsi_entities
    }

@app.post("/api/v1/validate-entity")
async def validate_entity(entity_type: str, entity_value: str):
    """Validate a specific entity value"""
    try:
        is_valid = await pii_processor._validate_bfsi_entity(entity_type, entity_value)
        
        return {
            "entity_type": entity_type,
            "entity_value": entity_value,
            "is_valid": is_valid,
            "validation_rules": await _get_validation_rules(entity_type)
        }
        
    except Exception as e:
        logger.error(f"Entity validation error: {e}")
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

@app.post("/api/v1/batch-detect")
async def batch_detect_pii(texts: List[str], entities: Optional[List[str]] = None):
    """Batch PII detection for multiple texts"""
    try:
        results = []
        
        for i, text in enumerate(texts):
            try:
                detected_entities = await pii_processor.detect_pii(
                    text=text,
                    entities=entities
                )
                
                risk_score = await _calculate_risk_score(detected_entities)
                
                results.append({
                    "index": i,
                    "text_length": len(text),
                    "entities": [entity.dict() for entity in detected_entities],
                    "total_entities": len(detected_entities),
                    "risk_score": risk_score
                })
                
            except Exception as e:
                results.append({
                    "index": i,
                    "error": str(e)
                })
        
        return {
            "results": results,
            "total_processed": len(texts),
            "successful": len([r for r in results if "error" not in r])
        }
        
    except Exception as e:
        logger.error(f"Batch PII detection error: {e}")
        raise HTTPException(status_code=500, detail=f"Batch detection failed: {str(e)}")

# ============================================================================
# Helper Functions
# ============================================================================

async def _calculate_risk_score(entities: List[PIIEntity]) -> float:
    """Calculate risk score based on detected PII entities"""
    if not entities:
        return 0.0
    
    # Risk weights for different entity types
    risk_weights = {
        "SSN": 1.0,
        "TAX_ID": 1.0,
        "CREDIT_CARD": 0.9,
        "CREDIT_CARD_ENHANCED": 0.9,
        "ACCOUNT_NUMBER": 0.8,
        "ROUTING_NUMBER": 0.7,
        "PERSON": 0.6,
        "PHONE_NUMBER": 0.5,
        "EMAIL_ADDRESS": 0.5,
        "ADDRESS": 0.6,
        "LOAN_NUMBER": 0.7,
        "POLICY_NUMBER": 0.6
    }
    
    total_risk = 0.0
    for entity in entities:
        weight = risk_weights.get(entity.entity_type, 0.3)
        confidence_factor = entity.confidence
        total_risk += weight * confidence_factor
    
    # Normalize to 0-1 scale
    max_possible_risk = len(entities) * 1.0
    normalized_risk = min(1.0, total_risk / max_possible_risk) if max_possible_risk > 0 else 0.0
    
    return round(normalized_risk, 3)

async def _get_validation_rules(entity_type: str) -> List[str]:
    """Get validation rules for entity type"""
    rules = {
        "CREDIT_CARD": [
            "Must be 13-19 digits",
            "Must pass Luhn algorithm check",
            "Must match known card patterns (Visa, MasterCard, etc.)"
        ],
        "SSN": [
            "Must be 9 digits",
            "Cannot start with 000, 666, or 9XX",
            "Group and serial cannot be 00 or 0000"
        ],
        "ACCOUNT_NUMBER": [
            "Must be 8-12 digits",
            "Must contain only numeric characters"
        ],
        "ROUTING_NUMBER": [
            "Must be exactly 9 digits",
            "Must pass ABA checksum validation"
        ]
    }
    
    return rules.get(entity_type, ["Standard format validation applied"])

# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.pii_detection_host,
        port=settings.pii_detection_port,
        reload=settings.debug,
        log_level=settings.log_level.lower()
    )
