"""
FastAPI Gateway Service for DocIntelPro
High-performance async gateway with gRPC and HTTP service communication
"""
from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from contextlib import asynccontextmanager
import asyncio
import httpx
import time
import logging
from typing import Dict, Any, Optional, List
import uuid
from datetime import datetime, timedelta

# Import shared modules
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.config import settings, service_urls
from shared.models import (
    DocumentProcessingRequest, DocumentProcessingResult, BaseResponse, 
    ErrorResponse, ServiceHealthCheck, BFSIMetrics, ProcessingMetrics,
    ComplianceMetrics, DashboardMetrics
)

# Configure logging
logging.basicConfig(level=getattr(logging, settings.log_level))
logger = logging.getLogger(__name__)

# Security
security = HTTPBearer()

# Global HTTP client for service communication
http_client: Optional[httpx.AsyncClient] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    global http_client
    
    # Startup
    logger.info("Starting FastAPI Gateway Service...")
    http_client = httpx.AsyncClient(
        timeout=httpx.Timeout(30.0),
        limits=httpx.Limits(max_keepalive_connections=20, max_connections=100)
    )
    
    # Health check for dependent services
    await check_service_health()
    
    yield
    
    # Shutdown
    logger.info("Shutting down FastAPI Gateway Service...")
    if http_client:
        await http_client.aclose()

# FastAPI app initialization
app = FastAPI(
    title="DocIntelPro Gateway",
    description="High-performance async gateway for document intelligence microservices",
    version=settings.app_version,
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
    lifespan=lifespan
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1000)

# ============================================================================
# Authentication & Authorization
# ============================================================================

async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify JWT token - implement proper JWT validation"""
    # TODO: Implement proper JWT verification with your auth service
    # For now, we'll accept any token for development
    if not credentials.credentials:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    return {"user_id": "demo-user", "organization_id": "f5a5744d-f922-4918-b5ae-0d9a430b9b0b"}

# ============================================================================
# Health & Monitoring
# ============================================================================

@app.get("/health", response_model=ServiceHealthCheck)
async def health_check():
    """Service health check endpoint"""
    return ServiceHealthCheck(
        service_name="gateway",
        status="healthy",
        version=settings.app_version,
        dependencies=await get_service_dependencies()
    )

async def get_service_dependencies() -> Dict[str, str]:
    """Check health of dependent services"""
    dependencies = {}
    services = [
        ("document-processor", service_urls.DOCUMENT_PROCESSOR),
        ("classification", service_urls.CLASSIFICATION),
        ("ocr", service_urls.OCR),
        ("vector-search", service_urls.VECTOR_SEARCH)
    ]
    
    async def check_service(name: str, url: str):
        try:
            if http_client:
                response = await http_client.get(f"{url}/health", timeout=5.0)
                dependencies[name] = "healthy" if response.status_code == 200 else "unhealthy"
            else:
                dependencies[name] = "unavailable"
        except Exception:
            dependencies[name] = "unreachable"
    
    await asyncio.gather(*[check_service(name, url) for name, url in services])
    return dependencies

async def check_service_health():
    """Check if all required services are available"""
    dependencies = await get_service_dependencies()
    unhealthy_services = [name for name, status in dependencies.items() if status != "healthy"]
    
    if unhealthy_services:
        logger.warning(f"Some services are not healthy: {unhealthy_services}")
    else:
        logger.info("All dependent services are healthy")

# ============================================================================
# Metrics & Analytics
# ============================================================================

@app.get("/api/v1/dashboard/metrics", response_model=DashboardMetrics)
async def get_dashboard_metrics(auth_data: dict = Depends(verify_token)):
    """Get comprehensive dashboard metrics for BFSI operations"""
    organization_id = auth_data["organization_id"]
    
    try:
        # Simulate metrics - replace with actual database queries
        metrics = DashboardMetrics(
            processing=ProcessingMetrics(
                total_documents=12547,
                processed_today=234,
                failed_today=3,
                average_processing_time=2.3,
                accuracy_rate=94.7
            ),
            bfsi=BFSIMetrics(
                loan_applications=1247,
                kyc_documents=856,
                compliance_reports=89,
                fraud_alerts=3,
                high_risk_documents=12,
                pii_detections=45
            ),
            compliance=ComplianceMetrics(
                overall_score=94.2,
                framework_scores={
                    "SOX": 95.0,
                    "BSA": 88.0,
                    "AML": 92.0,
                    "GLBA": 97.0
                },
                violations=8,
                pending_reviews=23
            ),
            classification_breakdown={
                "confidential": 1247,
                "restricted": 2134,
                "internal": 6789,
                "public": 2377
            }
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error fetching dashboard metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch dashboard metrics")

# ============================================================================
# Document Processing Pipeline
# ============================================================================

@app.post("/api/v1/documents/process", response_model=BaseResponse)
async def process_document(
    request: DocumentProcessingRequest,
    background_tasks: BackgroundTasks,
    auth_data: dict = Depends(verify_token)
):
    """Start document processing pipeline"""
    try:
        # Add organization context
        request.organization_id = auth_data["organization_id"]
        
        # Start background processing
        background_tasks.add_task(process_document_pipeline, request)
        
        return BaseResponse(
            message=f"Document processing started for {request.document_id}",
        )
        
    except Exception as e:
        logger.error(f"Error starting document processing: {e}")
        raise HTTPException(status_code=500, detail="Failed to start document processing")

async def process_document_pipeline(request: DocumentProcessingRequest):
    """Background task for document processing pipeline"""
    try:
        logger.info(f"Starting processing pipeline for document {request.document_id}")
        
        # Step 1: OCR Processing
        ocr_result = await call_ocr_service(request)
        
        # Step 2: Classification
        if ocr_result:
            classification_result = await call_classification_service(request, ocr_result)
        
        # Step 3: Vector Embedding
        if ocr_result:
            vector_result = await call_vector_service(request, ocr_result)
        
        # Step 4: Store results and update database
        # TODO: Implement database storage
        
        logger.info(f"Completed processing pipeline for document {request.document_id}")
        
    except Exception as e:
        logger.error(f"Error in processing pipeline for {request.document_id}: {e}")

async def call_ocr_service(request: DocumentProcessingRequest) -> Optional[Dict[str, Any]]:
    """Call OCR microservice"""
    try:
        if not http_client:
            return None
            
        ocr_request = {
            "document_id": request.document_id,
            "file_path": request.file_path,
            "provider": request.processing_options.get("ocr_provider", "paddleocr"),
            "language": request.metadata.language or "en"
        }
        
        response = await http_client.post(
            f"{service_urls.OCR}/api/v1/ocr/process",
            json=ocr_request,
            timeout=60.0
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"OCR service error: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Error calling OCR service: {e}")
        return None

async def call_classification_service(
    request: DocumentProcessingRequest, 
    ocr_result: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """Call Classification microservice"""
    try:
        if not http_client:
            return None
            
        classification_request = {
            "document_id": request.document_id,
            "text_content": ocr_result.get("extracted_text", ""),
            "metadata": request.metadata.dict(),
            "organization_id": request.organization_id
        }
        
        response = await http_client.post(
            f"{service_urls.CLASSIFICATION}/api/v1/classify",
            json=classification_request,
            timeout=30.0
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"Classification service error: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Error calling classification service: {e}")
        return None

async def call_vector_service(
    request: DocumentProcessingRequest, 
    ocr_result: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """Call Vector Search microservice for embedding generation"""
    try:
        if not http_client:
            return None
            
        vector_request = {
            "document_id": request.document_id,
            "text_content": ocr_result.get("extracted_text", ""),
            "metadata": request.metadata.dict(),
            "organization_id": request.organization_id
        }
        
        response = await http_client.post(
            f"{service_urls.VECTOR_SEARCH}/api/v1/embed",
            json=vector_request,
            timeout=30.0
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"Vector service error: {response.status_code}")
            return None
            
    except Exception as e:
        logger.error(f"Error calling vector service: {e}")
        return None

# ============================================================================
# Search & Retrieval
# ============================================================================

@app.post("/api/v1/search/documents")
async def search_documents(
    query: str,
    filters: Optional[Dict[str, Any]] = None,
    limit: int = 10,
    auth_data: dict = Depends(verify_token)
):
    """Search documents using vector similarity and filters"""
    try:
        if not http_client:
            raise HTTPException(status_code=503, detail="Vector search service unavailable")
        
        search_request = {
            "query": query,
            "organization_id": auth_data["organization_id"],
            "filters": filters or {},
            "limit": limit
        }
        
        response = await http_client.post(
            f"{service_urls.VECTOR_SEARCH}/api/v1/search",
            json=search_request,
            timeout=30.0
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise HTTPException(status_code=response.status_code, detail="Search failed")
            
    except Exception as e:
        logger.error(f"Error in document search: {e}")
        raise HTTPException(status_code=500, detail="Search operation failed")

# ============================================================================
# BFSI Specific Endpoints
# ============================================================================

@app.get("/api/v1/bfsi/document-types")
async def get_bfsi_document_types(auth_data: dict = Depends(verify_token)):
    """Get available BFSI document types"""
    # TODO: Implement database query for BFSI document types
    from shared.models import DocumentType
    
    document_types = [
        {
            "type_key": doc_type.value,
            "name": doc_type.value.replace("_", " ").title(),
            "category": "bfsi"
        }
        for doc_type in DocumentType
    ]
    
    return {"document_types": document_types}

@app.get("/api/v1/bfsi/compliance-frameworks")
async def get_compliance_frameworks(auth_data: dict = Depends(verify_token)):
    """Get available compliance frameworks"""
    frameworks = [
        {"code": "SOX", "name": "Sarbanes-Oxley Act", "industry": "Financial Services"},
        {"code": "BSA", "name": "Bank Secrecy Act", "industry": "Banking"},
        {"code": "AML", "name": "Anti-Money Laundering", "industry": "Financial Services"},
        {"code": "GLBA", "name": "Gramm-Leach-Bliley Act", "industry": "Financial Services"},
        {"code": "FCRA", "name": "Fair Credit Reporting Act", "industry": "Financial Services"},
    ]
    
    return {"frameworks": frameworks}

# ============================================================================
# Error Handlers
# ============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return ErrorResponse(
        message=exc.detail,
        error_code=str(exc.status_code)
    ).dict()

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}")
    return ErrorResponse(
        message="Internal server error",
        error_code="500",
        details={"exception": str(exc)} if settings.debug else None
    ).dict()

# ============================================================================
# Main Application Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.gateway_host,
        port=settings.gateway_port,
        reload=settings.debug,
        log_level=settings.log_level.lower(),
        access_log=True
    )
