"""
Shared Pydantic models for DocIntelPro microservices
"""
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from enum import Enum
import uuid

# ============================================================================
# Base Models
# ============================================================================

class BaseResponse(BaseModel):
    success: bool = True
    message: str = "Operation completed successfully"
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ErrorResponse(BaseResponse):
    success: bool = False
    error_code: Optional[str] = None
    details: Optional[Dict[str, Any]] = None

# ============================================================================
# Enums
# ============================================================================

class DocumentType(str, Enum):
    # BFSI Document Types
    LOAN_APPLICATION = "LOAN_APPLICATION"
    CREDIT_REPORT = "CREDIT_REPORT"
    LOAN_AGREEMENT = "LOAN_AGREEMENT"
    KYC_DOCUMENT = "KYC_DOCUMENT"
    AML_REPORT = "AML_REPORT"
    SAR_FILING = "SAR_FILING"
    FINANCIAL_STATEMENT = "FINANCIAL_STATEMENT"
    AUDIT_REPORT = "AUDIT_REPORT"
    TAX_DOCUMENT = "TAX_DOCUMENT"
    INSURANCE_POLICY = "INSURANCE_POLICY"
    INSURANCE_CLAIM = "INSURANCE_CLAIM"
    INVESTMENT_AGREEMENT = "INVESTMENT_AGREEMENT"
    PROSPECTUS = "PROSPECTUS"
    WIRE_TRANSFER = "WIRE_TRANSFER"
    TRANSACTION_RECORD = "TRANSACTION_RECORD"

class ClassificationLevel(str, Enum):
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    INTERNAL = "internal"
    PUBLIC = "public"

class ProcessingStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class ComplianceStatus(str, Enum):
    PENDING = "pending"
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    REVIEW_REQUIRED = "review_required"

class OCRProvider(str, Enum):
    PADDLEOCR = "paddleocr"
    AZURE_DI = "azure_di"
    TESSERACT = "tesseract"
    GOOGLE_VISION = "google_vision"

# ============================================================================
# Document Models
# ============================================================================

class DocumentMetadata(BaseModel):
    file_name: str
    file_size: int
    mime_type: str
    page_count: Optional[int] = None
    language: Optional[str] = "en"
    source_path: str
    
class PIIDetection(BaseModel):
    detected: bool = False
    types: List[str] = []
    confidence_scores: Dict[str, float] = {}
    masked_content: Optional[str] = None

class ClassificationResult(BaseModel):
    document_type: Optional[DocumentType] = None
    classification_level: ClassificationLevel = ClassificationLevel.INTERNAL
    confidence: float = 0.0
    reasoning: Optional[str] = None
    compliance_flags: List[str] = []

class OCRResult(BaseModel):
    provider: OCRProvider
    extracted_text: str
    confidence: float
    page_results: List[Dict[str, Any]] = []
    processing_time: float
    
class VectorEmbedding(BaseModel):
    vector: List[float]
    model: str
    dimensions: int

class DocumentProcessingRequest(BaseModel):
    document_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    file_path: str
    metadata: DocumentMetadata
    organization_id: str
    source_id: str
    processing_options: Dict[str, Any] = {}

class DocumentProcessingResult(BaseModel):
    document_id: str
    status: ProcessingStatus
    metadata: DocumentMetadata
    ocr_result: Optional[OCRResult] = None
    classification: Optional[ClassificationResult] = None
    pii_detection: Optional[PIIDetection] = None
    vector_embedding: Optional[VectorEmbedding] = None
    compliance_status: ComplianceStatus = ComplianceStatus.PENDING
    risk_score: Optional[float] = None
    processing_time: float
    error_message: Optional[str] = None

# ============================================================================
# BFSI Specific Models
# ============================================================================

class BFSIDocumentType(BaseModel):
    type_key: str
    name: str
    category: str
    classification: ClassificationLevel
    description: Optional[str] = None
    required_fields: List[str] = []
    pii_fields: List[str] = []
    retention_period: str = "7_years"
    compliance_flags: List[str] = []

class ComplianceFramework(BaseModel):
    code: str
    name: str
    description: Optional[str] = None
    industry: Optional[str] = None

class ComplianceCheck(BaseModel):
    framework: str
    status: ComplianceStatus
    score: Optional[float] = None
    findings: List[str] = []
    recommendations: List[str] = []

# ============================================================================
# Source Configuration Models
# ============================================================================

class SourceType(str, Enum):
    NETWORK_FOLDER = "network_folder"
    SHAREPOINT = "sharepoint"
    DATABASE = "database"
    FTP = "ftp"
    CLOUD_STORAGE = "cloud_storage"
    CORE_BANKING = "core_banking"
    LOAN_MANAGEMENT = "loan_management"

class DocumentSource(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    type: SourceType
    provider: Optional[str] = None
    description: Optional[str] = None
    domain: str = "bfsi"
    organization_id: str
    connection_config: Dict[str, Any]
    document_types: List[str] = []
    compliance_level: ClassificationLevel = ClassificationLevel.INTERNAL
    is_active: bool = True

class ProcessingRules(BaseModel):
    enable_ocr: bool = True
    ocr_languages: List[str] = ["en"]
    ocr_provider: OCRProvider = OCRProvider.PADDLEOCR
    enable_ai_classification: bool = True
    enable_pii_detection: bool = True
    enable_compliance_check: bool = True
    encryption_required: bool = False
    retention_policy: Optional[str] = None
    compliance_frameworks: List[str] = []

# ============================================================================
# Service Communication Models
# ============================================================================

class ServiceHealthCheck(BaseModel):
    service_name: str
    status: str
    version: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    dependencies: Dict[str, str] = {}

class OCRRequest(BaseModel):
    document_id: str
    file_path: str
    provider: OCRProvider = OCRProvider.PADDLEOCR
    language: str = "en"
    options: Dict[str, Any] = {}

class ClassificationRequest(BaseModel):
    document_id: str
    text_content: str
    metadata: DocumentMetadata
    organization_id: str
    
class VectorSearchRequest(BaseModel):
    query: str
    organization_id: str
    filters: Dict[str, Any] = {}
    limit: int = 10
    similarity_threshold: float = 0.7

class VectorSearchResult(BaseModel):
    document_id: str
    similarity_score: float
    metadata: Dict[str, Any]
    preview_text: Optional[str] = None

# ============================================================================
# Analytics and Metrics Models
# ============================================================================

class ProcessingMetrics(BaseModel):
    total_documents: int = 0
    processed_today: int = 0
    failed_today: int = 0
    average_processing_time: float = 0.0
    accuracy_rate: float = 0.0
    
class BFSIMetrics(BaseModel):
    loan_applications: int = 0
    kyc_documents: int = 0
    compliance_reports: int = 0
    fraud_alerts: int = 0
    high_risk_documents: int = 0
    pii_detections: int = 0
    
class ComplianceMetrics(BaseModel):
    overall_score: float = 0.0
    framework_scores: Dict[str, float] = {}
    violations: int = 0
    pending_reviews: int = 0

class DashboardMetrics(BaseModel):
    processing: ProcessingMetrics
    bfsi: BFSIMetrics
    compliance: ComplianceMetrics
    classification_breakdown: Dict[str, int] = {}

# ============================================================================
# Configuration
# ============================================================================

# Configure all models to use Python's built-in dataclasses for better performance
for model_class in [
    BaseResponse, ErrorResponse, DocumentMetadata, PIIDetection, 
    ClassificationResult, OCRResult, VectorEmbedding, DocumentProcessingRequest,
    DocumentProcessingResult, BFSIDocumentType, ComplianceFramework,
    ComplianceCheck, DocumentSource, ProcessingRules, ServiceHealthCheck,
    OCRRequest, ClassificationRequest, VectorSearchRequest, VectorSearchResult,
    ProcessingMetrics, BFSIMetrics, ComplianceMetrics, DashboardMetrics
]:
    model_class.model_config = ConfigDict(
        validate_assignment=True,
        use_enum_values=True,
        extra='forbid'
    )
