"""
Shared configuration for DocIntelPro Python microservices
"""
from pydantic_settings import BaseSettings
from typing import List, Optional
import os

class Settings(BaseSettings):
    # Application
    app_name: str = "DocIntelPro"
    app_version: str = "1.0.0"
    environment: str = "development"
    debug: bool = False
    
    # Database
    database_url: str = "postgresql+asyncpg://postgres:admin@12345@localhost:5432/RND"
    database_pool_size: int = 10
    database_max_overflow: int = 20
    
    # Database connection details for asyncpg
    db_host: str = "localhost"
    db_port: int = 5432
    db_user: str = "postgres"
    db_password: str = "admin@12345"
    db_name: str = "RND"
    
    # Redis
    redis_url: str = "redis://localhost:6379/0"
    redis_session_db: int = 1
    redis_cache_db: int = 2
    
    # Security
    secret_key: str = "your-super-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # FastAPI Gateway
    gateway_host: str = "0.0.0.0"
    gateway_port: int = 8000
    
    # Document Processor Service
    doc_processor_host: str = "0.0.0.0"
    doc_processor_port: int = 8001
    
    # Classification Service
    classification_host: str = "0.0.0.0"
    classification_port: int = 8002
    
    # OCR Service
    ocr_host: str = "0.0.0.0"
    ocr_port: int = 8003
    
    # Vector Search Service
    vector_search_host: str = "0.0.0.0"
    vector_search_port: int = 8004
    
    # PII Detection Service
    pii_detection_host: str = "0.0.0.0"
    pii_detection_port: int = 8005
    
    # ML Models Configuration
    ml_models_path: str = "./models"
    default_classification_model: str = "bert-base-uncased"
    spacy_model: str = "en_core_web_sm"
    
    # OCR Configuration
    ocr_providers: List[str] = ["paddleocr", "azure_di"]
    default_ocr_provider: str = "paddleocr"
    
    # Azure Document Intelligence (placeholder)
    azure_di_endpoint: Optional[str] = None
    azure_di_key: Optional[str] = None
    
    # Vector Database
    qdrant_host: str = "localhost"
    qdrant_port: int = 6333
    qdrant_grpc_port: int = 6334
    
    # On-premises storage
    local_storage_path: str = "./storage/documents"
    nas_storage_path: Optional[str] = None
    
    # Azure Cloud Storage (placeholder)
    azure_storage_connection_string: Optional[str] = None
    azure_container_name: Optional[str] = None
    
    # AWS S3 (placeholder)
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_region: str = "us-east-1"
    aws_bucket_name: Optional[str] = None
    
    # GCP Storage (placeholder)
    gcp_project_id: Optional[str] = None
    gcp_bucket_name: Optional[str] = None
    gcp_credentials_path: Optional[str] = None
    
    # Monitoring
    enable_prometheus: bool = True
    prometheus_port: int = 9090
    log_level: str = "INFO"
    
    # Processing configuration
    max_file_size_mb: int = 100
    supported_file_types: List[str] = [
        "pdf", "docx", "doc", "txt", "png", "jpg", "jpeg", "tiff"
    ]
    
    # BFSI specific configuration
    bfsi_compliance_frameworks: List[str] = [
        "SOX", "BSA", "AML", "GLBA", "FCRA", "TILA"
    ]
    
    # Healthcare specific configuration (placeholder)
    healthcare_compliance_frameworks: List[str] = [
        "HIPAA", "HITECH", "FDA_CFR"
    ]
    
    # Performance settings
    batch_size: int = 10
    max_concurrent_jobs: int = 5
    
    class Config:
        env_file = ".env"
        case_sensitive = False

# Global settings instance
settings = Settings()

# Service URLs for inter-service communication
class ServiceURLs:
    GATEWAY = f"http://{settings.gateway_host}:{settings.gateway_port}"
    DOCUMENT_PROCESSOR = f"http://{settings.doc_processor_host}:{settings.doc_processor_port}"
    CLASSIFICATION = f"http://{settings.classification_host}:{settings.classification_port}"
    OCR = f"http://{settings.ocr_host}:{settings.ocr_port}"
    VECTOR_SEARCH = f"http://{settings.vector_search_host}:{settings.vector_search_port}"
    PII_DETECTION = f"http://{settings.pii_detection_host}:{settings.pii_detection_port}"

service_urls = ServiceURLs()
