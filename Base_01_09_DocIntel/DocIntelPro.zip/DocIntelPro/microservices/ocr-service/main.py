"""
Multi-Provider OCR Service
Supports PaddleOCR, Azure Document Intelligence, and agentic provider selection
Optimized for BFSI document types with quality assessment
"""
from fastapi import FastAPI, HTTPException, File, UploadFile, BackgroundTasks
from contextlib import asynccontextmanager
import asyncio
import logging
import base64
import io
import json
import os
from typing import Dict, List, Optional, Union, Tuple
from datetime import datetime
from PIL import Image
import numpy as np
import cv2
import aiohttp
import aiofiles

# Import OCR libraries
try:
    import paddleocr
except ImportError:
    paddleocr = None

try:
    from azure.ai.documentintelligence import DocumentIntelligenceClient
    from azure.core.credentials import AzureKeyCredential
except ImportError:
    DocumentIntelligenceClient = None

# Import shared modules
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from shared.config import settings
from shared.models import (
    OCRRequest, OCRResult, OCRProvider, QualityAssessment,
    ServiceHealthCheck, BaseResponse, ErrorResponse
)

# Configure logging
logging.basicConfig(level=getattr(logging, settings.log_level))
logger = logging.getLogger(__name__)

# Global OCR instances
paddle_ocr = None
azure_client = None

# OCR Provider Configuration
OCR_PROVIDERS = {
    "PADDLE_OCR": {
        "enabled": True,
        "confidence_threshold": 0.6,
        "supports_layouts": True,
        "supports_tables": True,
        "cost_per_page": 0.0,  # Free
        "speed_score": 8,  # 1-10 scale
        "accuracy_score": 7
    },
    "AZURE_DI": {
        "enabled": bool(os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")),
        "confidence_threshold": 0.8,
        "supports_layouts": True,
        "supports_tables": True,
        "cost_per_page": 0.001,  # $1 per 1000 pages
        "speed_score": 6,
        "accuracy_score": 9
    }
}

# BFSI Document OCR Optimization
BFSI_OCR_CONFIG = {
    "LOAN_APPLICATION": {
        "preferred_provider": "AZURE_DI",
        "fallback_provider": "PADDLE_OCR",
        "quality_threshold": 0.85,
        "table_extraction": True,
        "layout_analysis": True
    },
    "FINANCIAL_STATEMENT": {
        "preferred_provider": "AZURE_DI",
        "fallback_provider": "PADDLE_OCR",
        "quality_threshold": 0.90,
        "table_extraction": True,
        "layout_analysis": True
    },
    "CHECK_DEPOSIT": {
        "preferred_provider": "PADDLE_OCR",
        "fallback_provider": "AZURE_DI",
        "quality_threshold": 0.80,
        "table_extraction": False,
        "layout_analysis": False
    },
    "DEFAULT": {
        "preferred_provider": "PADDLE_OCR",
        "fallback_provider": "AZURE_DI",
        "quality_threshold": 0.75,
        "table_extraction": True,
        "layout_analysis": True
    }
}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize OCR providers on startup"""
    global paddle_ocr, azure_client
    
    logger.info("Initializing OCR providers...")
    
    try:
        # Initialize PaddleOCR
        if paddleocr and OCR_PROVIDERS["PADDLE_OCR"]["enabled"]:
            paddle_ocr = paddleocr.PaddleOCR(
                use_angle_cls=True, 
                lang='en',
                show_log=False,
                use_gpu=False  # Set to True if CUDA available
            )
            logger.info("PaddleOCR initialized successfully")
        
        # Initialize Azure Document Intelligence
        azure_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
        azure_endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        
        if DocumentIntelligenceClient and azure_key and azure_endpoint:
            azure_client = DocumentIntelligenceClient(
                endpoint=azure_endpoint,
                credential=AzureKeyCredential(azure_key)
            )
            OCR_PROVIDERS["AZURE_DI"]["enabled"] = True
            logger.info("Azure Document Intelligence initialized successfully")
        else:
            OCR_PROVIDERS["AZURE_DI"]["enabled"] = False
            logger.warning("Azure Document Intelligence not available - missing credentials")
        
    except Exception as e:
        logger.error(f"Error initializing OCR providers: {e}")
        # Don't raise - service can still work with available providers
    
    yield
    
    # Cleanup
    logger.info("Cleaning up OCR service...")

# FastAPI app
app = FastAPI(
    title="Multi-Provider OCR Service",
    description="Intelligent OCR with multiple providers and agentic selection",
    version=settings.app_version,
    lifespan=lifespan
)

class AgenticOCRSelector:
    """Intelligent OCR provider selection based on document characteristics"""
    
    def __init__(self):
        self.provider_performance = {}  # Track provider performance over time
    
    async def select_optimal_provider(
        self, 
        image_data: bytes, 
        document_type: Optional[str] = None,
        quality_requirements: Optional[Dict] = None
    ) -> Tuple[str, Dict]:
        """
        Select the optimal OCR provider based on:
        1. Document type optimization
        2. Image quality assessment
        3. Provider availability and performance
        4. Cost considerations
        """
        
        # Step 1: Assess image quality
        quality_assessment = await self._assess_image_quality(image_data)
        
        # Step 2: Get document-specific configuration
        doc_config = BFSI_OCR_CONFIG.get(document_type, BFSI_OCR_CONFIG["DEFAULT"])
        
        # Step 3: Check provider availability
        available_providers = [
            provider for provider, config in OCR_PROVIDERS.items() 
            if config["enabled"]
        ]
        
        if not available_providers:
            raise HTTPException(status_code=503, detail="No OCR providers available")
        
        # Step 4: Select optimal provider
        selected_provider = await self._select_provider(
            doc_config, quality_assessment, available_providers
        )
        
        return selected_provider, {
            "quality_assessment": quality_assessment,
            "document_config": doc_config,
            "available_providers": available_providers
        }
    
    async def _assess_image_quality(self, image_data: bytes) -> Dict:
        """Assess image quality for OCR optimization"""
        try:
            # Convert bytes to OpenCV image
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is None:
                return {"quality_score": 0.0, "issues": ["Invalid image format"]}
            
            # Convert to grayscale for analysis
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Calculate quality metrics
            height, width = gray.shape
            
            # 1. Resolution check
            resolution_score = min(1.0, (width * height) / (1000 * 1000))  # Normalize to 1MP
            
            # 2. Contrast assessment
            contrast = gray.std()
            contrast_score = min(1.0, contrast / 50.0)  # Normalize
            
            # 3. Blur detection using Laplacian variance
            blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()
            blur_score = min(1.0, blur_score / 500.0)  # Normalize
            
            # 4. Brightness assessment
            brightness = gray.mean()
            brightness_score = 1.0 - abs(brightness - 128) / 128.0  # Optimal around 128
            
            # Overall quality score
            quality_score = (resolution_score + contrast_score + blur_score + brightness_score) / 4.0
            
            # Identify issues
            issues = []
            if resolution_score < 0.3:
                issues.append("Low resolution")
            if contrast_score < 0.3:
                issues.append("Poor contrast")
            if blur_score < 0.3:
                issues.append("Image blur detected")
            if brightness_score < 0.5:
                issues.append("Poor lighting")
            
            return {
                "quality_score": quality_score,
                "resolution": {"width": width, "height": height, "score": resolution_score},
                "contrast": {"value": contrast, "score": contrast_score},
                "blur": {"variance": blur_score * 500, "score": blur_score},
                "brightness": {"value": brightness, "score": brightness_score},
                "issues": issues
            }
            
        except Exception as e:
            logger.error(f"Image quality assessment error: {e}")
            return {"quality_score": 0.5, "issues": ["Quality assessment failed"]}
    
    async def _select_provider(
        self, 
        doc_config: Dict, 
        quality_assessment: Dict, 
        available_providers: List[str]
    ) -> str:
        """Select the best provider based on configuration and quality"""
        
        quality_score = quality_assessment["quality_score"]
        
        # If high quality image and Azure available, prefer Azure for accuracy
        if quality_score > 0.8 and "AZURE_DI" in available_providers:
            preferred = doc_config["preferred_provider"]
            if preferred in available_providers:
                return preferred
        
        # For poor quality images, try PaddleOCR first (often better with noisy images)
        if quality_score < 0.5 and "PADDLE_OCR" in available_providers:
            return "PADDLE_OCR"
        
        # Default to preferred provider if available
        preferred = doc_config["preferred_provider"]
        if preferred in available_providers:
            return preferred
        
        # Fallback to any available provider
        return available_providers[0]

# Initialize agentic selector
ocr_selector = AgenticOCRSelector()

# ============================================================================
# OCR Provider Implementations
# ============================================================================

class PaddleOCRProvider:
    """PaddleOCR implementation"""
    
    @staticmethod
    async def extract_text(image_data: bytes, config: Dict) -> OCRResult:
        """Extract text using PaddleOCR"""
        try:
            if not paddle_ocr:
                raise HTTPException(status_code=503, detail="PaddleOCR not available")
            
            # Convert bytes to image
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Run OCR
            results = paddle_ocr.ocr(image, cls=True)
            
            # Process results
            extracted_text = ""
            confidence_scores = []
            bounding_boxes = []
            
            if results and results[0]:
                for line in results[0]:
                    if line:
                        bbox, (text, confidence) = line
                        extracted_text += text + " "
                        confidence_scores.append(confidence)
                        bounding_boxes.append({
                            "text": text,
                            "confidence": confidence,
                            "bbox": bbox
                        })
            
            # Calculate overall confidence
            overall_confidence = np.mean(confidence_scores) if confidence_scores else 0.0
            
            return OCRResult(
                extracted_text=extracted_text.strip(),
                confidence=overall_confidence,
                provider=OCRProvider.PADDLE_OCR,
                bounding_boxes=bounding_boxes,
                metadata={
                    "total_lines": len(bounding_boxes),
                    "processing_time": None  # Could add timing
                }
            )
            
        except Exception as e:
            logger.error(f"PaddleOCR extraction error: {e}")
            raise HTTPException(status_code=500, detail=f"PaddleOCR failed: {str(e)}")

class AzureOCRProvider:
    """Azure Document Intelligence implementation"""
    
    @staticmethod
    async def extract_text(image_data: bytes, config: Dict) -> OCRResult:
        """Extract text using Azure Document Intelligence"""
        try:
            if not azure_client:
                raise HTTPException(status_code=503, detail="Azure Document Intelligence not available")
            
            # Determine the best model based on document type
            model_id = "prebuilt-read"  # Default
            if config.get("table_extraction"):
                model_id = "prebuilt-layout"
            
            # Submit for analysis
            poller = azure_client.begin_analyze_document(
                model_id=model_id,
                analyze_request=image_data,
                content_type="application/octet-stream"
            )
            
            # Get results
            result = poller.result()
            
            # Extract text and metadata
            extracted_text = result.content if result.content else ""
            
            # Process bounding boxes and confidence
            bounding_boxes = []
            confidence_scores = []
            
            if result.pages:
                for page in result.pages:
                    if page.lines:
                        for line in page.lines:
                            bbox = [
                                [line.polygon[i], line.polygon[i+1]] 
                                for i in range(0, len(line.polygon), 2)
                            ]
                            confidence = getattr(line, 'confidence', 0.9)  # Azure doesn't always provide confidence
                            
                            bounding_boxes.append({
                                "text": line.content,
                                "confidence": confidence,
                                "bbox": bbox
                            })
                            confidence_scores.append(confidence)
            
            # Calculate overall confidence
            overall_confidence = np.mean(confidence_scores) if confidence_scores else 0.9
            
            # Extract tables if available
            tables = []
            if result.tables:
                for table in result.tables:
                    table_data = {
                        "row_count": table.row_count,
                        "column_count": table.column_count,
                        "cells": []
                    }
                    
                    for cell in table.cells:
                        table_data["cells"].append({
                            "content": cell.content,
                            "row_index": cell.row_index,
                            "column_index": cell.column_index,
                            "row_span": getattr(cell, 'row_span', 1),
                            "column_span": getattr(cell, 'column_span', 1)
                        })
                    
                    tables.append(table_data)
            
            return OCRResult(
                extracted_text=extracted_text,
                confidence=overall_confidence,
                provider=OCRProvider.AZURE_DI,
                bounding_boxes=bounding_boxes,
                metadata={
                    "total_lines": len(bounding_boxes),
                    "tables": tables,
                    "model_used": model_id
                }
            )
            
        except Exception as e:
            logger.error(f"Azure OCR extraction error: {e}")
            raise HTTPException(status_code=500, detail=f"Azure OCR failed: {str(e)}")

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/health", response_model=ServiceHealthCheck)
async def health_check():
    """Service health check"""
    provider_status = {}
    for provider, config in OCR_PROVIDERS.items():
        provider_status[provider.lower()] = "enabled" if config["enabled"] else "disabled"
    
    return ServiceHealthCheck(
        service_name="ocr-service",
        status="healthy" if any(OCR_PROVIDERS[p]["enabled"] for p in OCR_PROVIDERS) else "unhealthy",
        version=settings.app_version,
        dependencies=provider_status
    )

@app.post("/api/v1/extract", response_model=OCRResult)
async def extract_text(
    file: UploadFile = File(...),
    document_type: Optional[str] = None,
    provider: Optional[str] = None
):
    """Extract text from uploaded image/document"""
    try:
        # Read file data
        image_data = await file.read()
        
        # Select optimal provider if not specified
        if not provider:
            selected_provider, selection_metadata = await ocr_selector.select_optimal_provider(
                image_data, document_type
            )
        else:
            selected_provider = provider
            selection_metadata = {}
        
        # Get provider configuration
        if selected_provider not in OCR_PROVIDERS:
            raise HTTPException(status_code=400, detail=f"Unknown provider: {selected_provider}")
        
        if not OCR_PROVIDERS[selected_provider]["enabled"]:
            raise HTTPException(status_code=503, detail=f"Provider {selected_provider} not available")
        
        # Extract text using selected provider
        config = BFSI_OCR_CONFIG.get(document_type, BFSI_OCR_CONFIG["DEFAULT"])
        
        if selected_provider == "PADDLE_OCR":
            result = await PaddleOCRProvider.extract_text(image_data, config)
        elif selected_provider == "AZURE_DI":
            result = await AzureOCRProvider.extract_text(image_data, config)
        else:
            raise HTTPException(status_code=400, detail=f"Provider {selected_provider} not implemented")
        
        # Add selection metadata
        result.metadata.update({
            "provider_selection": selection_metadata,
            "document_type": document_type
        })
        
        logger.info(f"OCR extraction completed using {selected_provider} with confidence {result.confidence:.2f}")
        return result
        
    except Exception as e:
        logger.error(f"OCR extraction error: {e}")
        raise HTTPException(status_code=500, detail=f"OCR extraction failed: {str(e)}")

@app.post("/api/v1/extract-base64", response_model=OCRResult)
async def extract_text_base64(request: OCRRequest):
    """Extract text from base64-encoded image"""
    try:
        # Decode base64 image
        try:
            image_data = base64.b64decode(request.image_data)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid base64 image data: {e}")
        
        # Select optimal provider
        selected_provider, selection_metadata = await ocr_selector.select_optimal_provider(
            image_data, request.document_type
        )
        
        # Override with user preference if specified
        if request.preferred_provider:
            if request.preferred_provider.value in OCR_PROVIDERS:
                if OCR_PROVIDERS[request.preferred_provider.value]["enabled"]:
                    selected_provider = request.preferred_provider.value
                else:
                    logger.warning(f"Preferred provider {request.preferred_provider.value} not available, using {selected_provider}")
        
        # Extract text
        config = BFSI_OCR_CONFIG.get(request.document_type, BFSI_OCR_CONFIG["DEFAULT"])
        
        if selected_provider == "PADDLE_OCR":
            result = await PaddleOCRProvider.extract_text(image_data, config)
        elif selected_provider == "AZURE_DI":
            result = await AzureOCRProvider.extract_text(image_data, config)
        else:
            raise HTTPException(status_code=400, detail=f"Provider {selected_provider} not implemented")
        
        # Add metadata
        result.metadata.update({
            "provider_selection": selection_metadata,
            "document_type": request.document_type,
            "document_id": request.document_id
        })
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Base64 OCR extraction error: {e}")
        raise HTTPException(status_code=500, detail=f"OCR extraction failed: {str(e)}")

@app.get("/api/v1/providers")
async def get_available_providers():
    """Get list of available OCR providers and their capabilities"""
    return {
        "providers": [
            {
                "name": provider,
                "enabled": config["enabled"],
                "capabilities": {
                    "supports_layouts": config["supports_layouts"],
                    "supports_tables": config["supports_tables"],
                    "accuracy_score": config["accuracy_score"],
                    "speed_score": config["speed_score"]
                }
            }
            for provider, config in OCR_PROVIDERS.items()
        ]
    }

@app.post("/api/v1/compare-providers")
async def compare_providers(file: UploadFile = File(...)):
    """Compare results from all available providers"""
    try:
        image_data = await file.read()
        results = {}
        
        # Test all available providers
        for provider_name, config in OCR_PROVIDERS.items():
            if not config["enabled"]:
                continue
            
            try:
                if provider_name == "PADDLE_OCR":
                    result = await PaddleOCRProvider.extract_text(image_data, {})
                elif provider_name == "AZURE_DI":
                    result = await AzureOCRProvider.extract_text(image_data, {})
                else:
                    continue
                
                results[provider_name] = {
                    "text": result.extracted_text,
                    "confidence": result.confidence,
                    "word_count": len(result.extracted_text.split()),
                    "processing_time": result.metadata.get("processing_time")
                }
                
            except Exception as e:
                results[provider_name] = {"error": str(e)}
        
        return {"comparison": results}
        
    except Exception as e:
        logger.error(f"Provider comparison error: {e}")
        raise HTTPException(status_code=500, detail=f"Provider comparison failed: {str(e)}")

# ============================================================================
# Quality Assessment
# ============================================================================

@app.post("/api/v1/assess-quality")
async def assess_image_quality(file: UploadFile = File(...)):
    """Assess image quality for OCR optimization"""
    try:
        image_data = await file.read()
        quality_assessment = await ocr_selector._assess_image_quality(image_data)
        
        return QualityAssessment(
            quality_score=quality_assessment["quality_score"],
            issues=quality_assessment["issues"],
            recommendations=await _get_quality_recommendations(quality_assessment)
        )
        
    except Exception as e:
        logger.error(f"Quality assessment error: {e}")
        raise HTTPException(status_code=500, detail=f"Quality assessment failed: {str(e)}")

async def _get_quality_recommendations(assessment: Dict) -> List[str]:
    """Generate recommendations based on quality assessment"""
    recommendations = []
    
    if assessment["quality_score"] < 0.5:
        recommendations.append("Consider rescanning the document at higher resolution")
    
    if "Poor contrast" in assessment["issues"]:
        recommendations.append("Adjust scanner contrast settings or document lighting")
    
    if "Image blur detected" in assessment["issues"]:
        recommendations.append("Ensure document is flat and scanner is stable")
    
    if "Low resolution" in assessment["issues"]:
        recommendations.append("Scan at minimum 300 DPI for text documents")
    
    if not recommendations:
        recommendations.append("Image quality is good for OCR processing")
    
    return recommendations

# ============================================================================
# Main Entry Point
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host=settings.ocr_host,
        port=settings.ocr_port,
        reload=settings.debug,
        log_level=settings.log_level.lower()
    )
