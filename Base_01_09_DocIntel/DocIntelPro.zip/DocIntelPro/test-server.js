// Simple test script to verify database connection and API endpoints
import express from 'express';
import cors from 'cors';
import { config } from './server/config.js';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Simple health check endpoint
app.get('/api/health', async (req, res) => {
  try {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      message: 'DocIntelPro BFSI API is running'
    });
  } catch (error) {
    res.status(500).json({ error: 'Health check failed' });
  }
});

// Test database connection
app.get('/api/test-db', async (req, res) => {
  try {
    // Import database connection
    const { rawDb } = await import('./server/db.js');
    
    // Try a simple query
    const result = await rawDb.query('SELECT NOW() as current_time, version() as postgres_version');
    
    res.json({
      status: 'Database connection successful',
      currentTime: result.rows[0]?.current_time,
      postgresVersion: result.rows[0]?.postgres_version,
      database: 'RND'
    });
  } catch (error) {
    console.error('Database connection error:', error);
    res.status(500).json({ 
      error: 'Database connection failed',
      message: error.message 
    });
  }
});

// Get BFSI document types (simple version)
app.get('/api/bfsi/document-types', async (req, res) => {
  try {
    const { rawDb } = await import('./server/db.js');
    
    const result = await rawDb.query(`
      SELECT type_key, name, category, classification, description, is_active 
      FROM bfsi_document_types 
      WHERE is_active = true 
      ORDER BY category, name
    `);
    
    res.json({
      count: result.rows.length,
      documentTypes: result.rows
    });
  } catch (error) {
    console.error('Failed to fetch BFSI document types:', error);
    res.status(500).json({ 
      error: 'Failed to fetch BFSI document types',
      message: error.message 
    });
  }
});

// Get organizations
app.get('/api/organizations', async (req, res) => {
  try {
    const { rawDb } = await import('./server/db.js');
    
    const result = await rawDb.query(`
      SELECT id, name, domain, industry, country, is_active, created_at 
      FROM organizations 
      WHERE is_active = true 
      ORDER BY name
    `);
    
    res.json({
      count: result.rows.length,
      organizations: result.rows
    });
  } catch (error) {
    console.error('Failed to fetch organizations:', error);
    res.status(500).json({ 
      error: 'Failed to fetch organizations',
      message: error.message 
    });
  }
});

// Get dashboard metrics (simple version)
app.get('/api/dashboard/metrics', async (req, res) => {
  try {
    const { rawDb } = await import('./server/db.js');
    const orgId = req.headers['x-organization-id'] || 'f5a5744d-f922-4918-b5ae-0d9a430b9b0b';
    
    // Get basic counts
    const documentsResult = await rawDb.query('SELECT COUNT(*) as count FROM documents WHERE organization_id = $1', [orgId]);
    const sourcesResult = await rawDb.query('SELECT COUNT(*) as count FROM document_sources WHERE organization_id = $1', [orgId]);
    const jobsResult = await rawDb.query('SELECT COUNT(*) as count FROM processing_jobs WHERE organization_id = $1', [orgId]);
    
    res.json({
      totalDocuments: parseInt(documentsResult.rows[0]?.count || 0),
      totalSources: parseInt(sourcesResult.rows[0]?.count || 0),
      totalJobs: parseInt(jobsResult.rows[0]?.count || 0),
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Failed to fetch dashboard metrics:', error);
    res.status(500).json({ 
      error: 'Failed to fetch dashboard metrics',
      message: error.message 
    });
  }
});

// Start server
const PORT = config.server?.port || 5000;
const HOST = config.server?.host || 'localhost';

app.listen(PORT, HOST, () => {
  console.log(`🚀 DocIntelPro BFSI API Server running on http://${HOST}:${PORT}`);
  console.log(`📊 Dashboard: http://localhost:5173`);
  console.log(`🔧 API Health: http://${HOST}:${PORT}/api/health`);
  console.log(`🗄️  Database Test: http://${HOST}:${PORT}/api/test-db`);
  console.log(`📋 BFSI Types: http://${HOST}:${PORT}/api/bfsi/document-types`);
});

export default app;
