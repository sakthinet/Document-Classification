#!/bin/bash

# DocIntelPro Python Microservices Setup Script
# This script sets up the development environment for the Python microservices

set -e

echo "🚀 Setting up DocIntelPro Python Microservices Development Environment"

# Check if Python 3.11+ is installed
python_version=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)
required_version="3.11"

if [ "$(printf '%s\n' "$required_version" "$python_version" | sort -V | head -n1)" != "$required_version" ]; then
    echo "❌ Python 3.11+ is required. Current version: $python_version"
    exit 1
fi

echo "✅ Python version check passed"

# Create virtual environment
echo "📦 Creating Python virtual environment..."
if [ ! -d "python-services/venv" ]; then
    python3 -m venv python-services/venv
    echo "✅ Virtual environment created"
else
    echo "✅ Virtual environment already exists"
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source python-services/venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install Python dependencies
echo "📚 Installing Python dependencies..."
cd python-services
pip install -r requirements.txt

# Download spaCy model
echo "🧠 Downloading spaCy English model..."
python -m spacy download en_core_web_sm

# Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p models
mkdir -p storage/documents
mkdir -p storage/processed
mkdir -p logs

echo "✅ Directory structure created"

# Set environment variables
echo "🔧 Setting up environment variables..."
if [ ! -f ".env" ]; then
    cat > .env << EOL
# DocIntelPro Environment Configuration

# Application
DEBUG=true
LOG_LEVEL=INFO
ENVIRONMENT=development

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=admin@12345
DB_NAME=RND

# Redis
REDIS_URL=redis://localhost:6379/0

# Azure Document Intelligence (Optional)
# AZURE_DOCUMENT_INTELLIGENCE_KEY=your_azure_key_here
# AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=your_azure_endpoint_here

# Security
SECRET_KEY=dev-secret-key-change-in-production

# Service Ports
GATEWAY_PORT=8000
OCR_PORT=8001
CLASSIFICATION_PORT=8002
VECTOR_SEARCH_PORT=8003
PII_DETECTION_PORT=8004
EOL
    echo "✅ Environment file created"
else
    echo "✅ Environment file already exists"
fi

# Create monitoring directories
echo "📊 Setting up monitoring..."
mkdir -p monitoring/grafana/dashboards
mkdir -p monitoring/grafana/datasources

# Create Prometheus configuration
if [ ! -f "monitoring/prometheus.yml" ]; then
    cat > monitoring/prometheus.yml << EOL
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  # - "first_rules.yml"
  # - "second_rules.yml"

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'docintel-gateway'
    static_configs:
      - targets: ['gateway-service:8000']
    metrics_path: '/metrics'

  - job_name: 'docintel-ocr'
    static_configs:
      - targets: ['ocr-service:8001']
    metrics_path: '/metrics'

  - job_name: 'docintel-classification'
    static_configs:
      - targets: ['classification-service:8002']
    metrics_path: '/metrics'

  - job_name: 'docintel-vector-search'
    static_configs:
      - targets: ['vector-search-service:8003']
    metrics_path: '/metrics'

  - job_name: 'docintel-pii-detection'
    static_configs:
      - targets: ['pii-detection-service:8004']
    metrics_path: '/metrics'
EOL
    echo "✅ Prometheus configuration created"
fi

# Create Grafana datasource configuration
if [ ! -f "monitoring/grafana/datasources/prometheus.yml" ]; then
    cat > monitoring/grafana/datasources/prometheus.yml << EOL
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
EOL
    echo "✅ Grafana datasource configuration created"
fi

# Create database migration script
if [ ! -f "database/run_migration.sql" ]; then
    cp database/migrations/001_bfsi_enhancement.sql database/run_migration.sql
    echo "✅ Database migration script prepared"
fi

# Create startup scripts
echo "📜 Creating startup scripts..."

# Development startup script
cat > start_dev.sh << EOL
#!/bin/bash
# Start DocIntelPro services in development mode

echo "Starting DocIntelPro Development Environment..."

# Start services in background
cd python-services

# Start each service in a separate terminal or tmux session
echo "Starting Gateway Service..."
source venv/bin/activate && cd gateway && python main.py &
GATEWAY_PID=\$!

echo "Starting OCR Service..."
source venv/bin/activate && cd ../ocr-service && python main.py &
OCR_PID=\$!

echo "Starting Classification Service..."
source venv/bin/activate && cd ../classification-service && python main.py &
CLASSIFICATION_PID=\$!

echo "Starting Vector Search Service..."
source venv/bin/activate && cd ../vector-search-service && python main.py &
VECTOR_PID=\$!

echo "Starting PII Detection Service..."
source venv/bin/activate && cd ../pii-detection-service && python main.py &
PII_PID=\$!

# Store PIDs for cleanup
echo \$GATEWAY_PID > gateway.pid
echo \$OCR_PID > ocr.pid
echo \$CLASSIFICATION_PID > classification.pid
echo \$VECTOR_PID > vector.pid
echo \$PII_PID > pii.pid

echo "All services started!"
echo "Gateway: http://localhost:8000"
echo "OCR: http://localhost:8001"
echo "Classification: http://localhost:8002"
echo "Vector Search: http://localhost:8003"
echo "PII Detection: http://localhost:8004"

# Wait for all services
wait
EOL

chmod +x start_dev.sh

# Stop script
cat > stop_dev.sh << EOL
#!/bin/bash
# Stop DocIntelPro development services

echo "Stopping DocIntelPro services..."

if [ -f gateway.pid ]; then
    kill \$(cat gateway.pid) 2>/dev/null || true
    rm gateway.pid
fi

if [ -f ocr.pid ]; then
    kill \$(cat ocr.pid) 2>/dev/null || true
    rm ocr.pid
fi

if [ -f classification.pid ]; then
    kill \$(cat classification.pid) 2>/dev/null || true
    rm classification.pid
fi

if [ -f vector.pid ]; then
    kill \$(cat vector.pid) 2>/dev/null || true
    rm vector.pid
fi

if [ -f pii.pid ]; then
    kill \$(cat pii.pid) 2>/dev/null || true
    rm pii.pid
fi

echo "All services stopped."
EOL

chmod +x stop_dev.sh

echo "✅ Startup scripts created"

# Create test script
cat > test_services.sh << EOL
#!/bin/bash
# Test DocIntelPro services

echo "Testing DocIntelPro services..."

# Test Gateway
echo "Testing Gateway service..."
curl -s http://localhost:8000/health | jq . || echo "Gateway not responding"

# Test OCR
echo "Testing OCR service..."
curl -s http://localhost:8001/health | jq . || echo "OCR service not responding"

# Test Classification
echo "Testing Classification service..."
curl -s http://localhost:8002/health | jq . || echo "Classification service not responding"

# Test Vector Search
echo "Testing Vector Search service..."
curl -s http://localhost:8003/health | jq . || echo "Vector Search service not responding"

# Test PII Detection
echo "Testing PII Detection service..."
curl -s http://localhost:8004/health | jq . || echo "PII Detection service not responding"

echo "Service testing completed!"
EOL

chmod +x test_services.sh

cd ..

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "Next steps:"
echo "1. Set up your database (PostgreSQL) and run the migration script in database/migrations/"
echo "2. Optional: Configure Azure Document Intelligence credentials in .env"
echo "3. Start the services:"
echo "   - Development: ./start_dev.sh"
echo "   - Docker: docker-compose up -d"
echo "4. Test the services: ./test_services.sh"
echo ""
echo "Service URLs:"
echo "- Gateway API: http://localhost:8000"
echo "- OCR Service: http://localhost:8001"
echo "- Classification Service: http://localhost:8002"
echo "- Vector Search Service: http://localhost:8003"
echo "- PII Detection Service: http://localhost:8004"
echo "- Prometheus: http://localhost:9090"
echo "- Grafana: http://localhost:3000 (admin/admin)"
echo ""
echo "Happy coding! 🚀"
