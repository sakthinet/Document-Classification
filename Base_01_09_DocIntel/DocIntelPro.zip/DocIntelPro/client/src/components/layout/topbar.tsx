import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Plus } from 'lucide-react';

interface TopBarProps {
  isConnected?: boolean;
  connectionStatus?: 'connecting' | 'connected' | 'disconnected' | 'error';
}

export function TopBar({ isConnected = false, connectionStatus = 'disconnected' }: TopBarProps) {
  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'bg-accent';
      case 'connecting':
        return 'bg-chart-3';
      case 'error':
        return 'bg-destructive';
      default:
        return 'bg-muted-foreground';
    }
  };

  const getStatusText = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Processing Active';
      case 'connecting':
        return 'Connecting...';
      case 'error':
        return 'Connection Error';
      default:
        return 'Offline';
    }
  };

  return (
    <header className="bg-card border-b border-border p-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-foreground">Processing Dashboard</h2>
          <p className="text-muted-foreground">Real-time document intelligence monitoring</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Processing Status Indicator */}
          <div className="flex items-center space-x-2 bg-accent/10 px-3 py-2 rounded-lg">
            <div className="flex space-x-1">
              <div className={`w-2 h-2 ${getStatusColor()} rounded-full ${isConnected ? 'animate-pulse' : ''}`}></div>
              <div className={`w-2 h-2 ${getStatusColor()} rounded-full ${isConnected ? 'animate-pulse' : ''}`} style={{ animationDelay: '0.5s' }}></div>
              <div className={`w-2 h-2 ${getStatusColor()} rounded-full ${isConnected ? 'animate-pulse' : ''}`} style={{ animationDelay: '1s' }}></div>
            </div>
            <span className="text-sm font-medium text-accent">
              {getStatusText()}
            </span>
          </div>
          
          {/* Notifications */}
          <div className="relative">
            <button 
              className="relative p-2 text-muted-foreground hover:text-foreground hover:bg-accent/20 rounded-md transition-all duration-200 ease-in-out"
              data-testid="button-notifications"
            >
              <Bell className="w-5 h-5" />
              <Badge 
                className="absolute -top-1 -right-1 w-4 h-4 p-0 flex items-center justify-center text-xs font-semibold"
                variant="destructive"
              >
                3
              </Badge>
            </button>
          </div>
          
          {/* Quick Actions */}
          <Button 
            className="flex items-center space-x-2 font-medium hover:bg-primary/90 transition-all duration-200 hover:scale-105"
            data-testid="button-new-job"
          >
            <Plus className="w-4 h-4" />
            <span>New Processing Job</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
