import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { FileText, HeartPulse, CheckCircle } from 'lucide-react';
import type { ProcessingJob } from '@/lib/types';

interface ProcessingQueueProps {
  jobs: ProcessingJob[];
  isLoading?: boolean;
}

export function ProcessingQueue({ jobs, isLoading = false }: ProcessingQueueProps) {
  const getJobIcon = (batchId: string) => {
    if (batchId.includes('bfsi')) return FileText;
    if (batchId.includes('health')) return HeartPulse;
    if (batchId.includes('kyc')) return CheckCircle;
    return FileText;
  };

  const getJobIconColor = (batchId: string) => {
    if (batchId.includes('bfsi')) return 'text-primary bg-primary/10';
    if (batchId.includes('health')) return 'text-accent bg-accent/10';
    if (batchId.includes('kyc')) return 'text-accent bg-accent/10';
    return 'text-primary bg-primary/10';
  };

  const getStatusBadgeVariant = (status: ProcessingJob['status']) => {
    switch (status) {
      case 'processing':
        return 'default';
      case 'queued':
        return 'secondary';
      case 'completed':
        return 'outline';
      case 'failed':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const getStatusText = (status: ProcessingJob['status']) => {
    switch (status) {
      case 'processing':
        return 'Processing';
      case 'queued':
        return 'Queued';
      case 'completed':
        return 'Complete';
      case 'failed':
        return 'Failed';
      default:
        return 'Unknown';
    }
  };

  const formatTimeRemaining = (minutes: number | null) => {
    if (!minutes) return '';
    if (minutes < 60) return `~${minutes} min remaining`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `~${hours}h ${mins}m remaining`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Live Processing Queue</CardTitle>
            <Skeleton className="h-6 w-24 rounded-full" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border">
                <div className="flex items-center space-x-4">
                  <Skeleton className="w-10 h-10 rounded-lg" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-36" />
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="space-y-1">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                  <Skeleton className="w-16 h-2 rounded-full" />
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="processing-queue">
      <CardHeader className="border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle>Live Processing Queue</CardTitle>
          <Badge variant="outline" className="bg-accent/10 text-accent">
            <div className="w-2 h-2 bg-accent rounded-full mr-2 animate-pulse"></div>
            Live Updates
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        {jobs.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No Active Jobs</h3>
            <p className="text-muted-foreground">
              Processing queue is empty. New jobs will appear here automatically.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {jobs.map((job, index) => {
              const Icon = getJobIcon(job.batchId);
              const iconColor = getJobIconColor(job.batchId);
              
              return (
                <div 
                  key={job.id} 
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-lg border"
                  data-testid={`processing-job-${index}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${iconColor}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground" data-testid={`job-name-${index}`}>
                        {job.name}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {job.batchId} • {job.totalDocuments} documents
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    {job.status === 'processing' && (
                      <>
                        <div className="text-right">
                          <p className="text-sm font-medium text-foreground">
                            {job.progress}% Complete
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatTimeRemaining(job.estimatedTimeRemaining)}
                          </p>
                        </div>
                        <div className="w-16">
                          <Progress value={job.progress} className="h-2" />
                        </div>
                      </>
                    )}
                    
                    {job.status === 'queued' && (
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">Queue Position: 2</p>
                        <p className="text-xs text-muted-foreground">Est. start in 5 min</p>
                      </div>
                    )}
                    
                    {job.status === 'completed' && (
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">Completed</p>
                        <p className="text-xs text-muted-foreground">
                          {job.completedAt && new Date(job.completedAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                    
                    <Badge 
                      variant={getStatusBadgeVariant(job.status)}
                      data-testid={`job-status-${index}`}
                    >
                      {getStatusText(job.status)}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
