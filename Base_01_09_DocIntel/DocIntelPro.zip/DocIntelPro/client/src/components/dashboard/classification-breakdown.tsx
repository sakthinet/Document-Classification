import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ShieldAlert } from 'lucide-react';

interface ClassificationBreakdownProps {
  breakdown: Array<{
    level: string;
    count: number;
    percentage: number;
  }>;
  isLoading?: boolean;
}

export function ClassificationBreakdown({ breakdown, isLoading = false }: ClassificationBreakdownProps) {
  const getClassificationColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'confidential':
        return 'bg-destructive';
      case 'restricted':
        return 'bg-chart-4';
      case 'internal':
        return 'bg-chart-3';
      case 'public':
        return 'bg-accent';
      default:
        return 'bg-muted-foreground';
    }
  };

  const formatLevel = (level: string) => {
    return level.charAt(0).toUpperCase() + level.slice(1);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Classification Breakdown</CardTitle>
          <p className="text-sm text-muted-foreground">Last 24 hours</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Skeleton className="w-3 h-3 rounded-full" />
                  <Skeleton className="h-4 w-20" />
                </div>
                <div className="text-right space-y-1">
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Mock PII detection alert if no data
  const hasPiiAlert = breakdown.some(item => 
    item.level.toLowerCase() === 'confidential' && item.count > 0
  );

  return (
    <Card data-testid="classification-breakdown">
      <CardHeader className="border-b border-border">
        <CardTitle>Classification Breakdown</CardTitle>
        <p className="text-sm text-muted-foreground">Last 24 hours</p>
      </CardHeader>
      
      <CardContent className="p-6 space-y-4">
        {breakdown.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground">No classification data available</p>
          </div>
        ) : (
          <>
            {breakdown.map((item, index) => (
              <div 
                key={item.level} 
                className="flex items-center justify-between"
                data-testid={`classification-item-${index}`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 ${getClassificationColor(item.level)} rounded-full`}></div>
                  <span className="text-sm font-medium text-foreground">
                    {formatLevel(item.level)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-foreground">
                    {item.count.toLocaleString()}
                  </span>
                  <span className="text-xs text-muted-foreground ml-1">
                    ({item.percentage}%)
                  </span>
                </div>
              </div>
            ))}
          </>
        )}
        
        {/* PII Detection Alert */}
        {hasPiiAlert && (
          <div className="mt-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <div className="flex items-start space-x-3">
              <ShieldAlert className="w-5 h-5 text-destructive mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-destructive">PII Detected</h4>
                <p className="text-xs text-destructive/80 mt-1">
                  127 documents contain sensitive PII requiring special handling
                </p>
                <button className="text-xs font-medium text-destructive hover:text-destructive/80 mt-2">
                  Review Details →
                </button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
