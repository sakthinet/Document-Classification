import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { FileText, Target, Database, Clock, LucideIcon } from 'lucide-react';

const ICONS = {
  'file-text': FileText,
  'target': Target,
  'database': Database,
  'clock': Clock,
} as const;

interface MetricsCardProps {
  title: string;
  value: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: keyof typeof ICONS;
  isLoading?: boolean;
}

export function MetricsCard({ 
  title, 
  value, 
  change, 
  changeType = 'neutral', 
  icon,
  isLoading = false
}: MetricsCardProps) {
  const Icon = ICONS[icon];
  
  const getChangeColor = () => {
    switch (changeType) {
      case 'positive':
        return 'text-accent';
      case 'negative':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const getIconColor = () => {
    switch (icon) {
      case 'file-text':
        return 'text-primary bg-primary/10';
      case 'target':
        return 'text-accent bg-accent/10';
      case 'database':
        return 'text-chart-3 bg-chart-3/10';
      case 'clock':
        return 'text-chart-4 bg-chart-4/10';
      default:
        return 'text-primary bg-primary/10';
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-8 w-20" />
              <Skeleton className="h-3 w-24" />
            </div>
            <Skeleton className="w-12 h-12 rounded-lg" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid={`metrics-card-${icon}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">
              {title}
            </p>
            <p className="text-3xl font-bold text-foreground" data-testid={`metrics-value-${icon}`}>
              {value}
            </p>
            {change && (
              <p className={cn("text-sm mt-1", getChangeColor())}>
                <span className="font-medium">{change.split(' ')[0]}</span>{' '}
                {change.split(' ').slice(1).join(' ')}
              </p>
            )}
          </div>
          <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center", getIconColor())}>
            <Icon className="w-6 h-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
