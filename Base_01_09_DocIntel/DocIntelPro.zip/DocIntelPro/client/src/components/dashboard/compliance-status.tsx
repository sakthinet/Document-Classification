import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, HeartPulse, CreditCard } from 'lucide-react';

const complianceItems = [
  {
    id: 'gdpr',
    name: 'GDPR Compliance',
    description: 'EU data protection',
    status: 'compliant',
    icon: ShieldCheck,
    color: 'text-accent bg-accent/10'
  },
  {
    id: 'hipaa',
    name: 'HIPAA Compliance',
    description: 'Healthcare privacy',
    status: 'compliant',
    icon: HeartPulse,
    color: 'text-accent bg-accent/10'
  },
  {
    id: 'pci-dss',
    name: 'PCI DSS',
    description: 'Payment security',
    status: 'review_required',
    icon: CreditCard,
    color: 'text-chart-4 bg-chart-4/10'
  }
];

export function ComplianceStatus() {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'compliant':
        return (
          <Badge className="bg-accent text-accent-foreground">
            ✓ Compliant
          </Badge>
        );
      case 'review_required':
        return (
          <Badge variant="outline" className="bg-chart-4/20 text-chart-4 border-chart-4">
            ⚠ Review Required
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary">
            Unknown
          </Badge>
        );
    }
  };

  return (
    <Card data-testid="compliance-status">
      <CardHeader className="border-b border-border">
        <CardTitle>Compliance Status</CardTitle>
        <p className="text-sm text-muted-foreground">GDPR, HIPAA, PCI DSS monitoring</p>
      </CardHeader>
      
      <CardContent className="p-6 space-y-4">
        {complianceItems.map((item, index) => {
          const Icon = item.icon;
          
          return (
            <div 
              key={item.id}
              className="flex items-center justify-between p-3 bg-accent/10 rounded-lg"
              data-testid={`compliance-item-${index}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${item.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">
                    {item.name}
                  </h4>
                  <p className="text-xs text-muted-foreground">
                    {item.description}
                  </p>
                </div>
              </div>
              <div data-testid={`compliance-status-${index}`}>
                {getStatusBadge(item.status)}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
