import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FilePlus, CheckCircle, AlertTriangle, Users } from 'lucide-react';

const recentActivities = [
  {
    id: '1',
    type: 'batch_started',
    title: 'New batch started',
    description: 'BFSI loan applications - 247 documents',
    time: '2 minutes ago',
    icon: FilePlus,
    iconColor: 'text-primary bg-primary/10'
  },
  {
    id: '2',
    type: 'classification_completed',
    title: 'Classification completed',
    description: 'KYC documents - 89 docs processed',
    time: '15 minutes ago',
    icon: CheckCircle,
    iconColor: 'text-accent bg-accent/10'
  },
  {
    id: '3',
    type: 'pii_detected',
    title: 'PII detected',
    description: 'Customer contracts require review',
    time: '32 minutes ago',
    icon: AlertTriangle,
    iconColor: 'text-chart-4 bg-chart-4/10'
  },
  {
    id: '4',
    type: 'user_added',
    title: 'New user added',
    description: 'sarah.analyst@company.com - Analyst role',
    time: '1 hour ago',
    icon: Users,
    iconColor: 'text-muted-foreground bg-muted'
  }
];

export function RecentActivity() {
  return (
    <Card data-testid="recent-activity">
      <CardHeader className="border-b border-border">
        <CardTitle>Recent Activity</CardTitle>
        <p className="text-sm text-muted-foreground">Last 2 hours</p>
      </CardHeader>
      
      <CardContent className="p-6 space-y-4">
        {recentActivities.map((activity, index) => {
          const Icon = activity.icon;
          
          return (
            <div 
              key={activity.id}
              className="flex items-start space-x-3"
              data-testid={`activity-item-${index}`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center mt-0.5 ${activity.iconColor}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">
                  {activity.title}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {activity.description}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {activity.time}
                </p>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
