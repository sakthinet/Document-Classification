import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Shield,
  AlertTriangle,
  CheckCircle,
  Clock,
  FileText,
  Building2,
  CreditCard,
  Users,
  DollarSign,
  BarChart3,
  Eye
} from 'lucide-react';

interface BfsiMetricsProps {
  metrics: {
    // Document Processing Metrics
    totalDocuments: number;
    documentsToday: number;
    processingQueue: number;
    completedToday: number;
    
    // BFSI-Specific Metrics
    loanApplications: number;
    kycDocuments: number;
    complianceReports: number;
    fraudAlerts: number;
    
    // Compliance Metrics
    complianceScore: number;
    auditFindings: number;
    regulatoryReports: number;
    
    // Performance Metrics
    averageProcessingTime: number;
    accuracyRate: number;
    slaCompliance: number;
    
    // Risk Metrics
    highRiskDocuments: number;
    piiDetections: number;
    securityIncidents: number;
  };
}

const BFSI_DOCUMENT_CATEGORIES = [
  {
    name: 'Loan Applications',
    count: 1247,
    change: 12.5,
    icon: FileText,
    color: 'blue',
    description: 'Personal and business loan applications processed'
  },
  {
    name: 'KYC Documents',
    count: 856,
    change: 8.3,
    icon: Users,
    color: 'green',
    description: 'Know Your Customer verification documents'
  },
  {
    name: 'Credit Reports',
    count: 432,
    change: -3.2,
    icon: CreditCard,
    color: 'purple',
    description: 'Credit bureau reports and scores'
  },
  {
    name: 'Financial Statements',
    count: 298,
    change: 15.7,
    icon: DollarSign,
    color: 'orange',
    description: 'Balance sheets and income statements'
  },
  {
    name: 'Compliance Reports',
    count: 89,
    change: 0,
    icon: Shield,
    color: 'red',
    description: 'Regulatory and compliance documentation'
  },
  {
    name: 'Insurance Claims',
    count: 567,
    change: 5.4,
    icon: Building2,
    color: 'indigo',
    description: 'Insurance policies and claims processing'
  }
];

const COMPLIANCE_METRICS = [
  {
    framework: 'SOX Compliance',
    score: 95,
    status: 'compliant',
    lastAudit: '2024-08-15',
    findings: 2
  },
  {
    framework: 'AML/BSA',
    score: 88,
    status: 'review_required',
    lastAudit: '2024-08-20',
    findings: 5
  },
  {
    framework: 'PCI DSS',
    score: 92,
    status: 'compliant',
    lastAudit: '2024-08-10',
    findings: 1
  },
  {
    framework: 'GLBA',
    score: 97,
    status: 'compliant',
    lastAudit: '2024-08-25',
    findings: 0
  }
];

const RISK_ALERTS = [
  {
    id: 1,
    type: 'High-Risk Transaction',
    severity: 'high',
    document: 'Wire Transfer - $250,000',
    timestamp: '2024-08-28 10:30 AM',
    status: 'pending_review'
  },
  {
    id: 2,
    type: 'PII Exposure',
    severity: 'medium',
    document: 'Loan Application - LA-2024-0834',
    timestamp: '2024-08-28 09:15 AM',
    status: 'mitigated'
  },
  {
    id: 3,
    type: 'Compliance Violation',
    severity: 'high',
    document: 'AML Report - Suspicious Activity',
    timestamp: '2024-08-28 08:45 AM',
    status: 'escalated'
  }
];

export function BfsiMetrics({ metrics }: BfsiMetricsProps) {
  const getTrendIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (change < 0) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-400" />;
  };

  const getTrendColor = (change: number) => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-gray-400';
  };

  const getComplianceStatusColor = (status: string) => {
    switch (status) {
      case 'compliant': return 'text-green-600 bg-green-50 border-green-200';
      case 'review_required': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'non_compliant': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* BFSI Document Categories */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Building2 className="h-5 w-5 text-blue-600" />
          BFSI Document Processing Overview
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {BFSI_DOCUMENT_CATEGORIES.map((category) => {
            const Icon = category.icon;
            return (
              <Card key={category.name} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Icon className={`h-5 w-5 text-${category.color}-600`} />
                    <div className="flex items-center gap-1">
                      {getTrendIcon(category.change)}
                      <span className={`text-sm font-medium ${getTrendColor(category.change)}`}>
                        {category.change > 0 ? '+' : ''}{category.change}%
                      </span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-2xl font-bold">{category.count.toLocaleString()}</div>
                    <div className="text-sm font-medium text-gray-900">{category.name}</div>
                    <div className="text-xs text-gray-500">{category.description}</div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Compliance Dashboard */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Shield className="h-5 w-5 text-green-600" />
          Regulatory Compliance Status
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {COMPLIANCE_METRICS.map((compliance) => (
            <Card key={compliance.framework} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{compliance.framework}</CardTitle>
                  <Badge className={getComplianceStatusColor(compliance.status)}>
                    {compliance.status.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span>Compliance Score</span>
                      <span className="font-medium">{compliance.score}%</span>
                    </div>
                    <Progress value={compliance.score} className="h-2" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Last Audit</span>
                      <div className="font-medium">{new Date(compliance.lastAudit).toLocaleDateString()}</div>
                    </div>
                    <div>
                      <span className="text-gray-500">Findings</span>
                      <div className="font-medium flex items-center gap-1">
                        {compliance.findings}
                        {compliance.findings === 0 ? (
                          <CheckCircle className="h-3 w-3 text-green-600" />
                        ) : (
                          <AlertTriangle className="h-3 w-3 text-yellow-600" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Risk Alerts & Security */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          Risk Alerts & Security Monitoring
        </h3>
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Risk Alerts</CardTitle>
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-2" />
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {RISK_ALERTS.map((alert) => (
                <div key={alert.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Badge className={getSeverityColor(alert.severity)}>
                      {alert.severity.toUpperCase()}
                    </Badge>
                    <div>
                      <div className="font-medium text-sm">{alert.type}</div>
                      <div className="text-xs text-gray-500">{alert.document}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-gray-500">{alert.timestamp}</div>
                    <Badge variant="outline" className="text-xs mt-1">
                      {alert.status.replace('_', ' ')}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-purple-600" />
          Processing Performance Metrics
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Clock className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-sm text-gray-500">Avg Processing Time</div>
                  <div className="text-2xl font-bold">2.3 min</div>
                  <div className="text-xs text-green-600">-15% vs last week</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-8 w-8 text-green-600" />
                <div>
                  <div className="text-sm text-gray-500">Classification Accuracy</div>
                  <div className="text-2xl font-bold">94.7%</div>
                  <div className="text-xs text-green-600">+2.1% vs last week</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Shield className="h-8 w-8 text-purple-600" />
                <div>
                  <div className="text-sm text-gray-500">SLA Compliance</div>
                  <div className="text-2xl font-bold">98.2%</div>
                  <div className="text-xs text-green-600">Target: 95%</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
