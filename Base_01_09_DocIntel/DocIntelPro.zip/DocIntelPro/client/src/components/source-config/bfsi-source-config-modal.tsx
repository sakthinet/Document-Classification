import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { BFSI_DOCUMENT_TYPES, BFSI_CATEGORIES, CLASSIFICATION_LEVELS, COMPLIANCE_FRAMEWORKS, getDocumentTypesByCategory } from '@/lib/constants/bfsi-document-types';
import { 
  HardDrive, 
  Share2, 
  Database, 
  Cloud, 
  Server,
  Building2,
  Shield,
  FileText,
  Settings,
  AlertTriangle,
  CheckCircle,
  Lock,
  Globe
} from 'lucide-react';

const sourceConfigSchema = z.object({
  name: z.string().min(1, 'Source name is required'),
  type: z.enum(['network_folder', 'sharepoint', 'database', 'ftp', 'cloud_storage', 'core_banking', 'loan_management']),
  provider: z.string().optional(),
  description: z.string().optional(),
  domain: z.enum(['bfsi', 'healthcare', 'general']).default('bfsi'),
  complianceLevel: z.enum(['confidential', 'restricted', 'internal', 'public']).default('internal'),
  connectionConfig: z.object({}).passthrough(),
  documentTypes: z.array(z.string()).default([]),
  processingRules: z.object({
    enableOCR: z.boolean().default(true),
    ocrLanguages: z.array(z.string()).default(['en']),
    enableAIClassification: z.boolean().default(true),
    enablePIIDetection: z.boolean().default(true),
    enableComplianceCheck: z.boolean().default(true),
    retentionPolicy: z.string().optional(),
    encryptionRequired: z.boolean().default(false)
  }).default({})
});

type SourceConfigForm = z.infer<typeof sourceConfigSchema>;

interface BfsiSourceConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: SourceConfigForm) => void;
  source?: any;
  mode: 'create' | 'edit';
}

const SOURCE_TYPES = [
  { 
    value: 'core_banking', 
    label: 'Core Banking System', 
    icon: Building2,
    description: 'Connect to core banking databases and APIs',
    providers: ['Oracle', 'SQL Server', 'DB2', 'Temenos', 'FIS']
  },
  { 
    value: 'loan_management', 
    label: 'Loan Management System', 
    icon: FileText,
    description: 'Loan origination and management systems',
    providers: ['Encompass', 'Calyx Point', 'BytePro', 'LendingQB']
  },
  { 
    value: 'sharepoint', 
    label: 'SharePoint Online', 
    icon: Share2,
    description: 'Microsoft SharePoint document libraries',
    providers: ['SharePoint Online', 'SharePoint Server']
  },
  { 
    value: 'network_folder', 
    label: 'Network Folder', 
    icon: HardDrive,
    description: 'Local network file shares and folders',
    providers: ['SMB/CIFS', 'NFS', 'Local Path']
  },
  { 
    value: 'database', 
    label: 'Database', 
    icon: Database,
    description: 'Direct database connections',
    providers: ['PostgreSQL', 'SQL Server', 'Oracle', 'MySQL']
  },
  { 
    value: 'cloud_storage', 
    label: 'Cloud Storage', 
    icon: Cloud,
    description: 'Cloud storage services',
    providers: ['Azure Blob', 'AWS S3', 'Google Cloud Storage']
  },
  { 
    value: 'ftp', 
    label: 'FTP/SFTP', 
    icon: Server,
    description: 'FTP and SFTP file servers',
    providers: ['FTP', 'SFTP', 'FTPS']
  }
];

export function BfsiSourceConfigModal({ isOpen, onClose, onSubmit, source, mode }: BfsiSourceConfigModalProps) {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>('lending');
  const [selectedDocTypes, setSelectedDocTypes] = useState<string[]>([]);
  const [selectedCompliance, setSelectedCompliance] = useState<string[]>([]);

  const form = useForm<SourceConfigForm>({
    resolver: zodResolver(sourceConfigSchema),
    defaultValues: {
      name: source?.name || '',
      type: source?.type || 'core_banking',
      provider: source?.provider || '',
      description: source?.description || '',
      domain: 'bfsi',
      complianceLevel: source?.complianceLevel || 'internal',
      connectionConfig: source?.connectionConfig || {},
      documentTypes: source?.documentTypes || [],
      processingRules: {
        enableOCR: true,
        ocrLanguages: ['en'],
        enableAIClassification: true,
        enablePIIDetection: true,
        enableComplianceCheck: true,
        encryptionRequired: false,
        ...source?.processingRules
      }
    }
  });

  const selectedSourceType = SOURCE_TYPES.find(type => type.value === form.watch('type'));
  const documentTypesInCategory = getDocumentTypesByCategory(selectedCategory);

  const handleDocumentTypeToggle = (docTypeKey: string) => {
    const current = selectedDocTypes;
    const updated = current.includes(docTypeKey) 
      ? current.filter(key => key !== docTypeKey)
      : [...current, docTypeKey];
    setSelectedDocTypes(updated);
    form.setValue('documentTypes', updated);
  };

  const handleSubmit = (data: SourceConfigForm) => {
    const formData = {
      ...data,
      documentTypes: selectedDocTypes,
      processingRules: {
        ...data.processingRules,
        complianceFrameworks: selectedCompliance
      }
    };
    onSubmit(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-blue-600" />
            {mode === 'create' ? 'Add New BFSI Data Source' : 'Edit BFSI Data Source'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="connection">Connection</TabsTrigger>
              <TabsTrigger value="documents">Document Types</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Source Name *</Label>
                      <Input
                        id="name"
                        {...form.register('name')}
                        placeholder="e.g., Main Core Banking System"
                      />
                      {form.formState.errors.name && (
                        <p className="text-sm text-red-500">{form.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="complianceLevel">Classification Level</Label>
                      <Select onValueChange={(value) => form.setValue('complianceLevel', value as any)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select classification level" />
                        </SelectTrigger>
                        <SelectContent>
                          {CLASSIFICATION_LEVELS.map((level) => (
                            <SelectItem key={level.value} value={level.value}>
                              <div className="flex items-center gap-2">
                                <span>{level.icon}</span>
                                <span>{level.label}</span>
                                <Badge variant="outline" className={`text-${level.color}-600`}>
                                  {level.value.toUpperCase()}
                                </Badge>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      {...form.register('description')}
                      placeholder="Describe this data source and its purpose..."
                      rows={3}
                    />
                  </div>

                  {/* Source Type Selection */}
                  <div className="space-y-3">
                    <Label>Source Type *</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {SOURCE_TYPES.map((sourceType) => {
                        const Icon = sourceType.icon;
                        const isSelected = form.watch('type') === sourceType.value;
                        return (
                          <div
                            key={sourceType.value}
                            className={`border rounded-lg p-3 cursor-pointer transition-all ${
                              isSelected 
                                ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => form.setValue('type', sourceType.value as any)}
                          >
                            <div className="flex items-start gap-3">
                              <Icon className={`h-5 w-5 mt-0.5 ${isSelected ? 'text-blue-600' : 'text-gray-500'}`} />
                              <div className="flex-1">
                                <div className="font-medium text-sm">{sourceType.label}</div>
                                <div className="text-xs text-gray-500 mt-1">{sourceType.description}</div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Connection Configuration Tab */}
            <TabsContent value="connection" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Connection Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedSourceType && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="provider">Provider/Platform</Label>
                        <Select onValueChange={(value) => form.setValue('provider', value)}>
                          <SelectTrigger>
                            <SelectValue placeholder={`Select ${selectedSourceType.label} provider`} />
                          </SelectTrigger>
                          <SelectContent>
                            {selectedSourceType.providers.map((provider) => (
                              <SelectItem key={provider} value={provider}>
                                {provider}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Dynamic connection fields based on source type */}
                      {form.watch('type') === 'core_banking' && (
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Database Host</Label>
                            <Input placeholder="e.g., core-db.bank.local" />
                          </div>
                          <div className="space-y-2">
                            <Label>Port</Label>
                            <Input placeholder="e.g., 1521" />
                          </div>
                          <div className="space-y-2">
                            <Label>Database Name</Label>
                            <Input placeholder="e.g., COREDB" />
                          </div>
                          <div className="space-y-2">
                            <Label>Schema</Label>
                            <Input placeholder="e.g., LENDING" />
                          </div>
                        </div>
                      )}

                      {form.watch('type') === 'sharepoint' && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>SharePoint Site URL</Label>
                            <Input placeholder="https://company.sharepoint.com/sites/lending" />
                          </div>
                          <div className="space-y-2">
                            <Label>Document Library</Label>
                            <Input placeholder="Loan Documents" />
                          </div>
                        </div>
                      )}

                      {form.watch('type') === 'network_folder' && (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>Network Path</Label>
                            <Input placeholder="\\\\file-server\\lending\\documents" />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label>Username</Label>
                              <Input placeholder="domain\\username" />
                            </div>
                            <div className="space-y-2">
                              <Label>Password</Label>
                              <Input type="password" placeholder="••••••••" />
                            </div>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Document Types Tab */}
            <TabsContent value="documents" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Document Types Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Category Selection */}
                  <div className="space-y-3">
                    <Label>Select Document Categories</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {BFSI_CATEGORIES.map((category) => (
                        <Button
                          key={category.value}
                          type="button"
                          variant={selectedCategory === category.value ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedCategory(category.value)}
                          className="justify-start"
                        >
                          <span className="mr-2">{category.icon}</span>
                          {category.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Document Types in Selected Category */}
                  <div className="space-y-3">
                    <Label>Document Types in {BFSI_CATEGORIES.find(c => c.value === selectedCategory)?.label}</Label>
                    <div className="grid gap-3">
                      {documentTypesInCategory.map((docType) => (
                        <div key={docType.key} className="border rounded-lg p-3">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              <Checkbox
                                checked={selectedDocTypes.includes(docType.key)}
                                onCheckedChange={() => handleDocumentTypeToggle(docType.key)}
                              />
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium">{docType.name}</span>
                                  <Badge variant="outline" className={`text-${getClassificationColor(docType.classification)}-600`}>
                                    {docType.classification.toUpperCase()}
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-600 mt-1">{docType.description}</p>
                                <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                                  <span>Retention: {docType.retentionPeriod.replace('_', ' ')}</span>
                                  <span>•</span>
                                  <span>PII Fields: {docType.piiFields.length}</span>
                                  <span>•</span>
                                  <span>Compliance: {docType.complianceFlags.join(', ')}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Compliance Tab */}
            <TabsContent value="compliance" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Compliance & Security Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Processing Rules */}
                  <div className="space-y-4">
                    <Label className="text-base font-medium">Processing Rules</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enableOCR">Enable OCR Processing</Label>
                        <Switch
                          id="enableOCR"
                          checked={form.watch('processingRules.enableOCR')}
                          onCheckedChange={(checked) => form.setValue('processingRules.enableOCR', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enableAI">Enable AI Classification</Label>
                        <Switch
                          id="enableAI"
                          checked={form.watch('processingRules.enableAIClassification')}
                          onCheckedChange={(checked) => form.setValue('processingRules.enableAIClassification', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enablePII">Enable PII Detection</Label>
                        <Switch
                          id="enablePII"
                          checked={form.watch('processingRules.enablePIIDetection')}
                          onCheckedChange={(checked) => form.setValue('processingRules.enablePIIDetection', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="enableCompliance">Enable Compliance Check</Label>
                        <Switch
                          id="enableCompliance"
                          checked={form.watch('processingRules.enableComplianceCheck')}
                          onCheckedChange={(checked) => form.setValue('processingRules.enableComplianceCheck', checked)}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="encryptionRequired">Require Encryption</Label>
                        <Switch
                          id="encryptionRequired"
                          checked={form.watch('processingRules.encryptionRequired')}
                          onCheckedChange={(checked) => form.setValue('processingRules.encryptionRequired', checked)}
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Compliance Frameworks */}
                  <div className="space-y-4">
                    <Label className="text-base font-medium">Applicable Compliance Frameworks</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {COMPLIANCE_FRAMEWORKS.map((framework) => (
                        <div key={framework.code} className="flex items-start gap-2">
                          <Checkbox
                            checked={selectedCompliance.includes(framework.code)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedCompliance([...selectedCompliance, framework.code]);
                              } else {
                                setSelectedCompliance(selectedCompliance.filter(c => c !== framework.code));
                              }
                            }}
                          />
                          <div className="flex-1">
                            <div className="font-medium text-sm">{framework.name}</div>
                            <div className="text-xs text-gray-500">{framework.description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Data Retention */}
                  <Separator />
                  <div className="space-y-4">
                    <Label className="text-base font-medium">Data Retention Policy</Label>
                    <Select onValueChange={(value) => form.setValue('processingRules.retentionPolicy', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select retention period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3_years">3 Years</SelectItem>
                        <SelectItem value="5_years">5 Years</SelectItem>
                        <SelectItem value="7_years">7 Years (Standard)</SelectItem>
                        <SelectItem value="10_years">10 Years</SelectItem>
                        <SelectItem value="permanent">Permanent</SelectItem>
                        <SelectItem value="custom">Custom Policy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              <CheckCircle className="h-4 w-4 mr-2" />
              {mode === 'create' ? 'Create Source' : 'Update Source'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Helper function to get classification color
function getClassificationColor(classification: string): string {
  switch (classification) {
    case 'confidential': return 'red';
    case 'restricted': return 'orange';
    case 'internal': return 'yellow';
    case 'public': return 'green';
    default: return 'gray';
  }
}
