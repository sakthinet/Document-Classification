import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  HardDrive,
  Share2,
  Database,
  Cloud,
  Server,
  Shield,
  Settings,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import type { DocumentSource } from '@/lib/types';

const sourceConfigSchema = z.object({
  name: z.string().min(1, 'Source name is required').max(100, 'Name too long'),
  type: z.enum(['network_folder', 'sharepoint', 'database', 'ftp', 'cloud_storage']),
  connectionConfig: z.object({
    path: z.string().optional(),
    username: z.string().optional(),
    password: z.string().optional(),
    server: z.string().optional(),
    port: z.number().optional(),
    database: z.string().optional(),
    apiKey: z.string().optional(),
    tenantId: z.string().optional(),
    clientId: z.string().optional(),
    clientSecret: z.string().optional(),
    bucketName: z.string().optional(),
    region: z.string().optional(),
  }),
  isActive: z.boolean().default(true),
});

type SourceConfigForm = z.infer<typeof sourceConfigSchema>;

interface SourceConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: SourceConfigForm) => void;
  source?: DocumentSource | null;
  isLoading?: boolean;
}

const SOURCE_TYPES = [
  {
    id: 'network_folder' as const,
    name: 'Network Folder',
    description: 'Windows/Linux file shares',
    icon: HardDrive,
    color: 'text-primary bg-primary/10',
  },
  {
    id: 'sharepoint' as const,
    name: 'SharePoint',
    description: 'Microsoft 365 integration',
    icon: Share2,
    color: 'text-chart-2 bg-chart-2/10',
  },
  {
    id: 'database' as const,
    name: 'Database',
    description: 'SQL Server, PostgreSQL, MySQL',
    icon: Database,
    color: 'text-chart-3 bg-chart-3/10',
  },
  {
    id: 'cloud_storage' as const,
    name: 'Cloud Storage',
    description: 'Azure Blob, AWS S3, Google Cloud',
    icon: Cloud,
    color: 'text-chart-4 bg-chart-4/10',
  },
  {
    id: 'ftp' as const,
    name: 'FTP/SFTP',
    description: 'File transfer protocol',
    icon: Server,
    color: 'text-chart-5 bg-chart-5/10',
  },
];

const CLASSIFICATION_LEVELS = [
  {
    level: 'confidential',
    name: 'Confidential',
    description: 'Local storage only',
    color: 'bg-destructive',
    enabled: true,
  },
  {
    level: 'restricted',
    name: 'Restricted',
    description: 'Encrypted backup',
    color: 'bg-chart-4',
    enabled: true,
  },
  {
    level: 'internal',
    name: 'Internal',
    description: 'Selective cloud sync',
    color: 'bg-chart-3',
    enabled: false,
  },
  {
    level: 'public',
    name: 'Public',
    description: 'Full cloud sync',
    color: 'bg-accent',
    enabled: false,
  },
];

export function SourceConfigModal({
  isOpen,
  onClose,
  onSave,
  source,
  isLoading = false,
}: SourceConfigModalProps) {
  const [selectedType, setSelectedType] = useState<string>('network_folder');
  const [testConnection, setTestConnection] = useState<{
    status: 'idle' | 'testing' | 'success' | 'error';
    message?: string;
  }>({ status: 'idle' });

  const form = useForm<SourceConfigForm>({
    resolver: zodResolver(sourceConfigSchema),
    defaultValues: {
      name: '',
      type: 'network_folder',
      connectionConfig: {},
      isActive: true,
    },
  });

  // Update form when source prop changes
  useEffect(() => {
    if (source) {
      form.reset({
        name: source.name,
        type: source.type,
        connectionConfig: source.connectionConfig,
        isActive: source.isActive,
      });
      setSelectedType(source.type);
    } else {
      form.reset({
        name: '',
        type: 'network_folder',
        connectionConfig: {},
        isActive: true,
      });
      setSelectedType('network_folder');
    }
  }, [source, form]);

  const watchedType = form.watch('type');
  
  useEffect(() => {
    if (watchedType !== selectedType) {
      setSelectedType(watchedType);
      // Clear connection config when type changes
      form.setValue('connectionConfig', {});
    }
  }, [watchedType, selectedType, form]);

  const handleTestConnection = async () => {
    setTestConnection({ status: 'testing' });
    
    // Simulate connection test
    setTimeout(() => {
      const success = Math.random() > 0.3; // 70% success rate for demo
      setTestConnection({
        status: success ? 'success' : 'error',
        message: success 
          ? 'Connection successful! Source is ready to use.'
          : 'Connection failed. Please check your configuration.',
      });
    }, 2000);
  };

  const onSubmit = (data: SourceConfigForm) => {
    onSave(data);
  };

  const renderConnectionFields = () => {
    switch (selectedType) {
      case 'network_folder':
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="connectionConfig.path"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Network Path</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="\\server\share\folder or /mnt/network/folder"
                      {...field}
                      data-testid="input-network-path"
                    />
                  </FormControl>
                  <FormDescription>
                    UNC path for Windows or mount path for Linux
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="domain\username"
                        {...field}
                        data-testid="input-username"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input 
                        type="password"
                        placeholder="••••••••"
                        {...field}
                        data-testid="input-password"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
        );

      case 'sharepoint':
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="connectionConfig.server"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SharePoint Site URL</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="https://company.sharepoint.com/sites/documents"
                      {...field}
                      data-testid="input-sharepoint-url"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.tenantId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tenant ID</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                        {...field}
                        data-testid="input-tenant-id"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.clientId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Client ID</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                        {...field}
                        data-testid="input-client-id"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="connectionConfig.clientSecret"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Client Secret</FormLabel>
                  <FormControl>
                    <Input 
                      type="password"
                      placeholder="••••••••••••••••••••••••••••••••"
                      {...field}
                      data-testid="input-client-secret"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );

      case 'database':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.server"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Server</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="localhost or server.domain.com"
                        {...field}
                        data-testid="input-db-server"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.port"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Port</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="5432"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                        data-testid="input-db-port"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="connectionConfig.database"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Database Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="documents_db"
                      {...field}
                      data-testid="input-database-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="db_user"
                        {...field}
                        data-testid="input-db-username"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input 
                        type="password"
                        placeholder="••••••••"
                        {...field}
                        data-testid="input-db-password"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
        );

      case 'cloud_storage':
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="connectionConfig.bucketName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bucket/Container Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="my-documents-bucket"
                      {...field}
                      data-testid="input-bucket-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.region"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Region</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="us-east-1 or eastus"
                        {...field}
                        data-testid="input-region"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.apiKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>API Key / Access Key</FormLabel>
                    <FormControl>
                      <Input 
                        type="password"
                        placeholder="••••••••••••••••••••"
                        {...field}
                        data-testid="input-api-key"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
        );

      case 'ftp':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.server"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>FTP Server</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="ftp.company.com"
                        {...field}
                        data-testid="input-ftp-server"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.port"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Port</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        placeholder="21 or 22"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || undefined)}
                        data-testid="input-ftp-port"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="connectionConfig.path"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Remote Path</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="/documents or /upload"
                      {...field}
                      data-testid="input-ftp-path"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="connectionConfig.username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="ftp_user"
                        {...field}
                        data-testid="input-ftp-username"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="connectionConfig.password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input 
                        type="password"
                        placeholder="••••••••"
                        {...field}
                        data-testid="input-ftp-password"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto" data-testid="source-config-modal">
        <DialogHeader>
          <DialogTitle>
            {source ? 'Edit Document Source' : 'Configure Document Source'}
          </DialogTitle>
          <DialogDescription>
            Set up enterprise document processing pipeline
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Tabs defaultValue="connection" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="connection">Connection</TabsTrigger>
                <TabsTrigger value="classification">Classification</TabsTrigger>
              </TabsList>

              <TabsContent value="connection" className="space-y-6">
                {/* Basic Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Basic Information</h3>
                  
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Source Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter a descriptive name for this source"
                            {...field}
                            data-testid="input-source-name"
                          />
                        </FormControl>
                        <FormDescription>
                          This name will be used to identify the source in the dashboard
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Active Source</FormLabel>
                          <FormDescription>
                            Enable automatic document processing from this source
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="switch-source-active"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Source Type Selection */}
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Source Type</h3>
                  
                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {SOURCE_TYPES.map((type) => {
                              const Icon = type.icon;
                              const isSelected = field.value === type.id;
                              
                              return (
                                <Card 
                                  key={type.id}
                                  className={`cursor-pointer transition-all hover:shadow-md ${
                                    isSelected ? 'ring-2 ring-primary bg-primary/5' : ''
                                  }`}
                                  onClick={() => field.onChange(type.id)}
                                  data-testid={`source-type-${type.id}`}
                                >
                                  <CardContent className="p-4">
                                    <div className="flex items-center space-x-3">
                                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${type.color}`}>
                                        <Icon className="w-5 h-5" />
                                      </div>
                                      <div>
                                        <h4 className="font-medium text-foreground">{type.name}</h4>
                                        <p className="text-xs text-muted-foreground">{type.description}</p>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              );
                            })}
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Connection Configuration */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium">Connection Configuration</h3>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={handleTestConnection}
                      disabled={testConnection.status === 'testing'}
                      data-testid="button-test-connection"
                    >
                      {testConnection.status === 'testing' ? (
                        <>
                          <Settings className="w-4 h-4 mr-2 animate-spin" />
                          Testing...
                        </>
                      ) : (
                        <>
                          <Shield className="w-4 h-4 mr-2" />
                          Test Connection
                        </>
                      )}
                    </Button>
                  </div>

                  {testConnection.status !== 'idle' && (
                    <div className={`p-3 rounded-lg border ${
                      testConnection.status === 'success' 
                        ? 'bg-accent/10 border-accent/20 text-accent'
                        : testConnection.status === 'error'
                        ? 'bg-destructive/10 border-destructive/20 text-destructive'
                        : 'bg-muted border-border'
                    }`}>
                      <div className="flex items-center space-x-2">
                        {testConnection.status === 'success' && <CheckCircle2 className="w-4 h-4" />}
                        {testConnection.status === 'error' && <AlertCircle className="w-4 h-4" />}
                        {testConnection.status === 'testing' && <Settings className="w-4 h-4 animate-spin" />}
                        <span className="text-sm font-medium">
                          {testConnection.message || 'Testing connection...'}
                        </span>
                      </div>
                    </div>
                  )}

                  {renderConnectionFields()}
                </div>
              </TabsContent>

              <TabsContent value="classification" className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Document Classification Rules</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure how documents from this source should be classified and routed.
                  </p>

                  <div className="space-y-3">
                    {CLASSIFICATION_LEVELS.map((level, index) => (
                      <div 
                        key={level.level}
                        className="flex items-center justify-between p-3 border border-border rounded-lg"
                        data-testid={`classification-level-${index}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 ${level.color} rounded-full`}></div>
                          <div>
                            <span className="font-medium text-foreground">{level.name}</span>
                            <p className="text-xs text-muted-foreground">{level.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">
                            {level.description}
                          </span>
                          <Switch 
                            defaultChecked={level.enabled}
                            data-testid={`switch-classification-${level.level}`}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  <Card className="bg-muted/50">
                    <CardHeader>
                      <CardTitle className="text-base">Advanced Options</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium text-foreground">
                            Confidence Threshold
                          </label>
                          <Input 
                            type="number" 
                            placeholder="85" 
                            min="0" 
                            max="100"
                            data-testid="input-confidence-threshold"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            Minimum confidence level for auto-classification (0-100)
                          </p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-foreground">
                            Processing Priority
                          </label>
                          <Input 
                            type="number" 
                            placeholder="5" 
                            min="1" 
                            max="10"
                            data-testid="input-processing-priority"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            Higher numbers = higher priority (1-10)
                          </p>
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium text-foreground">
                          File Pattern Filters
                        </label>
                        <Textarea 
                          placeholder="*.pdf, *.docx, *.txt&#10;!temp*, !*backup*"
                          className="mt-1"
                          rows={3}
                          data-testid="textarea-file-patterns"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Include/exclude patterns (one per line, use ! for exclusions)
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>

            <Separator />

            <div className="flex justify-end space-x-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading}
                data-testid="button-save"
              >
                {isLoading ? 'Saving...' : source ? 'Update Source' : 'Create Source'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
