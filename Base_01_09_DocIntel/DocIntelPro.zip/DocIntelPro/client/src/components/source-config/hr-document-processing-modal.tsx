import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import type { HRProcessingJob } from '@/lib/types';
import { 
  HardDrive, 
  Share2, 
  Database, 
  Cloud, 
  Mail,
  Building2,
  Shield,
  FileText,
  Settings,
  AlertTriangle,
  CheckCircle,
  Lock,
  Globe,
  Users,
  Search,
  Eye,
  Play
} from 'lucide-react';

// HR Document Processing Schema
const hrProcessingSchema = z.object({
  // Basic Configuration
  name: z.string().min(1, 'Processing job name is required'),
  description: z.string().optional(),
  
  // Source Configuration
  sourceType: z.enum(['network_folder', 'sharepoint', 'email_inbox', 'database']),
  sourcePath: z.string().min(1, 'Source path is required'),
  sourceCredentials: z.object({
    username: z.string().optional(),
    password: z.string().optional(),
    domain: z.string().optional()
  }).optional(),
  
  // Document Type Mapping
  documentTypes: z.array(z.object({
    folder: z.string(),
    classification: z.enum(['CONFIDENTIAL', 'RESTRICTED', 'INTERNAL', 'PUBLIC']),
    enabled: z.boolean().default(true)
  })).min(1, 'At least one document type mapping is required'),
  
  // Processing Rules
  processingRules: z.object({
    ocrLanguages: z.array(z.string()).min(1, 'At least one OCR language is required'),
    enableAIClassification: z.boolean().default(true),
    enablePIIDetection: z.boolean().default(true),
    retentionPolicy: z.string(),
    enableOCR: z.boolean().default(true)
  }),
  
  // Output Destinations
  outputDestinations: z.object({
    CONFIDENTIAL: z.array(z.string()),
    RESTRICTED: z.array(z.string()),
    INTERNAL: z.array(z.string()),
    PUBLIC: z.array(z.string())
  })
});

type HRProcessingForm = z.infer<typeof hrProcessingSchema>;

interface HRDocumentProcessingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>; // Changed to match source creation
  isLoading?: boolean;
  source?: any; // Add source prop for edit mode
  mode?: 'create' | 'edit'; // Add mode prop
}

// HR Document Types with their classifications
const HR_DOCUMENT_TYPES = [
  {
    folder: 'Contracts',
    classification: 'CONFIDENTIAL' as const,
    description: 'Employee contracts and agreements',
    icon: FileText,
    estimatedCount: 45,
    color: 'red'
  },
  {
    folder: 'Payroll',
    classification: 'RESTRICTED' as const,
    description: 'Payroll records and salary information',
    icon: Shield,
    estimatedCount: 78,
    color: 'orange'
  },
  {
    folder: 'Reviews',
    classification: 'INTERNAL' as const,
    description: 'Performance reviews and evaluations',
    icon: Users,
    estimatedCount: 123,
    color: 'blue'
  },
  {
    folder: 'Policies',
    classification: 'PUBLIC' as const,
    description: 'Company policies and procedures',
    icon: Globe,
    estimatedCount: 246,
    color: 'green'
  },
  {
    folder: 'Training',
    classification: 'PUBLIC' as const,
    description: 'Training materials and resources',
    icon: FileText,
    estimatedCount: 89,
    color: 'green'
  }
];

// Source type configurations
const SOURCE_TYPES = [
  {
    value: 'network_folder',
    label: 'Network Folder',
    icon: HardDrive,
    description: 'Access documents from network file shares',
    placeholder: '\\\\HR-SERVER\\Documents',
    requiresCredentials: true
  },
  {
    value: 'sharepoint',
    label: 'SharePoint',
    icon: Share2,
    description: 'Connect to SharePoint document libraries',
    placeholder: 'https://company.sharepoint.com/hr',
    requiresCredentials: true
  },
  {
    value: 'email_inbox',
    label: 'Email Inbox',
    icon: Mail,
    description: 'Process documents from email attachments',
    placeholder: 'hr@company.com',
    requiresCredentials: true
  },
  {
    value: 'database',
    label: 'HR Management System',
    icon: Database,
    description: 'Connect to HR database systems',
    placeholder: 'HR_SYSTEM_DB',
    requiresCredentials: true
  }
];

// Available OCR languages
const OCR_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' }
];

// Retention policies
const RETENTION_POLICIES = [
  { value: '1_year', label: '1 Year' },
  { value: '3_years', label: '3 Years' },
  { value: '5_years', label: '5 Years' },
  { value: '7_years', label: '7 Years (Recommended for HR)' },
  { value: '10_years', label: '10 Years' },
  { value: 'permanent', label: 'Permanent' }
];

// Output destination options
const OUTPUT_DESTINATIONS = [
  { value: 'local_nas', label: 'Local NAS Storage', icon: HardDrive },
  { value: 'azure_encrypted', label: 'Azure Encrypted Backup', icon: Cloud },
  { value: 'azure_selective', label: 'Azure Selective Sync', icon: Cloud },
  { value: 'azure_full', label: 'Azure Full Sync', icon: Globe }
];

export function HRDocumentProcessingModal({ 
  isOpen, 
  onClose, 
  onSubmit, 
  isLoading = false,
  source,
  mode = 'create'
}: HRDocumentProcessingModalProps) {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [estimatedDocuments, setEstimatedDocuments] = useState(0);
  const [estimatedTime, setEstimatedTime] = useState('');

  const form = useForm<HRProcessingForm>({
    resolver: zodResolver(hrProcessingSchema),
    defaultValues: {
      name: '',
      description: '',
      sourceType: 'network_folder',
      sourcePath: '',
      sourceCredentials: {
        username: '',
        password: '',
        domain: ''
      },
      documentTypes: HR_DOCUMENT_TYPES.map(type => ({
        folder: type.folder,
        classification: type.classification,
        enabled: true
      })),
      processingRules: {
        ocrLanguages: ['en'],
        enableAIClassification: true,
        enablePIIDetection: true,
        retentionPolicy: '7_years',
        enableOCR: true
      },
      outputDestinations: {
        CONFIDENTIAL: ['local_nas'],
        RESTRICTED: ['local_nas', 'azure_encrypted'],
        INTERNAL: ['local_nas', 'azure_selective'],
        PUBLIC: ['local_nas', 'azure_full']
      }
    }
  });

  // Populate form when editing an existing source
  useEffect(() => {
    if (mode === 'edit' && source && isOpen) {
      const config = source.connectionConfig || {};
      form.reset({
        name: source.name || '',
        description: config.description || '',
        sourceType: config.sourceType || 'network_folder',
        sourcePath: config.sourcePath || '',
        sourceCredentials: config.credentials || {
          username: '',
          password: '',
          domain: ''
        },
        documentTypes: config.documentTypes || HR_DOCUMENT_TYPES.map(type => ({
          folder: type.folder,
          classification: type.classification,
          enabled: true
        })),
        processingRules: config.processingRules || {
          ocrLanguages: ['en'],
          enableAIClassification: true,
          enablePIIDetection: true,
          retentionPolicy: '7_years',
          enableOCR: true
        },
        outputDestinations: config.outputDestinations || {
          CONFIDENTIAL: ['local_nas'],
          RESTRICTED: ['local_nas', 'azure_encrypted'],
          INTERNAL: ['local_nas', 'azure_selective'],
          PUBLIC: ['local_nas', 'azure_full']
        }
      });
    }
  }, [mode, source, isOpen, form]);

  const selectedSourceType = SOURCE_TYPES.find(type => type.value === form.watch('sourceType'));
  const watchedDocTypes = form.watch('documentTypes');

  // Calculate estimated documents and processing time
  useEffect(() => {
    const enabledTypes = watchedDocTypes.filter(type => type.enabled);
    const totalDocs = enabledTypes.reduce((sum, type) => {
      const hrType = HR_DOCUMENT_TYPES.find(hr => hr.folder === type.folder);
      return sum + (hrType?.estimatedCount || 0);
    }, 0);
    
    setEstimatedDocuments(totalDocs);
    
    // Estimate processing time (assuming 16.2 seconds per document as per the specs)
    const totalSeconds = totalDocs * 16.2;
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    setEstimatedTime(hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`);
  }, [watchedDocTypes]);

  const validateStep = (step: number): string[] => {
    const errors: string[] = [];
    
    switch (step) {
      case 1:
        if (!form.getValues('name')) errors.push('Processing job name is required');
        if (!form.getValues('sourcePath')) errors.push('Source path is required');
        break;
      case 2:
        const enabledTypes = form.getValues('documentTypes').filter(type => type.enabled);
        if (enabledTypes.length === 0) errors.push('At least one document type must be enabled');
        break;
      case 3:
        if (form.getValues('processingRules.ocrLanguages').length === 0) {
          errors.push('At least one OCR language must be selected');
        }
        if (!form.getValues('processingRules.retentionPolicy')) {
          errors.push('Retention policy must be selected');
        }
        break;
    }
    
    return errors;
  };

  const handleNextStep = () => {
    const errors = validateStep(currentStep);
    setValidationErrors(errors);
    
    if (errors.length === 0 && currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      setValidationErrors([]);
    }
  };

  const handleSubmit = async (data: HRProcessingForm) => {
    const finalErrors = validateStep(4);
    if (finalErrors.length > 0) {
      setValidationErrors(finalErrors);
      return;
    }

    try {
      // Convert HR processing configuration to a data source configuration
      const sourceData = {
        name: data.name,
        description: data.description || `HR Document Source - ${data.sourceType}`,
        type: data.sourceType,
        domain: 'hr', // Mark as HR domain
        connectionConfig: {
          path: data.sourcePath,
          credentials: data.sourceCredentials
        },
        processingRules: data.processingRules,
        documentTypes: data.documentTypes,
        outputDestinations: data.outputDestinations,
        isActive: true
      };

      await onSubmit(sourceData);
      toast({
        title: "HR Document Source Created",
        description: `HR document source "${data.name}" has been successfully configured.`,
      });
      onClose();
    } catch (error: any) {
      toast({
        title: "Error",
        description: `Failed to create HR document source: ${error.message}`,
        variant: "destructive",
      });
    }
  };

  const getStepStatus = (step: number) => {
    if (step < currentStep) return 'completed';
    if (step === currentStep) return 'current';
    return 'pending';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-6 w-6 text-green-600" />
            {mode === 'edit' ? 'Edit HR Document Source' : 'Configure HR Document Source'}
          </DialogTitle>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium
                  ${getStepStatus(step) === 'completed' ? 'bg-green-600 text-white' :
                    getStepStatus(step) === 'current' ? 'bg-blue-600 text-white' :
                    'bg-gray-200 text-gray-600'}
                `}>
                  {getStepStatus(step) === 'completed' ? <CheckCircle className="w-5 h-5" /> : step}
                </div>
                {step < 4 && (
                  <div className={`w-20 h-1 mx-2 ${
                    getStepStatus(step) === 'completed' ? 'bg-green-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          
          <div className="flex justify-between text-sm text-gray-600">
            <span>Source Configuration</span>
            <span>Document Mapping</span>
            <span>Processing Rules</span>
            <span>Review & Create</span>
          </div>
        </div>

        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          {/* Step 1: Source Selection */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HardDrive className="h-5 w-5" />
                    Data Source Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Processing Job Name *</Label>
                      <Input
                        id="name"
                        {...form.register('name')}
                        placeholder="e.g., HR Department Document Processing"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Input
                        id="description"
                        {...form.register('description')}
                        placeholder="Description of this processing job"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label>Source Type *</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {SOURCE_TYPES.map((sourceType) => {
                        const Icon = sourceType.icon;
                        const isSelected = form.watch('sourceType') === sourceType.value;
                        return (
                          <div
                            key={sourceType.value}
                            className={`border rounded-lg p-4 cursor-pointer transition-all ${
                              isSelected 
                                ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => form.setValue('sourceType', sourceType.value as any)}
                          >
                            <div className="flex items-start gap-3">
                              <Icon className={`h-6 w-6 mt-0.5 ${isSelected ? 'text-blue-600' : 'text-gray-500'}`} />
                              <div className="flex-1">
                                <div className="font-medium">{sourceType.label}</div>
                                <div className="text-sm text-gray-500 mt-1">{sourceType.description}</div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sourcePath">Source Path *</Label>
                    <Input
                      id="sourcePath"
                      {...form.register('sourcePath')}
                      placeholder={selectedSourceType?.placeholder}
                    />
                  </div>

                  {selectedSourceType?.requiresCredentials && (
                    <Card className="bg-gray-50">
                      <CardHeader>
                        <CardTitle className="text-sm">Connection Credentials</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-3 gap-3">
                          <div className="space-y-2">
                            <Label htmlFor="username">Username</Label>
                            <Input
                              id="username"
                              {...form.register('sourceCredentials.username')}
                              placeholder="Domain\\Username"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="password">Password</Label>
                            <Input
                              id="password"
                              type="password"
                              {...form.register('sourceCredentials.password')}
                              placeholder="••••••••"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="domain">Domain</Label>
                            <Input
                              id="domain"
                              {...form.register('sourceCredentials.domain')}
                              placeholder="COMPANY"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 2: Document Type Mapping */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    HR Document Type Mapping
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4">
                    {HR_DOCUMENT_TYPES.map((docType, index) => {
                      const Icon = docType.icon;
                      const isEnabled = form.watch(`documentTypes.${index}.enabled`);
                      
                      return (
                        <div key={docType.folder} className={`border rounded-lg p-4 ${
                          isEnabled ? 'border-blue-200 bg-blue-50' : 'border-gray-200'
                        }`}>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <Checkbox
                                checked={isEnabled}
                                onCheckedChange={(checked) => 
                                  form.setValue(`documentTypes.${index}.enabled`, !!checked)
                                }
                              />
                              <Icon className={`h-5 w-5 ${isEnabled ? 'text-blue-600' : 'text-gray-400'}`} />
                              <div>
                                <div className="font-medium">
                                  Folder: "{docType.folder}"
                                </div>
                                <div className="text-sm text-gray-500">{docType.description}</div>
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-3">
                              <Badge 
                                variant="outline" 
                                className={`text-${docType.color}-600 border-${docType.color}-300`}
                              >
                                {docType.classification}
                              </Badge>
                              <div className="text-sm text-gray-500">
                                ~{docType.estimatedCount} docs
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      Document classifications will determine access controls and storage routing. 
                      Review carefully before proceeding.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 3: Processing Rules */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Processing Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* OCR Configuration */}
                  <div className="space-y-3">
                    <Label>OCR Languages *</Label>
                    <div className="grid grid-cols-3 gap-3">
                      {OCR_LANGUAGES.map((lang) => {
                        const isSelected = form.watch('processingRules.ocrLanguages').includes(lang.code);
                        return (
                          <div
                            key={lang.code}
                            className={`border rounded-lg p-3 cursor-pointer transition-all ${
                              isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => {
                              const current = form.getValues('processingRules.ocrLanguages');
                              const updated = isSelected 
                                ? current.filter(code => code !== lang.code)
                                : [...current, lang.code];
                              form.setValue('processingRules.ocrLanguages', updated);
                            }}
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{lang.flag}</span>
                              <span className="text-sm font-medium">{lang.name}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Processing Toggles */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="enableOCR">Enable OCR Processing</Label>
                        <p className="text-sm text-gray-500">Extract text from scanned documents and images</p>
                      </div>
                      <Switch
                        id="enableOCR"
                        checked={form.watch('processingRules.enableOCR')}
                        onCheckedChange={(checked) => form.setValue('processingRules.enableOCR', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="enableAI">AI Classification</Label>
                        <p className="text-sm text-gray-500">Automatically classify documents using machine learning</p>
                      </div>
                      <Switch
                        id="enableAI"
                        checked={form.watch('processingRules.enableAIClassification')}
                        onCheckedChange={(checked) => form.setValue('processingRules.enableAIClassification', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label htmlFor="enablePII">PII Detection</Label>
                        <p className="text-sm text-gray-500">Detect and flag personally identifiable information</p>
                      </div>
                      <Switch
                        id="enablePII"
                        checked={form.watch('processingRules.enablePIIDetection')}
                        onCheckedChange={(checked) => form.setValue('processingRules.enablePIIDetection', checked)}
                      />
                    </div>
                  </div>

                  {/* Retention Policy */}
                  <div className="space-y-2">
                    <Label htmlFor="retention">Retention Policy *</Label>
                    <Select onValueChange={(value) => form.setValue('processingRules.retentionPolicy', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select retention policy" />
                      </SelectTrigger>
                      <SelectContent>
                        {RETENTION_POLICIES.map((policy) => (
                          <SelectItem key={policy.value} value={policy.value}>
                            {policy.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Output Destinations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cloud className="h-5 w-5" />
                    Output Routing Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {(['CONFIDENTIAL', 'RESTRICTED', 'INTERNAL', 'PUBLIC'] as const).map((classification) => (
                    <div key={classification} className="space-y-3">
                      <Label className="flex items-center gap-2">
                        <Lock className="h-4 w-4" />
                        {classification} Documents
                      </Label>
                      <div className="grid grid-cols-2 gap-3">
                        {OUTPUT_DESTINATIONS.map((dest) => {
                          const Icon = dest.icon;
                          const isSelected = form.watch(`outputDestinations.${classification}`).includes(dest.value);
                          
                          return (
                            <div
                              key={dest.value}
                              className={`border rounded-lg p-3 cursor-pointer transition-all ${
                                isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                              }`}
                              onClick={() => {
                                const current = form.getValues(`outputDestinations.${classification}`);
                                const updated = isSelected 
                                  ? current.filter(val => val !== dest.value)
                                  : [...current, dest.value];
                                form.setValue(`outputDestinations.${classification}`, updated);
                              }}
                            >
                              <div className="flex items-center gap-2">
                                <Icon className={`h-4 w-4 ${isSelected ? 'text-blue-600' : 'text-gray-500'}`} />
                                <span className="text-sm font-medium">{dest.label}</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Step 4: Review & Start */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="h-5 w-5" />
                    Configuration Review
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Summary Stats */}
                  <div className="grid grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{estimatedDocuments}</div>
                      <div className="text-sm text-gray-600">Documents to Process</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{estimatedTime}</div>
                      <div className="text-sm text-gray-600">Estimated Time</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        {form.watch('processingRules.ocrLanguages').length}
                      </div>
                      <div className="text-sm text-gray-600">OCR Languages</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {form.watch('documentTypes').filter(t => t.enabled).length}
                      </div>
                      <div className="text-sm text-gray-600">Document Types</div>
                    </div>
                  </div>

                  {/* Configuration Summary */}
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Source Configuration</h4>
                      <div className="bg-gray-50 p-3 rounded">
                        <p><strong>Type:</strong> {selectedSourceType?.label}</p>
                        <p><strong>Path:</strong> {form.watch('sourcePath')}</p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Processing Rules</h4>
                      <div className="bg-gray-50 p-3 rounded space-y-1">
                        <p><strong>OCR:</strong> {form.watch('processingRules.enableOCR') ? 'Enabled' : 'Disabled'}</p>
                        <p><strong>AI Classification:</strong> {form.watch('processingRules.enableAIClassification') ? 'Enabled' : 'Disabled'}</p>
                        <p><strong>PII Detection:</strong> {form.watch('processingRules.enablePIIDetection') ? 'Enabled' : 'Disabled'}</p>
                        <p><strong>Retention:</strong> {RETENTION_POLICIES.find(p => p.value === form.watch('processingRules.retentionPolicy'))?.label}</p>
                      </div>
                    </div>
                  </div>

                  {/* Ready to Process */}
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      Configuration is complete and ready to be saved as a data source. Click "Create Source" to save.
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Validation Errors */}
          {validationErrors.length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {validationErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex justify-between">
            <div>
              {currentStep > 1 && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handlePreviousStep}
                >
                  Previous
                </Button>
              )}
            </div>
            
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
              >
                Cancel
              </Button>
              
              {currentStep < 4 ? (
                <Button
                  type="button"
                  onClick={handleNextStep}
                >
                  Next
                </Button>
              ) : (
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="flex items-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      Create HR Source
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
