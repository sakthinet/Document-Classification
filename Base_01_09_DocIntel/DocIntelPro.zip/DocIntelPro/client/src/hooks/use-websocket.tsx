import { useEffect, useRef, useState, useCallback } from 'react';
import { WebSocketMessage } from '@/lib/types';

interface UseWebSocketOptions {
  organizationId: string;
  userId: string;
  onMessage?: (message: WebSocketMessage) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Event) => void;
}

export function useWebSocket({
  organizationId,
  userId,
  onMessage,
  onConnect,
  onDisconnect,
  onError
}: UseWebSocketOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('disconnected');
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const isConnectingRef = useRef(false);
  const isMountedRef = useRef(true);
  const maxReconnectAttempts = 5;

  // Store callbacks in refs to avoid recreating connection on callback changes
  const onMessageRef = useRef(onMessage);
  const onConnectRef = useRef(onConnect);
  const onDisconnectRef = useRef(onDisconnect);
  const onErrorRef = useRef(onError);
  
  // Update refs when callbacks change
  useEffect(() => {
    onMessageRef.current = onMessage;
    onConnectRef.current = onConnect;
    onDisconnectRef.current = onDisconnect;
    onErrorRef.current = onError;
  });

  const connect = useCallback(() => {
    // Prevent multiple simultaneous connection attempts
    if (isConnectingRef.current || !isMountedRef.current) {
      return;
    }
    
    // Check if already connected
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }
    
    // Close existing connection if it's in a bad state
    if (wsRef.current && 
        (wsRef.current.readyState === WebSocket.CONNECTING || 
         wsRef.current.readyState === WebSocket.CLOSING)) {
      wsRef.current.close();
      wsRef.current = null;
    }

    isConnectingRef.current = true;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    if (isMountedRef.current) {
      setConnectionStatus('connecting');
    }
    
    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        isConnectingRef.current = false;
        if (!isMountedRef.current) {
          ws.close();
          return;
        }
        
        setIsConnected(true);
        setConnectionStatus('connected');
        reconnectAttemptsRef.current = 0;
        
        // Authenticate with the server
        ws.send(JSON.stringify({
          type: 'authenticate',
          data: { organizationId, userId }
        }));
        
        onConnectRef.current?.();
      };

      ws.onmessage = (event) => {
        if (!isMountedRef.current) return;
        
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          onMessageRef.current?.(message);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      ws.onclose = () => {
        isConnectingRef.current = false;
        if (!isMountedRef.current) return;
        
        setIsConnected(false);
        setConnectionStatus('disconnected');
        wsRef.current = null;
        onDisconnectRef.current?.();
        
        // Attempt to reconnect only if component is still mounted and under retry limit
        if (isMountedRef.current && reconnectAttemptsRef.current < maxReconnectAttempts) {
          const timeout = Math.pow(2, reconnectAttemptsRef.current) * 1000; // Exponential backoff
          reconnectAttemptsRef.current++;
          
          reconnectTimeoutRef.current = setTimeout(() => {
            if (isMountedRef.current) {
              connect();
            }
          }, timeout);
        }
      };

      ws.onerror = (error) => {
        isConnectingRef.current = false;
        if (!isMountedRef.current) return;
        
        setConnectionStatus('error');
        onErrorRef.current?.(error);
        console.error('WebSocket error:', error);
      };
    } catch (error) {
      isConnectingRef.current = false;
      if (isMountedRef.current) {
        setConnectionStatus('error');
      }
      console.error('Failed to create WebSocket connection:', error);
    }
  }, [organizationId, userId]);

  const disconnect = useCallback(() => {
    // Clear reconnection timer
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    // Reset flags
    isConnectingRef.current = false;
    reconnectAttemptsRef.current = 0;
    
    // Close WebSocket connection
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    
    if (isMountedRef.current) {
      setIsConnected(false);
      setConnectionStatus('disconnected');
    }
  }, []);

  const sendMessage = useCallback((message: Omit<WebSocketMessage, 'timestamp'>) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        ...message,
        timestamp: new Date().toISOString()
      }));
      return true;
    }
    return false;
  }, []);

  const subscribe = useCallback((channel: string) => {
    return sendMessage({
      type: 'subscribe',
      data: { channel }
    });
  }, [sendMessage]);

  useEffect(() => {
    isMountedRef.current = true;
    connect();
    
    return () => {
      isMountedRef.current = false;
      disconnect();
    };
  }, [organizationId, userId]); // Only reconnect when org/user changes

  return {
    isConnected,
    connectionStatus,
    sendMessage,
    subscribe,
    connect,
    disconnect
  };
}
