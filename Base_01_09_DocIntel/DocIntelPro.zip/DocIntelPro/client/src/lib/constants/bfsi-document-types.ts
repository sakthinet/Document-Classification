// BFSI Document Types and Classification Rules
export const BFSI_DOCUMENT_TYPES = {
  // Loan & Credit Documents
  LOAN_APPLICATION: {
    name: 'Loan Application',
    category: 'lending',
    classification: 'confidential',
    description: 'Personal and business loan applications',
    requiredFields: ['applicant_name', 'loan_amount', 'purpose'],
    piiFields: ['ssn', 'income', 'employment_details'],
    retentionPeriod: '7_years',
    complianceFlags: ['SOX', 'Fair_Lending_Act']
  },
  
  CREDIT_REPORT: {
    name: 'Credit Report',
    category: 'lending',
    classification: 'confidential',
    description: 'Credit bureau reports and scores',
    requiredFields: ['credit_score', 'report_date', 'bureau'],
    piiFields: ['ssn', 'credit_history', 'debt_information'],
    retentionPeriod: '7_years',
    complianceFlags: ['FCRA', 'GLBA']
  },

  LOAN_AGREEMENT: {
    name: 'Loan Agreement',
    category: 'lending',
    classification: 'confidential',
    description: 'Signed loan contracts and agreements',
    requiredFields: ['loan_amount', 'interest_rate', 'terms'],
    piiFields: ['borrower_info', 'collateral_details'],
    retentionPeriod: '7_years',
    complianceFlags: ['SOX', 'TILA']
  },

  // KYC & Compliance Documents
  KYC_DOCUMENT: {
    name: 'KYC Document',
    category: 'compliance',
    classification: 'restricted',
    description: 'Know Your Customer verification documents',
    requiredFields: ['customer_id', 'document_type', 'verification_status'],
    piiFields: ['government_id', 'address', 'phone', 'email'],
    retentionPeriod: '5_years',
    complianceFlags: ['BSA', 'AML', 'PATRIOT_Act']
  },

  AML_REPORT: {
    name: 'AML Report',
    category: 'compliance',
    classification: 'restricted',
    description: 'Anti-Money Laundering reports and investigations',
    requiredFields: ['transaction_id', 'suspicious_activity', 'investigation_status'],
    piiFields: ['customer_info', 'transaction_details'],
    retentionPeriod: '5_years',
    complianceFlags: ['BSA', 'AML', 'FinCEN']
  },

  SAR_FILING: {
    name: 'SAR Filing',
    category: 'compliance',
    classification: 'confidential',
    description: 'Suspicious Activity Reports',
    requiredFields: ['filing_date', 'activity_type', 'amount'],
    piiFields: ['subject_info', 'transaction_details'],
    retentionPeriod: '5_years',
    complianceFlags: ['BSA', 'FinCEN']
  },

  // Financial Statements & Reports
  FINANCIAL_STATEMENT: {
    name: 'Financial Statement',
    category: 'financial_reporting',
    classification: 'internal',
    description: 'Balance sheets, income statements, cash flow',
    requiredFields: ['statement_type', 'period', 'prepared_by'],
    piiFields: ['financial_data'],
    retentionPeriod: '7_years',
    complianceFlags: ['SOX', 'GAAP']
  },

  AUDIT_REPORT: {
    name: 'Audit Report',
    category: 'financial_reporting',
    classification: 'restricted',
    description: 'Internal and external audit reports',
    requiredFields: ['audit_type', 'auditor', 'findings'],
    piiFields: ['financial_details'],
    retentionPeriod: '7_years',
    complianceFlags: ['SOX', 'PCAOB']
  },

  TAX_DOCUMENT: {
    name: 'Tax Document',
    category: 'financial_reporting',
    classification: 'confidential',
    description: 'Tax returns and related documentation',
    requiredFields: ['tax_year', 'entity_type', 'jurisdiction'],
    piiFields: ['tax_id', 'financial_data'],
    retentionPeriod: '7_years',
    complianceFlags: ['IRS', 'State_Tax']
  },

  // Insurance Documents
  INSURANCE_POLICY: {
    name: 'Insurance Policy',
    category: 'insurance',
    classification: 'internal',
    description: 'Insurance policies and coverage details',
    requiredFields: ['policy_number', 'coverage_type', 'premium'],
    piiFields: ['policyholder_info', 'beneficiary_info'],
    retentionPeriod: '7_years',
    complianceFlags: ['State_Insurance']
  },

  INSURANCE_CLAIM: {
    name: 'Insurance Claim',
    category: 'insurance',
    classification: 'restricted',
    description: 'Insurance claims and settlements',
    requiredFields: ['claim_number', 'incident_date', 'claim_amount'],
    piiFields: ['claimant_info', 'medical_info'],
    retentionPeriod: '7_years',
    complianceFlags: ['State_Insurance', 'HIPAA']
  },

  // Investment & Securities
  INVESTMENT_AGREEMENT: {
    name: 'Investment Agreement',
    category: 'securities',
    classification: 'confidential',
    description: 'Investment contracts and agreements',
    requiredFields: ['investment_type', 'amount', 'terms'],
    piiFields: ['investor_info', 'financial_status'],
    retentionPeriod: '7_years',
    complianceFlags: ['SEC', 'FINRA']
  },

  PROSPECTUS: {
    name: 'Prospectus',
    category: 'securities',
    classification: 'public',
    description: 'Investment prospectus and offering documents',
    requiredFields: ['offering_type', 'securities_details', 'risks'],
    piiFields: [],
    retentionPeriod: '7_years',
    complianceFlags: ['SEC', 'Securities_Act']
  },

  // Transaction Documents
  WIRE_TRANSFER: {
    name: 'Wire Transfer',
    category: 'transactions',
    classification: 'restricted',
    description: 'Wire transfer instructions and confirmations',
    requiredFields: ['amount', 'sender', 'receiver', 'purpose'],
    piiFields: ['account_numbers', 'customer_info'],
    retentionPeriod: '5_years',
    complianceFlags: ['BSA', 'OFAC']
  },

  TRANSACTION_RECORD: {
    name: 'Transaction Record',
    category: 'transactions',
    classification: 'internal',
    description: 'General transaction records and logs',
    requiredFields: ['transaction_id', 'amount', 'date', 'type'],
    piiFields: ['account_info', 'customer_info'],
    retentionPeriod: '7_years',
    complianceFlags: ['BSA', 'Record_Keeping']
  }
} as const;

export const BFSI_CATEGORIES = [
  { value: 'lending', label: 'Lending & Credit', icon: '💰' },
  { value: 'compliance', label: 'Compliance & AML', icon: '🛡️' },
  { value: 'financial_reporting', label: 'Financial Reporting', icon: '📊' },
  { value: 'insurance', label: 'Insurance', icon: '🏥' },
  { value: 'securities', label: 'Securities & Investment', icon: '📈' },
  { value: 'transactions', label: 'Transactions', icon: '💳' }
] as const;

export const CLASSIFICATION_LEVELS = [
  { 
    value: 'confidential', 
    label: 'Confidential', 
    color: 'red',
    description: 'Highest sensitivity - Local storage only',
    storage: ['local_nas'],
    icon: '🔒'
  },
  { 
    value: 'restricted', 
    label: 'Restricted', 
    color: 'orange',
    description: 'High sensitivity - Local + encrypted cloud backup',
    storage: ['local_nas', 'azure_encrypted'],
    icon: '🔐'
  },
  { 
    value: 'internal', 
    label: 'Internal', 
    color: 'yellow',
    description: 'Medium sensitivity - Local + selective cloud sync',
    storage: ['local_nas', 'azure_selective'],
    icon: '🏢'
  },
  { 
    value: 'public', 
    label: 'Public', 
    color: 'green',
    description: 'Low sensitivity - Full cloud sync + CDN',
    storage: ['local_nas', 'azure_full', 'cdn'],
    icon: '📖'
  }
] as const;

export const COMPLIANCE_FRAMEWORKS = [
  { code: 'SOX', name: 'Sarbanes-Oxley Act', description: 'Financial reporting and corporate governance' },
  { code: 'BSA', name: 'Bank Secrecy Act', description: 'Anti-money laundering requirements' },
  { code: 'AML', name: 'Anti-Money Laundering', description: 'Money laundering prevention' },
  { code: 'GLBA', name: 'Gramm-Leach-Bliley Act', description: 'Financial privacy protection' },
  { code: 'FCRA', name: 'Fair Credit Reporting Act', description: 'Credit reporting accuracy and privacy' },
  { code: 'TILA', name: 'Truth in Lending Act', description: 'Credit terms disclosure' },
  { code: 'PATRIOT_Act', name: 'USA PATRIOT Act', description: 'Terrorism financing prevention' },
  { code: 'FinCEN', name: 'Financial Crimes Enforcement Network', description: 'Financial intelligence reporting' },
  { code: 'SEC', name: 'Securities and Exchange Commission', description: 'Securities regulation' },
  { code: 'FINRA', name: 'Financial Industry Regulatory Authority', description: 'Broker-dealer regulation' },
  { code: 'OFAC', name: 'Office of Foreign Assets Control', description: 'Economic sanctions enforcement' },
  { code: 'PCAOB', name: 'Public Company Accounting Oversight Board', description: 'Audit oversight' },
  { code: 'GAAP', name: 'Generally Accepted Accounting Principles', description: 'Accounting standards' },
  { code: 'HIPAA', name: 'Health Insurance Portability and Accountability Act', description: 'Healthcare privacy (for insurance)' },
  { code: 'Fair_Lending_Act', name: 'Fair Lending Act', description: 'Equal credit opportunity' },
  { code: 'Securities_Act', name: 'Securities Act of 1933', description: 'Securities registration and disclosure' },
  { code: 'Record_Keeping', name: 'Record Keeping Requirements', description: 'Document retention obligations' },
  { code: 'State_Insurance', name: 'State Insurance Regulations', description: 'State-level insurance oversight' },
  { code: 'State_Tax', name: 'State Tax Regulations', description: 'State taxation compliance' },
  { code: 'IRS', name: 'Internal Revenue Service', description: 'Federal tax compliance' }
] as const;

// Helper functions
export const getDocumentTypesByCategory = (category: string) => {
  return Object.entries(BFSI_DOCUMENT_TYPES)
    .filter(([_, type]) => type.category === category)
    .map(([key, type]) => ({ key, ...type }));
};

export const getDocumentTypeByKey = (key: string) => {
  return BFSI_DOCUMENT_TYPES[key as keyof typeof BFSI_DOCUMENT_TYPES];
};

export const getClassificationByLevel = (level: string) => {
  return CLASSIFICATION_LEVELS.find(cl => cl.value === level);
};

export const getComplianceFramework = (code: string) => {
  return COMPLIANCE_FRAMEWORKS.find(cf => cf.code === code);
};
