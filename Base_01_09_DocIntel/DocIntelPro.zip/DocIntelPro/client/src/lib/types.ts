// Core types for the Document Intelligence Platform
export interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'manager' | 'analyst' | 'viewer';
  organizationId: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Organization {
  id: string;
  name: string;
  domain: string;
  settings: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

// Import the correct types from shared schema
import type { DocumentSource, NewDocumentSource } from '../../../shared/schema';

// Re-export for convenience
export type { DocumentSource, NewDocumentSource };

export interface DocumentDestination {
  id: string;
  name: string;
  type: 'cloud_storage' | 'database' | 'ftp' | 'api_endpoint';
  provider?: string | null;
  description?: string | null;
  organizationId: string;
  connectionConfig: Record<string, any>;
  routingRules: Record<string, any>;
  isActive: boolean;
  lastTestAt?: string | null;
  testResult?: string | null;
  testMessage?: string | null;
  createdAt: string;
  updatedAt: string;
}

// Insert types
export type InsertDocumentSource = Omit<DocumentSource, 'id' | 'createdAt' | 'updatedAt' | 'lastSyncAt' | 'lastTestAt'>;
export type InsertDocumentDestination = Omit<DocumentDestination, 'id' | 'createdAt' | 'updatedAt' | 'lastTestAt'>;

export interface DocumentType {
  id: string;
  name: string;
  domain: 'bfsi' | 'healthcare';
  category: string;
  classificationRules: Record<string, any>;
  piiDetectionRules: Record<string, any>;
  organizationId: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProcessingJob {
  id: string;
  batchId: string;
  name: string;
  sourceId: string;
  organizationId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  totalDocuments: number;
  processedDocuments: number;
  failedDocuments: number;
  progress: number;
  estimatedTimeRemaining: number | null;
  startedAt: string | null;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Document {
  id: string;
  fileName: string;
  filePath: string;
  fileSize: number | null;
  mimeType: string | null;
  sourceId: string;
  jobId: string | null;
  organizationId: string;
  documentTypeId: string | null;
  classificationStatus: 'pending' | 'classified' | 'failed';
  classificationConfidence: number | null;
  classificationLevel: 'confidential' | 'restricted' | 'internal' | 'public' | null;
  containsPii: boolean;
  piiTypes: string[];
  ocrText: string | null;
  vectorEmbedding: string | null;
  metadata: Record<string, any>;
  processedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardMetrics {
  totalProcessed: number;
  todaysProcessed: number;
  completedToday: number;
  accuracy: number;
  activeSources: number;
  queueSize: number;
  classificationBreakdown: Array<{
    level: string;
    count: number;
    percentage: number;
  }>;
}

export interface WebSocketMessage {
  type: string;
  data: any;
  organizationId?: string;
  timestamp: string;
}

export interface ClassificationResult {
  documentType: string;
  classificationLevel: 'confidential' | 'restricted' | 'internal' | 'public';
  confidence: number;
  reasoning: string;
  detectedPII: string[];
  domain: 'bfsi' | 'healthcare' | 'general';
}

export interface PIIDetectionResult {
  containsPii: boolean;
  piiTypes: string[];
  confidence: number;
  details: Array<{
    type: string;
    description: string;
    severity: 'high' | 'medium' | 'low';
  }>;
}

export interface AuditLog {
  id: string;
  userId: string | null;
  organizationId: string;
  action: string;
  resource: string;
  resourceId: string | null;
  details: Record<string, any>;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

export interface SystemMetric {
  id: string;
  organizationId: string;
  metricType: string;
  value: number;
  metadata: Record<string, any>;
  timestamp: string;
}

// HR Document Processing Types
export interface HRProcessingJob {
  id: string;
  name: string;
  description?: string;
  sourceType: 'network_folder' | 'sharepoint' | 'email_inbox' | 'database';
  sourcePath: string;
  sourceCredentials?: {
    username?: string;
    password?: string;
    domain?: string;
  };
  documentTypes: Array<{
    folder: string;
    classification: 'CONFIDENTIAL' | 'RESTRICTED' | 'INTERNAL' | 'PUBLIC';
    enabled: boolean;
  }>;
  processingRules: {
    ocrLanguages: string[];
    enableAIClassification: boolean;
    enablePIIDetection: boolean;
    retentionPolicy: string;
    enableOCR: boolean;
  };
  outputDestinations: {
    CONFIDENTIAL: string[];
    RESTRICTED: string[];
    INTERNAL: string[];
    PUBLIC: string[];
  };
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  progress?: number;
  estimatedCompletion?: string;
  documentsToProcess?: number;
  documentsProcessed?: number;
  websocketChannel?: string;
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
}

export interface HRProcessingResponse {
  success: boolean;
  job_id: string;
  status: string;
  estimated_completion: string;
  documents_to_process: number;
  websocket_channel: string;
}
