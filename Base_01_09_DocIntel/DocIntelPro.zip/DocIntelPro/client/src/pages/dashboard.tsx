import { useEffect, useState, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Sidebar } from '@/components/layout/sidebar';
import { TopBar } from '@/components/layout/topbar';
import { MetricsCard } from '@/components/dashboard/metrics-card';
import { ProcessingQueue } from '@/components/dashboard/processing-queue';
import { ClassificationBreakdown } from '@/components/dashboard/classification-breakdown';
import { ComplianceStatus } from '@/components/dashboard/compliance-status';
import { RecentActivity } from '@/components/dashboard/recent-activity';
import { BfsiMetrics } from '@/components/dashboard/bfsi-metrics';
import { useWebSocket } from '@/hooks/use-websocket';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Building2, BarChart3, Shield, Activity } from 'lucide-react';
import type { DashboardMetrics, ProcessingJob, WebSocketMessage } from '@/lib/types';

export default function Dashboard() {
  const { toast } = useToast();
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [activeJobs, setActiveJobs] = useState<ProcessingJob[]>([]);

  // Organization and user IDs - in real app these would come from auth context
  const organizationId = 'f5a5744d-f922-4918-b5ae-0d9a430b9b0b';
  const userId = '3761d7a3-eace-492a-8cf2-eab83c28fd2f';

  // Fetch initial dashboard metrics
  const { data: initialMetrics, isLoading: metricsLoading } = useQuery({
    queryKey: ['/api/dashboard/metrics'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch active processing jobs
  const { data: initialActiveJobs, isLoading: jobsLoading } = useQuery({
    queryKey: ['/api/processing/jobs/active'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // WebSocket connection for real-time updates
  const handleWebSocketMessage = useCallback((message: WebSocketMessage) => {
    switch (message.type) {
      case 'processing_update':
        setActiveJobs(prev => {
          const updatedJobs = [...prev];
          const jobIndex = updatedJobs.findIndex(job => job.id === message.data.id);
          if (jobIndex >= 0) {
            updatedJobs[jobIndex] = message.data;
          } else {
            updatedJobs.push(message.data);
          }
          return updatedJobs;
        });
        break;
      
      case 'metrics_update':
        setMetrics(message.data);
        break;
      
      case 'document_classified':
        toast({
          title: "Document Classified",
          description: `${message.data.fileName} has been classified as ${message.data.classificationLevel}`,
        });
        break;
      
      case 'compliance_alert':
        toast({
          title: "Compliance Alert",
          description: message.data.type === 'pii_detected' 
            ? `PII detected: ${message.data.piiTypes.join(', ')}`
            : message.data.message,
          variant: message.data.severity === 'high' ? 'destructive' : 'default',
        });
        break;
      
      case 'system_notification':
        toast({
          title: message.data.title || "System Notification",
          description: message.data.message,
        });
        break;
      
      default:
        console.log('Unhandled WebSocket message:', message);
    }
  }, [toast]);
  
  const handleWebSocketConnect = useCallback(() => {
    console.log('WebSocket connected');
  }, []);
  
  const handleWebSocketDisconnect = useCallback(() => {
    console.log('WebSocket disconnected');
  }, []);
  
  const handleWebSocketError = useCallback((error: Event) => {
    console.error('WebSocket error:', error);
    toast({
      title: "Connection Error",
      description: "Real-time updates may be delayed",
      variant: "destructive",
    });
  }, [toast]);

  const { isConnected, connectionStatus } = useWebSocket({
    organizationId,
    userId,
    onMessage: handleWebSocketMessage,
    onConnect: handleWebSocketConnect,
    onDisconnect: handleWebSocketDisconnect,
    onError: handleWebSocketError
  });

  // Set initial data when queries complete
  useEffect(() => {
    if (initialMetrics) {
      setMetrics(initialMetrics as DashboardMetrics);
    }
  }, [initialMetrics]);

  useEffect(() => {
    if (initialActiveJobs) {
      setActiveJobs(initialActiveJobs as ProcessingJob[]);
    }
  }, [initialActiveJobs]);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          isConnected={isConnected} 
          connectionStatus={connectionStatus}
        />
        
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {/* Metrics Cards Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricsCard
              title="Documents Processed"
              value={metrics?.totalProcessed?.toLocaleString() || "0"}
              change="+12% from last month"
              changeType="positive"
              icon="file-text"
              isLoading={metricsLoading}
            />
            
            <MetricsCard
              title="Classification Accuracy"
              value={`${metrics?.accuracy?.toFixed(1)}%` || "0%"}
              change="+2.1% improvement"
              changeType="positive"
              icon="target"
              isLoading={metricsLoading}
            />
            
            <MetricsCard
              title="Active Sources"
              value={metrics?.activeSources?.toString() || "0"}
              change="Across 3 tenants"
              changeType="neutral"
              icon="database"
              isLoading={metricsLoading}
            />
            
            <MetricsCard
              title="Queue Status"
              value={metrics?.queueSize?.toLocaleString() || "0"}
              change="Documents pending"
              changeType="neutral"
              icon="clock"
              isLoading={metricsLoading}
            />
          </div>

          {/* BFSI-Specific Dashboard Tabs */}
          <Tabs defaultValue="bfsi" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="bfsi" className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                BFSI Analytics
                <Badge variant="outline" className="ml-1">Live</Badge>
              </TabsTrigger>
              <TabsTrigger value="operations" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Operations
              </TabsTrigger>
              <TabsTrigger value="compliance" className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Compliance
              </TabsTrigger>
              <TabsTrigger value="activity" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Activity
              </TabsTrigger>
            </TabsList>

            {/* BFSI Analytics Tab */}
            <TabsContent value="bfsi" className="mt-6">
              <BfsiMetrics metrics={{
                totalDocuments: metrics?.totalProcessed || 0,
                documentsToday: metrics?.todaysProcessed || 0,
                processingQueue: metrics?.queueSize || 0,
                completedToday: metrics?.completedToday || 0,
                loanApplications: 1247,
                kycDocuments: 856,
                complianceReports: 89,
                fraudAlerts: 3,
                complianceScore: 94,
                auditFindings: 8,
                regulatoryReports: 23,
                averageProcessingTime: 2.3,
                accuracyRate: metrics?.accuracy || 94.7,
                slaCompliance: 98.2,
                highRiskDocuments: 12,
                piiDetections: 45,
                securityIncidents: 1
              }} />
            </TabsContent>

            {/* Operations Tab */}
            <TabsContent value="operations" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <ProcessingQueue 
                    jobs={activeJobs}
                    isLoading={jobsLoading}
                  />
                </div>
                
                <ClassificationBreakdown 
                  breakdown={metrics?.classificationBreakdown || []}
                  isLoading={metricsLoading}
                />
              </div>
            </TabsContent>

            {/* Compliance Tab */}
            <TabsContent value="compliance" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <ComplianceStatus />
                <div className="space-y-6">
                  <ClassificationBreakdown 
                    breakdown={metrics?.classificationBreakdown || []}
                    isLoading={metricsLoading}
                  />
                </div>
              </div>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <RecentActivity />
                <ProcessingQueue 
                  jobs={activeJobs}
                  isLoading={jobsLoading}
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
