import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/sidebar';
import { TopBar } from '@/components/layout/topbar';
import { HRDocumentProcessingModal } from '@/components/source-config/hr-document-processing-modal';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { HRProcessingResponse } from '@/lib/types';
import { 
  Users, 
  Play, 
  Clock, 
  CheckCircle,
  FileText,
  Activity,
  AlertCircle,
  RefreshCw
} from 'lucide-react';

export default function HRProcessingPage() {
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Mock active jobs data - in real app this would come from API
  const mockActiveJobs = [
    {
      id: 'hr-proc-20241221-001',
      name: 'HR Department Q4 Processing',
      status: 'RUNNING',
      progress: 67,
      documentsProcessed: 234,
      documentsTotal: 492,
      estimatedCompletion: '47 minutes',
      startedAt: '2024-12-21T10:30:00Z'
    },
    {
      id: 'hr-proc-20241220-002',
      name: 'Employee Contracts Review',
      status: 'COMPLETED',
      progress: 100,
      documentsProcessed: 45,
      documentsTotal: 45,
      estimatedCompletion: 'Completed',
      startedAt: '2024-12-20T14:15:00Z'
    }
  ];

  const handleStartHRProcessing = async (processingData: any) => {
    setIsLoading(true);
    try {
      // This would call the FastAPI endpoint to start HR document processing
      const response = await apiRequest('POST', '/api/v1/processing/start', processingData) as unknown as HRProcessingResponse;
      
      toast({
        title: "HR Processing Started",
        description: `Processing job "${processingData.name}" has been initiated. Job ID: ${response.job_id}`,
      });
      
      setIsModalOpen(false);
      // Optionally refresh the active jobs list here
      
    } catch (error: any) {
      toast({
        title: "Error",
        description: `Failed to start HR document processing: ${error.message}`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'RUNNING': return 'blue';
      case 'COMPLETED': return 'green';
      case 'FAILED': return 'red';
      case 'PENDING': return 'yellow';
      default: return 'gray';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'RUNNING': return <Activity className="w-4 h-4" />;
      case 'COMPLETED': return <CheckCircle className="w-4 h-4" />;
      case 'FAILED': return <AlertCircle className="w-4 h-4" />;
      case 'PENDING': return <Clock className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-foreground">HR Document Processing</h2>
              <p className="text-muted-foreground">Start new processing jobs and monitor active workflows</p>
            </div>
            
            <Button 
              onClick={() => setIsModalOpen(true)}
              size="lg"
              className="flex items-center space-x-2 bg-green-600 hover:bg-green-700"
            >
              <Play className="w-5 h-5" />
              <span>Start New HR Processing</span>
            </Button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Jobs</p>
                    <p className="text-2xl font-bold">1</p>
                  </div>
                  <Activity className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Completed Today</p>
                    <p className="text-2xl font-bold">1</p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Documents Processed</p>
                    <p className="text-2xl font-bold">279</p>
                  </div>
                  <FileText className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Processing Time</p>
                    <p className="text-2xl font-bold">2h 18m</p>
                  </div>
                  <Clock className="w-8 h-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Active Processing Jobs */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Active HR Processing Jobs
              </CardTitle>
              <Button variant="outline" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockActiveJobs.map((job) => (
                  <div key={job.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg bg-${getStatusColor(job.status)}-100`}>
                          {getStatusIcon(job.status)}
                        </div>
                        <div>
                          <h3 className="font-medium">{job.name}</h3>
                          <p className="text-sm text-muted-foreground">Job ID: {job.id}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge 
                          variant="outline" 
                          className={`text-${getStatusColor(job.status)}-600 border-${getStatusColor(job.status)}-300`}
                        >
                          {job.status}
                        </Badge>
                        {job.status === 'RUNNING' && (
                          <span className="text-sm text-muted-foreground">
                            ETA: {job.estimatedCompletion}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {job.status === 'RUNNING' && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress: {job.documentsProcessed}/{job.documentsTotal} documents</span>
                          <span>{job.progress}%</span>
                        </div>
                        <Progress value={job.progress} className="h-2" />
                      </div>
                    )}
                    
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Started: {new Date(job.startedAt).toLocaleString()}</span>
                      <span>Documents: {job.documentsProcessed}/{job.documentsTotal}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Processing Templates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                HR Processing Templates
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Quick start templates for common HR document processing workflows
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  {
                    name: 'Employee Onboarding',
                    description: 'Process new employee contracts, forms, and documentation',
                    documentTypes: ['Contracts', 'Forms', 'ID Documents'],
                    estimatedDocs: 25
                  },
                  {
                    name: 'Quarterly Review',
                    description: 'Process performance reviews and evaluation documents',
                    documentTypes: ['Reviews', 'Evaluations', 'Goals'],
                    estimatedDocs: 150
                  },
                  {
                    name: 'Policy Update',
                    description: 'Process updated company policies and procedures',
                    documentTypes: ['Policies', 'Procedures', 'Guidelines'],
                    estimatedDocs: 45
                  },
                  {
                    name: 'Payroll Processing',
                    description: 'Process payroll records and salary documentation',
                    documentTypes: ['Payroll', 'Timesheets', 'Benefits'],
                    estimatedDocs: 200
                  },
                  {
                    name: 'Training Materials',
                    description: 'Process training content and certification documents',
                    documentTypes: ['Training', 'Certifications', 'Courses'],
                    estimatedDocs: 80
                  },
                  {
                    name: 'Custom Workflow',
                    description: 'Create a custom processing workflow for specific needs',
                    documentTypes: ['Custom'],
                    estimatedDocs: 0
                  }
                ].map((template) => (
                  <Card key={template.name} className="cursor-pointer hover:border-primary transition-colors">
                    <CardContent className="p-4">
                      <h3 className="font-medium mb-2">{template.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
                      <div className="space-y-2">
                        <div className="flex flex-wrap gap-1">
                          {template.documentTypes.map((type) => (
                            <Badge key={type} variant="secondary" className="text-xs">
                              {type}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">
                            ~{template.estimatedDocs} docs
                          </span>
                          <Button size="sm" variant="outline">
                            Use Template
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* HR Document Processing Modal */}
      <HRDocumentProcessingModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleStartHRProcessing}
        isLoading={isLoading}
      />
    </div>
  );
}
