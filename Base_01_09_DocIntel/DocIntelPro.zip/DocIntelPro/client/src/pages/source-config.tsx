import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Sidebar } from '@/components/layout/sidebar';
import { TopBar } from '@/components/layout/topbar';
import { SourceConfigModal } from '@/components/source-config/source-config-modal';
import { BfsiSourceConfigModal } from '@/components/source-config/bfsi-source-config-modal';
import { HRDocumentProcessingModal } from '@/components/source-config/hr-document-processing-modal';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { DocumentSource, DocumentDestination, HRProcessingResponse } from '@/lib/types';
import { 
  HardDrive, 
  Share2, 
  Database, 
  Cloud, 
  Plus, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  Filter,
  Search,
  TestTube,
  Edit,
  Trash2,
  Upload,
  Download,
  Building2,
  Server,
  Users,
  FileText
} from 'lucide-react';

const SOURCE_TYPE_ICONS = {
  network_folder: HardDrive,
  sharepoint: Share2,
  database: Database,
  cloud_storage: Cloud,
  ftp: HardDrive,
  hr_documents: Users,
  bfsi_documents: Building2,
  generic_source: FileText,
} as const;

const SOURCE_TYPE_LABELS = {
  network_folder: 'Network Folder',
  sharepoint: 'SharePoint',
  database: 'Database',
  cloud_storage: 'Cloud Storage',
  ftp: 'FTP/SFTP',
  hr_documents: 'HR Documents',
  bfsi_documents: 'BFSI Documents',
  generic_source: 'Generic Source',
} as const;

const getStatusBadgeColor = (status: string) => {
  switch (status) {
    case 'success': return 'bg-green-500';
    case 'error': return 'bg-red-500';
    case 'not_tested': return 'bg-gray-400';
    default: return 'bg-gray-400';
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case 'success': return 'Passed';
    case 'error': return 'Failed';
    case 'not_tested': return 'Not tested';
    default: return 'Unknown';
  }
};

export default function SourceConfig() {
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBfsiModalOpen, setIsBfsiModalOpen] = useState(false);
  const [isHRProcessingModalOpen, setIsHRProcessingModalOpen] = useState(false);
  const [selectedSource, setSelectedSource] = useState<DocumentSource | null>(null);
  const [activeTab, setActiveTab] = useState('sources');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');

  // Organization ID - in real app this would come from auth context
  const organizationId = 'f5a5744d-f922-4918-b5ae-0d9a430b9b0b';

  // Helper function to get description from connectionConfig
  const getSourceDescription = (source: DocumentSource): string => {
    if (source.connectionConfig && 
        typeof source.connectionConfig === 'object' && 
        'description' in source.connectionConfig && 
        typeof source.connectionConfig.description === 'string') {
      return source.connectionConfig.description;
    }
    return '-';
  };

  // Fetch document sources
  const { data: sources = [], isLoading: sourcesLoading } = useQuery<DocumentSource[]>({
    queryKey: ['/api/sources'],
  });

  // Fetch document destinations
  const { data: destinations = [], isLoading: destinationsLoading } = useQuery<DocumentDestination[]>({
    queryKey: ['/api/destinations'],
  });

  // Create source mutation
  const createSourceMutation = useMutation({
    mutationFn: (sourceData: Omit<DocumentSource, 'id' | 'organizationId' | 'createdAt' | 'updatedAt' | 'lastSyncAt'>) =>
      apiRequest('POST', '/api/sources', sourceData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sources'] });
      setIsModalOpen(false);
      setSelectedSource(null);
      toast({
        title: "Source Created",
        description: "Document source has been successfully configured.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create source: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleCreateSource = (sourceData: any) => {
    createSourceMutation.mutate(sourceData);
  };

  const handleCreateHRSource = async (hrData: any) => {
    // Convert HR processing configuration to a data source format
    const sourceData = {
      name: hrData.name,
      type: 'hr_documents' as const,
      connectionConfig: {
        sourceType: hrData.sourceType,
        sourcePath: hrData.sourcePath,
        credentials: hrData.sourceCredentials,
        documentTypes: hrData.documentTypes,
        processingRules: hrData.processingRules,
        outputDestinations: hrData.outputDestinations,
        provider: 'HR System',
        description: hrData.description || `HR Document Source - ${hrData.sourceType}`,
      },
      authenticationConfig: {},
      scanSchedule: 'manual',
      lastScan: null,
      status: 'active',
      errorMessage: null,
      isActive: true,
      domain: 'hr',
      documentTypes: hrData.documentTypes || [],
      complianceLevel: 'internal'
    };

    return new Promise<void>((resolve, reject) => {
      createSourceMutation.mutate(sourceData, {
        onSuccess: () => {
          setIsHRProcessingModalOpen(false);
          resolve();
        },
        onError: (error) => {
          reject(error);
        }
      });
    });
  };

  const handleCreateBFSISource = (bfsiData: any) => {
    // Convert BFSI configuration to a data source format
    const sourceData = {
      name: bfsiData.name,
      type: 'bfsi_documents' as const,
      connectionConfig: {
        sourceType: bfsiData.type,
        complianceLevel: bfsiData.complianceLevel,
        documentTypes: bfsiData.documentTypes,
        processingRules: bfsiData.processingRules,
        provider: 'BFSI System',
        description: bfsiData.description || `BFSI Document Source - ${bfsiData.type}`,
        ...bfsiData.connectionConfig
      },
      authenticationConfig: {},
      scanSchedule: 'manual',
      lastScan: null,
      status: 'active',
      errorMessage: null,
      isActive: true,
      domain: 'bfsi',
      documentTypes: bfsiData.documentTypes || [],
      complianceLevel: bfsiData.complianceLevel || 'internal'
    };

    createSourceMutation.mutate(sourceData, {
      onSuccess: () => {
        setIsBfsiModalOpen(false);
        setSelectedSource(null);
      }
    });
  };

  const handleCreateGenericSource = (genericData: any) => {
    // Convert generic configuration to a data source format
    const sourceData = {
      name: genericData.name,
      type: 'generic_source' as const,
      connectionConfig: {
        ...genericData.connectionConfig,
        sourceType: genericData.type,
        processingRules: genericData.processingRules || {},
        provider: genericData.provider || 'Generic System',
        description: genericData.description || `Generic Document Source - ${genericData.type}`,
      },
      authenticationConfig: {},
      scanSchedule: 'manual',
      lastScan: null,
      status: 'active',
      errorMessage: null,
      isActive: true,
      domain: 'general',
      documentTypes: [],
      complianceLevel: 'internal'
    };

    createSourceMutation.mutate(sourceData, {
      onSuccess: () => {
        setIsModalOpen(false);
        setSelectedSource(null);
      }
    });
  };

  const handleEditSource = (source: DocumentSource) => {
    setSelectedSource(source);
    
    // Determine which modal to open based on source type
    switch (source.type) {
      case 'hr_documents':
        setIsHRProcessingModalOpen(true);
        break;
      case 'bfsi_documents':
        setIsBfsiModalOpen(true);
        break;
      case 'generic_source':
      default:
        setIsModalOpen(true);
        break;
    }
  };

  const handleTestConnection = async (id: string, type: 'source' | 'destination') => {
    try {
      await apiRequest('POST', `/api/${type === 'source' ? 'sources' : 'destinations'}/${id}/test`);
      queryClient.invalidateQueries({ queryKey: [`/api/${type === 'source' ? 'sources' : 'destinations'}`] });
      toast({
        title: "Test Successful",
        description: "Connection test completed successfully.",
      });
    } catch (error: any) {
      toast({
        title: "Test Failed",
        description: `Connection test failed: ${error.message || 'Unknown error'}`,
        variant: "destructive",
      });
    }
  };

  const filteredSources = sources.filter(source => {
    const description = source.connectionConfig && 
                       typeof source.connectionConfig === 'object' && 
                       'description' in source.connectionConfig && 
                       typeof source.connectionConfig.description === 'string' 
                       ? source.connectionConfig.description : '';
    
    const matchesSearch = source.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (description && description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = filterType === 'all' || source.type === filterType;
    return matchesSearch && matchesType;
  });

  const filteredDestinations = destinations.filter(dest => {
    const matchesSearch = dest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (dest.description && dest.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = filterType === 'all' || dest.type === filterType;
    return matchesSearch && matchesType;
  });

  const getSourceStats = (type: string) => {
    const sourcesOfType = sources.filter((s: DocumentSource) => s.type === type);
    return {
      total: sourcesOfType.length,
      active: sourcesOfType.filter((s: DocumentSource) => s.isActive).length,
    };
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-foreground">Configuration Management</h2>
              <p className="text-muted-foreground">Configure data sources, destinations, document types, and processing rules</p>
            </div>
          </div>

          {/* Configuration Management Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Configuration Management
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure data sources, destinations, document types, and processing rules
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* HR Document Source Button */}
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-green-200 hover:border-green-500 hover:bg-green-100 hover:text-green-800 dark:border-green-700 dark:hover:border-green-400 dark:hover:bg-green-900 dark:hover:text-green-100 transition-all duration-200"
                  onClick={() => setIsHRProcessingModalOpen(true)}
                >
                  <Users className="h-6 w-6 text-green-600 group-hover:text-green-700 dark:group-hover:text-green-300" />
                  <span className="font-medium">Add HR Document Source</span>
                </Button>

                {/* BFSI Document Classification Button */}
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-blue-200 hover:border-blue-500 hover:bg-blue-100 hover:text-blue-800 dark:border-blue-700 dark:hover:border-blue-400 dark:hover:bg-blue-900 dark:hover:text-blue-100 transition-all duration-200"
                  onClick={() => setIsBfsiModalOpen(true)}
                >
                  <Building2 className="h-6 w-6 text-blue-600 group-hover:text-blue-700 dark:group-hover:text-blue-300" />
                  <span className="font-medium">Add BFSI Document Source</span>
                </Button>

                {/* Generic Source Button */}
                <Button
                  variant="outline"
                  className="h-20 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-gray-200 hover:border-gray-500 hover:bg-gray-100 hover:text-gray-800 dark:border-gray-700 dark:hover:border-gray-400 dark:hover:bg-gray-900 dark:hover:text-gray-100 transition-all duration-200"
                  onClick={() => setIsModalOpen(true)}
                >
                  <Plus className="h-6 w-6 text-gray-600 group-hover:text-gray-700 dark:group-hover:text-gray-300" />
                  <span className="font-medium">Add Generic Source</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Configured Data Sources */}
          <Card>
            <CardHeader>
              <CardTitle>Configured Data Sources</CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage all configured data sources. Use the buttons above to add new HR, BFSI, or generic data sources.
              </p>
            </CardHeader>
            <CardContent>
              {/* Filter and search controls */}
              <div className="flex items-center justify-between py-4">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    <Input
                      placeholder="Filter data sources..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <select 
                    value={filterType} 
                    onChange={(e) => setFilterType(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">All Types</option>
                    <option value="hr_documents">HR Documents</option>
                    <option value="bfsi_documents">BFSI Documents</option>
                    <option value="generic_source">Generic Source</option>
                    <option value="network_folder">Network Folder</option>
                    <option value="sharepoint">SharePoint</option>
                    <option value="database">Database</option>
                    <option value="cloud_storage">Cloud Storage</option>
                    <option value="ftp">FTP/SFTP</option>
                  </select>
                </div>
              </div>

              {/* Data Sources Table */}
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Tested</TableHead>
                      <TableHead>Test Result</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sourcesLoading ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          Loading data sources...
                        </TableCell>
                      </TableRow>
                    ) : filteredSources.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          <div className="flex flex-col items-center justify-center space-y-3">
                            <Database className="h-12 w-12 text-muted-foreground" />
                            <div className="text-center">
                              <p className="text-lg font-medium text-muted-foreground">No sources configured</p>
                              <p className="text-sm text-muted-foreground">Get started by adding your first data source using the buttons above</p>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredSources.map((source) => {
                        const Icon = SOURCE_TYPE_ICONS[source.type as keyof typeof SOURCE_TYPE_ICONS] || FileText;
                        const typeLabel = SOURCE_TYPE_LABELS[source.type as keyof typeof SOURCE_TYPE_LABELS] || source.type;
                        
                        return (
                          <TableRow key={source.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Icon className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{source.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">{typeLabel}</Badge>
                            </TableCell>
                            <TableCell className="max-w-xs truncate">
                              {getSourceDescription(source)}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${source.isActive ? 'bg-green-500' : 'bg-gray-400'}`} />
                                <span className="text-sm">{source.isActive ? 'Active' : 'Inactive'}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              Never
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="text-xs">
                                Not tested
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="hover:bg-blue-100 hover:text-blue-700 dark:hover:bg-blue-900 dark:hover:text-blue-300 transition-colors duration-200"
                                  onClick={() => handleEditSource(source)}
                                  title="Edit source"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="hover:bg-green-100 hover:text-green-700 dark:hover:bg-green-900 dark:hover:text-green-300 transition-colors duration-200"
                                  onClick={() => handleTestConnection(source.id, 'source')}
                                  title="Test connection"
                                >
                                  <TestTube className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-fit grid-cols-2">
              <TabsTrigger value="sources" className="flex items-center space-x-2">
                <Upload className="w-4 h-4" />
                <span>Sources</span>
              </TabsTrigger>
              <TabsTrigger value="destinations" className="flex items-center space-x-2">
                <Download className="w-4 h-4" />
                <span>Destinations</span>
              </TabsTrigger>
            </TabsList>

            {/* Filters and Search */}
            <div className="flex items-center justify-between py-4">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Filter data sources..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
                <select 
                  value={filterType} 
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-3 py-2 border rounded-md bg-background"
                >
                  <option value="all">All Types</option>
                  <option value="network_folder">Network Folder</option>
                  <option value="sharepoint">SharePoint</option>
                  <option value="database">Database</option>
                  <option value="cloud_storage">Cloud Storage</option>
                  <option value="ftp">FTP/SFTP</option>
                </select>
              </div>
            </div>

            <TabsContent value="sources" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Data Sources</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Last Tested</TableHead>
                          <TableHead>Test Result</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {sourcesLoading ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8">
                              Loading sources...
                            </TableCell>
                          </TableRow>
                        ) : filteredSources.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8">
                              <div className="flex flex-col items-center space-y-4">
                                <Database className="w-12 h-12 text-muted-foreground" />
                                <div className="text-center">
                                  <h3 className="text-lg font-medium">No sources found</h3>
                                  <p className="text-muted-foreground">
                                    {searchTerm || filterType !== 'all' 
                                      ? 'Try adjusting your filters' 
                                      : 'Get started by adding your first data source'
                                    }
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredSources.map((source) => {
                            const Icon = SOURCE_TYPE_ICONS[source.type as keyof typeof SOURCE_TYPE_ICONS];
                            const label = SOURCE_TYPE_LABELS[source.type as keyof typeof SOURCE_TYPE_LABELS];
                            
                            return (
                              <TableRow key={source.id}>
                                <TableCell className="font-medium">
                                  <div className="flex items-center space-x-3">
                                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                                      <Icon className="w-4 h-4 text-primary" />
                                    </div>
                                    <span>{source.name}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline">{label}</Badge>
                                </TableCell>
                                <TableCell className="max-w-xs truncate">
                                  {getSourceDescription(source)}
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <Switch checked={source.isActive ?? false} disabled />
                                    <span className="text-sm">
                                      {source.isActive ? 'Active' : 'Inactive'}
                                    </span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">
                                  Never
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <div className={`w-2 h-2 rounded-full ${getStatusBadgeColor('not_tested')}`} />
                                    <span className="text-sm">{getStatusLabel('not_tested')}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="hover:bg-green-100 hover:text-green-700 dark:hover:bg-green-900 dark:hover:text-green-300 transition-colors duration-200"
                                      onClick={() => handleTestConnection(source.id, 'source')}
                                      title="Test connection"
                                    >
                                      <TestTube className="w-4 h-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="hover:bg-blue-100 hover:text-blue-700 dark:hover:bg-blue-900 dark:hover:text-blue-300 transition-colors duration-200"
                                      onClick={() => handleEditSource(source)}
                                      title="Edit source"
                                    >
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="destinations" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Data Destinations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Last Tested</TableHead>
                          <TableHead>Test Result</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {destinationsLoading ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8">
                              Loading destinations...
                            </TableCell>
                          </TableRow>
                        ) : filteredDestinations.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={7} className="text-center py-8">
                              <div className="flex flex-col items-center space-y-4">
                                <Download className="w-12 h-12 text-muted-foreground" />
                                <div className="text-center">
                                  <h3 className="text-lg font-medium">No destinations found</h3>
                                  <p className="text-muted-foreground">
                                    {searchTerm || filterType !== 'all' 
                                      ? 'Try adjusting your filters' 
                                      : 'Configure destinations for processed documents'
                                    }
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredDestinations.map((destination) => {
                            const Icon = SOURCE_TYPE_ICONS[destination.type as keyof typeof SOURCE_TYPE_ICONS] || Database;
                            
                            return (
                              <TableRow key={destination.id}>
                                <TableCell className="font-medium">
                                  <div className="flex items-center space-x-3">
                                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                                      <Icon className="w-4 h-4 text-primary" />
                                    </div>
                                    <span>{destination.name}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Badge variant="outline">{destination.type}</Badge>
                                </TableCell>
                                <TableCell className="max-w-xs truncate">
                                  {destination.description || '-'}
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <Switch checked={destination.isActive} disabled />
                                    <span className="text-sm">
                                      {destination.isActive ? 'Active' : 'Inactive'}
                                    </span>
                                  </div>
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">
                                  {destination.lastTestAt 
                                    ? new Date(destination.lastTestAt).toLocaleDateString()
                                    : 'Never'
                                  }
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <div className={`w-2 h-2 rounded-full ${getStatusBadgeColor(destination.testResult || 'not_tested')}`} />
                                    <span className="text-sm">{getStatusLabel(destination.testResult || 'not_tested')}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleTestConnection(destination.id, 'destination')}
                                    >
                                      <TestTube className="w-4 h-4" />
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                    >
                                      <Edit className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Source Configuration Modal */}
      <SourceConfigModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedSource(null);
        }}
        onSave={handleCreateGenericSource}
        source={selectedSource}
        isLoading={createSourceMutation.isPending}
      />

      {/* BFSI Source Configuration Modal */}
      <BfsiSourceConfigModal
        isOpen={isBfsiModalOpen}
        onClose={() => {
          setIsBfsiModalOpen(false);
          setSelectedSource(null);
        }}
        onSubmit={handleCreateBFSISource}
        source={selectedSource}
        mode={selectedSource ? 'edit' : 'create'}
      />

      {/* HR Document Processing Modal */}
      <HRDocumentProcessingModal
        isOpen={isHRProcessingModalOpen}
        onClose={() => {
          setIsHRProcessingModalOpen(false);
          setSelectedSource(null);
        }}
        onSubmit={handleCreateHRSource}
        isLoading={createSourceMutation.isPending}
        source={selectedSource}
        mode={selectedSource ? 'edit' : 'create'}
      />
    </div>
  );
}
