#!/usr/bin/env node
/**
 * Quick Port Checker for DocIntelPro
 * Checks port availability and suggests alternatives
 */

import { isPortAvailable, findAvailablePort } from './server/port-utils.js';

async function checkPorts() {
  const defaultPorts = {
    'Node.js Server': 5000,
    'FastAPI Gateway': 8000,
    'Airflow Web UI': 8083,
    'Redis': 6379,
    'PostgreSQL': 5432
  };

  console.log('🔍 DocIntelPro Port Availability Check');
  console.log('=' .repeat(50));

  for (const [service, port] of Object.entries(defaultPorts)) {
    const available = await isPortAvailable(port);
    const status = available ? '✅ Available' : '❌ In Use';
    
    console.log(`${service.padEnd(20)} : ${port.toString().padEnd(5)} ${status}`);
    
    if (!available && ['Node.js Server', 'FastAPI Gateway', 'Airflow Web UI'].includes(service)) {
      try {
        const alternativePort = await findAvailablePort(port + 1);
        console.log(`${' '.repeat(20)}   → Alternative: ${alternativePort}`);
      } catch (error) {
        console.log(`${' '.repeat(20)}   → No alternatives found nearby`);
      }
    }
  }

  console.log('=' .repeat(50));
  console.log('💡 Use npm run dev for automatic port allocation');
  console.log('🚀 Use npm run dev:dynamic to start all services');
}

checkPorts().catch(console.error);
