const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
const port = 3001;

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json());

// Database connection using environment variables
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'RND',
  user: 'postgres',
  password: 'root',
});

// Test database connection
async function testConnection() {
  try {
    const client = await pool.connect();
    console.log('✅ Database connected successfully');
    const result = await client.query('SELECT version()');
    console.log('📊 Database version:', result.rows[0].version);
    client.release();
    return true;
  } catch (err) {
    console.error('❌ Database connection failed:', err.message);
    return false;
  }
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'DocIntelPro Test Server'
  });
});

// Database test endpoint
app.get('/test-db', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW() as current_time');
    client.release();
    res.json({ 
      status: 'success', 
      message: 'Database connection successful',
      current_time: result.rows[0].current_time
    });
  } catch (err) {
    res.status(500).json({ 
      status: 'error', 
      message: 'Database connection failed',
      error: err.message 
    });
  }
});

// Test BFSI document types
app.get('/bfsi-document-types', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT * FROM bfsi_document_types ORDER BY name');
    client.release();
    res.json({ 
      status: 'success',
      count: result.rows.length,
      document_types: result.rows
    });
  } catch (err) {
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch BFSI document types',
      error: err.message 
    });
  }
});

// Test organizations
app.get('/organizations', async (req, res) => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT id, name, industry_type, created_at FROM organizations LIMIT 10');
    client.release();
    res.json({ 
      status: 'success',
      count: result.rows.length,
      organizations: result.rows
    });
  } catch (err) {
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch organizations',
      error: err.message 
    });
  }
});

// Test dashboard metrics
app.get('/dashboard-metrics', async (req, res) => {
  try {
    const client = await pool.connect();
    
    // Get basic counts
    const docCountResult = await client.query('SELECT COUNT(*) as count FROM documents');
    const orgCountResult = await client.query('SELECT COUNT(*) as count FROM organizations');
    const userCountResult = await client.query('SELECT COUNT(*) as count FROM users');
    
    client.release();
    
    res.json({ 
      status: 'success',
      metrics: {
        total_documents: parseInt(docCountResult.rows[0].count),
        total_organizations: parseInt(orgCountResult.rows[0].count),
        total_users: parseInt(userCountResult.rows[0].count),
        generated_at: new Date().toISOString()
      }
    });
  } catch (err) {
    res.status(500).json({ 
      status: 'error', 
      message: 'Failed to fetch dashboard metrics',
      error: err.message 
    });
  }
});

// Start server
async function startServer() {
  // Test database connection first
  const dbConnected = await testConnection();
  
  if (!dbConnected) {
    console.error('❌ Failed to connect to database. Please check your PostgreSQL connection.');
    process.exit(1);
  }
  
  app.listen(port, () => {
    console.log(`\n🚀 DocIntelPro Test Server running on http://localhost:${port}`);
    console.log('📋 Available endpoints:');
    console.log(`   • GET  /health                 - Health check`);
    console.log(`   • GET  /test-db                - Database connection test`);
    console.log(`   • GET  /bfsi-document-types    - BFSI document types`);
    console.log(`   • GET  /organizations          - Organizations list`);
    console.log(`   • GET  /dashboard-metrics      - Dashboard metrics`);
    console.log('\n✅ Ready to test API endpoints!');
  });
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down server...');
  await pool.end();
  process.exit(0);
});

// Start the server
startServer().catch(console.error);
