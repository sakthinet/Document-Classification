import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, uuid, decimal, bigint, date, inet } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Organizations (Multi-tenant)
export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  domain: varchar("domain", { length: 100 }).notNull().default("bfsi"),
  industry: varchar("industry", { length: 100 }).default("financial_services"),
  country: varchar("country", { length: 10 }).default("US"),
  settings: jsonb("settings").default({}),
  subscriptionPlan: varchar("subscription_plan", { length: 50 }).default("basic"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Users
export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  username: varchar("username", { length: 100 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  role: varchar("role", { length: 50 }).default("user"),
  permissions: jsonb("permissions").default([]),
  lastLogin: timestamp("last_login"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Document Sources
export const documentSources = pgTable("document_sources", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(), // Supports: network_folder, sharepoint, database, ftp, cloud_storage, hr_documents, bfsi_documents, generic_source
  connectionConfig: jsonb("connection_config").notNull().default({}),
  authenticationConfig: jsonb("authentication_config").default({}),
  scanSchedule: varchar("scan_schedule", { length: 100 }).default("manual"),
  lastScan: timestamp("last_scan"),
  status: varchar("status", { length: 50 }).default("active"),
  errorMessage: text("error_message"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  domain: varchar("domain", { length: 50 }).default("bfsi"), // Supports: hr, bfsi, general
  documentTypes: jsonb("document_types").default([]),
  complianceLevel: varchar("compliance_level", { length: 20 }).default("internal"),
});

// BFSI Document Types
export const bfsiDocumentTypes = pgTable("bfsi_document_types", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  typeKey: varchar("type_key", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 200 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  classification: varchar("classification", { length: 20 }).notNull().default("internal"),
  description: text("description"),
  requiredFields: jsonb("required_fields").default([]),
  piiFields: jsonb("pii_fields").default([]),
  retentionPeriod: varchar("retention_period", { length: 50 }).default("7_years"),
  complianceFlags: jsonb("compliance_flags").default([]),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Documents
export const documents = pgTable("documents", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  sourceId: uuid("source_id").references(() => documentSources.id, { onDelete: "set null" }),
  fileName: varchar("file_name", { length: 500 }).notNull(),
  filePath: text("file_path").notNull(),
  fileSize: bigint("file_size", { mode: "number" }),
  fileType: varchar("file_type", { length: 50 }),
  mimeType: varchar("mime_type", { length: 100 }),
  fileHash: varchar("file_hash", { length: 128 }),
  originalText: text("original_text"),
  processedText: text("processed_text"),
  classificationStatus: varchar("classification_status", { length: 50 }).default("pending"),
  classificationConfidence: decimal("classification_confidence", { precision: 5, scale: 4 }),
  classificationLevel: varchar("classification_level", { length: 50 }),
  containsPii: boolean("contains_pii").default(false),
  piiEntities: jsonb("pii_entities").default([]),
  extractionStatus: varchar("extraction_status", { length: 50 }).default("pending"),
  processingStartTime: timestamp("processing_start_time"),
  processedAt: timestamp("processed_at"),
  errorMessage: text("error_message"),
  metadata: jsonb("metadata").default({}),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  documentTypeKey: varchar("document_type_key", { length: 100 }).references(() => bfsiDocumentTypes.typeKey),
  complianceStatus: varchar("compliance_status", { length: 50 }).default("pending"),
  complianceScore: decimal("compliance_score", { precision: 5, scale: 2 }),
  riskScore: decimal("risk_score", { precision: 5, scale: 2 }),
  retentionDate: date("retention_date"),
  regulatoryFlags: jsonb("regulatory_flags").default([]),
});

// Processing Jobs
export const processingJobs = pgTable("processing_jobs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  documentId: uuid("document_id").references(() => documents.id, { onDelete: "cascade" }),
  sourceId: uuid("source_id").references(() => documentSources.id, { onDelete: "set null" }),
  jobType: varchar("job_type", { length: 50 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending"),
  priority: integer("priority").default(100),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  progress: decimal("progress", { precision: 5, scale: 2 }).default("0.00"),
  errorMessage: text("error_message"),
  jobConfig: jsonb("job_config").default({}),
  result: jsonb("result").default({}),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit Logs
export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  documentId: uuid("document_id").references(() => documents.id, { onDelete: "set null" }),
  action: varchar("action", { length: 100 }).notNull(),
  resourceType: varchar("resource_type", { length: 50 }).notNull(),
  resourceId: uuid("resource_id"),
  oldValues: jsonb("old_values"),
  newValues: jsonb("new_values"),
  ipAddress: inet("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentSourceSchema = createInsertSchema(documentSources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProcessingJobSchema = createInsertSchema(processingJobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type Organization = typeof organizations.$inferSelect;
export type NewOrganization = typeof organizations.$inferInsert;
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type DocumentSource = typeof documentSources.$inferSelect;
export type NewDocumentSource = typeof documentSources.$inferInsert;
export type Document = typeof documents.$inferSelect;
export type NewDocument = typeof documents.$inferInsert;
export type ProcessingJob = typeof processingJobs.$inferSelect;
export type NewProcessingJob = typeof processingJobs.$inferInsert;
export type AuditLog = typeof auditLogs.$inferSelect;
export type NewAuditLog = typeof auditLogs.$inferInsert;
