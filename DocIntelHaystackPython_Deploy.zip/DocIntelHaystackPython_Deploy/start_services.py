# Microservices Orchestration Script
# Start all services according to the service architecture

import subprocess
import time
import sys
import requests
from pathlib import Path

# Service configuration matching the architecture table
SERVICES = [
    {
        "name": "Python Gateway",
        "port": 8006,
        "path": "backend",
        "command": "python -m uvicorn app.main:app --host 127.0.0.1 --port 8006",
        "status": "Microservices orchestrator"
    },
    {
        "name": "OCR Service", 
        "port": 8001,
        "path": "microservices/ocr_service",
        "command": "python main.py",
        "status": "Document text extraction"
    },
    {
        "name": "Classification Service",
        "port": 8002, 
        "path": "microservices/classification_service",
        "command": "python main.py",
        "status": "BFSI document classification"
    },
    {
        "name": "Vector Search",
        "port": 8003,
        "path": "microservices/vector_search", 
        "command": "python main.py",
        "status": "Semantic search"
    },
    {
        "name": "PII Detection",
        "port": 8004,
        "path": "microservices/pii_detection",
        "command": "python main.py", 
        "status": "Sensitive data detection"
    }
]

def check_service_health(port):
    """Check if service is healthy"""
    try:
        response = requests.get(f"http://localhost:{port}/health", timeout=5)
        return response.status_code == 200
    except:
        return False

def start_service(service):
    """Start a microservice"""
    print(f"🚀 Starting {service['name']} on port {service['port']}...")
    
    # Set working directory
    service_path = Path(__file__).parent / service['path']
    
    # Set environment variables
    env = {"PYTHONPATH": str(Path(__file__).parent / "backend")}
    
    # Start the service
    process = subprocess.Popen(
        service['command'].split(),
        cwd=service_path,
        env={**subprocess.os.environ, **env}
    )
    
    return process

def check_all_services():
    """Check health of all services"""
    print("\n📊 Service Health Check:")
    print("=" * 70)
    print(f"{'Component':<25} {'Port':<8} {'Status':<12} {'Description'}")
    print("=" * 70)
    
    for service in SERVICES:
        is_healthy = check_service_health(service['port'])
        status_icon = "✅" if is_healthy else "❌"
        status_text = "Running" if is_healthy else "Down"
        
        print(f"{service['name']:<25} {service['port']:<8} {status_icon} {status_text:<8} {service['status']}")
    
    print("=" * 70)

if __name__ == "__main__":
    print("🏗️  DocIntel Microservices Orchestrator")
    print("=" * 50)
    
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        check_all_services()
        sys.exit(0)
    
    processes = []
    
    try:
        # Start all services
        for service in SERVICES:
            process = start_service(service)
            processes.append((service, process))
            time.sleep(2)  # Stagger startup
        
        print("\n⏳ Waiting for services to initialize...")
        time.sleep(10)
        
        # Check health
        check_all_services()
        
        print("\n🎯 All services started! Press Ctrl+C to stop all services.")
        print("\nService URLs:")
        for service in SERVICES:
            print(f"  • {service['name']}: http://localhost:{service['port']}")
        
        # Keep running
        while True:
            time.sleep(30)
            # Optionally add periodic health checks here
            
    except KeyboardInterrupt:
        print("\n🛑 Stopping all services...")
        for service, process in processes:
            print(f"   Stopping {service['name']}...")
            process.terminate()
            
        # Wait for processes to clean up
        for service, process in processes:
            process.wait(timeout=5)
            
        print("✅ All services stopped.")
    
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
