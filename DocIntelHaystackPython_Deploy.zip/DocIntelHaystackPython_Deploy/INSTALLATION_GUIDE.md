# 🚀 DocIntel Haystack AI - Installation Guide for New Machine

## 📦 Deployment Package Contents

This deployment package contains the clean codebase without Python environment or node_modules:
- **Size**: ~1.1 MB (ultra-light!)
- **Includes**: All source code, configurations, and project structure
- **Excludes**: Python virtual environment, node_modules, cache files

## 🔧 Prerequisites

### Required Software
1. **Python 3.13+** - Download from [python.org](https://python.org)
2. **Node.js 18+** - Download from [nodejs.org](https://nodejs.org)
3. **Git** (optional) - For version control
4. **PowerShell** (Windows) or Terminal (macOS/Linux)

### System Requirements
- **RAM**: 8GB minimum (16GB recommended for AI workloads)
- **Storage**: 5GB free space for dependencies
- **Internet**: Required for package downloads

## 📋 Installation Steps

### Step 1: Extract and Navigate
```bash
# Extract the deployment package to your desired location
# Navigate to the project directory
cd path/to/DocIntelHaystackPython_Deploy
```

### Step 2: Create Python Virtual Environment
```bash
# Create virtual environment
python -m venv backend/haystack_env

# Activate the environment
# Windows PowerShell:
backend/haystack_env/Scripts/Activate.ps1

# Windows CMD:
backend/haystack_env/Scripts/activate.bat

# macOS/Linux:
source backend/haystack_env/bin/activate
```

### Step 3: Install Python Dependencies
```bash
# Make sure you're in the project root and virtual environment is activated
# Install optimized requirements (CPU-only PyTorch)
pip install -r backend/requirements_optimized.txt --index-url https://download.pytorch.org/whl/cpu --extra-index-url https://pypi.org/simple

# OR install standard requirements (if you need CUDA)
# pip install -r backend/requirements.txt
```

### Step 4: Install Node.js Dependencies
```bash
# Install frontend dependencies
npm install
```

### Step 5: Verify Installation
```bash
# Test Python environment
cd backend/haystack_env/Scripts
./activate
python -c "from haystack import Pipeline; from haystack.components.embedders import SentenceTransformersTextEmbedder; print('✅ Haystack AI installed successfully!')"
cd ../../..

# Test Node.js setup
npm run dev --dry-run
```

## 🚀 Quick Start Commands

### Option 1: Two-Terminal Setup (Recommended)

#### Terminal 1: Backend Services
```bash
# Navigate to project root
cd path/to/DocIntelHaystackPython_Deploy

# Activate Python environment
backend/haystack_env/Scripts/Activate.ps1  # Windows
# source backend/haystack_env/bin/activate   # macOS/Linux

# Start backend services
python start_services.py
```

#### Terminal 2: Frontend Service
```bash
# In the same project root directory
npm run dev
```

### Option 2: Single Command (If Available)
```bash
# If fast_start.py exists
python fast_start.py
```

## 📁 Project Structure After Installation

```
DocIntelHaystackPython_Deploy/
├── backend/
│   ├── haystack_env/           # ← Created during installation
│   ├── app/                    # FastAPI application
│   ├── requirements*.txt       # Python dependencies
│   └── Dockerfile
├── microservices/              # Individual AI services
├── client/                     # React frontend source
├── server/                     # Node.js server
├── airflow/                    # Workflow orchestration
├── shared/                     # Shared configurations
├── node_modules/               # ← Created during npm install
├── package.json                # Node.js dependencies
└── *.md                       # Documentation
```

## ⚡ Expected Installation Sizes

After full installation:
```
node_modules/           ~200-300 MB    # Frontend dependencies
backend/haystack_env/   ~3,400 MB      # Python AI/ML environment
Project files/          ~1.1 MB        # Your source code
Total:                  ~3.6-3.7 GB    # Complete installation
```

## 🔍 Troubleshooting

### Common Issues

1. **Python version mismatch**
   ```bash
   python --version  # Should be 3.13+
   ```

2. **Virtual environment activation fails**
   ```bash
   # Windows: Enable script execution
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

3. **PyTorch installation issues**
   ```bash
   # Use CPU-only version if CUDA issues
   pip install torch --index-url https://download.pytorch.org/whl/cpu
   ```

4. **Node.js permission issues**
   ```bash
   # Clear npm cache
   npm cache clean --force
   ```

5. **Port conflicts**
   - Frontend typically runs on port 3000-8007
   - Backend services use ports 8001-8006
   - Check for conflicts: `netstat -an | findstr :8000`

### Verification Commands

```bash
# Check Python installation
python --version
pip --version

# Check Node.js installation
node --version
npm --version

# Test Haystack import
python -c "import haystack; print('Haystack version:', haystack.__version__)"

# Test React build
npm run build --dry-run
```

## 🎯 Performance Tips

1. **Use SSD storage** for faster package installation
2. **Close unnecessary applications** during installation
3. **Use wired internet** for stable package downloads
4. **Exclude antivirus scanning** of project folder during installation

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section above
2. Verify all prerequisites are installed
3. Ensure stable internet connection for package downloads
4. Review the installation logs for specific error messages

## ✅ Installation Complete!

Once installation is successful, you'll have:
- ✅ Full Haystack AI environment
- ✅ React frontend ready for development
- ✅ All microservices configured
- ✅ Development environment ready

**Total Installation Time**: 15-30 minutes (depending on internet speed)

---

*This deployment package was optimized to be ultra-light (1.1 MB) while maintaining all functionality. The heavy dependencies (AI/ML libraries) are downloaded during installation for the latest versions.*
