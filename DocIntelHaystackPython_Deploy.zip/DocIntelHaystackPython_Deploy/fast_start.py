"""
Fast Service Startup - Optimized for Performance
Starts all microservices quickly with performance optimizations
"""

import subprocess
import time
import sys
import os

def start_service_fast(service_name, port, directory, service_type="python"):
    """Start a service quickly with minimal logging"""
    try:
        # Special handling for Python Gateway (backend)
        if service_name == "Python Gateway":
            cmd = [
                "E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe",
                "-m", "uvicorn", "app.main:app",
                "--host", "127.0.0.1",
                "--port", str(port)
            ]
        else:
            cmd = [
                "E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe",
                "main.py",
                "--port", str(port),
                "--host", "127.0.0.1"
            ]
        
        # Set environment variables for performance
        env = os.environ.copy()
        env.update({
            'OMP_NUM_THREADS': '2',
            'TOKENIZERS_PARALLELISM': 'false',
            'PYTHONPATH': 'E:/Dev_Branch/DataClassification/DocIntelHaystackPython'
        })
        
        process = subprocess.Popen(
            cmd,
            cwd=directory,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )
        
        print(f"[OK] Started {service_name} on port {port} (PID: {process.pid})")
        return process
        
    except Exception as e:
        print(f"[ERROR] Failed to start {service_name}: {e}")
        return None

def main():
    print("Fast Service Startup - Starting All Microservices")
    print("=" * 70)
    
    # Service configurations with optimized ports (NO FRONTEND)
    services = [
        ("Python Gateway", 8006, "backend", "python"),
        ("OCR Service", 8001, "microservices/ocr_service", "python"), 
        ("Classification Service", 8002, "microservices/classification_service", "python"),
        ("Vector Search", 8003, "microservices/vector_search", "python"),
        ("PII Detection", 8004, "microservices/pii_detection", "python"),
        ("Pipeline Config", 8005, "microservices/pipeline_config", "python")
    ]
    
    processes = []
    base_dir = "e:/Dev_Branch/DataClassification/DocIntelHaystackPython"
    
    for service_name, port, rel_dir, service_type in services:
        full_dir = os.path.join(base_dir, rel_dir)
        if os.path.exists(full_dir):
            process = start_service_fast(service_name, port, full_dir, service_type)
            if process:
                processes.append((service_name, process))
            time.sleep(2)  # Slightly longer delay for stability
        else:
            print(f"[WARNING] Directory not found: {full_dir}")
    
    print(f"\n[SUCCESS] Started {len(processes)} services")
    print("[INFO] Waiting 10 seconds for services to initialize...")
    time.sleep(10)
    
    # Test connectivity
    print("\n[TESTING] Service Connectivity:")
    for service_name, port, _, service_type in services:
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            status = "[UP]" if result == 0 else "[DOWN]"
            print(f"  {status} {service_name} (127.0.0.1:{port})")
        except:
            print(f"  🔴 DOWN {service_name} (127.0.0.1:{port})")
    
    print("\n[SERVICES] URLs:")
    for service_name, port, _, service_type in services:
        print(f"  http://127.0.0.1:{port}/health - {service_name}")
    
    print("\n[SUCCESS] All microservices started! Press Ctrl+C to stop everything...")
    print("[BACKEND] Backend services accessible at: http://127.0.0.1:800X/health")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] Stopping all services...")
        for service_name, process in processes:
            try:
                process.terminate()
                print(f"  [OK] Stopped {service_name}")
            except:
                pass

if __name__ == "__main__":
    main()
