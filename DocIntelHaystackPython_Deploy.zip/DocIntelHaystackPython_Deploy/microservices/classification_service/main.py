# Classification Service - BFSI Document Classification
# Port: 8002

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import logging
from typing import Dict, Any, List
from pydantic import BaseModel

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Classification Service",
    description="BFSI document classification service",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request/Response models
class ClassificationRequest(BaseModel):
    text: str
    document_type: str = "unknown"
    metadata: Dict[str, Any] = {}

class ClassificationResult(BaseModel):
    document_type: str
    confidence: float
    categories: List[Dict[str, Any]]
    extracted_entities: List[Dict[str, Any]]
    risk_level: str
    compliance_flags: List[str]

# BFSI Document Categories
BFSI_CATEGORIES = {
    "loan_application": {
        "keywords": ["loan", "application", "credit", "borrower", "income", "collateral"],
        "risk_level": "medium",
        "compliance": ["KYC", "AML"]
    },
    "insurance_policy": {
        "keywords": ["policy", "premium", "coverage", "beneficiary", "claim"],
        "risk_level": "low",
        "compliance": ["GDPR", "HIPAA"]
    },
    "bank_statement": {
        "keywords": ["statement", "balance", "transaction", "deposit", "withdrawal"],
        "risk_level": "high",
        "compliance": ["PCI", "SOX"]
    },
    "kyc_document": {
        "keywords": ["identity", "verification", "passport", "license", "address"],
        "risk_level": "high",
        "compliance": ["KYC", "AML", "CDD"]
    },
    "financial_report": {
        "keywords": ["report", "revenue", "profit", "loss", "balance sheet"],
        "risk_level": "medium",
        "compliance": ["SOX", "GAAP"]
    }
}

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Classification Service",
        "port": 8002,
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Classification Service",
        "status": "BFSI document classification service running",
        "endpoints": ["/health", "/classify", "/categories", "/models"]
    }

@app.post("/classify", response_model=ClassificationResult)
async def classify_document(request: ClassificationRequest) -> ClassificationResult:
    """Classify BFSI document based on content"""
    try:
        logger.info(f"🔍 Classifying document with {len(request.text)} characters")
        
        text_lower = request.text.lower()
        classification_scores = {}
        
        # Simple keyword-based classification (in production, use ML models)
        for category, info in BFSI_CATEGORIES.items():
            score = 0
            keywords_found = []
            
            for keyword in info["keywords"]:
                if keyword in text_lower:
                    score += 1
                    keywords_found.append(keyword)
            
            if score > 0:
                confidence = min(score / len(info["keywords"]), 1.0)
                classification_scores[category] = {
                    "confidence": confidence,
                    "keywords_found": keywords_found,
                    "risk_level": info["risk_level"],
                    "compliance": info["compliance"]
                }
        
        # Determine best classification
        if classification_scores:
            best_category = max(classification_scores.keys(), 
                              key=lambda x: classification_scores[x]["confidence"])
            best_result = classification_scores[best_category]
        else:
            best_category = "unclassified"
            best_result = {
                "confidence": 0.1,
                "keywords_found": [],
                "risk_level": "unknown",
                "compliance": []
            }
        
        # Build categories list
        categories = []
        for cat, result in classification_scores.items():
            categories.append({
                "category": cat,
                "confidence": result["confidence"],
                "keywords_found": result["keywords_found"]
            })
        
        # Extract mock entities (in production, use NER models)
        entities = []
        if "account" in text_lower:
            entities.append({"type": "ACCOUNT_NUMBER", "value": "****1234", "confidence": 0.9})
        if "ssn" in text_lower or "social security" in text_lower:
            entities.append({"type": "SSN", "value": "***-**-****", "confidence": 0.95})
        if "$" in request.text:
            entities.append({"type": "CURRENCY", "value": "USD", "confidence": 0.8})
        
        result = ClassificationResult(
            document_type=best_category,
            confidence=best_result["confidence"],
            categories=categories,
            extracted_entities=entities,
            risk_level=best_result["risk_level"],
            compliance_flags=best_result["compliance"]
        )
        
        logger.info(f"✅ Document classified as: {best_category} (confidence: {best_result['confidence']:.2f})")
        return result
        
    except Exception as e:
        logger.error(f"❌ Classification failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Classification failed: {str(e)}")

@app.get("/categories")
async def get_categories():
    """Get available BFSI document categories"""
    return {
        "categories": list(BFSI_CATEGORIES.keys()),
        "total_categories": len(BFSI_CATEGORIES),
        "category_details": BFSI_CATEGORIES
    }

@app.get("/models")
async def get_model_info():
    """Get information about classification models"""
    return {
        "active_models": [
            {
                "name": "BFSI_keyword_classifier",
                "type": "keyword_based",
                "version": "1.0.0",
                "accuracy": 0.75
            }
        ],
        "supported_languages": ["en"],
        "model_capabilities": [
            "Document type classification",
            "Risk level assessment", 
            "Compliance flag detection",
            "Entity extraction"
        ]
    }

@app.get("/status")
async def get_service_status():
    """Get detailed service status"""
    return {
        "service": "Classification Service",
        "port": 8002,
        "status": "running",
        "capabilities": [
            "BFSI document classification",
            "Risk assessment",
            "Compliance checking",
            "Entity extraction"
        ],
        "categories_supported": len(BFSI_CATEGORIES),
        "performance": {
            "avg_processing_time_ms": 200,
            "throughput_docs_per_sec": 50
        }
    }

if __name__ == "__main__":
    logger.info("🚀 Starting Classification Service on port 8002...")
    uvicorn.run(app, host="127.0.0.1", port=8002)
