# PII Detection Service - Sensitive Data Detection
# Port: 8004

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import logging
import re
from typing import Dict, Any, List
from pydantic import BaseModel
from enum import Enum

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="PII Detection Service",
    description="Sensitive data detection and masking service",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Enums and Models
class PIIType(str, Enum):
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    EMAIL = "email"
    PHONE = "phone"
    ACCOUNT_NUMBER = "account_number"
    ROUTING_NUMBER = "routing_number"
    LICENSE_NUMBER = "license_number"
    PASSPORT = "passport"
    IP_ADDRESS = "ip_address"
    DATE_OF_BIRTH = "date_of_birth"

class SensitivityLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class PIIMatch(BaseModel):
    type: PIIType
    value: str
    masked_value: str
    start_pos: int
    end_pos: int
    confidence: float
    sensitivity: SensitivityLevel

class PIIDetectionRequest(BaseModel):
    text: str
    mask_pii: bool = True
    detection_types: List[PIIType] = []  # Empty list means detect all types

class PIIDetectionResponse(BaseModel):
    original_text: str
    masked_text: str
    pii_found: List[PIIMatch]
    risk_score: float
    compliance_flags: List[str]
    summary: Dict[str, int]

# PII Detection patterns
PII_PATTERNS = {
    PIIType.SSN: {
        "pattern": r'\b\d{3}-?\d{2}-?\d{4}\b',
        "mask": "***-**-****",
        "sensitivity": SensitivityLevel.CRITICAL,
        "compliance": ["GDPR", "CCPA", "SOX"]
    },
    PIIType.CREDIT_CARD: {
        "pattern": r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
        "mask": "****-****-****-****",
        "sensitivity": SensitivityLevel.CRITICAL,
        "compliance": ["PCI-DSS", "GDPR"]
    },
    PIIType.EMAIL: {
        "pattern": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "mask": "****@****.***",
        "sensitivity": SensitivityLevel.MEDIUM,
        "compliance": ["GDPR", "CAN-SPAM"]
    },
    PIIType.PHONE: {
        "pattern": r'\b(?:\+?1[-.\s]?)?(?:\(?[0-9]{3}\)?[-.\s]?)?[0-9]{3}[-.\s]?[0-9]{4}\b',
        "mask": "***-***-****",
        "sensitivity": SensitivityLevel.MEDIUM,
        "compliance": ["TCPA", "GDPR"]
    },
    PIIType.ACCOUNT_NUMBER: {
        "pattern": r'\b(?:account|acct)?\s*#?\s*[0-9]{8,17}\b',
        "mask": "****-****-****",
        "sensitivity": SensitivityLevel.HIGH,
        "compliance": ["SOX", "GLBA"]
    },
    PIIType.ROUTING_NUMBER: {
        "pattern": r'\b[0-9]{9}\b',
        "mask": "*********",
        "sensitivity": SensitivityLevel.HIGH,
        "compliance": ["SOX", "GLBA"]
    },
    PIIType.IP_ADDRESS: {
        "pattern": r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
        "mask": "***.***.***.***",
        "sensitivity": SensitivityLevel.LOW,
        "compliance": ["GDPR"]
    },
    PIIType.DATE_OF_BIRTH: {
        "pattern": r'\b(?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12][0-9]|3[01])[-/](?:19|20)\d{2}\b',
        "mask": "**/**/****",
        "sensitivity": SensitivityLevel.HIGH,
        "compliance": ["HIPAA", "GDPR"]
    }
}

def detect_pii_in_text(text: str, detection_types: List[PIIType] = []) -> List[PIIMatch]:
    """Detect PII in text using regex patterns"""
    matches = []
    
    # If no specific types requested, check all
    types_to_check = detection_types if detection_types else list(PIIType)
    
    for pii_type in types_to_check:
        if pii_type not in PII_PATTERNS:
            continue
            
        pattern_info = PII_PATTERNS[pii_type]
        pattern = pattern_info["pattern"]
        
        for match in re.finditer(pattern, text, re.IGNORECASE):
            # Calculate confidence based on pattern specificity
            confidence = 0.9 if pii_type in [PIIType.SSN, PIIType.CREDIT_CARD] else 0.7
            
            pii_match = PIIMatch(
                type=pii_type,
                value=match.group(),
                masked_value=pattern_info["mask"],
                start_pos=match.start(),
                end_pos=match.end(),
                confidence=confidence,
                sensitivity=pattern_info["sensitivity"]
            )
            matches.append(pii_match)
    
    return matches

def mask_text_with_pii(text: str, pii_matches: List[PIIMatch]) -> str:
    """Mask PII in text with replacement values"""
    masked_text = text
    
    # Sort matches by start position in reverse order to avoid offset issues
    sorted_matches = sorted(pii_matches, key=lambda x: x.start_pos, reverse=True)
    
    for match in sorted_matches:
        masked_text = (
            masked_text[:match.start_pos] + 
            match.masked_value + 
            masked_text[match.end_pos:]
        )
    
    return masked_text

def calculate_risk_score(pii_matches: List[PIIMatch]) -> float:
    """Calculate overall risk score based on PII found"""
    if not pii_matches:
        return 0.0
    
    risk_values = {
        SensitivityLevel.LOW: 0.1,
        SensitivityLevel.MEDIUM: 0.3,
        SensitivityLevel.HIGH: 0.6,
        SensitivityLevel.CRITICAL: 1.0
    }
    
    total_risk = sum(risk_values[match.sensitivity] for match in pii_matches)
    max_possible_risk = len(pii_matches) * 1.0
    
    return min(total_risk / max_possible_risk, 1.0) if max_possible_risk > 0 else 0.0

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "PII Detection Service",
        "port": 8004,
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "PII Detection Service",
        "status": "Sensitive data detection service running",
        "endpoints": ["/health", "/detect-pii", "/supported-types", "/compliance-info"]
    }

@app.post("/detect-pii", response_model=PIIDetectionResponse)
async def detect_pii(request: PIIDetectionRequest) -> PIIDetectionResponse:
    """Detect and optionally mask PII in text"""
    try:
        logger.info(f"🔍 Analyzing text for PII (length: {len(request.text)} chars)")
        
        # Detect PII
        pii_matches = detect_pii_in_text(request.text, request.detection_types)
        
        # Mask text if requested
        masked_text = mask_text_with_pii(request.text, pii_matches) if request.mask_pii else request.text
        
        # Calculate risk score
        risk_score = calculate_risk_score(pii_matches)
        
        # Gather compliance flags
        compliance_flags = set()
        for match in pii_matches:
            if match.type in PII_PATTERNS:
                compliance_flags.update(PII_PATTERNS[match.type]["compliance"])
        
        # Create summary
        summary = {}
        for match in pii_matches:
            pii_type = match.type.value
            summary[pii_type] = summary.get(pii_type, 0) + 1
        
        logger.info(f"✅ Found {len(pii_matches)} PII instances (risk score: {risk_score:.2f})")
        
        return PIIDetectionResponse(
            original_text=request.text,
            masked_text=masked_text,
            pii_found=pii_matches,
            risk_score=risk_score,
            compliance_flags=list(compliance_flags),
            summary=summary
        )
        
    except Exception as e:
        logger.error(f"❌ PII detection failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"PII detection failed: {str(e)}")

@app.get("/supported-types")
async def get_supported_types():
    """Get list of supported PII types"""
    type_info = {}
    for pii_type, pattern_info in PII_PATTERNS.items():
        type_info[pii_type.value] = {
            "sensitivity": pattern_info["sensitivity"].value,
            "compliance_requirements": pattern_info["compliance"],
            "mask_format": pattern_info["mask"]
        }
    
    return {
        "supported_types": list(PIIType),
        "total_types": len(PIIType),
        "type_details": type_info
    }

@app.get("/compliance-info")
async def get_compliance_info():
    """Get compliance framework information"""
    frameworks = {
        "GDPR": {
            "name": "General Data Protection Regulation",
            "scope": "EU data protection",
            "applies_to": ["email", "ip_address", "date_of_birth"]
        },
        "PCI-DSS": {
            "name": "Payment Card Industry Data Security Standard",
            "scope": "Payment card data protection",
            "applies_to": ["credit_card"]
        },
        "HIPAA": {
            "name": "Health Insurance Portability and Accountability Act",
            "scope": "Healthcare data protection",
            "applies_to": ["date_of_birth", "ssn"]
        },
        "SOX": {
            "name": "Sarbanes-Oxley Act",
            "scope": "Financial reporting",
            "applies_to": ["ssn", "account_number", "routing_number"]
        }
    }
    
    return {
        "compliance_frameworks": frameworks,
        "risk_assessment": {
            "low": "Minimal compliance risk",
            "medium": "Moderate compliance requirements",
            "high": "Significant compliance obligations",
            "critical": "Severe compliance penalties possible"
        }
    }

@app.get("/status")
async def get_service_status():
    """Get detailed service status"""
    return {
        "service": "PII Detection Service",
        "port": 8004,
        "status": "running",
        "capabilities": [
            "PII pattern detection",
            "Data masking/redaction",
            "Risk scoring",
            "Compliance mapping"
        ],
        "detection_types": len(PIIType),
        "compliance_frameworks": 4,
        "performance": {
            "avg_processing_time_ms": 100,
            "throughput_kb_per_sec": 500
        }
    }

if __name__ == "__main__":
    logger.info("🚀 Starting PII Detection Service on port 8004...")
    uvicorn.run(app, host="127.0.0.1", port=8004)
