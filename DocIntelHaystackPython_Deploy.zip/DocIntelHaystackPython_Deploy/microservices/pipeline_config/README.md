# Pipeline Configuration Service - Advanced Haystack AI Orchestration

## Overview
This service provides advanced Haystack pipeline configuration, template management, and component registry functionality.

## Features
- Pipeline template management
- Component registry
- Pipeline versioning
- Dynamic pipeline composition
- A/B testing framework
- Model lifecycle management

## Endpoints
- `GET /health` - Health check
- `GET /templates` - List available pipeline templates
- `POST /templates` - Create new pipeline template
- `GET /templates/{template_id}` - Get specific template
- `PUT /templates/{template_id}` - Update template
- `DELETE /templates/{template_id}` - Delete template
- `GET /components` - List available Haystack components
- `POST /pipelines/create` - Create pipeline from template
- `GET /pipelines` - List created pipelines
- `POST /pipelines/{pipeline_id}/run` - Execute pipeline
- `GET /pipelines/{pipeline_id}/status` - Get pipeline status
- `POST /pipelines/{pipeline_id}/version` - Create new version
- `GET /analytics/performance` - Pipeline performance metrics

## Dependencies
- FastAPI
- Haystack 2.17.1
- Pydantic
- SQLAlchemy (for pipeline metadata storage)
