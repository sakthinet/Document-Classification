$ErrorActionPreference = "Stop"

# Change to the correct directory
Set-Location "e:\Dev_Branch\DataClassification\DocIntelHaystackPython\microservices\pipeline_config"

# Start the Pipeline Configuration Service
& "E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe" main.py --port 8008 --host 127.0.0.1
