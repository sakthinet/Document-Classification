"""
Pipeline Configuration Service - Startup Script
Advanced Haystack AI Orchestration

Port: 8005
"""

import sys
import os
import subprocess
import time

def check_dependencies():
    """Check if required dependencies are installed"""
    print("🔍 Checking dependencies...")
    
    required_packages = [
        "fastapi",
        "uvicorn", 
        "pydantic",
        "haystack-ai",
        "sentence-transformers",
        "numpy"
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace("-", "_"))
            print(f"  ✅ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"  ❌ {package}")
    
    if missing_packages:
        print(f"\n❌ Missing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        
        try:
            subprocess.check_call([
                sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
            ])
            print("✅ Dependencies installed successfully")
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install dependencies: {e}")
            return False
    
    return True

def start_service():
    """Start the Pipeline Configuration Service"""
    print("🚀 Starting Pipeline Configuration Service...")
    print("📍 Port: 8005")
    print("🔗 URL: http://localhost:8005")
    print("📚 Docs: http://localhost:8005/docs")
    print("=" * 60)
    
    try:
        # Start the service
        subprocess.run([
            sys.executable, "-m", "uvicorn", 
            "main:app",
            "--host", "127.0.0.1",
            "--port", "8005",
            "--reload"
        ])
    except KeyboardInterrupt:
        print("\n🛑 Service stopped by user")
    except Exception as e:
        print(f"❌ Error starting service: {e}")

def main():
    """Main startup function"""
    print("🔧 Pipeline Configuration Service - Startup")
    print("⚡ Advanced Haystack AI Orchestration")
    print()
    
    # Check dependencies
    if not check_dependencies():
        print("❌ Dependency check failed. Please install required packages.")
        return
    
    print("✅ All dependencies satisfied")
    print()
    
    # Start service
    start_service()

if __name__ == "__main__":
    main()
