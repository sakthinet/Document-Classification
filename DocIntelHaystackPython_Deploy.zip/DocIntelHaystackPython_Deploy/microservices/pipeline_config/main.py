"""
Pipeline Configuration Service - Advanced Haystack AI Orchestration
Port: 8005

This service provides advanced Haystack pipeline configuration, template management,
and component registry functionality for true Haystack-native AI orchestration.
"""

import asyncio
import json
import logging
import uuid
import sys
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

import uvicorn
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Haystack imports for pipeline management
from haystack import Pipeline
from haystack.components.embedders import SentenceTransformersDocumentEmbedder, SentenceTransformersTextEmbedder
from haystack.components.retrievers import InMemoryEmbeddingRetriever
from haystack.components.writers import DocumentWriter
from haystack.document_stores.in_memory import InMemoryDocumentStore
from haystack.components.preprocessors import DocumentSplitter
from haystack.components.generators import OpenAIGenerator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# =====================================================================================
# PYDANTIC MODELS
# =====================================================================================

class PipelineTemplate(BaseModel):
    """Pipeline template model"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str
    version: str = "1.0.0"
    category: str  # indexing, search, rag, classification, etc.
    components: List[Dict[str, Any]]
    connections: List[Dict[str, Any]]
    parameters: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)
    tags: List[str] = Field(default_factory=list)
    is_active: bool = True

class PipelineInstance(BaseModel):
    """Pipeline instance model"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    template_id: str
    name: str
    description: str
    configuration: Dict[str, Any]
    status: str = "inactive"  # inactive, active, running, error
    created_at: datetime = Field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    metrics: Dict[str, Any] = Field(default_factory=dict)

class ComponentInfo(BaseModel):
    """Haystack component information"""
    name: str
    type: str
    description: str
    parameters: Dict[str, Any]
    version: str
    category: str

class PipelineExecution(BaseModel):
    """Pipeline execution request"""
    pipeline_id: str
    inputs: Dict[str, Any]
    parameters: Optional[Dict[str, Any]] = None

# =====================================================================================
# PIPELINE CONFIGURATION SERVICE
# =====================================================================================

class PipelineConfigurationService:
    """Advanced Haystack Pipeline Configuration Service"""
    
    def __init__(self):
        """Initialize the pipeline configuration service"""
        self.templates: Dict[str, PipelineTemplate] = {}
        self.instances: Dict[str, PipelineInstance] = {}
        self.active_pipelines: Dict[str, Pipeline] = {}
        self.component_registry = self._initialize_component_registry()
        self.performance_metrics: Dict[str, Any] = {}
        
        # Initialize with default templates
        self._load_default_templates()
        
        logger.info("🚀 Pipeline Configuration Service initialized")
    
    def _initialize_component_registry(self) -> Dict[str, ComponentInfo]:
        """Initialize the Haystack component registry"""
        registry = {}
        
        # Document Processing Components
        registry["document_embedder"] = ComponentInfo(
            name="SentenceTransformersDocumentEmbedder",
            type="embedder",
            description="Embeds documents using sentence transformers",
            parameters={
                "model": "sentence-transformers/all-MiniLM-L6-v2",
                "device": "cpu",
                "batch_size": 32
            },
            version="2.17.1",
            category="embedding"
        )
        
        registry["text_embedder"] = ComponentInfo(
            name="SentenceTransformersTextEmbedder", 
            type="embedder",
            description="Embeds text queries using sentence transformers",
            parameters={
                "model": "sentence-transformers/all-MiniLM-L6-v2",
                "device": "cpu"
            },
            version="2.17.1",
            category="embedding"
        )
        
        registry["document_writer"] = ComponentInfo(
            name="DocumentWriter",
            type="writer", 
            description="Writes documents to document store",
            parameters={
                "document_store": "required",
                "policy": "OVERWRITE"
            },
            version="2.17.1",
            category="storage"
        )
        
        registry["embedding_retriever"] = ComponentInfo(
            name="InMemoryEmbeddingRetriever",
            type="retriever",
            description="Retrieves documents using embedding similarity",
            parameters={
                "document_store": "required",
                "top_k": 10,
                "scale_score": True
            },
            version="2.17.1", 
            category="retrieval"
        )
        
        registry["document_splitter"] = ComponentInfo(
            name="DocumentSplitter",
            type="preprocessor",
            description="Splits documents into smaller chunks",
            parameters={
                "split_by": "sentence",
                "split_length": 3,
                "split_overlap": 0
            },
            version="2.17.1",
            category="preprocessing"
        )
        
        registry["openai_generator"] = ComponentInfo(
            name="OpenAIGenerator",
            type="generator",
            description="Generates text using OpenAI models",
            parameters={
                "api_key": "required",
                "model": "gpt-3.5-turbo",
                "max_tokens": 150
            },
            version="2.17.1",
            category="generation"
        )
        
        return registry
    
    def _load_default_templates(self):
        """Load default pipeline templates"""
        
        # Document Indexing Template
        indexing_template = PipelineTemplate(
            name="Document Indexing Pipeline",
            description="Standard document indexing with embeddings",
            category="indexing",
            components=[
                {
                    "name": "embedder",
                    "type": "SentenceTransformersDocumentEmbedder",
                    "parameters": {
                        "model": "sentence-transformers/all-MiniLM-L6-v2"
                    }
                },
                {
                    "name": "writer", 
                    "type": "DocumentWriter",
                    "parameters": {
                        "policy": "OVERWRITE"
                    }
                }
            ],
            connections=[
                {
                    "from": "embedder.documents",
                    "to": "writer.documents"
                }
            ],
            tags=["indexing", "embeddings", "default"]
        )
        self.templates[indexing_template.id] = indexing_template
        
        # Semantic Search Template
        search_template = PipelineTemplate(
            name="Semantic Search Pipeline", 
            description="Semantic search with embedding similarity",
            category="search",
            components=[
                {
                    "name": "text_embedder",
                    "type": "SentenceTransformersTextEmbedder", 
                    "parameters": {
                        "model": "sentence-transformers/all-MiniLM-L6-v2"
                    }
                },
                {
                    "name": "retriever",
                    "type": "InMemoryEmbeddingRetriever",
                    "parameters": {
                        "top_k": 10
                    }
                }
            ],
            connections=[
                {
                    "from": "text_embedder.embedding",
                    "to": "retriever.query_embedding"
                }
            ],
            tags=["search", "retrieval", "default"]
        )
        self.templates[search_template.id] = search_template
        
        # RAG Pipeline Template
        rag_template = PipelineTemplate(
            name="RAG Question Answering Pipeline",
            description="Retrieval Augmented Generation for Q&A",
            category="rag",
            components=[
                {
                    "name": "text_embedder",
                    "type": "SentenceTransformersTextEmbedder",
                    "parameters": {
                        "model": "sentence-transformers/all-MiniLM-L6-v2"
                    }
                },
                {
                    "name": "retriever", 
                    "type": "InMemoryEmbeddingRetriever",
                    "parameters": {
                        "top_k": 5
                    }
                },
                {
                    "name": "generator",
                    "type": "OpenAIGenerator",
                    "parameters": {
                        "model": "gpt-3.5-turbo",
                        "max_tokens": 150
                    }
                }
            ],
            connections=[
                {
                    "from": "text_embedder.embedding", 
                    "to": "retriever.query_embedding"
                },
                {
                    "from": "retriever.documents",
                    "to": "generator.documents"
                }
            ],
            tags=["rag", "qa", "generation", "default"]
        )
        self.templates[rag_template.id] = rag_template
        
        logger.info(f"✅ Loaded {len(self.templates)} default pipeline templates")
    
    def create_pipeline_from_template(self, template_id: str, instance_name: str, 
                                    configuration: Dict[str, Any]) -> PipelineInstance:
        """Create a pipeline instance from template"""
        if template_id not in self.templates:
            raise ValueError(f"Template {template_id} not found")
        
        template = self.templates[template_id]
        
        # Create pipeline instance
        instance = PipelineInstance(
            template_id=template_id,
            name=instance_name,
            description=f"Instance of {template.name}",
            configuration=configuration
        )
        
        self.instances[instance.id] = instance
        
        # Build actual Haystack pipeline
        pipeline = self._build_haystack_pipeline(template, configuration)
        self.active_pipelines[instance.id] = pipeline
        
        instance.status = "active"
        logger.info(f"✅ Created pipeline instance: {instance_name}")
        
        return instance
    
    def _build_haystack_pipeline(self, template: PipelineTemplate, 
                               configuration: Dict[str, Any]) -> Pipeline:
        """Build actual Haystack pipeline from template"""
        pipeline = Pipeline()
        
        # Add components
        for component_config in template.components:
            component_name = component_config["name"]
            component_type = component_config["type"]
            params = {**component_config.get("parameters", {}), **configuration.get(component_name, {})}
            
            # Create component instance based on type
            if component_type == "SentenceTransformersDocumentEmbedder":
                component = SentenceTransformersDocumentEmbedder(
                    model=params.get("model", "sentence-transformers/all-MiniLM-L6-v2")
                )
            elif component_type == "SentenceTransformersTextEmbedder":
                component = SentenceTransformersTextEmbedder(
                    model=params.get("model", "sentence-transformers/all-MiniLM-L6-v2")
                )
            elif component_type == "DocumentWriter":
                # Need document store - use in-memory for now
                document_store = InMemoryDocumentStore()
                component = DocumentWriter(document_store=document_store)
            elif component_type == "InMemoryEmbeddingRetriever":
                # Need document store - use in-memory for now
                document_store = InMemoryDocumentStore()
                component = InMemoryEmbeddingRetriever(document_store=document_store)
            elif component_type == "DocumentSplitter":
                component = DocumentSplitter(
                    split_by=params.get("split_by", "sentence"),
                    split_length=params.get("split_length", 3)
                )
            elif component_type == "OpenAIGenerator":
                if "api_key" not in params:
                    logger.warning("OpenAI API key not provided, using mock generator")
                    # Skip OpenAI component if no API key
                    continue
                component = OpenAIGenerator(api_key=params["api_key"])
            else:
                logger.warning(f"Unknown component type: {component_type}")
                continue
            
            pipeline.add_component(component_name, component)
        
        # Add connections
        for connection in template.connections:
            try:
                pipeline.connect(connection["from"], connection["to"])
            except Exception as e:
                logger.warning(f"Failed to connect {connection['from']} to {connection['to']}: {e}")
        
        return pipeline
    
    async def execute_pipeline(self, execution: PipelineExecution) -> Dict[str, Any]:
        """Execute a pipeline instance"""
        if execution.pipeline_id not in self.active_pipelines:
            raise ValueError(f"Pipeline {execution.pipeline_id} not found or not active")
        
        pipeline = self.active_pipelines[execution.pipeline_id]
        instance = self.instances[execution.pipeline_id]
        
        try:
            # Update status
            instance.status = "running"
            instance.last_run = datetime.now()
            
            # Execute pipeline
            start_time = datetime.now()
            result = pipeline.run(execution.inputs)
            end_time = datetime.now()
            
            # Update metrics
            execution_time = (end_time - start_time).total_seconds()
            instance.metrics.update({
                "last_execution_time": execution_time,
                "total_executions": instance.metrics.get("total_executions", 0) + 1,
                "last_execution_status": "success"
            })
            
            instance.status = "active"
            
            logger.info(f"✅ Pipeline {execution.pipeline_id} executed successfully in {execution_time:.2f}s")
            
            return {
                "status": "success",
                "execution_time": execution_time,
                "result": result,
                "timestamp": end_time.isoformat()
            }
            
        except Exception as e:
            instance.status = "error"
            instance.metrics.update({
                "last_execution_status": "error",
                "last_error": str(e)
            })
            
            logger.error(f"❌ Pipeline {execution.pipeline_id} execution failed: {e}")
            raise HTTPException(status_code=500, detail=f"Pipeline execution failed: {e}")

# =====================================================================================
# FASTAPI APPLICATION
# =====================================================================================

# Global variables for dynamic port tracking
CURRENT_PORT = None

# Initialize service
service = PipelineConfigurationService()

# Create FastAPI app
app = FastAPI(
    title="Pipeline Configuration Service",
    description="Advanced Haystack AI Orchestration - Pipeline Configuration Service",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================================================
# API ENDPOINTS
# =====================================================================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    global CURRENT_PORT
    return {
        "status": "healthy",
        "service": "Pipeline Configuration Service",
        "host": "127.0.0.1",
        "port": CURRENT_PORT or "dynamic",
        "url": f"http://127.0.0.1:{CURRENT_PORT}" if CURRENT_PORT else "http://127.0.0.1:dynamic",
        "timestamp": datetime.now().isoformat(),
        "templates_count": len(service.templates),
        "active_instances": len(service.instances),
        "component_registry_size": len(service.component_registry),
        "dynamic_port_allocation": True
    }

@app.get("/templates", response_model=List[PipelineTemplate])
async def get_templates():
    """Get all pipeline templates"""
    return list(service.templates.values())

@app.get("/templates/{template_id}", response_model=PipelineTemplate)
async def get_template(template_id: str):
    """Get specific pipeline template"""
    if template_id not in service.templates:
        raise HTTPException(status_code=404, detail="Template not found")
    return service.templates[template_id]

@app.post("/templates", response_model=PipelineTemplate)
async def create_template(template: PipelineTemplate):
    """Create new pipeline template"""
    service.templates[template.id] = template
    logger.info(f"✅ Created template: {template.name}")
    return template

@app.put("/templates/{template_id}", response_model=PipelineTemplate)
async def update_template(template_id: str, template: PipelineTemplate):
    """Update pipeline template"""
    if template_id not in service.templates:
        raise HTTPException(status_code=404, detail="Template not found")
    
    template.id = template_id
    template.updated_at = datetime.now()
    service.templates[template_id] = template
    
    logger.info(f"✅ Updated template: {template.name}")
    return template

@app.delete("/templates/{template_id}")
async def delete_template(template_id: str):
    """Delete pipeline template"""
    if template_id not in service.templates:
        raise HTTPException(status_code=404, detail="Template not found")
    
    del service.templates[template_id]
    logger.info(f"✅ Deleted template: {template_id}")
    return {"message": "Template deleted successfully"}

@app.get("/components", response_model=List[ComponentInfo])
async def get_components():
    """Get available Haystack components"""
    return list(service.component_registry.values())

@app.post("/pipelines/create", response_model=PipelineInstance)
async def create_pipeline(template_id: str, instance_name: str, configuration: Dict[str, Any] = {}):
    """Create pipeline instance from template"""
    try:
        instance = service.create_pipeline_from_template(template_id, instance_name, configuration)
        return instance
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/pipelines", response_model=List[PipelineInstance])
async def get_pipelines():
    """Get all pipeline instances"""
    return list(service.instances.values())

@app.get("/pipelines/{pipeline_id}", response_model=PipelineInstance)
async def get_pipeline(pipeline_id: str):
    """Get specific pipeline instance"""
    if pipeline_id not in service.instances:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return service.instances[pipeline_id]

@app.post("/pipelines/{pipeline_id}/run")
async def run_pipeline(pipeline_id: str, inputs: Dict[str, Any], parameters: Optional[Dict[str, Any]] = None):
    """Execute pipeline"""
    execution = PipelineExecution(
        pipeline_id=pipeline_id,
        inputs=inputs,
        parameters=parameters or {}
    )
    return await service.execute_pipeline(execution)

@app.get("/pipelines/{pipeline_id}/status")
async def get_pipeline_status(pipeline_id: str):
    """Get pipeline status and metrics"""
    if pipeline_id not in service.instances:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    
    instance = service.instances[pipeline_id]
    return {
        "id": instance.id,
        "name": instance.name,
        "status": instance.status,
        "created_at": instance.created_at,
        "last_run": instance.last_run,
        "metrics": instance.metrics
    }

@app.get("/analytics/performance")
async def get_performance_analytics():
    """Get pipeline performance analytics"""
    analytics = {
        "total_templates": len(service.templates),
        "total_instances": len(service.instances),
        "active_pipelines": len([i for i in service.instances.values() if i.status == "active"]),
        "running_pipelines": len([i for i in service.instances.values() if i.status == "running"]),
        "error_pipelines": len([i for i in service.instances.values() if i.status == "error"]),
        "templates_by_category": {},
        "average_execution_time": 0,
        "total_executions": 0
    }
    
    # Category breakdown
    for template in service.templates.values():
        category = template.category
        analytics["templates_by_category"][category] = analytics["templates_by_category"].get(category, 0) + 1
    
    # Execution metrics
    execution_times = []
    total_executions = 0
    
    for instance in service.instances.values():
        if "total_executions" in instance.metrics:
            total_executions += instance.metrics["total_executions"]
        if "last_execution_time" in instance.metrics:
            execution_times.append(instance.metrics["last_execution_time"])
    
    analytics["total_executions"] = total_executions
    if execution_times:
        analytics["average_execution_time"] = sum(execution_times) / len(execution_times)
    
    return analytics

# =====================================================================================
# MAIN
# =====================================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Pipeline Configuration Service")
    parser.add_argument("--port", type=int, help="Port number to run on")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host IP address to bind to")
    args = parser.parse_args()
    
    if args.port:
        # Port provided via command line (from service starter)
        allocated_port = args.port
        host_ip = args.host
        logger.info(f"🔧 Using provided port {allocated_port} and host {host_ip} for Pipeline Configuration Service")
    else:
        # Dynamic port allocation
        try:
            # Import here to avoid circular import issues
            sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "shared"))
            from port_manager import allocate_port
            # Try to allocate port for pipeline config service
            allocated_port = allocate_port("pipeline_config", 8005)
            logger.info(f"🚀 Starting Pipeline Configuration Service on dynamically allocated port {allocated_port}...")
        except Exception as e:
            logger.error(f"Failed to allocate port using port manager: {e}")
            # Fallback to manual port finding
            import socket
            def find_free_port():
                for port in range(8005, 8020):
                    try:
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                            sock.settimeout(1)
                            result = sock.connect_ex(('localhost', port))
                            if result != 0:
                                return port
                    except:
                        continue
                return 8005
            
            allocated_port = find_free_port()
            logger.info(f"🔄 Fallback: Using port {allocated_port} for Pipeline Configuration Service")
        
        # Default host for dynamic allocation
        host_ip = "127.0.0.1"
    
    # Set global port for health check
    CURRENT_PORT = allocated_port
    
    # Use specific IP address instead of 0.0.0.0
    logger.info(f"🌐 Pipeline Configuration Service will be available at http://{host_ip}:{allocated_port}")
    
    uvicorn.run(
        "main:app",
        host=host_ip,
        port=allocated_port,
        reload=False,
        log_level="info"
    )
