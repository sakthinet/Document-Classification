"""
Pipeline Configuration Service - Test Suite

Tests for the advanced Haystack AI orchestration Pipeline Configuration Service.
"""

import asyncio
import json
import requests
import time
from typing import Dict, Any

# Configuration
BASE_URL = "http://127.0.0.1:8008"
TEST_TIMEOUT = 10

class PipelineConfigServiceTester:
    """Test suite for Pipeline Configuration Service"""
    
    def __init__(self):
        self.base_url = BASE_URL
        self.session = requests.Session()
        self.test_results = []
    
    def log_test(self, test_name: str, success: bool, message: str = "", response_data: Any = None):
        """Log test result"""
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")
        
        self.test_results.append({
            "test": test_name,
            "success": success,
            "message": message,
            "response_data": response_data
        })
    
    def test_health_check(self):
        """Test health check endpoint"""
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=10)
            if response.status_code == 200:
                data = response.json()
                self.log_test(
                    "Health Check",
                    True,
                    f"Service healthy - Templates: {data.get('templates_count', 0)}, Active Instances: {data.get('active_instances', 0)}",
                    data
                )
                return True
            else:
                self.log_test("Health Check", False, f"HTTP {response.status_code}")
                return False
        except Exception as e:
            self.log_test("Health Check", False, f"Exception: {e}")
            return False
    
    def test_get_templates(self):
        """Test getting pipeline templates"""
        try:
            response = self.session.get(f"{self.base_url}/templates", timeout=10)
            if response.status_code == 200:
                templates = response.json()
                self.log_test(
                    "Get Templates",
                    True,
                    f"Retrieved {len(templates)} templates",
                    {"count": len(templates), "templates": [t.get("name") for t in templates]}
                )
                return templates
            else:
                self.log_test("Get Templates", False, f"HTTP {response.status_code}")
                return []
        except Exception as e:
            self.log_test("Get Templates", False, f"Exception: {e}")
            return []
    
    def test_get_components(self):
        """Test getting available components"""
        try:
            response = self.session.get(f"{self.base_url}/components", timeout=10)
            if response.status_code == 200:
                components = response.json()
                self.log_test(
                    "Get Components",
                    True,
                    f"Retrieved {len(components)} components",
                    {"count": len(components), "components": [c.get("name") for c in components]}
                )
                return components
            else:
                self.log_test("Get Components", False, f"HTTP {response.status_code}")
                return []
        except Exception as e:
            self.log_test("Get Components", False, f"Exception: {e}")
            return []
    
    def test_create_custom_template(self):
        """Test creating a custom pipeline template"""
        custom_template = {
            "name": "Custom Document Processing Pipeline",
            "description": "Custom pipeline for advanced document processing",
            "category": "custom",
            "components": [
                {
                    "name": "splitter",
                    "type": "DocumentSplitter",
                    "parameters": {
                        "split_by": "sentence",
                        "split_length": 5
                    }
                },
                {
                    "name": "embedder",
                    "type": "SentenceTransformersDocumentEmbedder",
                    "parameters": {
                        "model": "sentence-transformers/all-MiniLM-L6-v2"
                    }
                },
                {
                    "name": "writer",
                    "type": "DocumentWriter",
                    "parameters": {
                        "policy": "OVERWRITE"
                    }
                }
            ],
            "connections": [
                {"from": "splitter.documents", "to": "embedder.documents"},
                {"from": "embedder.documents", "to": "writer.documents"}
            ],
            "tags": ["custom", "document-processing", "test"]
        }
        
        try:
            response = self.session.post(
                f"{self.base_url}/templates",
                json=custom_template,
                timeout=10
            )
            if response.status_code == 200:
                created_template = response.json()
                self.log_test(
                    "Create Custom Template",
                    True,
                    f"Created template: {created_template.get('name')}",
                    {"template_id": created_template.get("id")}
                )
                return created_template
            else:
                self.log_test("Create Custom Template", False, f"HTTP {response.status_code}")
                return None
        except Exception as e:
            self.log_test("Create Custom Template", False, f"Exception: {e}")
            return None
    
    def test_create_pipeline_instance(self, template_id: str):
        """Test creating a pipeline instance from template"""
        try:
            response = self.session.post(
                f"{self.base_url}/pipelines/create",
                params={
                    "template_id": template_id,
                    "instance_name": "Test Pipeline Instance",
                    "configuration": json.dumps({
                        "embedder": {
                            "model": "sentence-transformers/all-MiniLM-L6-v2"
                        }
                    })
                },
                timeout=15
            )
            if response.status_code == 200:
                instance = response.json()
                self.log_test(
                    "Create Pipeline Instance",
                    True,
                    f"Created instance: {instance.get('name')}",
                    {"instance_id": instance.get("id"), "status": instance.get("status")}
                )
                return instance
            else:
                self.log_test("Create Pipeline Instance", False, f"HTTP {response.status_code}: {response.text}")
                return None
        except Exception as e:
            self.log_test("Create Pipeline Instance", False, f"Exception: {e}")
            return None
    
    def test_get_pipelines(self):
        """Test getting all pipeline instances"""
        try:
            response = self.session.get(f"{self.base_url}/pipelines", timeout=10)
            if response.status_code == 200:
                pipelines = response.json()
                self.log_test(
                    "Get Pipeline Instances",
                    True,
                    f"Retrieved {len(pipelines)} pipeline instances",
                    {"count": len(pipelines), "pipelines": [p.get("name") for p in pipelines]}
                )
                return pipelines
            else:
                self.log_test("Get Pipeline Instances", False, f"HTTP {response.status_code}")
                return []
        except Exception as e:
            self.log_test("Get Pipeline Instances", False, f"Exception: {e}")
            return []
    
    def test_pipeline_status(self, pipeline_id: str):
        """Test getting pipeline status"""
        try:
            response = self.session.get(f"{self.base_url}/pipelines/{pipeline_id}/status", timeout=10)
            if response.status_code == 200:
                status = response.json()
                self.log_test(
                    "Get Pipeline Status",
                    True,
                    f"Status: {status.get('status')}",
                    status
                )
                return status
            else:
                self.log_test("Get Pipeline Status", False, f"HTTP {response.status_code}")
                return None
        except Exception as e:
            self.log_test("Get Pipeline Status", False, f"Exception: {e}")
            return None
    
    def test_performance_analytics(self):
        """Test performance analytics endpoint"""
        try:
            response = self.session.get(f"{self.base_url}/analytics/performance", timeout=10)
            if response.status_code == 200:
                analytics = response.json()
                self.log_test(
                    "Performance Analytics",
                    True,
                    f"Analytics retrieved - Total templates: {analytics.get('total_templates')}, Active pipelines: {analytics.get('active_pipelines')}",
                    analytics
                )
                return analytics
            else:
                self.log_test("Performance Analytics", False, f"HTTP {response.status_code}")
                return None
        except Exception as e:
            self.log_test("Performance Analytics", False, f"Exception: {e}")
            return None
    
    def run_all_tests(self):
        """Run comprehensive test suite"""
        print("🚀 Starting Pipeline Configuration Service Test Suite...")
        print("=" * 80)
        
        # Basic health and connectivity tests
        if not self.test_health_check():
            print("❌ Service is not healthy, stopping tests")
            return self.print_summary()
        
        # Test template operations
        templates = self.test_get_templates()
        components = self.test_get_components()
        
        # Test custom template creation
        custom_template = self.test_create_custom_template()
        
        # Test pipeline instance creation
        if templates and len(templates) > 0:
            # Use first template for testing
            template_id = templates[0].get("id")
            if template_id:
                pipeline_instance = self.test_create_pipeline_instance(template_id)
                
                # Test pipeline operations
                self.test_get_pipelines()
                
                if pipeline_instance:
                    pipeline_id = pipeline_instance.get("id")
                    if pipeline_id:
                        self.test_pipeline_status(pipeline_id)
        
        # Test analytics
        self.test_performance_analytics()
        
        self.print_summary()
    
    def print_summary(self):
        """Print test summary"""
        print("=" * 80)
        print("📊 TEST SUMMARY")
        print("=" * 80)
        
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["success"]])
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  - {result['test']}: {result['message']}")
        
        print("\n🎯 RECOMMENDATIONS:")
        if passed_tests == total_tests:
            print("  ✅ All tests passed! Pipeline Configuration Service is fully operational.")
            print("  🚀 Ready for production use with advanced Haystack orchestration.")
        else:
            print("  🔧 Some tests failed. Check service logs and configuration.")
            print("  📋 Ensure all dependencies are installed and service is running.")
        
        return passed_tests == total_tests

def main():
    """Main test execution"""
    print("🧪 Pipeline Configuration Service - Comprehensive Test Suite")
    print("📋 Testing advanced Haystack AI orchestration capabilities")
    print()
    
    tester = PipelineConfigServiceTester()
    
    # Wait for service to be ready
    print("⏳ Waiting for service to be ready...")
    for i in range(5):
        try:
            response = requests.get(f"{BASE_URL}/health", timeout=5)
            if response.status_code == 200:
                print("✅ Service is ready!")
                break
        except:
            pass
        time.sleep(2)
        print(f"   Attempt {i+1}/5...")
    
    # Run tests
    tester.run_all_tests()

if __name__ == "__main__":
    main()
