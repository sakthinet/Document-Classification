# Vector Search Service - Semantic Search
# Port: 8003

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import logging
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
import numpy as np
import time

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Vector Search Service",
    description="Semantic search service using vector embeddings",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request/Response models
class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    threshold: float = 0.7
    filters: Dict[str, Any] = {}

class DocumentEmbedding(BaseModel):
    id: str
    content: str
    embedding: List[float]
    metadata: Dict[str, Any] = {}

class SearchResult(BaseModel):
    id: str
    content: str
    score: float
    metadata: Dict[str, Any]

class SearchResponse(BaseModel):
    query: str
    results: List[SearchResult]
    total_found: int
    processing_time_ms: int

# In-memory vector store (in production, use Qdrant, Pinecone, or Weaviate)
vector_store: List[DocumentEmbedding] = []

def create_mock_embedding(text: str) -> List[float]:
    """Create a mock embedding vector for demonstration"""
    # In production, use actual embedding models like sentence-transformers
    np.random.seed(hash(text) % 2**32)
    return np.random.normal(0, 1, 384).tolist()  # 384-dimensional embedding

def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity between two vectors"""
    vec1_np = np.array(vec1)
    vec2_np = np.array(vec2)
    
    dot_product = np.dot(vec1_np, vec2_np)
    norm1 = np.linalg.norm(vec1_np)
    norm2 = np.linalg.norm(vec2_np)
    
    if norm1 == 0 or norm2 == 0:
        return 0.0
    
    return dot_product / (norm1 * norm2)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Vector Search Service",
        "port": 8003,
        "version": "1.0.0"
    }

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Vector Search Service",
        "status": "Semantic search service running",
        "endpoints": ["/health", "/search", "/add-document", "/list-documents", "/stats"]
    }

@app.post("/search", response_model=SearchResponse)
async def search_documents(request: SearchRequest) -> SearchResponse:
    """Perform semantic search across document vectors"""
    try:
        start_time = time.time()
        logger.info(f"🔍 Searching for: '{request.query}' (top_k={request.top_k})")
        
        if not vector_store:
            return SearchResponse(
                query=request.query,
                results=[],
                total_found=0,
                processing_time_ms=int((time.time() - start_time) * 1000)
            )
        
        # Create query embedding
        query_embedding = create_mock_embedding(request.query)
        
        # Calculate similarities
        similarities = []
        for doc in vector_store:
            similarity = cosine_similarity(query_embedding, doc.embedding)
            if similarity >= request.threshold:
                similarities.append((doc, similarity))
        
        # Sort by similarity and take top_k
        similarities.sort(key=lambda x: x[1], reverse=True)
        top_results = similarities[:request.top_k]
        
        # Build response
        results = []
        for doc, score in top_results:
            results.append(SearchResult(
                id=doc.id,
                content=doc.content,
                score=score,
                metadata=doc.metadata
            ))
        
        processing_time = int((time.time() - start_time) * 1000)
        
        logger.info(f"✅ Found {len(results)} results in {processing_time}ms")
        
        return SearchResponse(
            query=request.query,
            results=results,
            total_found=len(similarities),
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.error(f"❌ Search failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@app.post("/add-document")
async def add_document(
    id: str,
    content: str,
    metadata: Dict[str, Any] = {}
) -> Dict[str, Any]:
    """Add a document to the vector store"""
    try:
        logger.info(f"📄 Adding document: {id}")
        
        # Check if document already exists
        for i, doc in enumerate(vector_store):
            if doc.id == id:
                # Update existing document
                embedding = create_mock_embedding(content)
                vector_store[i] = DocumentEmbedding(
                    id=id,
                    content=content,
                    embedding=embedding,
                    metadata=metadata
                )
                logger.info(f"✅ Updated existing document: {id}")
                return {"status": "updated", "id": id, "embedding_dim": len(embedding)}
        
        # Add new document
        embedding = create_mock_embedding(content)
        new_doc = DocumentEmbedding(
            id=id,
            content=content,
            embedding=embedding,
            metadata=metadata
        )
        vector_store.append(new_doc)
        
        logger.info(f"✅ Added new document: {id}")
        return {"status": "added", "id": id, "embedding_dim": len(embedding)}
        
    except Exception as e:
        logger.error(f"❌ Failed to add document: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to add document: {str(e)}")

@app.get("/list-documents")
async def list_documents(limit: int = 10, offset: int = 0) -> Dict[str, Any]:
    """List documents in the vector store"""
    try:
        total = len(vector_store)
        documents = vector_store[offset:offset + limit]
        
        doc_list = []
        for doc in documents:
            doc_list.append({
                "id": doc.id,
                "content_preview": doc.content[:100] + "..." if len(doc.content) > 100 else doc.content,
                "metadata": doc.metadata,
                "embedding_dim": len(doc.embedding)
            })
        
        return {
            "total_documents": total,
            "limit": limit,
            "offset": offset,
            "documents": doc_list
        }
        
    except Exception as e:
        logger.error(f"❌ Failed to list documents: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to list documents: {str(e)}")

@app.delete("/documents/{doc_id}")
async def delete_document(doc_id: str) -> Dict[str, Any]:
    """Delete a document from the vector store"""
    try:
        for i, doc in enumerate(vector_store):
            if doc.id == doc_id:
                deleted_doc = vector_store.pop(i)
                logger.info(f"✅ Deleted document: {doc_id}")
                return {"status": "deleted", "id": doc_id}
        
        raise HTTPException(status_code=404, detail=f"Document not found: {doc_id}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Failed to delete document: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to delete document: {str(e)}")

@app.get("/stats")
async def get_stats():
    """Get vector store statistics"""
    return {
        "total_documents": len(vector_store),
        "embedding_dimension": 384,
        "memory_usage_mb": len(vector_store) * 384 * 4 / (1024 * 1024),  # Rough estimate
        "search_performance": {
            "avg_search_time_ms": 50,
            "max_similarity_threshold": 1.0,
            "min_similarity_threshold": 0.0
        }
    }

@app.get("/status")
async def get_service_status():
    """Get detailed service status"""
    return {
        "service": "Vector Search Service",
        "port": 8003,
        "status": "running",
        "capabilities": [
            "Semantic document search",
            "Vector embedding storage",
            "Similarity scoring",
            "Document management"
        ],
        "vector_store": {
            "type": "in_memory",
            "documents_count": len(vector_store),
            "embedding_model": "mock_embedding_384d"
        }
    }

# Initialize with some sample documents
@app.on_event("startup")
async def startup_event():
    """Initialize vector store with sample documents"""
    sample_docs = [
        {
            "id": "doc1",
            "content": "Loan application for mortgage with income verification and credit check",
            "metadata": {"type": "loan_application", "date": "2025-01-01"}
        },
        {
            "id": "doc2", 
            "content": "Insurance policy document with coverage details and premium information",
            "metadata": {"type": "insurance_policy", "date": "2025-01-02"}
        },
        {
            "id": "doc3",
            "content": "Bank statement showing transaction history and account balance",
            "metadata": {"type": "bank_statement", "date": "2025-01-03"}
        }
    ]
    
    for doc in sample_docs:
        await add_document(doc["id"], doc["content"], doc["metadata"])
    
    logger.info(f"✅ Initialized vector store with {len(sample_docs)} sample documents")

if __name__ == "__main__":
    logger.info("🚀 Starting Vector Search Service on port 8003...")
    uvicorn.run(app, host="127.0.0.1", port=8003)
