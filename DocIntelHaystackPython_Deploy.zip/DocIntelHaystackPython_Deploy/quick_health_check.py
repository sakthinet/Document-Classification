"""
Quick Health Check - Test services without stopping them
"""

import requests
import json

def check_service(name, port):
    """Check if a service is healthy"""
    try:
        response = requests.get(f"http://127.0.0.1:{port}/health", timeout=3)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ {name:20} | Port {port} | Status: {data.get('status', 'unknown')}")
            return True
        else:
            print(f"❌ {name:20} | Port {port} | HTTP {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print(f"🔴 {name:20} | Port {port} | Connection refused")
        return False
    except Exception as e:
        print(f"⚠️ {name:20} | Port {port} | Error: {str(e)[:30]}")
        return False

def main():
    print("🔍 Health Check - All Microservices")
    print("=" * 60)
    
    services = [
        ("Python Gateway", 8000),
        ("OCR Service", 8001), 
        ("Classification", 8002),
        ("Vector Search", 8003),
        ("PII Detection", 8004),
        ("Pipeline Config", 8005)
    ]
    
    running_count = 0
    for name, port in services:
        if check_service(name, port):
            running_count += 1
    
    print("=" * 60)
    print(f"📊 Status: {running_count}/{len(services)} services running")
    
    if running_count == len(services):
        print("🎉 All services are healthy!")
    elif running_count > 0:
        print("⚠️ Some services are running, check the ones marked with 🔴")
    else:
        print("❌ No services are running")

if __name__ == "__main__":
    main()
