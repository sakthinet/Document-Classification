import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const pipelineConfigurations = pgTable("pipeline_configurations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  sourceType: text("source_type").notNull(), // 'generic', 'bfsi', 'hr'
  status: text("status").notNull().default("draft"), // 'draft', 'active', 'inactive', 'testing'
  connectionConfig: jsonb("connection_config"),
  processingRules: jsonb("processing_rules"),
  outputDestinations: jsonb("output_destinations"),
  haystackPipelineConfig: jsonb("haystack_pipeline_config"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
});

export const documentSources = pgTable("document_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'generic', 'bfsi', 'hr'
  connectionString: text("connection_string"),
  isActive: boolean("is_active").default(true),
  features: jsonb("features"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const processingJobs = pgTable("processing_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pipelineId: varchar("pipeline_id").references(() => pipelineConfigurations.id),
  status: text("status").notNull().default("pending"), // 'pending', 'running', 'completed', 'failed'
  documentsProcessed: integer("documents_processed").default(0),
  documentsTotal: integer("documents_total").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  metrics: jsonb("metrics"),
});

export const documentEntities = pgTable("document_entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sourceId: varchar("source_id").references(() => documentSources.id),
  originalPath: text("original_path").notNull(),
  processedPath: text("processed_path"),
  documentType: text("document_type"),
  classification: jsonb("classification"),
  extractedData: jsonb("extracted_data"),
  vectorEmbedding: text("vector_embedding"),
  processedAt: timestamp("processed_at"),
  confidence: integer("confidence"),
});

export const systemMetrics = pgTable("system_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  metricName: text("metric_name").notNull(),
  metricValue: text("metric_value").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: jsonb("metadata"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPipelineConfigurationSchema = createInsertSchema(pipelineConfigurations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentSourceSchema = createInsertSchema(documentSources).omit({
  id: true,
  createdAt: true,
});

export const insertProcessingJobSchema = createInsertSchema(processingJobs).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export const insertDocumentEntitySchema = createInsertSchema(documentEntities).omit({
  id: true,
  processedAt: true,
});

export const insertSystemMetricSchema = createInsertSchema(systemMetrics).omit({
  id: true,
  timestamp: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type PipelineConfiguration = typeof pipelineConfigurations.$inferSelect;
export type InsertPipelineConfiguration = z.infer<typeof insertPipelineConfigurationSchema>;

export type DocumentSource = typeof documentSources.$inferSelect;
export type InsertDocumentSource = z.infer<typeof insertDocumentSourceSchema>;

export type ProcessingJob = typeof processingJobs.$inferSelect;
export type InsertProcessingJob = z.infer<typeof insertProcessingJobSchema>;

export type DocumentEntity = typeof documentEntities.$inferSelect;
export type InsertDocumentEntity = z.infer<typeof insertDocumentEntitySchema>;

export type SystemMetric = typeof systemMetrics.$inferSelect;
export type InsertSystemMetric = z.infer<typeof insertSystemMetricSchema>;

// Source type definitions
export const SOURCE_TYPES = {
  GENERIC: 'generic',
  BFSI: 'bfsi',
  HR: 'hr'
} as const;

export type SourceType = typeof SOURCE_TYPES[keyof typeof SOURCE_TYPES];

// Pipeline step definitions
export const PIPELINE_STEPS = {
  SOURCE_TYPE: 1,
  CONNECTION_CONFIG: 2,
  PROCESSING_RULES: 3,
  OUTPUT_DESTINATIONS: 4,
  TEST_SAVE: 5
} as const;

export type PipelineStep = typeof PIPELINE_STEPS[keyof typeof PIPELINE_STEPS];

// Security Classification Levels
export const SECURITY_CLASSIFICATIONS = {
  CONFIDENTIAL: 'confidential',
  RESTRICTED: 'restricted', 
  INTERNAL: 'internal',
  PUBLIC: 'public'
} as const;

export type SecurityClassification = typeof SECURITY_CLASSIFICATIONS[keyof typeof SECURITY_CLASSIFICATIONS];

// Domain-specific source types
export const BFSI_SOURCE_TYPES = {
  CORE_BANKING: 'core_banking_system',
  LOAN_MANAGEMENT: 'loan_management_system', 
  SHAREPOINT_ONLINE: 'sharepoint_online',
  NETWORK_FOLDER: 'network_folder',
  DATABASE: 'database',
  CLOUD_STORAGE: 'cloud_storage',
  FTP_SFTP: 'ftp_sftp'
} as const;

export const HR_SOURCE_TYPES = {
  NETWORK_FOLDER: 'network_folder',
  SHAREPOINT_HR: 'sharepoint_hr',
  HRMS_SYSTEM: 'hrms_system',
  DATABASE: 'database', 
  CLOUD_STORAGE: 'cloud_storage'
} as const;

export const GENERIC_SOURCE_TYPES = {
  NETWORK_FOLDER: 'network_folder',
  SHAREPOINT: 'sharepoint',
  DATABASE: 'database',
  CLOUD_STORAGE: 'cloud_storage', 
  FTP_SFTP: 'ftp_sftp',
  ON_PREMISES: 'on_premises'
} as const;

// Document types for each domain with classifications
export const HR_DOCUMENT_TYPES = {
  CONTRACTS: { name: 'Contracts', classification: 'confidential', folder: 'Contracts', retention: '7_years' },
  PAYROLL: { name: 'Payroll', classification: 'restricted', folder: 'Payroll', retention: '7_years' },
  REVIEWS: { name: 'Reviews', classification: 'internal', folder: 'Reviews', retention: '5_years' },
  POLICIES: { name: 'Policies', classification: 'public', folder: 'Policies', retention: '10_years' },
  TRAINING: { name: 'Training', classification: 'public', folder: 'Training', retention: '3_years' }
} as const;

export const BFSI_DOCUMENT_TYPES = {
  FINANCIAL_STATEMENTS: { name: 'Financial Statements', classification: 'confidential', retention: '10_years' },
  LOAN_APPLICATIONS: { name: 'Loan Applications', classification: 'restricted', retention: '7_years' },
  COMPLIANCE_REPORTS: { name: 'Compliance Reports', classification: 'internal', retention: '5_years' },
  CUSTOMER_ONBOARDING: { name: 'Customer Onboarding', classification: 'restricted', retention: '7_years' },
  RISK_ASSESSMENTS: { name: 'Risk Assessments', classification: 'internal', retention: '5_years' }
} as const;

// Output destinations based on security classification
export const OUTPUT_DESTINATIONS = {
  LOCAL_NAS: 'local_nas_storage',
  AZURE_ENCRYPTED: 'azure_encrypted_backup', 
  AZURE_SELECTIVE: 'azure_selective_sync',
  AZURE_FULL: 'azure_full_sync',
  CLOUD_STORAGE: 'cloud_storage',
  DATABASE: 'database'
} as const;

// Advanced connection configuration types
export const CONNECTION_CONFIG_STEPS = {
  BASIC_INFO: 1,
  CONNECTION: 2,
  DOCUMENT_TYPES: 3,
  COMPLIANCE: 4
} as const;

export type BFSISourceType = typeof BFSI_SOURCE_TYPES[keyof typeof BFSI_SOURCE_TYPES];
export type HRSourceType = typeof HR_SOURCE_TYPES[keyof typeof HR_SOURCE_TYPES];
export type GenericSourceType = typeof GENERIC_SOURCE_TYPES[keyof typeof GENERIC_SOURCE_TYPES];
export type OutputDestination = typeof OUTPUT_DESTINATIONS[keyof typeof OUTPUT_DESTINATIONS];
export type ConnectionConfigStep = typeof CONNECTION_CONFIG_STEPS[keyof typeof CONNECTION_CONFIG_STEPS];
