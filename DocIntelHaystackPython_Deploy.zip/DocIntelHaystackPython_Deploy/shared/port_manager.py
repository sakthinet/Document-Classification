"""
Dynamic Port Manager
Handles automatic port allocation across all microservices to prevent conflicts
"""

import socket
import json
import os
import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PortManager:
    """Dynamic port allocation and management system"""
    
    def __init__(self, config_file: str = "port_config.json"):
        """Initialize port manager with configuration file"""
        self.config_file = Path(config_file)
        self.service_ports: Dict[str, int] = {}
        self.reserved_ports: List[int] = [22, 25, 53, 80, 110, 443, 993, 995]  # Common system ports
        self.port_range = (8000, 9000)  # Default port range
        self.load_configuration()
    
    def load_configuration(self):
        """Load existing port configuration"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    self.service_ports = config.get("service_ports", {})
                    self.reserved_ports.extend(config.get("reserved_ports", []))
                    self.port_range = tuple(config.get("port_range", [8000, 9000]))
                logger.info(f"✅ Loaded port configuration from {self.config_file}")
            except Exception as e:
                logger.warning(f"Failed to load port configuration: {e}")
        else:
            logger.info("No existing port configuration found, using defaults")
    
    def save_configuration(self):
        """Save current port configuration"""
        try:
            config = {
                "service_ports": self.service_ports,
                "reserved_ports": list(set(self.reserved_ports)),
                "port_range": list(self.port_range)
            }
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            logger.info(f"✅ Saved port configuration to {self.config_file}")
        except Exception as e:
            logger.error(f"Failed to save port configuration: {e}")
    
    def is_port_available(self, port: int) -> bool:
        """Check if a port is available"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(1)
                result = sock.connect_ex(('localhost', port))
                return result != 0
        except Exception:
            return False
    
    def find_available_port(self, preferred_port: Optional[int] = None, 
                          service_name: Optional[str] = None) -> int:
        """Find an available port, preferring the suggested port"""
        
        # If service already has an assigned port and it's available, use it
        if service_name and service_name in self.service_ports:
            existing_port = self.service_ports[service_name]
            if self.is_port_available(existing_port):
                logger.info(f"🔄 Reusing existing port {existing_port} for {service_name}")
                return existing_port
            else:
                logger.warning(f"⚠️ Previously assigned port {existing_port} for {service_name} is now occupied")
        
        # Try preferred port first
        if preferred_port and self.is_port_available(preferred_port):
            if service_name:
                self.service_ports[service_name] = preferred_port
                self.save_configuration()
            logger.info(f"✅ Using preferred port {preferred_port}" + (f" for {service_name}" if service_name else ""))
            return preferred_port
        
        # Find next available port in range
        start_port, end_port = self.port_range
        for port in range(start_port, end_port + 1):
            if port in self.reserved_ports:
                continue
            if port in self.service_ports.values() and port != preferred_port:
                continue  # Skip ports assigned to other services
            if self.is_port_available(port):
                if service_name:
                    self.service_ports[service_name] = port
                    self.save_configuration()
                logger.info(f"🆕 Allocated new port {port}" + (f" for {service_name}" if service_name else ""))
                return port
        
        raise RuntimeError(f"No available ports in range {self.port_range}")
    
    def allocate_service_port(self, service_name: str, preferred_port: Optional[int] = None) -> int:
        """Allocate a port for a specific service"""
        port = self.find_available_port(preferred_port, service_name)
        logger.info(f"📍 Service '{service_name}' allocated port {port}")
        return port
    
    def get_service_port(self, service_name: str) -> Optional[int]:
        """Get the currently assigned port for a service"""
        return self.service_ports.get(service_name)
    
    def release_service_port(self, service_name: str):
        """Release a port assigned to a service"""
        if service_name in self.service_ports:
            port = self.service_ports.pop(service_name)
            self.save_configuration()
            logger.info(f"🔓 Released port {port} from service '{service_name}'")
    
    def get_all_services(self) -> Dict[str, int]:
        """Get all currently assigned service ports"""
        return self.service_ports.copy()
    
    def validate_all_ports(self) -> Dict[str, bool]:
        """Validate that all assigned ports are still available"""
        status = {}
        for service_name, port in self.service_ports.items():
            is_available = self.is_port_available(port)
            status[service_name] = not is_available  # True if service is running
            if not is_available:
                logger.info(f"🟢 {service_name} is running on port {port}")
            else:
                logger.warning(f"🔴 {service_name} is not running on assigned port {port}")
        return status
    
    def suggest_service_ports(self) -> Dict[str, int]:
        """Suggest ports for all known services"""
        services = [
            ("frontend", 3000),
            ("python_gateway", 8000),
            ("ocr_service", 8001),
            ("classification_service", 8002),
            ("vector_search", 8003),
            ("pii_detection", 8004),
            ("pipeline_config", 8005),
            ("model_serving", 8006),
            ("postgresql", 5432),
            ("redis", 6379),
            ("airflow", 8083)
        ]
        
        suggestions = {}
        for service_name, preferred_port in services:
            try:
                port = self.allocate_service_port(service_name, preferred_port)
                suggestions[service_name] = port
            except Exception as e:
                logger.error(f"Failed to allocate port for {service_name}: {e}")
        
        return suggestions

# Global port manager instance
port_manager = PortManager()

def get_port_manager() -> PortManager:
    """Get the global port manager instance"""
    return port_manager

def allocate_port(service_name: str, preferred_port: Optional[int] = None) -> int:
    """Convenient function to allocate a port"""
    return port_manager.allocate_service_port(service_name, preferred_port)

def get_service_port(service_name: str) -> Optional[int]:
    """Convenient function to get service port"""
    return port_manager.get_service_port(service_name)

def main():
    """Main function for testing and port allocation"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Dynamic Port Manager")
    parser.add_argument("--service", help="Service name to allocate port for")
    parser.add_argument("--port", type=int, help="Preferred port number")
    parser.add_argument("--list", action="store_true", help="List all allocated ports")
    parser.add_argument("--validate", action="store_true", help="Validate all service ports")
    parser.add_argument("--suggest", action="store_true", help="Suggest ports for all services")
    parser.add_argument("--release", help="Release port for service")
    
    args = parser.parse_args()
    
    if args.list:
        services = port_manager.get_all_services()
        print("📋 Currently allocated service ports:")
        for service, port in services.items():
            print(f"  {service}: {port}")
    
    elif args.validate:
        print("🔍 Validating service ports...")
        status = port_manager.validate_all_ports()
        for service, is_running in status.items():
            status_icon = "🟢" if is_running else "🔴"
            print(f"  {status_icon} {service}: {port_manager.get_service_port(service)}")
    
    elif args.suggest:
        print("💡 Suggesting ports for all services...")
        suggestions = port_manager.suggest_service_ports()
        for service, port in suggestions.items():
            print(f"  {service}: {port}")
    
    elif args.release:
        port_manager.release_service_port(args.release)
        print(f"🔓 Released port for service: {args.release}")
    
    elif args.service:
        port = port_manager.allocate_service_port(args.service, args.port)
        print(f"📍 Allocated port {port} for service: {args.service}")
    
    else:
        print("🔧 Port Manager - Dynamic Port Allocation")
        print("Use --help for available commands")

if __name__ == "__main__":
    main()
