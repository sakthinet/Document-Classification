# Haystack Manager - Core AI/ML Engine
# Central manager for all Haystack pipelines and components

import asyncio
import logging
from typing import Dict, Optional, List, Any
from pathlib import Path
import json
from datetime import datetime

from haystack import Pipeline, Document
from haystack.components.embedders import SentenceTransformersDocumentEmbedder, SentenceTransformersTextEmbedder
from haystack.components.writers import DocumentWriter
from haystack.components.retrievers import InMemoryBM25Retriever, InMemoryEmbeddingRetriever
from haystack.document_stores.in_memory import InMemoryDocumentStore
from haystack.utils.device import ComponentDevice
from haystack.components.builders import PromptBuilder
from haystack.components.generators import OpenAIGenerator

from app.config.settings import settings

logger = logging.getLogger(__name__)

class HaystackManager:
    """Central manager for Haystack AI pipelines and components"""
    
    def __init__(self):
        self.is_ready: bool = False
        self.document_store: Optional[InMemoryDocumentStore] = None
        self.pipelines: Dict[str, Pipeline] = {}
        self.loaded_models: Dict[str, Any] = {}
        self.embedder: Optional[SentenceTransformersDocumentEmbedder] = None
        
    async def initialize(self):
        """Initialize Haystack components and pipelines"""
        try:
            logger.info("🔄 Initializing Haystack Manager...")
            
            # Initialize document store (start with InMemory, upgrade to Qdrant later)
            self.document_store = InMemoryDocumentStore()
            logger.info("✅ Document store initialized")
            
            # Initialize embedder
            await self._initialize_embedder()
            
            # Create core pipelines
            await self._create_pipelines()
            
            self.is_ready = True
            logger.info("✅ Haystack Manager fully initialized")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize Haystack Manager: {e}")
            raise
    
    async def _initialize_embedder(self):
        """Initialize the embedding model with performance optimizations"""
        try:
            logger.info(f"🧠 Loading embedding model: {settings.default_embedding_model}")
            
            # Performance optimizations
            model_kwargs = {
                "model": settings.default_embedding_model,
                "batch_size": settings.model_batch_size,
                "progress_bar": False,
                "normalize_embeddings": True
            }
            
            # Add device optimization
            if hasattr(settings, 'fast_mode') and settings.fast_mode:
                model_kwargs["device"] = ComponentDevice.from_str("cpu")  # Force CPU for consistent performance
                model_kwargs["trust_remote_code"] = False
            
            # Run in thread to avoid blocking
            loop = asyncio.get_event_loop()
            self.embedder = await loop.run_in_executor(
                None, 
                lambda: SentenceTransformersDocumentEmbedder(**model_kwargs)
            )
            
            # Quick warmup with smaller test
            if hasattr(settings, 'fast_mode') and settings.fast_mode:
                logger.info("⚡ Fast mode enabled - skipping extensive warmup")
            else:
                test_docs = [Document(content="Test document for model warmup")]
                await loop.run_in_executor(None, self.embedder.warm_up)
            
            self.loaded_models["embedder"] = settings.default_embedding_model
            logger.info("✅ Embedding model loaded and ready")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize embedder: {e}")
            raise
    
    async def _create_pipelines(self):
        """Create core Haystack pipelines"""
        try:
            # 1. Document Indexing Pipeline
            indexing_pipeline = Pipeline()
            
            indexing_pipeline.add_component("embedder", self.embedder)
            indexing_pipeline.add_component(
                "writer", 
                DocumentWriter(document_store=self.document_store)
            )
            
            indexing_pipeline.connect("embedder", "writer")
            self.pipelines["indexing"] = indexing_pipeline
            
            # 2. Basic Search Pipeline
            search_pipeline = Pipeline()
            
            search_pipeline.add_component(
                "embedder",
                SentenceTransformersTextEmbedder(model=settings.default_embedding_model)
            )
            search_pipeline.add_component(
                "retriever", 
                InMemoryEmbeddingRetriever(document_store=self.document_store)
            )
            
            search_pipeline.connect("embedder", "retriever")
            self.pipelines["search"] = search_pipeline
            
            # 3. RAG Pipeline (if OpenAI key available)
            if settings.openai_api_key:
                rag_pipeline = Pipeline()
                
                rag_pipeline.add_component(
                    "embedder",
                    SentenceTransformersTextEmbedder(model=settings.default_embedding_model)
                )
                rag_pipeline.add_component(
                    "retriever",
                    InMemoryEmbeddingRetriever(document_store=self.document_store)
                )
                rag_pipeline.add_component(
                    "prompt_builder",
                    PromptBuilder(
                        template="""
                        Based on the following documents, answer the question:
                        
                        Documents:
                        {% for doc in documents %}
                        {{ doc.content }}
                        {% endfor %}
                        
                        Question: {{ question }}
                        Answer:
                        """
                    )
                )
                rag_pipeline.add_component(
                    "llm",
                    OpenAIGenerator(api_key=settings.openai_api_key)
                )
                
                rag_pipeline.connect("embedder", "retriever")
                rag_pipeline.connect("retriever", "prompt_builder.documents")
                rag_pipeline.connect("prompt_builder", "llm")
                
                self.pipelines["rag"] = rag_pipeline
                logger.info("✅ RAG pipeline created with OpenAI integration")
            
            logger.info(f"✅ Created {len(self.pipelines)} pipelines")
            
        except Exception as e:
            logger.error(f"❌ Failed to create pipelines: {e}")
            raise
    
    async def index_documents(self, documents: List[Document]) -> Dict[str, Any]:
        """Index documents using Haystack pipeline"""
        try:
            if "indexing" not in self.pipelines:
                raise ValueError("Indexing pipeline not available")
            
            logger.info(f"📄 Indexing {len(documents)} documents...")
            
            # Run indexing pipeline
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                self.pipelines["indexing"].run,
                {"embedder": {"documents": documents}}
            )
            
            logger.info(f"✅ Indexed {len(documents)} documents successfully")
            return {
                "success": True,
                "documents_indexed": len(documents),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to index documents: {e}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def search_documents(self, query: str, top_k: int = 10) -> Dict[str, Any]:
        """Search documents using Haystack pipeline"""
        try:
            if "search" not in self.pipelines:
                raise ValueError("Search pipeline not available")
            
            logger.info(f"🔍 Searching for: {query}")
            
            # Run search pipeline
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                self.pipelines["search"].run,
                {"retriever": {"query": query, "top_k": top_k}}
            )
            
            documents = result.get("retriever", {}).get("documents", [])
            
            return {
                "success": True,
                "query": query,
                "results": [
                    {
                        "content": doc.content[:500] + "..." if len(doc.content) > 500 else doc.content,
                        "meta": doc.meta,
                        "score": getattr(doc, 'score', 0.0)
                    }
                    for doc in documents
                ],
                "total_results": len(documents),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Search failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def answer_question(self, question: str, top_k: int = 5) -> Dict[str, Any]:
        """Answer question using RAG pipeline"""
        try:
            if "rag" not in self.pipelines:
                return {
                    "success": False,
                    "error": "RAG pipeline not available (OpenAI API key required)",
                    "timestamp": datetime.now().isoformat()
                }
            
            logger.info(f"💭 Answering question: {question}")
            
            # Run RAG pipeline
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                self.pipelines["rag"].run,
                {"retriever": {"query": question, "top_k": top_k}, "prompt_builder": {"question": question}}
            )
            
            answer = result.get("llm", {}).get("replies", ["No answer generated"])[0]
            
            return {
                "success": True,
                "question": question,
                "answer": answer,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Question answering failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    async def get_pipeline_status(self) -> Dict[str, Any]:
        """Get status of all pipelines"""
        return {
            "manager_ready": self.is_ready,
            "pipelines": list(self.pipelines.keys()),
            "loaded_models": self.loaded_models,
            "document_count": len(self.document_store.filter_documents()) if self.document_store else 0,
            "timestamp": datetime.now().isoformat()
        }
    
    async def cleanup(self):
        """Cleanup resources"""
        logger.info("🔄 Cleaning up Haystack Manager...")
        self.pipelines.clear()
        self.loaded_models.clear()
        self.is_ready = False
        logger.info("✅ Cleanup complete")
