# Custom Exceptions
# TODO: Implement custom exception classes
