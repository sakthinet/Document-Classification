# Pydantic Settings Configuration
from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional
import os

class Settings(BaseSettings):
    """Application settings with Haystack integration"""
    
    # App Configuration
    app_name: str = "DocIntel Haystack Backend"
    version: str = "1.0.0"
    debug: bool = Field(default=False, env="DEBUG")
    
    # Server Configuration
    host: str = Field(default="127.0.0.1", env="HOST")
    port: int = Field(default=8006, env="PORT")
    
    # Database Configuration (Parallel with Node.js)
    database_url: Optional[str] = Field(default=None, env="DATABASE_URL")
    database_echo: bool = Field(default=False, env="DATABASE_ECHO")
    
    # Haystack Configuration
    haystack_pipeline_cache_dir: str = Field(default="./cache/pipelines", env="HAYSTACK_CACHE_DIR")
    haystack_model_cache_dir: str = Field(default="./cache/models", env="HAYSTACK_MODEL_CACHE_DIR")
    
    # Embedding Models - Optimized for speed
    default_embedding_model: str = Field(
        default="sentence-transformers/all-MiniLM-L6-v2", 
        env="EMBEDDING_MODEL"
    )
    
    # Performance optimization settings
    model_batch_size: int = Field(default=8, env="MODEL_BATCH_SIZE")  # Reduced from 32
    max_document_length: int = Field(default=1000, env="MAX_DOC_LENGTH")  # Limit doc size
    enable_model_caching: bool = Field(default=True, env="ENABLE_MODEL_CACHING")
    fast_mode: bool = Field(default=True, env="FAST_MODE")  # Enable fast processing
    classification_model: str = Field(
        default="microsoft/DialoGPT-medium", 
        env="CLASSIFICATION_MODEL"
    )
    model_batch_size: int = Field(default=32, env="MODEL_BATCH_SIZE")
    
    # Vector Database (Windows-based Qdrant)
    qdrant_host: str = Field(default="localhost", env="QDRANT_HOST")
    qdrant_port: int = Field(default=6333, env="QDRANT_PORT")
    qdrant_api_key: Optional[str] = Field(default=None, env="QDRANT_API_KEY")
    
    # Security
    secret_key: str = Field(default="dev-secret-key-change-in-production", env="SECRET_KEY")
    algorithm: str = Field(default="HS256", env="ALGORITHM")
    access_token_expire_minutes: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    
    # External APIs
    openai_api_key: Optional[str] = Field(default=None, env="OPENAI_API_KEY")
    huggingface_api_token: Optional[str] = Field(default=None, env="HUGGINGFACE_API_TOKEN")
    
    # Windows-specific paths
    document_storage_path: str = Field(default="C:/DocIntelData/documents", env="DOCUMENT_STORAGE_PATH")
    temp_storage_path: str = Field(default="C:/DocIntelData/temp", env="TEMP_STORAGE_PATH")
    
    # Performance
    max_concurrent_pipelines: int = Field(default=4, env="MAX_CONCURRENT_PIPELINES")
    gpu_enabled: bool = Field(default=True, env="GPU_ENABLED")
    
    class Config:
        env_file = os.path.join(os.path.dirname(__file__), "..", "..", ".env")
        case_sensitive = False
        extra = "ignore"  # Allow extra environment variables

# Global settings instance
settings = Settings()
