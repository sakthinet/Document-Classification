# Monitoring Endpoints for Haystack Pipelines
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel
from typing import Dict, Any, List
import logging
import psutil
import time
from datetime import datetime

logger = logging.getLogger(__name__)

router = APIRouter()

class SystemMetrics(BaseModel):
    cpu_percent: float
    memory_percent: float
    memory_available_gb: float
    disk_usage_percent: float
    timestamp: str

class PipelineStatus(BaseModel):
    pipeline_name: str
    status: str
    last_execution: str
    success_rate: float
    avg_execution_time: float

class MonitoringResponse(BaseModel):
    success: bool
    data: Dict[str, Any]
    timestamp: str

def get_haystack_manager(request: Request):
    """Dependency to get Haystack manager from app state"""
    if not hasattr(request.app.state, 'haystack_manager'):
        raise HTTPException(status_code=503, detail="Haystack manager not initialized")
    return request.app.state.haystack_manager

@router.get("/system", response_model=MonitoringResponse)
async def get_system_metrics():
    """Get system performance metrics"""
    try:
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        metrics = SystemMetrics(
            cpu_percent=cpu_percent,
            memory_percent=memory.percent,
            memory_available_gb=round(memory.available / (1024**3), 2),
            disk_usage_percent=disk.percent,
            timestamp=datetime.now().isoformat()
        )
        
        return MonitoringResponse(
            success=True,
            data=metrics.dict(),
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"❌ Failed to get system metrics: {e}")
        raise HTTPException(status_code=500, detail=f"System metrics failed: {str(e)}")

@router.get("/pipelines", response_model=MonitoringResponse)
async def get_pipeline_status(haystack_manager = Depends(get_haystack_manager)):
    """Get status of all Haystack pipelines"""
    try:
        status = await haystack_manager.get_pipeline_status()
        
        return MonitoringResponse(
            success=True,
            data=status,
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"❌ Failed to get pipeline status: {e}")
        raise HTTPException(status_code=500, detail=f"Pipeline status failed: {str(e)}")

@router.get("/health/detailed")
async def detailed_health_check(haystack_manager = Depends(get_haystack_manager)):
    """Comprehensive health check"""
    try:
        health_data = {
            "backend_status": "healthy",
            "haystack_ready": haystack_manager.is_ready,
            "pipelines": list(haystack_manager.pipelines.keys()),
            "loaded_models": haystack_manager.loaded_models,
            "document_count": len(haystack_manager.document_store.filter_documents()) if haystack_manager.document_store else 0,
            "system": {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "uptime_seconds": time.time()
            }
        }
        
        # Determine overall health
        overall_status = "healthy"
        if not haystack_manager.is_ready:
            overall_status = "degraded"
        if psutil.virtual_memory().percent > 90:
            overall_status = "warning"
        
        health_data["overall_status"] = overall_status
        
        return MonitoringResponse(
            success=True,
            data=health_data,
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"❌ Health check failed: {e}")
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")

@router.get("/performance")
async def get_performance_metrics(haystack_manager = Depends(get_haystack_manager)):
    """Get performance metrics for AI operations"""
    try:
        # Basic performance data
        performance_data = {
            "models_loaded": len(haystack_manager.loaded_models),
            "pipelines_available": len(haystack_manager.pipelines),
            "embedding_model": haystack_manager.loaded_models.get("embedder", "Not loaded"),
            "memory_usage": {
                "total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
                "used_gb": round(psutil.virtual_memory().used / (1024**3), 2),
                "available_gb": round(psutil.virtual_memory().available / (1024**3), 2)
            },
            "recommendations": []
        }
        
        # Add performance recommendations
        if psutil.virtual_memory().percent > 80:
            performance_data["recommendations"].append("High memory usage detected. Consider reducing batch size.")
        
        if len(haystack_manager.loaded_models) == 0:
            performance_data["recommendations"].append("No models loaded. Initialize models for better performance.")
        
        return MonitoringResponse(
            success=True,
            data=performance_data,
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"❌ Performance metrics failed: {e}")
        raise HTTPException(status_code=500, detail=f"Performance metrics failed: {str(e)}")

@router.post("/test/pipeline/{pipeline_name}")
async def test_pipeline(
    pipeline_name: str,
    haystack_manager = Depends(get_haystack_manager)
):
    """Test a specific pipeline"""
    try:
        if pipeline_name not in haystack_manager.pipelines:
            raise HTTPException(status_code=404, detail=f"Pipeline '{pipeline_name}' not found")
        
        # Test based on pipeline type
        if pipeline_name == "search":
            result = await haystack_manager.search_documents("test query", top_k=1)
        elif pipeline_name == "indexing":
            from haystack import Document
            test_doc = Document(content="Test document for pipeline testing")
            result = await haystack_manager.index_documents([test_doc])
        elif pipeline_name == "rag":
            result = await haystack_manager.answer_question("What is a test?")
        else:
            result = {"success": True, "message": f"Pipeline '{pipeline_name}' is available"}
        
        return MonitoringResponse(
            success=True,
            data={
                "pipeline": pipeline_name,
                "test_result": result,
                "status": "passed" if result.get("success", True) else "failed"
            },
            timestamp=datetime.now().isoformat()
        )
        
    except Exception as e:
        logger.error(f"❌ Pipeline test failed: {e}")
        raise HTTPException(status_code=500, detail=f"Pipeline test failed: {str(e)}")
