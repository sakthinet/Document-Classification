# Search Endpoints with Haystack Integration
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import logging

from haystack import Document

logger = logging.getLogger(__name__)

router = APIRouter()

# Pydantic models for API
class DocumentInput(BaseModel):
    content: str
    meta: Optional[Dict[str, Any]] = {}

class IndexRequest(BaseModel):
    documents: List[DocumentInput]

class SearchRequest(BaseModel):
    query: str
    top_k: int = Field(default=10, ge=1, le=100)

class QuestionRequest(BaseModel):
    question: str
    top_k: int = Field(default=5, ge=1, le=20)

class SearchResponse(BaseModel):
    success: bool
    query: Optional[str] = None
    results: List[Dict[str, Any]] = []
    total_results: int = 0
    timestamp: str
    error: Optional[str] = None

def get_haystack_manager(request: Request):
    """Dependency to get Haystack manager from app state"""
    if not hasattr(request.app.state, 'haystack_manager'):
        raise HTTPException(status_code=503, detail="Haystack manager not initialized")
    return request.app.state.haystack_manager

@router.post("/index", response_model=SearchResponse)
async def index_documents(
    request: IndexRequest,
    haystack_manager = Depends(get_haystack_manager)
):
    """Index documents for semantic search"""
    try:
        # Convert to Haystack documents
        documents = [
            Document(content=doc.content, meta=doc.meta)
            for doc in request.documents
        ]
        
        # Index using Haystack
        result = await haystack_manager.index_documents(documents)
        
        return SearchResponse(
            success=result["success"],
            total_results=result.get("documents_indexed", 0),
            timestamp=result["timestamp"],
            error=result.get("error")
        )
        
    except Exception as e:
        logger.error(f"❌ Document indexing failed: {e}")
        raise HTTPException(status_code=500, detail=f"Indexing failed: {str(e)}")

@router.post("/semantic", response_model=SearchResponse)
async def semantic_search(
    request: SearchRequest,
    haystack_manager = Depends(get_haystack_manager)
):
    """Perform semantic search using Haystack"""
    try:
        result = await haystack_manager.search_documents(request.query, request.top_k)
        
        return SearchResponse(
            success=result["success"],
            query=result.get("query"),
            results=result.get("results", []),
            total_results=result.get("total_results", 0),
            timestamp=result["timestamp"],
            error=result.get("error")
        )
        
    except Exception as e:
        logger.error(f"❌ Semantic search failed: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@router.post("/ask", response_model=SearchResponse)
async def ask_question(
    request: QuestionRequest,
    haystack_manager = Depends(get_haystack_manager)
):
    """Answer questions using RAG pipeline"""
    try:
        result = await haystack_manager.answer_question(request.question, request.top_k)
        
        return SearchResponse(
            success=result["success"],
            query=result.get("question"),
            results=[{"answer": result.get("answer")}] if result.get("answer") else [],
            total_results=1 if result.get("answer") else 0,
            timestamp=result["timestamp"],
            error=result.get("error")
        )
        
    except Exception as e:
        logger.error(f"❌ Question answering failed: {e}")
        raise HTTPException(status_code=500, detail=f"Question answering failed: {str(e)}")

@router.get("/status")
async def get_search_status(haystack_manager = Depends(get_haystack_manager)):
    """Get search system status"""
    try:
        status = await haystack_manager.get_pipeline_status()
        return status
    except Exception as e:
        logger.error(f"❌ Status check failed: {e}")
        raise HTTPException(status_code=500, detail=f"Status check failed: {str(e)}")

# Quick test endpoints
@router.post("/test/simple")
async def test_simple_search():
    """Simple test endpoint for basic functionality"""
    return {
        "message": "Search API is working",
        "endpoints": [
            "POST /index - Index documents",
            "POST /semantic - Semantic search", 
            "POST /ask - Question answering",
            "GET /status - System status"
        ]
    }
