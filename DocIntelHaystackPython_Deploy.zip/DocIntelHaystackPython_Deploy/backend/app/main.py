# Backend FastAPI Application
# LAYER 1: API Gateway with Haystack Integration

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from contextlib import asynccontextmanager
import uvicorn
import logging
import os
from pathlib import Path

from app.config.settings import settings
from app.core.haystack_manager import HaystackManager
from app.api.v1 import workflows, monitoring, search, admin
from app.api import auth

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Global Haystack manager instance
haystack_manager: HaystackManager = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle with Haystack initialization"""
    global haystack_manager
    
    logger.info("🚀 Starting DocIntel Haystack Backend...")
    
    # Create necessary directories
    os.makedirs(settings.haystack_pipeline_cache_dir, exist_ok=True)
    os.makedirs(settings.haystack_model_cache_dir, exist_ok=True)
    os.makedirs(settings.document_storage_path, exist_ok=True)
    os.makedirs(settings.temp_storage_path, exist_ok=True)
    
    # Initialize Haystack Manager
    try:
        haystack_manager = HaystackManager()
        await haystack_manager.initialize()
        logger.info("✅ Haystack Manager initialized successfully")
    except Exception as e:
        logger.error(f"❌ Failed to initialize Haystack Manager: {e}")
        raise
    
    # Store in app state for access in routes
    app.state.haystack_manager = haystack_manager
    
    logger.info(f"🌐 Backend ready at http://{settings.host}:{settings.port}")
    
    yield  # Application is running
    
    # Cleanup on shutdown
    logger.info("🔄 Shutting down Haystack Backend...")
    if haystack_manager:
        await haystack_manager.cleanup()
    logger.info("✅ Shutdown complete")

# Create FastAPI application
app = FastAPI(
    title=settings.app_name,
    version=settings.version,
    description="AI-Powered Document Intelligence Platform with Haystack",
    lifespan=lifespan
)

# Add middleware
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],  # Frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check endpoint
@app.get("/")
async def root():
    """Root endpoint with system status"""
    return {
        "message": "DocIntel Haystack Backend",
        "version": settings.version,
        "status": "running",
        "haystack_ready": haystack_manager is not None and haystack_manager.is_ready
    }

@app.get("/health")
async def health_check():
    """Detailed health check"""
    health_status = {
        "status": "healthy",
        "backend": "operational",
        "haystack": haystack_manager.is_ready if haystack_manager else False,
        "models_loaded": len(haystack_manager.loaded_models) if haystack_manager else 0,
        "pipelines_ready": len(haystack_manager.pipelines) if haystack_manager else 0
    }
    
    if not (haystack_manager and haystack_manager.is_ready):
        health_status["status"] = "degraded"
        raise HTTPException(status_code=503, detail="Haystack services not ready")
    
    return health_status

# Include API routers
app.include_router(auth.router, prefix="/api/auth", tags=["authentication"])
app.include_router(workflows.router, prefix="/api/v1/workflows", tags=["workflows"])
app.include_router(monitoring.router, prefix="/api/v1/monitoring", tags=["monitoring"])
app.include_router(search.router, prefix="/api/v1/search", tags=["search"])
app.include_router(admin.router, prefix="/api/v1/admin", tags=["admin"])

if __name__ == "__main__":
    # For Windows development
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level="info" if not settings.debug else "debug"
    )
