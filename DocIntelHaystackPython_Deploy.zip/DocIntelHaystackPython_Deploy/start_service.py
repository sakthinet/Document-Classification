"""
Universal Service Starter with Dynamic Port Allocation
Starts any microservice with automatic port management
"""

import sys
import os
import subprocess
import time
import argparse
import json
from pathlib import Path

# Add shared modules to path
current_dir = Path(__file__).parent
shared_dir = current_dir.parent.parent / "shared"
sys.path.append(str(shared_dir))

try:
    from port_manager import PortManager, allocate_port
    PORT_MANAGER_AVAILABLE = True
except ImportError:
    PORT_MANAGER_AVAILABLE = False
    print("⚠️ Port manager not available, using fallback port allocation")

class ServiceStarter:
    """Universal service starter with dynamic ports"""
    
    def __init__(self):
        self.services_config = {
            "frontend": {
                "default_port": 3000,
                "command": ["npm", "run", "dev"],
                "directory": "client",
                "description": "React Frontend"
            },
            "python_gateway": {
                "default_port": 8006,
                "command": ["python", "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1"],
                "directory": "backend",
                "description": "Python Gateway with Haystack"
            },
            "ocr_service": {
                "default_port": 8001,
                "command": ["python", "main.py"],
                "directory": "microservices/ocr_service",
                "description": "OCR Document Processing"
            },
            "classification_service": {
                "default_port": 8002,
                "command": ["python", "main.py"],
                "directory": "microservices/classification_service",
                "description": "Document Classification"
            },
            "vector_search": {
                "default_port": 8003,
                "command": ["python", "main.py"],
                "directory": "microservices/vector_search",
                "description": "Vector Search Service"
            },
            "pii_detection": {
                "default_port": 8004,
                "command": ["python", "main.py"],
                "directory": "microservices/pii_detection",
                "description": "PII Detection Service"
            },
            "pipeline_config": {
                "default_port": 8005,
                "command": ["python", "main.py"],
                "directory": "microservices/pipeline_config",
                "description": "Pipeline Configuration Service"
            },
            "model_serving": {
                "default_port": 8006,
                "command": ["python", "main.py"],
                "directory": "microservices/model_serving",
                "description": "Model Serving Service"
            }
        }
    
    def find_free_port(self, start_port: int, max_attempts: int = 20) -> int:
        """Find a free port starting from start_port"""
        import socket
        for port in range(start_port, start_port + max_attempts):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(1)
                    result = sock.connect_ex(('localhost', port))
                    if result != 0:
                        # Double check by trying to bind
                        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as test_sock:
                            test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                            test_sock.bind(('127.0.0.1', port))
                            return port
            except:
                continue
        raise RuntimeError(f"No free port found in range {start_port}-{start_port + max_attempts}")
    
    def allocate_service_port(self, service_name: str) -> int:
        """Allocate a port for the service"""
        if service_name not in self.services_config:
            raise ValueError(f"Unknown service: {service_name}")
        
        default_port = self.services_config[service_name]["default_port"]
        
        if PORT_MANAGER_AVAILABLE:
            try:
                port = allocate_port(service_name, default_port)
                print(f"✅ Port Manager: Allocated port {port} for {service_name}")
                return port
            except Exception as e:
                print(f"⚠️ Port Manager failed: {e}")
        
        # Fallback to manual allocation
        port = self.find_free_port(default_port)
        print(f"🔄 Fallback: Using port {port} for {service_name}")
        return port
    
    def get_python_executable(self) -> str:
        """Get the correct Python executable path"""
        # Try to find the virtual environment Python
        possible_paths = [
            "E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe",
            "backend/haystack_env/Scripts/python.exe",
            "venv/Scripts/python.exe",
            sys.executable
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
        
        return "python"  # Fallback to system python
    
    def start_service(self, service_name: str, custom_port: int = None, 
                     custom_directory: str = None) -> subprocess.Popen:
        """Start a specific service"""
        if service_name not in self.services_config:
            raise ValueError(f"Unknown service: {service_name}. Available: {list(self.services_config.keys())}")
        
        config = self.services_config[service_name]
        
        # Determine port
        if custom_port:
            port = custom_port
            print(f"🔧 Using custom port {port} for {service_name}")
        else:
            port = self.allocate_service_port(service_name)
        
        # Determine directory
        work_dir = custom_directory or config["directory"]
        if not os.path.isabs(work_dir):
            # Make relative to project root
            project_root = Path(__file__).parent
            work_dir = project_root / work_dir
        
        # Ensure directory exists
        if not work_dir.exists():
            raise ValueError(f"Service directory does not exist: {work_dir}")
        
        # Prepare command
        command = config["command"].copy()
        
        # Replace python with correct executable for Python services
        if command[0] == "python":
            command[0] = self.get_python_executable()
        
        # Use specific IP address instead of 0.0.0.0
        host_ip = "127.0.0.1"  # localhost
        
        # Add host and port arguments for services that support it
        if service_name != "frontend":  # Frontend uses different port config
            if "--host" not in command:
                command.extend(["--host", host_ip])
            if "--port" not in command:
                command.extend(["--port", str(port)])
        
        print(f"🚀 Starting {config['description']} ({service_name})")
        print(f"📁 Directory: {work_dir}")
        print(f"🌐 Host: {host_ip}")
        print(f"📍 Port: {port}")
        print(f"🔗 URL: http://{host_ip}:{port}")
        print(f"⚡ Command: {' '.join(command)}")
        print("-" * 50)
        
        # Set environment variables
        env = os.environ.copy()
        if service_name == "frontend":
            env["PORT"] = str(port)
        
        # Start the service
        try:
            process = subprocess.Popen(
                command,
                cwd=work_dir,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            print(f"✅ Started {service_name} (PID: {process.pid}) on port {port}")
            return process
            
        except Exception as e:
            print(f"❌ Failed to start {service_name}: {e}")
            raise
    
    def start_multiple_services(self, service_names: list) -> dict:
        """Start multiple services"""
        processes = {}
        
        for service_name in service_names:
            try:
                process = self.start_service(service_name)
                processes[service_name] = process
                time.sleep(2)  # Give each service time to start
            except Exception as e:
                print(f"❌ Failed to start {service_name}: {e}")
        
        return processes
    
    def check_service_health(self, service_name: str, port: int, host: str = "127.0.0.1") -> bool:
        """Check if a service is healthy"""
        import requests
        
        try:
            response = requests.get(f"http://{host}:{port}/health", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def list_services(self):
        """List all available services"""
        print("📋 Available Services:")
        print("=" * 60)
        for name, config in self.services_config.items():
            print(f"  {name:20} - {config['description']:30} (default port: {config['default_port']})")
    
    def get_service_status(self):
        """Get status of all services"""
        if not PORT_MANAGER_AVAILABLE:
            print("⚠️ Port manager not available, cannot check service status")
            return
        
        try:
            from port_manager import PortManager
            pm = PortManager()
            status = pm.validate_all_ports()
            
            print("📊 Service Status:")
            print("=" * 60)
            for service_name, config in self.services_config.items():
                port = pm.get_service_port(service_name)
                if port:
                    is_running = status.get(service_name, False)
                    status_icon = "🟢" if is_running else "🔴"
                    print(f"  {status_icon} {service_name:20} - Port {port:5} - {config['description']}")
                else:
                    print(f"  ⚪ {service_name:20} - No port assigned - {config['description']}")
        except Exception as e:
            print(f"❌ Error checking service status: {e}")

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="Universal Service Starter with Dynamic Ports")
    parser.add_argument("service", nargs="?", help="Service name to start")
    parser.add_argument("--port", type=int, help="Custom port number")
    parser.add_argument("--directory", help="Custom working directory")
    parser.add_argument("--list", action="store_true", help="List available services")
    parser.add_argument("--status", action="store_true", help="Show service status")
    parser.add_argument("--all", action="store_true", help="Start all services")
    parser.add_argument("--microservices", action="store_true", help="Start all microservices only")
    
    args = parser.parse_args()
    
    starter = ServiceStarter()
    
    if args.list:
        starter.list_services()
        return
    
    if args.status:
        starter.get_service_status()
        return
    
    if args.all:
        services = list(starter.services_config.keys())
        print(f"🚀 Starting all services: {', '.join(services)}")
        processes = starter.start_multiple_services(services)
        
        print(f"\n✅ Started {len(processes)}/{len(services)} services")
        print("Press Ctrl+C to stop all services...")
        
        try:
            # Keep main process alive
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 Stopping all services...")
            for name, process in processes.items():
                process.terminate()
        return
    
    if args.microservices:
        microservices = [
            "python_gateway", "ocr_service", "classification_service", 
            "vector_search", "pii_detection", "pipeline_config"
        ]
        print(f"🚀 Starting microservices: {', '.join(microservices)}")
        processes = starter.start_multiple_services(microservices)
        
        print(f"\n✅ Started {len(processes)}/{len(microservices)} microservices")
        print("Press Ctrl+C to stop all services...")
        
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 Stopping all microservices...")
            for name, process in processes.items():
                process.terminate()
        return
    
    if args.service:
        try:
            process = starter.start_service(args.service, args.port, args.directory)
            
            print(f"\n✅ {args.service} is running (PID: {process.pid})")
            print("Press Ctrl+C to stop the service...")
            
            try:
                # Stream output
                for line in process.stdout:
                    print(line.rstrip())
            except KeyboardInterrupt:
                print(f"\n🛑 Stopping {args.service}...")
                process.terminate()
                
        except Exception as e:
            print(f"❌ Error: {e}")
    else:
        print("🔧 Universal Service Starter")
        print("Use --help for available options")
        starter.list_services()

if __name__ == "__main__":
    main()
