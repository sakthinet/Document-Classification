#!/usr/bin/env python3
"""
Quick Setup Script for DocIntel Haystack AI
Automates the installation process for new machines
"""

import os
import sys
import subprocess
import platform

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def check_prerequisites():
    """Check if required software is installed"""
    print("🔍 Checking prerequisites...")
    
    # Check Python
    try:
        python_version = subprocess.run([sys.executable, "--version"], capture_output=True, text=True)
        print(f"✅ Python: {python_version.stdout.strip()}")
    except:
        print("❌ Python not found")
        return False
    
    # Check Node.js
    try:
        node_version = subprocess.run(["node", "--version"], capture_output=True, text=True)
        npm_version = subprocess.run(["npm", "--version"], capture_output=True, text=True)
        print(f"✅ Node.js: {node_version.stdout.strip()}")
        print(f"✅ npm: {npm_version.stdout.strip()}")
    except:
        print("❌ Node.js/npm not found")
        return False
    
    return True

def setup_python_environment():
    """Set up Python virtual environment and install dependencies"""
    print("\n🐍 Setting up Python environment...")
    
    # Create virtual environment
    if not run_command(f"{sys.executable} -m venv backend/haystack_env", "Creating virtual environment"):
        return False
    
    # Determine activation script based on OS
    if platform.system() == "Windows":
        activate_script = "backend/haystack_env/Scripts/python.exe"
        pip_script = "backend/haystack_env/Scripts/pip.exe"
    else:
        activate_script = "backend/haystack_env/bin/python"
        pip_script = "backend/haystack_env/bin/pip"
    
    # Upgrade pip
    if not run_command(f"{pip_script} install --upgrade pip", "Upgrading pip"):
        return False
    
    # Install requirements
    install_cmd = f"{pip_script} install -r backend/requirements_optimized.txt --index-url https://download.pytorch.org/whl/cpu --extra-index-url https://pypi.org/simple"
    if not run_command(install_cmd, "Installing Python dependencies (this may take several minutes)"):
        print("⚠️ Optimized requirements failed, trying standard requirements...")
        fallback_cmd = f"{pip_script} install -r backend/requirements.txt"
        if not run_command(fallback_cmd, "Installing standard Python dependencies"):
            return False
    
    return True

def setup_nodejs_environment():
    """Set up Node.js environment and install dependencies"""
    print("\n📦 Setting up Node.js environment...")
    
    # Install npm dependencies
    if not run_command("npm install", "Installing Node.js dependencies"):
        return False
    
    return True

def verify_installation():
    """Verify the installation was successful"""
    print("\n🧪 Verifying installation...")
    
    # Test Python environment
    if platform.system() == "Windows":
        python_script = "backend/haystack_env/Scripts/python.exe"
    else:
        python_script = "backend/haystack_env/bin/python"
    
    test_cmd = f'{python_script} -c "from haystack import Pipeline; from haystack.components.embedders import SentenceTransformersTextEmbedder; print(\\"✅ Haystack AI installed successfully!\\")"'
    if not run_command(test_cmd, "Testing Haystack AI installation"):
        return False
    
    # Test Node.js environment
    if not run_command("npm run dev --dry-run", "Testing Node.js setup"):
        print("⚠️ Node.js dry-run test failed, but dependencies are installed")
    
    return True

def main():
    """Main setup function"""
    print("🚀 DocIntel Haystack AI - Quick Setup")
    print("=" * 50)
    
    # Check prerequisites
    if not check_prerequisites():
        print("\n❌ Prerequisites not met. Please install Python 3.13+ and Node.js 18+")
        sys.exit(1)
    
    # Change to script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    print(f"\n📂 Working directory: {script_dir}")
    
    # Setup Python environment
    if not setup_python_environment():
        print("\n❌ Python environment setup failed")
        sys.exit(1)
    
    # Setup Node.js environment
    if not setup_nodejs_environment():
        print("\n❌ Node.js environment setup failed")
        sys.exit(1)
    
    # Verify installation
    if not verify_installation():
        print("\n⚠️ Installation verification had issues, but setup may still work")
    
    print("\n🎉 Installation completed successfully!")
    print("\n📋 Next steps:")
    print("1. Activate Python environment:")
    if platform.system() == "Windows":
        print("   backend\\haystack_env\\Scripts\\Activate.ps1")
    else:
        print("   source backend/haystack_env/bin/activate")
    print("2. Start backend services: python start_services.py")
    print("3. In another terminal, start frontend: npm run dev")
    print("\n📖 For detailed instructions, see INSTALLATION_GUIDE.md")

if __name__ == "__main__":
    main()
