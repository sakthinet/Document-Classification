## ✅ CURRENT STATUS UPDATE (September 7, 2025)

**🎉 ISSUE RESOLVED**: The Python Gateway port conflict has been fixed!

### Fixed Configuration:
- **Python Gateway**: Now properly running on port **8006** (instead of conflicting with frontend on 8000)
- **Frontend**: Remains on port **8000** 
- **All Services**: Port allocations updated and coordinated

### Key Fixes Applied:
1. ✅ Updated `backend/app/config/settings.py` - Changed default port from 8000 to 8006 and host to 127.0.0.1
2. ✅ Updated `start_services.py` - Python Gateway command now uses port 8006 and host 127.0.0.1
3. ✅ Updated `quick_check.py` - Health checks now target correct port 8006
4. ✅ Updated `port_config.json` - Added all service port mappings
5. ✅ Updated frontend status monitoring - Points to correct backend port
6. ✅ **NEW**: Updated ALL microservices to use 127.0.0.1 instead of 0.0.0.0 for better compatibility
   - OCR Service (8001): Now uses 127.0.0.1
   - Classification Service (8002): Now uses 127.0.0.1
   - Vector Search (8003): Now uses 127.0.0.1
   - PII Detection (8004): Now uses 127.0.0.1
   - Pipeline Config (8005): Now uses 127.0.0.1
   - Python Gateway (8006): Now uses 127.0.0.1

### Verification Results:
- ✅ **Python Gateway starts successfully** on port 8006
- ✅ **Haystack AI integration working** - All components initialized  
- ✅ **Health endpoints responding** - Returns 200 OK status
- ✅ **Port conflicts resolved** - No more frontend/backend collision
- ✅ **Service monitoring updated** - Dashboard shows correct ports

---

# 🚀 DocIntel Haystack AI - Complete Startup Guide

## Overview
Complete startup guide for the Haystack-powered document processing system with dynamic port allocation and microservices architecture.

## Prerequisites
- Python 3.13+ with virtual environment activated
- Node.js 18+ with npm
- PowerShell (Windows)
- All dependencies installed

## Quick Start (Recommended)

### Two-Terminal Approach

#### Terminal 1: Backend Services
```powershell
# Navigate to project root
cd e:\Dev_Branch\DataClassification\DocIntelHaystackPython

# Start all Python backend services
E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe fast_start.py
```

#### Terminal 2: Frontend Service
```powershell
# In the same project root directory
# Start the React frontend with dynamic port allocation
npm run dev
```

## What Happens During Startup

### Backend Services (`fast_start.py`)
1. **Port Manager Initialization**: Shared port allocation system starts
2. **Python Gateway**: Main API gateway (typically port 8000)
3. **Microservices Launch**:
   - Classification Service
   - OCR Service
   - PII Detection Service
   - Vector Search Service
   - Pipeline Configuration Service
4. **Health Checks**: Automatic verification of all services

### Frontend Service (`npm run dev`)
1. **Dynamic Port Detection**: Communicates with Python port manager
2. **Port Allocation**: Gets assigned available port (avoiding conflicts)
3. **Development Server**: Starts React app with hot reload
4. **Backend Integration**: Automatically connects to Python Gateway

## Service Architecture

### Core Services
- **Python Gateway** (Port 8000): Main API router and coordinator
- **Frontend Server** (Dynamic Port): React development server
- **Classification Service**: Document type classification
- **OCR Service**: Text extraction from images/PDFs
- **PII Detection**: Personal information identification
- **Vector Search**: Semantic document search
- **Pipeline Config**: Haystack pipeline management

### Port Management
- **Dynamic Allocation**: Prevents port conflicts
- **Shared Registry**: All services coordinate through central manager
- **IP Binding**: All services bind to 127.0.0.1 for security

## Verification Steps

### 1. Check Service Status
```powershell
# Run health check (after ~30 seconds)
E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe quick_check.py
```

### 2. Access Frontend
- URL will be displayed in Terminal 2 (typically `http://localhost:3000` or similar)
- Dashboard should show all microservices as "Online"

### 3. Test API Gateway
```powershell
# Test main gateway health
Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method GET
```

## Troubleshooting

### Common Issues

#### Port Conflicts
**Symptom**: Services fail to start with "Address already in use"
**Solution**: 
```powershell
# Check what's using ports
netstat -ano | findstr "LISTENING" | findstr ":800"
# Kill conflicting processes if needed
```

#### Frontend Connection Issues
**Symptom**: Frontend can't connect to backend
**Solution**:
1. Ensure Python Gateway is running on port 8000
2. Check Windows Firewall settings
3. Verify no proxy/VPN interference

#### Service Startup Delays
**Symptom**: Health checks fail initially
**Solution**: 
- Wait 30-60 seconds for all services to fully initialize
- Haystack model loading can take time on first run

### Advanced Troubleshooting

#### Individual Service Testing
```powershell
# Test specific service (example: pipeline config)
Invoke-RestMethod -Uri "http://127.0.0.1:8007/health" -Method GET
```

#### Manual Service Restart
```powershell
# If a service fails, restart it individually
E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe start_service.py classification_service
```

#### Log Analysis
- Service logs appear in the terminal where `fast_start.py` is running
- Look for error messages during startup
- Check for missing dependencies or configuration issues

## Alternative Startup Methods

### PowerShell Script (Single Command)
```powershell
# If available, use the automated script
PowerShell -ExecutionPolicy Bypass -File "start-dev.ps1"
```

### Docker Deployment (Future)
```bash
# When Docker setup is complete
docker-compose up -d
```

## Development Workflow

### Making Changes
1. **Backend Changes**: Services auto-reload with `--reload` flag
2. **Frontend Changes**: Hot reload active by default
3. **Configuration Changes**: May require service restart

### Testing
```powershell
# Run comprehensive health check
E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe health_check.py
```

### Stopping Services
- **Frontend**: Ctrl+C in Terminal 2
- **Backend**: Ctrl+C in Terminal 1 (stops all Python services)

## Performance Notes

### First-Time Startup
- **Duration**: 2-5 minutes (model downloads and cache building)
- **Resources**: High CPU/memory usage initially
- **Storage**: ~2-4GB for Haystack models and dependencies

### Subsequent Startups
- **Duration**: 30-90 seconds
- **Resources**: Moderate resource usage
- **Caching**: Models and configurations cached for faster loading

## Security Considerations

### Local Development
- All services bind to `127.0.0.1` (localhost only)
- No external network exposure by default
- Authentication disabled in development mode

### Production Deployment
- Enable authentication and authorization
- Configure proper firewall rules
- Use environment variables for sensitive configurations
- Consider HTTPS/TLS termination

## Support and Documentation

### Key Files
- `README.md`: Project overview and basic setup
- `SERVICE_ARCHITECTURE.md`: Detailed service documentation
- `HAYSTACK_LICENSING_ANALYSIS.md`: Licensing information
- `HAYSTACK_COMPLIANCE_ANALYSIS.md`: Compliance details

### Getting Help
1. Check service logs for specific error messages
2. Verify all prerequisites are installed
3. Ensure virtual environment is properly activated
4. Review port allocation conflicts

---

**Last Updated**: January 2025  
**Compatible With**: Haystack 2.17.1, Python 3.13, Node.js 18+
