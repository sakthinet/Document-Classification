# Overview

DocIntel Pro is a comprehensive document intelligence platform built on the Haystack framework for AI-powered document processing. The system provides semantic search, classification, extraction, and analytics capabilities for various document types including generic documents, BFSI (Banking, Financial Services, Insurance) documents, and HR documents. The platform features a React-based frontend with a FastAPI backend, leveraging modern AI/ML technologies for intelligent document processing workflows.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript 5 and Vite for build tooling
- **UI Library**: Radix UI components with Tailwind CSS for styling (New York theme variant)
- **State Management**: Zustand for pipeline configuration state, React Query for server state
- **Routing**: Wouter for client-side routing
- **Real-time Communication**: WebSocket integration for live updates

## Backend Architecture
- **API Framework**: Express.js with TypeScript for RESTful APIs
- **Database ORM**: Drizzle ORM with PostgreSQL for data persistence
- **AI Framework**: Haystack framework integration for document processing pipelines
- **Service Layer**: Modular service architecture with separate services for:
  - Pipeline configuration management
  - Document processing workflows
  - Classification and NLP operations
  - Vector store management
  - Analytics and system metrics

## Database Design
- **PostgreSQL** with the following core entities:
  - Users (authentication and user management)
  - Pipeline Configurations (Haystack pipeline definitions)
  - Document Sources (data source configurations)
  - Processing Jobs (batch processing workflows)
  - Document Entities (processed document metadata)
  - System Metrics (performance and analytics tracking)

## Document Processing Pipeline
- **Source Types**: Generic, BFSI, and HR document processing with specialized rules
- **Processing Steps**: Multi-stage pipeline with source selection, connection configuration, processing rules, and output destinations
- **AI Capabilities**: Classification, NER, extraction, summarization using configurable models
- **Output Options**: Vector stores, databases, file storage, and API webhooks

## Vector Store Integration
- **Purpose**: Semantic search and similarity matching capabilities
- **Implementation**: Configurable vector store connections (designed for Qdrant)
- **Features**: Embedding generation, similarity search, and vector analytics

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit**: Database migrations and schema management

## AI/ML Services
- **Haystack Framework**: Core document processing and NLP pipeline orchestration
- **Sentence Transformers**: Text embedding models for semantic search
- **OpenAI API**: Large language model integration for advanced NLP tasks
- **PaddleOCR**: Optical character recognition for document scanning

## UI Component Libraries
- **Radix UI**: Accessible component primitives for dialog, dropdown, form controls
- **Lucide React**: Icon library for consistent iconography
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens

## Development Tools
- **Vite**: Build tool with hot module replacement and optimized bundling
- **TypeScript**: Static type checking across frontend and backend
- **ESBuild**: Fast JavaScript bundler for production builds
- **React Hook Form**: Form state management with validation
- **Zod**: Runtime type validation and schema parsing