# Complete DocIntel Haystack Project Folder Structure

```
DOCINTEL-HAYSTACK-PYTHON/
│
├── 📱 client/                                    # LAYER 6: Frontend (React + TypeScript)
│   ├── src/
│   │   ├── components/
│   │   │   ├── WorkflowBuilder/                 # Your existing workflow builder
│   │   │   │   ├── SourceTypeSelector.tsx
│   │   │   │   ├── ConnectionConfig.tsx
│   │   │   │   ├── ProcessingRules.tsx
│   │   │   │   ├── OutputDestinations.tsx
│   │   │   │   └── TestConfiguration.tsx
│   │   │   ├── HaystackPipeline/               # New Haystack components
│   │   │   │   ├── PipelineBuilder.tsx
│   │   │   │   ├── ComponentSelector.tsx
│   │   │   │   ├── PipelineStatus.tsx
│   │   │   │   └── ResultsViewer.tsx
│   │   │   ├── MonitoringDashboard/
│   │   │   │   ├── index.tsx
│   │   │   │   ├── ExecutionMonitor.tsx
│   │   │   │   ├── PerformanceMetrics.tsx
│   │   │   │   └── TaskProgress.tsx
│   │   │   └── SearchInterface/
│   │   │       ├── index.tsx
│   │   │       ├── SemanticSearch.tsx
│   │   │       ├── FacetedFilters.tsx
│   │   │       └── ResultsDisplay.tsx
│   │   ├── services/
│   │   │   ├── api.ts                          # API client
│   │   │   ├── websocket.ts                    # WebSocket client
│   │   │   └── auth.ts                         # Authentication
│   │   ├── store/                              # Redux store
│   │   │   ├── index.ts
│   │   │   ├── workflowSlice.ts
│   │   │   ├── monitoringSlice.ts
│   │   │   └── searchSlice.ts
│   │   ├── hooks/                              # Custom React hooks
│   │   │   ├── useWorkflow.ts
│   │   │   ├── useWebSocket.ts
│   │   │   └── useSearch.ts
│   │   ├── types/                              # TypeScript definitions
│   │   │   ├── workflow.ts
│   │   │   ├── api.ts
│   │   │   └── haystack.ts
│   │   └── utils/
│   │       ├── validation.ts
│   │       └── formatters.ts
│   ├── public/
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts
│
├── 🌊 backend/                                   # LAYER 1: FastAPI Gateway
│   ├── app/
│   │   ├── main.py                             # FastAPI application
│   │   ├── config/
│   │   │   ├── __init__.py
│   │   │   ├── settings.py                     # Pydantic settings
│   │   │   ├── database.py                     # Database configuration
│   │   │   └── security.py                     # Security configuration
│   │   ├── api/
│   │   │   ├── __init__.py
│   │   │   ├── deps.py                         # Dependencies
│   │   │   ├── auth.py                         # Authentication routes
│   │   │   └── v1/
│   │   │       ├── __init__.py
│   │   │       ├── workflows.py                # Workflow endpoints
│   │   │       ├── monitoring.py               # Monitoring endpoints
│   │   │       ├── search.py                   # Search endpoints
│   │   │       └── admin.py                    # Admin endpoints
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── workflow.py                     # Pydantic models
│   │   │   ├── user.py                         # User models
│   │   │   ├── document.py                     # Document models
│   │   │   └── monitoring.py                   # Monitoring models
│   │   ├── core/
│   │   │   ├── __init__.py
│   │   │   ├── auth.py                         # JWT authentication
│   │   │   ├── websocket.py                    # WebSocket manager
│   │   │   └── exceptions.py                   # Custom exceptions
│   │   └── utils/
│   │       ├── __init__.py
│   │       ├── validation.py
│   │       └── helpers.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
│
├── 🔧 haystack_service/                         # LAYER 2: Haystack Pipeline Service
│   ├── src/
│   │   ├── __init__.py
│   │   ├── pipeline_factory.py                 # Pipeline factory
│   │   ├── components/
│   │   │   ├── __init__.py
│   │   │   ├── hr_classifier.py                # HR document classifier
│   │   │   ├── bfsi_classifier.py              # BFSI document classifier
│   │   │   ├── pii_detector.py                 # PII detection
│   │   │   ├── security_tagger.py              # Security tagging
│   │   │   └── metadata_enricher.py            # Metadata enrichment
│   │   ├── pipelines/
│   │   │   ├── __init__.py
│   │   │   ├── hr_pipeline.py                  # HR processing pipeline
│   │   │   ├── bfsi_pipeline.py                # BFSI processing pipeline
│   │   │   └── generic_pipeline.py             # Generic processing pipeline
│   │   ├── execution/
│   │   │   ├── __init__.py
│   │   │   ├── manager.py                      # Pipeline execution manager
│   │   │   ├── monitor.py                      # Execution monitoring
│   │   │   └── metrics.py                      # Performance metrics
│   │   └── utils/
│   │       ├── __init__.py
│   │       ├── model_loader.py                 # Model loading utilities
│   │       └── optimization.py                 # Performance optimization
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── test_pipelines.py
│   │   └── test_components.py
│   ├── requirements.txt
│   └── Dockerfile
│
├── 🔄 airflow/                                  # LAYER 3: Apache Airflow Orchestration
│   ├── dags/
│   │   ├── __init__.py
│   │   ├── docitel_workflow_dag.py             # Main workflow DAG
│   │   ├── hr_processing_dag.py                # HR-specific DAG
│   │   ├── bfsi_processing_dag.py              # BFSI-specific DAG
│   │   └── task_functions.py                   # Reusable task functions
│   ├── operators/
│   │   ├── __init__.py
│   │   ├── haystack_pipeline_operator.py       # Custom Haystack operator
│   │   ├── document_source_operator.py         # Document scanning operator
│   │   └── classification_operator.py          # Classification routing operator
│   ├── plugins/
│   │   ├── __init__.py
│   │   └── docitel_plugin.py                   # Custom Airflow plugin
│   ├── config/
│   │   ├── airflow.cfg                         # Airflow configuration
│   │   └── connections.py                      # Connection definitions
│   ├── requirements.txt
│   └── Dockerfile
│
├── ⚙️ services/                                 # LAYER 4: Business Services
│   ├── workflow_service/
│   │   ├── __init__.py
│   │   ├── main.py                             # Workflow service app
│   │   ├── models.py                           # SQLAlchemy models
│   │   ├── crud.py                             # CRUD operations
│   │   ├── service.py                          # Business logic
│   │   └── schemas.py                          # Pydantic schemas
│   ├── document_service/
│   │   ├── __init__.py
│   │   ├── main.py                             # Document service app
│   │   ├── connectors/
│   │   │   ├── __init__.py
│   │   │   ├── network_folder.py               # Network folder connector
│   │   │   ├── sharepoint.py                   # SharePoint connector
│   │   │   ├── email.py                        # Email connector
│   │   │   └── database.py                     # Database connector
│   │   ├── processors/
│   │   │   ├── __init__.py
│   │   │   ├── classification.py               # Classification processor
│   │   │   ├── routing.py                      # Routing processor
│   │   │   └── metadata.py                     # Metadata processor
│   │   └── utils/
│   │       ├── __init__.py
│   │       └── file_utils.py
│   ├── user_service/
│   │   ├── __init__.py
│   │   ├── main.py                             # User service app
│   │   ├── auth.py                             # Authentication logic
│   │   ├── models.py                           # User models
│   │   └── permissions.py                      # Permission management
│   └── notification_service/
│       ├── __init__.py
│       ├── main.py                             # Notification service
│       ├── email_notifier.py                   # Email notifications
│       ├── slack_notifier.py                   # Slack notifications
│       └── webhook_notifier.py                 # Webhook notifications
│
├── 💾 storage/                                  # LAYER 5: Storage Integration
│   ├── __init__.py
│   ├── managers/
│   │   ├── __init__.py
│   │   ├── storage_manager.py                  # Unified storage manager
│   │   ├── local_nas.py                        # Local NAS manager
│   │   ├── azure_blob.py                       # Azure Blob manager
│   │   ├── minio_manager.py                    # MinIO manager
│   │   └── s3_manager.py                       # S3 manager
│   ├── vector_db/
│   │   ├── __init__.py
│   │   ├── qdrant_service.py                   # Qdrant integration
│   │   ├── elasticsearch_service.py            # Elasticsearch integration
│   │   └── search_service.py                   # Unified search service
│   ├── metadata/
│   │   ├── __init__.py
│   │   ├── postgres_metadata.py                # PostgreSQL metadata
│   │   ├── mongodb_metadata.py                 # MongoDB metadata
│   │   └── metadata_service.py                 # Metadata service
│   ├── cache/
│   │   ├── __init__.py
│   │   ├── redis_cache.py                      # Redis cache manager
│   │   └── memory_cache.py                     # In-memory cache
│   └── utils/
│       ├── __init__.py
│       ├── encryption.py                       # Encryption utilities
│       └── compression.py                      # Compression utilities
│
├── 🗄️ database/                                # Database Layer
│   ├── alembic/
│   │   ├── versions/                           # Migration files
│   │   ├── env.py                              # Alembic environment
│   │   └── script.py.mako                      # Migration template
│   ├── models/
│   │   ├── __init__.py
│   │   ├── base.py                             # Base model class
│   │   ├── user.py                             # User tables
│   │   ├── workflow.py                         # Workflow tables
│   │   ├── document.py                         # Document tables
│   │   └── audit.py                            # Audit tables
│   ├── seeds/
│   │   ├── __init__.py
│   │   ├── users.py                            # Seed users
│   │   ├── workflows.py                        # Seed workflow templates
│   │   └── permissions.py                      # Seed permissions
│   └── alembic.ini                             # Alembic configuration
│
├── 📊 monitoring/                               # Monitoring & Observability
│   ├── __init__.py
│   ├── prometheus/
│   │   ├── metrics.py                          # Custom metrics
│   │   └── middleware.py                       # Metrics middleware
│   ├── logging/
│   │   ├── __init__.py
│   │   ├── formatters.py                       # Log formatters
│   │   └── handlers.py                         # Log handlers
│   ├── health/
│   │   ├── __init__.py
│   │   ├── checks.py                           # Health check functions
│   │   └── endpoints.py                        # Health endpoints
│   └── tracing/
│       ├── __init__.py
│       └── opentelemetry_setup.py              # Distributed tracing
│
├── 🔒 security/                                # Security & Compliance
│   ├── __init__.py
│   ├── auth/
│   │   ├── __init__.py
│   │   ├── jwt_handler.py                      # JWT token handling
│   │   ├── oauth.py                            # OAuth integration
│   │   └── rbac.py                             # Role-based access control
│   ├── encryption/
│   │   ├── __init__.py
│   │   ├── document_encryption.py              # Document encryption
│   │   ├── key_management.py                   # Key management
│   │   └── pii_masking.py                      # PII masking
│   ├── compliance/
│   │   ├── __init__.py
│   │   ├── gdpr.py                             # GDPR compliance
│   │   ├── hipaa.py                            # HIPAA compliance
│   │   └── sox.py                              # SOX compliance
│   └── audit/
│       ├── __init__.py
│       ├── logger.py                           # Audit logging
│       └── reports.py                          # Compliance reports
│
├── 🚀 deployment/                              # LAYER 7: Configuration & Deployment
│   ├── docker/
│   │   ├── Dockerfile.backend                  # Backend Dockerfile
│   │   ├── Dockerfile.frontend                 # Frontend Dockerfile
│   │   ├── Dockerfile.haystack                 # Haystack service Dockerfile
│   │   ├── Dockerfile.airflow                  # Airflow Dockerfile
│   │   └── docker-compose.yml                  # Full stack compose
│   ├── kubernetes/
│   │   ├── namespace.yaml                      # K8s namespace
│   │   ├── configmaps/                         # Configuration maps
│   │   ├── deployments/                        # Service deployments
│   │   ├── services/                           # K8s services
│   │   ├── ingress/                            # Ingress controllers
│   │   └── volumes/                            # Persistent volumes
│   ├── terraform/                              # Infrastructure as Code
│   │   ├── main.tf                             # Main Terraform config
│   │   ├── variables.tf                        # Variable definitions
│   │   ├── outputs.tf                          # Output definitions
│   │   ├── modules/                            # Terraform modules
│   │   └── environments/                       # Environment configs
│   ├── ansible/                                # Configuration management
│   │   ├── playbooks/                          # Ansible playbooks
│   │   ├── roles/                              # Ansible roles
│   │   └── inventory/                          # Environment inventory
│   ├── scripts/
│   │   ├── setup.sh                            # Setup script
│   │   ├── deploy.sh                           # Deployment script
│   │   ├── backup.sh                           # Backup script
│   │   └── monitoring.sh                       # Monitoring setup
│   └── configs/
│       ├── nginx.conf                          # Nginx configuration
│       ├── prometheus.yml                      # Prometheus config
│       ├── grafana/                            # Grafana dashboards
│       └── environments/                       # Environment configs
│           ├── development.env
│           ├── staging.env
│           └── production.env
│
├── 📋 tests/                                   # Testing
│   ├── __init__.py
│   ├── unit/                                   # Unit tests
│   │   ├── test_backend/
│   │   ├── test_haystack/
│   │   ├── test_services/
│   │   └── test_storage/
│   ├── integration/                            # Integration tests
│   │   ├── test_api/
│   │   ├── test_pipelines/
│   │   └── test_workflows/
│   ├── e2e/                                    # End-to-end tests
│   │   ├── test_user_workflows/
│   │   └── test_document_processing/
│   ├── fixtures/                               # Test fixtures
│   │   ├── sample_documents/
│   │   ├── mock_data/
│   │   └── test_configs/
│   └── utils/
│       ├── __init__.py
│       ├── test_helpers.py
│       └── mock_services.py
│
├── 📖 docs/                                    # Documentation
│   ├── api/                                    # API documentation
│   ├── architecture/                           # Architecture docs
│   ├── deployment/                             # Deployment guides
│   ├── user/                                   # User manuals
│   └── development/                            # Developer guides
│
├── 📦 shared/                                  # Shared utilities (keep existing)
│   ├── __init__.py
│   ├── constants.py                            # Shared constants
│   ├── exceptions.py                           # Shared exceptions
│   ├── types.py                                # Shared type definitions
│   └── utils.py                                # Shared utilities
│
├── 🔧 tools/                                   # Development tools
│   ├── scripts/
│   │   ├── generate_docs.py                    # Documentation generator
│   │   ├── run_tests.py                        # Test runner
│   │   └── code_quality.py                     # Code quality checks
│   ├── migrations/
│   │   └── data_migration.py                   # Data migration scripts
│   └── monitoring/
│       └── performance_profiler.py             # Performance profiling
│
├── .env                                        # Environment variables (keep existing)
├── .env.example                                # Environment template
├── .gitignore                                  # Git ignore (keep existing)
├── .pre-commit-config.yaml                     # Pre-commit hooks
├── docker-compose.yml                          # Main docker compose
├── docker-compose.dev.yml                      # Development compose
├── docker-compose.prod.yml                     # Production compose
├── Makefile                                    # Build automation
├── pyproject.toml                              # Python project config
├── requirements.txt                            # Python dependencies
├── package.json                                # Node.js dependencies (keep existing)
├── README.md                                   # Project documentation
├── CONTRIBUTING.md                             # Contribution guidelines
├── LICENSE                                     # License file
└── CHANGELOG.md                                # Change log
```

## 🎯 **Layer Separation Strategy**

### **Frontend (Layer 6) - `client/`**
- Keep your existing React frontend structure
- Add new Haystack-specific components
- Maintain existing Ant Design components

### **API Gateway (Layer 1) - `backend/`**
- FastAPI application with clean API structure
- Authentication and authorization
- WebSocket management for real-time updates

### **AI Processing (Layer 2) - `haystack_service/`**
- Isolated Haystack pipeline service
- Custom components and pipeline factories
- Independent deployment and scaling

### **Orchestration (Layer 3) - `airflow/`**
- Complete Airflow setup with custom operators
- DAG definitions for workflow orchestration
- Airflow plugins for DocIntel integration

### **Business Logic (Layer 4) - `services/`**
- Microservices architecture
- Domain-specific services (workflow, document, user)
- Independent scaling and deployment

### **Storage (Layer 5) - `storage/`**
- Unified storage abstraction layer
- Multiple storage backend support
- Vector database and search integration

### **Infrastructure (Layer 7) - `deployment/`**
- Complete deployment automation
- Environment-specific configurations
- Monitoring and observability setup

## 🚀 **Implementation Order**

1. **Start with `backend/`** - Set up FastAPI gateway
2. **Add `database/`** - Create database schema and migrations
3. **Implement `haystack_service/`** - Build core AI processing
4. **Set up `airflow/`** - Add workflow orchestration
5. **Build `services/`** - Implement business logic services
6. **Configure `storage/`** - Set up storage and search
7. **Enhance `client/`** - Connect frontend to new backend
8. **Deploy with `deployment/`** - Production deployment setup

This structure provides clear separation of concerns while maintaining the ability to develop, test, and deploy each layer independently.