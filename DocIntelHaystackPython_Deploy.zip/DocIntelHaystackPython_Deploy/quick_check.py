"""
Quick Service Health Check and Performance Fix
"""
import requests
import time
import sys

def get_frontend_port():
    """Get the frontend port from port manager"""
    try:
        import sys
        import os
        sys.path.append('shared')
        from port_manager import get_service_port
        port = get_service_port('frontend')
        return port if port else 3000
    except:
        return 3000

def quick_health_check():
    """Quick check of all service endpoints"""
    services = {
        "Python Gateway": "http://127.0.0.1:8006/health",  # Updated to use actual port
        "OCR Service": "http://127.0.0.1:8001/health", 
        "Classification": "http://127.0.0.1:8002/health",
        "Vector Search": "http://127.0.0.1:8003/health",
        "PII Detection": "http://127.0.0.1:8004/health",
        "Pipeline Config": "http://127.0.0.1:8005/health"
    }
    
    # Get dynamic frontend port
    frontend_port = get_frontend_port()
    frontend_url = f"http://127.0.0.1:{frontend_port}"
    
    print("🔍 Testing Service Connectivity:")
    print("=" * 50)
    
    running_services = 0
    
    # Check backend services
    for name, url in services.items():
        try:
            response = requests.get(url, timeout=3)
            if response.status_code == 200:
                print(f"🟢 UP {name} (127.0.0.1:{url.split(':')[-1].split('/')[0]})")
                running_services += 1
            else:
                print(f"❌ {name:15} - Error {response.status_code}")
        except requests.exceptions.RequestException:
            print(f"🔴 DOWN {name} (127.0.0.1:{url.split(':')[-1].split('/')[0]})")
    
    # Check frontend
    try:
        response = requests.get(frontend_url, timeout=3)
        if response.status_code == 200:
            print(f"🟢 UP Frontend (React) (127.0.0.1:{frontend_port})")
            running_services += 1
        else:
            print(f"❌ Frontend (React) - Error {response.status_code}")
    except requests.exceptions.RequestException:
        print(f"🔴 DOWN Frontend (React) (127.0.0.1:{frontend_port})")
    
    total_services = len(services) + 1  # +1 for frontend
    
    print("=" * 50)
    print(f"📊 Services Running: {running_services}/{total_services}")
    
    # Service URLs for reference
    print("\n📋 Service URLs:")
    for name, url in services.items():
        port = url.split(':')[-1].split('/')[0]
        print(f"  http://127.0.0.1:{port}/health - {name}")
    print(f"  http://127.0.0.1:{frontend_port} - Frontend (React) (Main UI)")
    
    if running_services == 0:
        print("\n⚠️  No services are running!")
        print("💡 Run: python fast_start.py to start all services + frontend")
    elif running_services < total_services:
        print(f"\n⚠️  Only {running_services}/{total_services} services running!")
        print("💡 Run: python fast_start.py to start all services + frontend")
    else:
        print("\n🎉 All services + frontend are running perfectly!")
        print(f"📱 Frontend accessible at: http://localhost:{frontend_port}")
    
    return running_services

if __name__ == "__main__":
    quick_health_check()
