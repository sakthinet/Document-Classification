// Semantic Search Interface Component
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  FileText, 
  Clock, 
  BarChart3, 
  Filter,
  Download,
  Eye,
  Sparkles
} from 'lucide-react';

interface SearchResult {
  id: string;
  filename: string;
  similarity: number;
  content: string;
  metadata: {
    category?: string;
    riskLevel?: string;
    uploadDate: string;
    fileSize: number;
  };
  highlights?: string[];
}

interface IndexedDocument {
  id: string;
  filename: string;
  category: string;
  uploadDate: string;
  vectorCount: number;
  status: 'indexed' | 'processing' | 'error';
}

export function SemanticSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [indexedDocuments, setIndexedDocuments] = useState<IndexedDocument[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingIndex, setIsLoadingIndex] = useState(true);
  const [similarityThreshold, setSimilarityThreshold] = useState(0.7);
  const [maxResults, setMaxResults] = useState(10);

  // Mock data for demonstration
  useEffect(() => {
    // Load indexed documents from vector search service
    loadIndexedDocuments();
  }, []);

  const loadIndexedDocuments = async () => {
    setIsLoadingIndex(true);
    try {
      const response = await fetch('http://localhost:8003/list_documents');
      if (response.ok) {
        const documents = await response.json();
        setIndexedDocuments(documents.documents || []);
      } else {
        // Fallback mock data if service is unavailable
        setIndexedDocuments([
          {
            id: 'doc-1',
            filename: 'financial-statement-2024.pdf',
            category: 'Financial Statement',
            uploadDate: '2024-01-15T10:30:00Z',
            vectorCount: 156,
            status: 'indexed'
          },
          {
            id: 'doc-2',
            filename: 'loan-application-john-doe.pdf',
            category: 'Loan Application',
            uploadDate: '2024-01-14T14:22:00Z',
            vectorCount: 89,
            status: 'indexed'
          },
          {
            id: 'doc-3',
            filename: 'compliance-report-q4.docx',
            category: 'Compliance Report',
            uploadDate: '2024-01-13T09:15:00Z',
            vectorCount: 234,
            status: 'indexed'
          }
        ]);
      }
    } catch (error) {
      console.error('Failed to load indexed documents:', error);
      // Use mock data on error
      setIndexedDocuments([]);
    } finally {
      setIsLoadingIndex(false);
    }
  };

  const performSearch = async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    try {
      const response = await fetch('http://localhost:8003/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: searchQuery,
          top_k: maxResults,
          similarity_threshold: similarityThreshold
        }),
      });

      if (response.ok) {
        const results = await response.json();
        setSearchResults(results.results || []);
      } else {
        // Fallback mock results if service is unavailable
        setSearchResults([
          {
            id: 'result-1',
            filename: 'financial-statement-2024.pdf',
            similarity: 0.89,
            content: 'Annual financial statement showing revenue growth of 15% year-over-year with strong balance sheet indicators...',
            metadata: {
              category: 'Financial Statement',
              riskLevel: 'Low',
              uploadDate: '2024-01-15T10:30:00Z',
              fileSize: 2048576
            },
            highlights: ['financial statement', 'revenue growth', 'balance sheet']
          },
          {
            id: 'result-2',
            filename: 'loan-application-john-doe.pdf',
            similarity: 0.76,
            content: 'Loan application for $250,000 home mortgage with credit score 780 and debt-to-income ratio of 28%...',
            metadata: {
              category: 'Loan Application',
              riskLevel: 'Medium',
              uploadDate: '2024-01-14T14:22:00Z',
              fileSize: 1536000
            },
            highlights: ['loan application', 'mortgage', 'credit score']
          }
        ]);
      }
    } catch (error) {
      console.error('Search failed:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch();
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getSimilarityColor = (similarity: number) => {
    if (similarity >= 0.9) return 'text-green-600';
    if (similarity >= 0.8) return 'text-blue-600';
    if (similarity >= 0.7) return 'text-yellow-600';
    return 'text-gray-600';
  };

  const getRiskBadgeVariant = (riskLevel?: string) => {
    switch (riskLevel) {
      case 'High': return 'destructive';
      case 'Medium': return 'secondary';
      case 'Low': return 'default';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Semantic Search</h2>
        <p className="text-muted-foreground">
          Search through indexed documents using natural language queries
        </p>
      </div>

      {/* Search Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="h-5 w-5 mr-2" />
            Document Search
          </CardTitle>
          <CardDescription>
            Use natural language to find relevant documents in your knowledge base
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSearchSubmit} className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Search for documents, e.g., 'financial statements with high revenue' or 'loan applications with good credit scores'"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" disabled={isSearching || !searchQuery.trim()}>
                {isSearching ? (
                  <Clock className="h-4 w-4 animate-spin" />
                ) : (
                  <Search className="h-4 w-4" />
                )}
                {isSearching ? 'Searching...' : 'Search'}
              </Button>
            </div>

            {/* Search Options */}
            <div className="flex space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <label htmlFor="similarity" className="text-muted-foreground">
                  Min Similarity:
                </label>
                <Input
                  id="similarity"
                  type="number"
                  min="0"
                  max="1"
                  step="0.1"
                  value={similarityThreshold}
                  onChange={(e) => setSimilarityThreshold(parseFloat(e.target.value))}
                  className="w-20"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label htmlFor="maxResults" className="text-muted-foreground">
                  Max Results:
                </label>
                <Input
                  id="maxResults"
                  type="number"
                  min="1"
                  max="50"
                  value={maxResults}
                  onChange={(e) => setMaxResults(parseInt(e.target.value))}
                  className="w-20"
                />
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Search Results and Document Index */}
      <Tabs defaultValue="results" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="results" className="flex items-center">
            <Search className="h-4 w-4 mr-1" />
            Search Results ({searchResults.length})
          </TabsTrigger>
          <TabsTrigger value="index" className="flex items-center">
            <FileText className="h-4 w-4 mr-1" />
            Document Index ({indexedDocuments.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="results" className="space-y-4">
          {searchResults.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center text-muted-foreground">
                  <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">No search results yet</p>
                  <p className="text-sm">Enter a search query to find relevant documents</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {searchResults.map((result) => (
                <Card key={result.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg flex items-center">
                          <FileText className="h-5 w-5 mr-2" />
                          {result.filename}
                        </CardTitle>
                        <CardDescription className="flex items-center space-x-2 mt-1">
                          <span>Uploaded: {formatDate(result.metadata.uploadDate)}</span>
                          <span>•</span>
                          <span>{formatFileSize(result.metadata.fileSize)}</span>
                          {result.metadata.category && (
                            <>
                              <span>•</span>
                              <Badge variant="outline">{result.metadata.category}</Badge>
                            </>
                          )}
                          {result.metadata.riskLevel && (
                            <Badge variant={getRiskBadgeVariant(result.metadata.riskLevel)}>
                              {result.metadata.riskLevel} Risk
                            </Badge>
                          )}
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        <div className={`text-lg font-bold ${getSimilarityColor(result.similarity)}`}>
                          {(result.similarity * 100).toFixed(1)}%
                        </div>
                        <div className="text-xs text-muted-foreground">Similarity</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <p className="text-sm line-clamp-3">{result.content}</p>
                      
                      {result.highlights && result.highlights.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          <span className="text-xs text-muted-foreground mr-2">Highlights:</span>
                          {result.highlights.map((highlight, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {highlight}
                            </Badge>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline" className="flex items-center">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button size="sm" variant="outline" className="flex items-center">
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="index" className="space-y-4">
          {isLoadingIndex ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center text-muted-foreground">
                  <Clock className="h-12 w-12 mx-auto mb-4 animate-spin" />
                  <p>Loading document index...</p>
                </div>
              </CardContent>
            </Card>
          ) : indexedDocuments.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">No documents indexed yet</p>
                  <p className="text-sm">Process documents through the pipeline to build your search index</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {/* Index Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Index Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{indexedDocuments.length}</div>
                      <p className="text-xs text-muted-foreground">Total Documents</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">
                        {indexedDocuments.reduce((sum, doc) => sum + doc.vectorCount, 0)}
                      </div>
                      <p className="text-xs text-muted-foreground">Vector Embeddings</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">
                        {indexedDocuments.filter(doc => doc.status === 'indexed').length}
                      </div>
                      <p className="text-xs text-muted-foreground">Successfully Indexed</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold">
                        {new Set(indexedDocuments.map(doc => doc.category)).size}
                      </div>
                      <p className="text-xs text-muted-foreground">Document Categories</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Document List */}
              <div className="space-y-3">
                {indexedDocuments.map((doc) => (
                  <Card key={doc.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <FileText className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{doc.filename}</span>
                            <Badge variant="outline">{doc.category}</Badge>
                            <Badge 
                              variant={
                                doc.status === 'indexed' ? 'default' :
                                doc.status === 'processing' ? 'secondary' :
                                'destructive'
                              }
                            >
                              {doc.status}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Uploaded: {formatDate(doc.uploadDate)} • {doc.vectorCount} vectors
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Filter className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default SemanticSearch;
