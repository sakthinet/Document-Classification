// Microservices Status Dashboard Component
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react';

interface ServiceStatus {
  name: string;
  port: number;
  status: 'running' | 'down' | 'pending';
  description: string;
  health?: {
    status: string;
    service: string;
    version?: string;
  };
  responseTime?: number;
}

const SERVICES: Omit<ServiceStatus, 'health' | 'responseTime'>[] = [
  {
    name: 'Frontend & API',
    port: 3000,
    status: 'running',
    description: 'Primary interface (Node.js + React)'
  },
  {
    name: 'Python Gateway',
    port: 8006,
    status: 'running',
    description: 'Microservices orchestrator (Haystack)'
  },
  {
    name: 'OCR Service',
    port: 8001,
    status: 'running',
    description: 'Document text extraction'
  },
  {
    name: 'Classification Service',
    port: 8002,
    status: 'running',
    description: 'BFSI document classification'
  },
  {
    name: 'Vector Search',
    port: 8003,
    status: 'running',
    description: 'Semantic search'
  },
  {
    name: 'PII Detection',
    port: 8004,
    status: 'running',
    description: 'Sensitive data detection'
  }
];

export function MicroservicesStatus() {
  const [services, setServices] = useState<ServiceStatus[]>(
    SERVICES.map(service => ({ ...service, status: 'pending' as const }))
  );
  const [lastCheck, setLastCheck] = useState<Date | null>(null);
  const [isChecking, setIsChecking] = useState(false);

  const checkServiceHealth = async (port: number): Promise<{ 
    isHealthy: boolean; 
    health?: any; 
    responseTime: number; 
  }> => {
    const startTime = Date.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(`http://localhost:${port}/health`, {
        method: 'GET',
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        const health = await response.json();
        return { isHealthy: true, health, responseTime };
      }
      return { isHealthy: false, responseTime };
    } catch (error) {
      const responseTime = Date.now() - startTime;
      return { isHealthy: false, responseTime };
    }
  };

  const checkAllServices = async () => {
    setIsChecking(true);
    
    const updatedServices = await Promise.all(
      SERVICES.map(async (service) => {
        if (service.port === 3000) {
          // Frontend is running if we can execute this code
          return {
            ...service,
            status: 'running' as const,
            health: { status: 'healthy', service: 'Frontend & API', version: '1.0.0' },
            responseTime: 0
          };
        }

        const { isHealthy, health, responseTime } = await checkServiceHealth(service.port);
        return {
          ...service,
          status: isHealthy ? 'running' as const : 'down' as const,
          health,
          responseTime
        };
      })
    );

    setServices(updatedServices);
    setLastCheck(new Date());
    setIsChecking(false);
  };

  useEffect(() => {
    checkAllServices();
    // Auto-refresh every 30 seconds
    const interval = setInterval(checkAllServices, 30000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: ServiceStatus['status']) => {
    switch (status) {
      case 'running':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'down':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: ServiceStatus['status']) => {
    const variants = {
      running: 'default',
      down: 'destructive',
      pending: 'secondary'
    } as const;

    return (
      <Badge variant={variants[status]} className="ml-2">
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const runningServices = services.filter(s => s.status === 'running').length;
  const totalServices = services.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Service Architecture Status</h2>
          <p className="text-muted-foreground">
            DocIntel Haystack Platform - Microservices Health Monitor
          </p>
        </div>
        <Button 
          onClick={checkAllServices} 
          disabled={isChecking}
          variant="outline"
          size="sm"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isChecking ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            System Overview
            <Badge variant={runningServices === totalServices ? 'default' : 'destructive'}>
              {runningServices}/{totalServices} Services Running
            </Badge>
          </CardTitle>
          <CardDescription>
            {lastCheck ? `Last checked: ${lastCheck.toLocaleTimeString()}` : 'Checking services...'}
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Services Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {services.map((service) => (
          <Card key={service.name} className="relative">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center">
                  {getStatusIcon(service.status)}
                  <span className="ml-2">{service.name}</span>
                </div>
                {getStatusBadge(service.status)}
              </CardTitle>
              <CardDescription>
                Port {service.port} • {service.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {service.health && (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Service:</span>
                    <span>{service.health.service}</span>
                  </div>
                  {service.health.version && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Version:</span>
                      <span>{service.health.version}</span>
                    </div>
                  )}
                  {service.responseTime !== undefined && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Response:</span>
                      <span>{service.responseTime}ms</span>
                    </div>
                  )}
                </div>
              )}
              {service.status === 'down' && (
                <div className="text-sm text-red-500">
                  Service unavailable - check if running on port {service.port}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Service URLs */}
      <Card>
        <CardHeader>
          <CardTitle>Service Endpoints</CardTitle>
          <CardDescription>
            Direct access to microservice APIs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 text-sm">
            {services.map((service) => (
              <div key={service.name} className="flex justify-between items-center py-1">
                <span>{service.name}:</span>
                <a
                  href={`http://localhost:${service.port}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-500 hover:text-blue-700 underline"
                >
                  http://localhost:{service.port}
                </a>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default MicroservicesStatus;
