// Document Upload and Processing Component
import React, { useState, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Upload, 
  FileText, 
  Eye, 
  Shield, 
  Search, 
  CheckCircle, 
  XCircle, 
  Clock,
  Download,
  AlertTriangle
} from 'lucide-react';

interface ProcessingStep {
  id: string;
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  service: string;
  port: number;
  result?: any;
  error?: string;
}

interface ProcessedDocument {
  filename: string;
  ocr: {
    text: string;
    confidence: number;
    pages: number;
  };
  classification: {
    category: string;
    confidence: number;
    riskLevel: string;
    entities: Array<{ type: string; value: string; confidence: number }>;
  };
  vectorSearch: {
    indexed: boolean;
    embeddings: number;
    searchId: string;
  };
  piiDetection: {
    detected: Array<{ type: string; value: string; risk: string; location: string }>;
    riskScore: number;
    complianceFlags: string[];
  };
}

export function DocumentProcessor() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [processedDocument, setProcessedDocument] = useState<ProcessedDocument | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const PROCESSING_PIPELINE: Omit<ProcessingStep, 'status' | 'result' | 'error'>[] = [
    { id: 'ocr', name: 'Text Extraction', service: 'OCR Service', port: 8001 },
    { id: 'classification', name: 'Document Classification', service: 'Classification Service', port: 8002 },
    { id: 'vector', name: 'Vector Indexing', service: 'Vector Search', port: 8003 },
    { id: 'pii', name: 'PII Detection', service: 'PII Detection', port: 8004 }
  ];

  const initializeProcessing = () => {
    setProcessingSteps(
      PROCESSING_PIPELINE.map(step => ({ ...step, status: 'pending' }))
    );
    setProcessedDocument(null);
  };

  const updateStepStatus = (stepId: string, status: ProcessingStep['status'], result?: any, error?: string) => {
    setProcessingSteps(prev => 
      prev.map(step => 
        step.id === stepId ? { ...step, status, result, error } : step
      )
    );
  };

  const callMicroservice = async (endpoint: string, port: number, formData: FormData) => {
    const response = await fetch(`http://localhost:${port}${endpoint}`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Service on port ${port} returned ${response.status}`);
    }

    return await response.json();
  };

  const processDocument = async () => {
    if (!selectedFile) return;

    setIsProcessing(true);
    initializeProcessing();

    const formData = new FormData();
    formData.append('file', selectedFile);

    let documentData: Partial<ProcessedDocument> = {
      filename: selectedFile.name
    };

    try {
      // Step 1: OCR Text Extraction
      updateStepStatus('ocr', 'processing');
      const ocrResult = await callMicroservice('/extract_text', 8001, formData);
      documentData.ocr = ocrResult;
      updateStepStatus('ocr', 'completed', ocrResult);

      // Step 2: Document Classification
      updateStepStatus('classification', 'processing');
      const classificationFormData = new FormData();
      classificationFormData.append('text', ocrResult.text);
      const classificationResult = await callMicroservice('/classify', 8002, classificationFormData);
      documentData.classification = classificationResult;
      updateStepStatus('classification', 'completed', classificationResult);

      // Step 3: Vector Search Indexing
      updateStepStatus('vector', 'processing');
      const vectorFormData = new FormData();
      vectorFormData.append('text', ocrResult.text);
      vectorFormData.append('filename', selectedFile.name);
      const vectorResult = await callMicroservice('/add_document', 8003, vectorFormData);
      documentData.vectorSearch = vectorResult;
      updateStepStatus('vector', 'completed', vectorResult);

      // Step 4: PII Detection
      updateStepStatus('pii', 'processing');
      const piiFormData = new FormData();
      piiFormData.append('text', ocrResult.text);
      const piiResult = await callMicroservice('/detect_pii', 8004, piiFormData);
      documentData.piiDetection = piiResult;
      updateStepStatus('pii', 'completed', piiResult);

      setProcessedDocument(documentData as ProcessedDocument);

    } catch (error) {
      const failedStep = processingSteps.find(step => step.status === 'processing');
      if (failedStep) {
        updateStepStatus(failedStep.id, 'error', null, error instanceof Error ? error.message : 'Unknown error');
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setProcessedDocument(null);
      setProcessingSteps([]);
    }
  }, []);

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) {
      setSelectedFile(file);
      setProcessedDocument(null);
      setProcessingSteps([]);
    }
  }, []);

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  }, []);

  const getStepIcon = (status: ProcessingStep['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const completedSteps = processingSteps.filter(step => step.status === 'completed').length;
  const progressPercentage = processingSteps.length > 0 ? (completedSteps / processingSteps.length) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Document Processing Pipeline</h2>
        <p className="text-muted-foreground">
          Upload and process documents through the Haystack microservices architecture
        </p>
      </div>

      {/* File Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Upload className="h-5 w-5 mr-2" />
            Document Upload
          </CardTitle>
          <CardDescription>
            Supported formats: PDF, DOCX, TXT, PNG, JPG
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors cursor-pointer"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept=".pdf,.docx,.txt,.png,.jpg,.jpeg"
              onChange={handleFileSelect}
            />
            {selectedFile ? (
              <div className="space-y-2">
                <FileText className="h-12 w-12 mx-auto text-blue-500" />
                <p className="text-lg font-medium">{selectedFile.name}</p>
                <p className="text-sm text-muted-foreground">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
                <Button 
                  onClick={processDocument} 
                  disabled={isProcessing}
                  className="mt-4"
                >
                  {isProcessing ? 'Processing...' : 'Process Document'}
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="h-12 w-12 mx-auto text-gray-400" />
                <p className="text-lg">Drop a document here or click to browse</p>
                <p className="text-sm text-muted-foreground">
                  Maximum file size: 10MB
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Processing Pipeline */}
      {processingSteps.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Processing Pipeline</CardTitle>
            <CardDescription>
              Document processing through microservices
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Progress value={progressPercentage} className="w-full" />
              <div className="space-y-3">
                {processingSteps.map((step, index) => (
                  <div key={step.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-medium text-muted-foreground">
                        {index + 1}.
                      </span>
                      {getStepIcon(step.status)}
                      <div>
                        <p className="font-medium">{step.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {step.service} (Port {step.port})
                        </p>
                      </div>
                    </div>
                    <Badge 
                      variant={
                        step.status === 'completed' ? 'default' :
                        step.status === 'error' ? 'destructive' :
                        step.status === 'processing' ? 'secondary' : 'outline'
                      }
                    >
                      {step.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Results */}
      {processedDocument && (
        <Card>
          <CardHeader>
            <CardTitle>Processing Results</CardTitle>
            <CardDescription>
              Extracted data and analysis results
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="ocr" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="ocr" className="flex items-center">
                  <Eye className="h-4 w-4 mr-1" />
                  OCR
                </TabsTrigger>
                <TabsTrigger value="classification" className="flex items-center">
                  <FileText className="h-4 w-4 mr-1" />
                  Classification
                </TabsTrigger>
                <TabsTrigger value="vector" className="flex items-center">
                  <Search className="h-4 w-4 mr-1" />
                  Vector Search
                </TabsTrigger>
                <TabsTrigger value="pii" className="flex items-center">
                  <Shield className="h-4 w-4 mr-1" />
                  PII Detection
                </TabsTrigger>
              </TabsList>

              <TabsContent value="ocr" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.ocr.confidence}%</div>
                      <p className="text-xs text-muted-foreground">OCR Confidence</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.ocr.pages}</div>
                      <p className="text-xs text-muted-foreground">Pages Processed</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.ocr.text.length}</div>
                      <p className="text-xs text-muted-foreground">Characters Extracted</p>
                    </CardContent>
                  </Card>
                </div>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Extracted Text</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="max-h-60 overflow-y-auto bg-gray-50 p-4 rounded text-sm">
                      {processedDocument.ocr.text}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="classification" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.classification.category}</div>
                      <p className="text-xs text-muted-foreground">Document Category</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.classification.confidence}%</div>
                      <p className="text-xs text-muted-foreground">Classification Confidence</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <Badge variant={
                        processedDocument.classification.riskLevel === 'High' ? 'destructive' :
                        processedDocument.classification.riskLevel === 'Medium' ? 'secondary' :
                        'default'
                      }>
                        {processedDocument.classification.riskLevel}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">Risk Level</p>
                    </CardContent>
                  </Card>
                </div>
                {processedDocument.classification.entities.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Detected Entities</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {processedDocument.classification.entities.map((entity, index) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <div>
                              <span className="font-medium">{entity.type}:</span> {entity.value}
                            </div>
                            <Badge variant="outline">{entity.confidence}%</Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="vector" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">
                        {processedDocument.vectorSearch.indexed ? '✓' : '✗'}
                      </div>
                      <p className="text-xs text-muted-foreground">Document Indexed</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.vectorSearch.embeddings}</div>
                      <p className="text-xs text-muted-foreground">Vector Embeddings</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm font-mono">{processedDocument.vectorSearch.searchId}</div>
                      <p className="text-xs text-muted-foreground">Search ID</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="pii" className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.piiDetection.detected.length}</div>
                      <p className="text-xs text-muted-foreground">PII Items Detected</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.piiDetection.riskScore}/10</div>
                      <p className="text-xs text-muted-foreground">Risk Score</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{processedDocument.piiDetection.complianceFlags.length}</div>
                      <p className="text-xs text-muted-foreground">Compliance Flags</p>
                    </CardContent>
                  </Card>
                </div>
                {processedDocument.piiDetection.detected.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center">
                        <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />
                        Detected PII
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {processedDocument.piiDetection.detected.map((pii, index) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-red-50 border border-red-200 rounded">
                            <div>
                              <span className="font-medium">{pii.type}:</span> {pii.value}
                              <span className="text-sm text-muted-foreground ml-2">({pii.location})</span>
                            </div>
                            <Badge variant="destructive">{pii.risk}</Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default DocumentProcessor;
