import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { usePipelineStore } from "@/hooks/use-pipeline-store";
import { SOURCE_TYPES, type SourceType } from "@shared/schema";
import { Cog, Building2, Users, Check, ArrowLeft, ArrowRight } from "lucide-react";

export default function SourceTypeSelector() {
  const { pipelineConfig, updateSourceType, nextStep, previousStep, currentStep } = usePipelineStore();

  const sourceTypes = [
    {
      id: SOURCE_TYPES.GENERIC,
      title: "Add Generic Source",
      description: "General purpose document processing for various document types and workflows",
      icon: Cog,
      iconBg: "bg-blue-100",
      iconColor: "text-primary",
      buttonColor: "bg-primary hover:bg-primary/90 text-primary-foreground",
      features: [
        "Custom document types",
        "Flexible classification rules", 
        "Multi-format support",
        "Configurable workflows"
      ]
    },
    {
      id: SOURCE_TYPES.BFSI,
      title: "Add BFSI Document Source",
      description: "Banking, Financial Services, and Insurance document processing with regulatory compliance",
      icon: Building2,
      iconBg: "bg-green-100",
      iconColor: "text-accent",
      buttonColor: "bg-accent hover:bg-accent/90 text-accent-foreground",
      features: [
        "Financial statement analysis",
        "Regulatory compliance checks",
        "Risk assessment documents", 
        "Customer onboarding forms"
      ]
    },
    {
      id: SOURCE_TYPES.HR,
      title: "Add HR Document Source", 
      description: "Configure HR document processing workflows for employee records, policies, and compliance documents",
      icon: Users,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      buttonColor: "bg-purple-600 hover:bg-purple-700 text-white",
      features: [
        "Employee record processing",
        "Policy document classification",
        "Compliance monitoring",
        "PII detection and masking"
      ]
    }
  ];

  const handleSelectSource = (sourceType: SourceType) => {
    updateSourceType(sourceType);
  };

  const isSelected = (sourceType: SourceType) => {
    return pipelineConfig.sourceType === sourceType;
  };

  return (
    <div className="fade-in">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Select Source Type</h2>
        <p className="text-muted-foreground">
          Choose the type of documents you want to process with Haystack AI
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {sourceTypes.map((source) => {
          const Icon = source.icon;
          const selected = isSelected(source.id);
          
          return (
            <Card 
              key={source.id}
              className={`service-card cursor-pointer transition-all duration-300 ${
                selected ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => handleSelectSource(source.id)}
              data-testid={`card-source-${source.id}`}
            >
              <CardContent className="p-6">
                <div className={`flex items-center justify-center w-16 h-16 ${source.iconBg} rounded-xl mb-4 mx-auto`}>
                  <Icon className={`${source.iconColor} text-2xl`} size={24} />
                </div>
                
                <div className="flex items-center justify-center mb-3">
                  <h3 className="text-xl font-semibold text-foreground">{source.title}</h3>
                  {selected && (
                    <Badge className="ml-2 bg-primary text-primary-foreground">
                      Selected
                    </Badge>
                  )}
                </div>
                
                <p className="text-muted-foreground text-center mb-6 text-sm">
                  {source.description}
                </p>
                
                <div className="space-y-3 mb-6">
                  <h4 className="font-medium text-foreground text-sm">Key Features:</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    {source.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <Check className="text-accent w-4 h-4 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <Button 
                  className={`w-full font-medium py-3 px-4 transition-colors ${source.buttonColor}`}
                  data-testid={`button-configure-${source.id}`}
                >
                  <Icon className="mr-2" size={16} />
                  Configure Source
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="text-center mt-8">
        <div className="flex items-center justify-center space-x-4">
          <Button 
            variant="outline" 
            onClick={previousStep}
            disabled={currentStep <= 1}
            data-testid="button-previous"
          >
            <ArrowLeft className="mr-2" size={16} />
            Previous
          </Button>
          <Button 
            onClick={nextStep}
            disabled={!pipelineConfig.sourceType}
            data-testid="button-next"
          >
            Next Step
            <ArrowRight className="ml-2" size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}
