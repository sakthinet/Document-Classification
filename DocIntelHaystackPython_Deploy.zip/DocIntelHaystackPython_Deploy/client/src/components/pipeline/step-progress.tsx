import { Steps } from "@/components/ui/steps";
import { usePipelineStore } from "@/hooks/use-pipeline-store";
import { PIPELINE_STEPS } from "@shared/schema";

export default function StepProgress() {
  const { currentStep } = usePipelineStore();

  const steps = [
    {
      title: "Select Source Type",
      description: "Choose document source",
      status: currentStep >= PIPELINE_STEPS.SOURCE_TYPE 
        ? (currentStep === PIPELINE_STEPS.SOURCE_TYPE ? "current" : "completed")
        : "upcoming"
    },
    {
      title: "Configure Connection", 
      description: "Setup data source",
      status: currentStep >= PIPELINE_STEPS.CONNECTION_CONFIG
        ? (currentStep === PIPELINE_STEPS.CONNECTION_CONFIG ? "current" : "completed")
        : "upcoming"
    },
    {
      title: "Set Processing Rules",
      description: "Define AI rules", 
      status: currentStep >= PIPELINE_STEPS.PROCESSING_RULES
        ? (currentStep === PIPELINE_STEPS.PROCESSING_RULES ? "current" : "completed")
        : "upcoming"
    },
    {
      title: "Define Output Destinations",
      description: "Set storage targets",
      status: currentStep >= PIPELINE_STEPS.OUTPUT_DESTINATIONS
        ? (currentStep === PIPELINE_STEPS.OUTPUT_DESTINATIONS ? "current" : "completed")
        : "upcoming"
    },
    {
      title: "Test & Save Configuration",
      description: "Validate & deploy",
      status: currentStep >= PIPELINE_STEPS.TEST_SAVE
        ? (currentStep === PIPELINE_STEPS.TEST_SAVE ? "current" : "completed")
        : "upcoming"
    },
  ];

  return <Steps steps={steps} />;
}
