import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { usePipelineStore } from "@/hooks/use-pipeline-store";
import DomainSourceConfig from "./domain-source-config";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function ConnectionConfig() {
  const { pipelineConfig, updateConnectionConfig, nextStep, previousStep, currentStep } = usePipelineStore();
  const [showDomainConfig, setShowDomainConfig] = useState(false);
  const [connectionConfig, setConnectionConfig] = useState<any>(null);

  const handleConfigureSource = () => {
    setShowDomainConfig(true);
  };

  const handleConfigComplete = (config: any) => {
    setConnectionConfig(config);
    setShowDomainConfig(false);
    updateConnectionConfig(config);
  };

  const handleConfigCancel = () => {
    setShowDomainConfig(false);
  };

  if (showDomainConfig) {
    return (
      <DomainSourceConfig
        sourceType={pipelineConfig.sourceType || 'generic'}
        onComplete={handleConfigComplete}
        onCancel={handleConfigCancel}
      />
    );
  }

  return (
    <div className="fade-in max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Configure Connection</h2>
        <p className="text-muted-foreground">
          Set up the connection details for your {pipelineConfig.sourceType} data source
        </p>
      </div>

      {!connectionConfig ? (
        <Card>
          <CardContent className="p-12 text-center">
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-foreground">Ready to Configure</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Configure your {pipelineConfig.sourceType?.toUpperCase() || 'document'} source with domain-specific settings,
                security classifications, and processing rules.
              </p>
              <Button 
                onClick={handleConfigureSource}
                size="lg"
                data-testid="button-configure-source"
              >
                Configure {pipelineConfig.sourceType?.toUpperCase()} Source
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-accent">✓ Configuration Complete</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Source Name:</span> {connectionConfig.basicInfo?.sourceName || 'Not specified'}
                </div>
                <div>
                  <span className="font-medium">Source Type:</span> {connectionConfig.basicInfo?.specificSourceType || 'Not specified'}
                </div>
                <div>
                  <span className="font-medium">Classification:</span> {connectionConfig.basicInfo?.classificationLevel || 'Not specified'}
                </div>
                <div>
                  <span className="font-medium">Connection:</span> Configured
                </div>
              </div>
              <div className="pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowDomainConfig(true)}
                  data-testid="button-edit-config"
                >
                  Edit Configuration
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="text-center mt-8">
        <div className="flex items-center justify-center space-x-4">
          <Button 
            variant="outline" 
            onClick={previousStep}
            data-testid="button-previous"
          >
            <ArrowLeft className="mr-2" size={16} />
            Previous
          </Button>
          <Button 
            onClick={nextStep}
            disabled={!connectionConfig}
            data-testid="button-next"
          >
            Next Step
            <ArrowRight className="ml-2" size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}