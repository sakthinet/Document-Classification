import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { usePipelineStore } from "@/hooks/use-pipeline-store";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Save, Play, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { Link } from "wouter";

export default function TestSaveConfig() {
  const { pipelineConfig, previousStep, resetPipeline } = usePipelineStore();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [pipelineName, setPipelineName] = useState("");
  const [pipelineDescription, setPipelineDescription] = useState("");
  const [testProgress, setTestProgress] = useState(0);
  const [testStatus, setTestStatus] = useState<"idle" | "testing" | "success" | "error">("idle");
  const [testResults, setTestResults] = useState<any>(null);

  const testPipelineMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/pipelines/test", {
        sourceType: pipelineConfig.sourceType,
        connectionConfig: pipelineConfig.connectionConfig,
        processingRules: pipelineConfig.processingRules,
        outputDestinations: pipelineConfig.outputDestinations,
      });
    },
    onSuccess: (response) => {
      setTestStatus("success");
      setTestResults(response);
      toast({
        title: "Pipeline Test Successful",
        description: "Your pipeline configuration is valid and ready to deploy.",
      });
    },
    onError: (error: any) => {
      setTestStatus("error");
      toast({
        title: "Pipeline Test Failed",
        description: error.message || "There was an error testing your pipeline.",
        variant: "destructive",
      });
    },
  });

  const savePipelineMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/pipelines", {
        name: pipelineName,
        description: pipelineDescription,
        sourceType: pipelineConfig.sourceType,
        connectionConfig: pipelineConfig.connectionConfig,
        processingRules: pipelineConfig.processingRules,
        outputDestinations: pipelineConfig.outputDestinations,
        status: "active",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pipelines"] });
      toast({
        title: "Pipeline Saved",
        description: "Your pipeline has been saved and is now active.",
      });
      resetPipeline();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Save Pipeline",
        description: error.message || "There was an error saving your pipeline.",
        variant: "destructive",
      });
    },
  });

  const handleTestPipeline = async () => {
    setTestStatus("testing");
    setTestProgress(0);
    
    // Simulate test progress
    const progressInterval = setInterval(() => {
      setTestProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    testPipelineMutation.mutate();
  };

  const handleSavePipeline = () => {
    if (!pipelineName.trim()) {
      toast({
        title: "Pipeline Name Required",
        description: "Please enter a name for your pipeline.",
        variant: "destructive",
      });
      return;
    }
    savePipelineMutation.mutate();
  };

  const getStatusIcon = () => {
    switch (testStatus) {
      case "testing":
        return <Loader2 className="animate-spin" size={16} />;
      case "success":
        return <CheckCircle className="text-accent" size={16} />;
      case "error":
        return <AlertCircle className="text-destructive" size={16} />;
      default:
        return <Play size={16} />;
    }
  };

  const getStatusColor = () => {
    switch (testStatus) {
      case "testing":
        return "bg-blue-100 text-blue-800";
      case "success":
        return "bg-green-100 text-green-800";
      case "error":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="fade-in max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Test & Save Configuration</h2>
        <p className="text-muted-foreground">
          Validate your pipeline configuration and save it for deployment
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Configuration Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-medium text-foreground mb-2">Source Type</h4>
              <Badge variant="outline">{pipelineConfig.sourceType?.toUpperCase()}</Badge>
            </div>
            
            <div>
              <h4 className="font-medium text-foreground mb-2">Connection</h4>
              <p className="text-sm text-muted-foreground">
                {pipelineConfig.connectionConfig?.connectionType || "Not configured"}
              </p>
            </div>
            
            <div>
              <h4 className="font-medium text-foreground mb-2">Processing Rules</h4>
              <div className="space-y-1">
                {pipelineConfig.processingRules?.enableClassification && (
                  <Badge variant="secondary" className="mr-2">Classification</Badge>
                )}
                {pipelineConfig.processingRules?.enableExtraction && (
                  <Badge variant="secondary" className="mr-2">Extraction</Badge>
                )}
                {pipelineConfig.processingRules?.enableNER && (
                  <Badge variant="secondary" className="mr-2">NER</Badge>
                )}
                {pipelineConfig.processingRules?.enableSummarization && (
                  <Badge variant="secondary">Summarization</Badge>
                )}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-foreground mb-2">Output Destinations</h4>
              <div className="space-y-1">
                {pipelineConfig.outputDestinations?.enableVectorStore && (
                  <Badge variant="secondary" className="mr-2">Vector Store</Badge>
                )}
                {pipelineConfig.outputDestinations?.enableDatabase && (
                  <Badge variant="secondary" className="mr-2">Database</Badge>
                )}
                {pipelineConfig.outputDestinations?.enableFileStorage && (
                  <Badge variant="secondary" className="mr-2">File Storage</Badge>
                )}
                {pipelineConfig.outputDestinations?.enableApi && (
                  <Badge variant="secondary">API Webhook</Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Test & Save */}
        <Card>
          <CardHeader>
            <CardTitle>Test & Deploy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Pipeline Testing */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-medium text-foreground">Pipeline Validation</h4>
                <Badge className={getStatusColor()}>
                  {getStatusIcon()}
                  <span className="ml-2">
                    {testStatus === "idle" && "Ready to Test"}
                    {testStatus === "testing" && "Testing..."}
                    {testStatus === "success" && "Test Passed"}
                    {testStatus === "error" && "Test Failed"}
                  </span>
                </Badge>
              </div>
              
              {testStatus === "testing" && (
                <div className="space-y-2">
                  <Progress value={testProgress} className="w-full" />
                  <p className="text-sm text-muted-foreground">
                    Testing pipeline configuration...
                  </p>
                </div>
              )}
              
              {testResults && testStatus === "success" && (
                <div className="bg-green-50 p-3 rounded-lg">
                  <p className="text-sm text-green-800">
                    ✓ Configuration validated successfully
                  </p>
                  <p className="text-sm text-green-600">
                    Ready for deployment
                  </p>
                </div>
              )}
              
              <Button
                onClick={handleTestPipeline}
                disabled={testStatus === "testing"}
                className="w-full"
                data-testid="button-test-pipeline"
              >
                {getStatusIcon()}
                <span className="ml-2">Test Pipeline</span>
              </Button>
            </div>

            {/* Save Configuration */}
            <div className="space-y-4">
              <h4 className="font-medium text-foreground">Save Pipeline</h4>
              
              <Input
                placeholder="Pipeline Name"
                value={pipelineName}
                onChange={(e) => setPipelineName(e.target.value)}
                data-testid="input-pipeline-name"
              />
              
              <Textarea
                placeholder="Pipeline Description (optional)"
                value={pipelineDescription}
                onChange={(e) => setPipelineDescription(e.target.value)}
                rows={3}
                data-testid="textarea-pipeline-description"
              />
              
              <Button
                onClick={handleSavePipeline}
                disabled={!pipelineName.trim() || savePipelineMutation.isPending}
                className="w-full"
                data-testid="button-save-pipeline"
              >
                {savePipelineMutation.isPending ? (
                  <Loader2 className="animate-spin mr-2" size={16} />
                ) : (
                  <Save className="mr-2" size={16} />
                )}
                Save Pipeline
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-center space-x-4 mt-8">
        <Button 
          variant="outline" 
          onClick={previousStep}
          data-testid="button-previous"
        >
          <ArrowLeft className="mr-2" size={16} />
          Previous
        </Button>
        <Link href="/">
          <Button variant="outline" data-testid="button-back-dashboard">
            Back to Dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
}
