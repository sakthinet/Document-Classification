import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { usePipelineStore } from "@/hooks/use-pipeline-store";
import { ArrowLeft, ArrowRight, Brain, Filter, Tag } from "lucide-react";

const processingRulesSchema = z.object({
  enableClassification: z.boolean().default(false),
  classificationModel: z.string().optional(),
  enableExtraction: z.boolean().default(false),
  extractionFields: z.string().optional(),
  enableNER: z.boolean().default(false),
  nerModel: z.string().optional(),
  enableSummarization: z.boolean().default(false),
  summaryLength: z.string().optional(),
  customRules: z.string().optional(),
});

type ProcessingRulesForm = z.infer<typeof processingRulesSchema>;

export default function ProcessingRules() {
  const { pipelineConfig, updateProcessingRules, nextStep, previousStep } = usePipelineStore();

  const form = useForm<ProcessingRulesForm>({
    resolver: zodResolver(processingRulesSchema),
    defaultValues: {
      enableClassification: pipelineConfig.processingRules?.enableClassification || false,
      classificationModel: pipelineConfig.processingRules?.classificationModel || "",
      enableExtraction: pipelineConfig.processingRules?.enableExtraction || false,
      extractionFields: pipelineConfig.processingRules?.extractionFields || "",
      enableNER: pipelineConfig.processingRules?.enableNER || false,
      nerModel: pipelineConfig.processingRules?.nerModel || "",
      enableSummarization: pipelineConfig.processingRules?.enableSummarization || false,
      summaryLength: pipelineConfig.processingRules?.summaryLength || "",
      customRules: pipelineConfig.processingRules?.customRules || "",
    },
  });

  const onSubmit = (data: ProcessingRulesForm) => {
    updateProcessingRules(data);
    nextStep();
  };

  const getSourceTypeFeatures = () => {
    switch (pipelineConfig.sourceType) {
      case "bfsi":
        return {
          title: "BFSI Document Processing",
          features: [
            "Financial statement analysis",
            "Regulatory compliance checks",
            "Risk assessment scoring",
            "Customer onboarding validation"
          ]
        };
      case "hr":
        return {
          title: "HR Document Processing", 
          features: [
            "Employee data extraction",
            "PII detection and masking",
            "Policy compliance checking",
            "Resume parsing and scoring"
          ]
        };
      default:
        return {
          title: "Generic Document Processing",
          features: [
            "Custom document classification",
            "Flexible data extraction",
            "Multi-format support",
            "Configurable workflows"
          ]
        };
    }
  };

  const sourceFeatures = getSourceTypeFeatures();

  return (
    <div className="fade-in max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Set Processing Rules</h2>
        <p className="text-muted-foreground">
          Configure AI processing rules for {pipelineConfig.sourceType} documents
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Processing Configuration */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="mr-2" size={20} />
                AI Processing Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Classification */}
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="enableClassification"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-classification"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Enable Document Classification</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Automatically classify documents by type
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    {form.watch("enableClassification") && (
                      <FormField
                        control={form.control}
                        name="classificationModel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Classification Model</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="sentence-transformers/all-MiniLM-L6-v2"
                                {...field}
                                data-testid="input-classification-model"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  {/* Data Extraction */}
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="enableExtraction"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-extraction"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Enable Data Extraction</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Extract structured data from documents
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    {form.watch("enableExtraction") && (
                      <FormField
                        control={form.control}
                        name="extractionFields"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Extraction Fields</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="name, email, phone, address, amount, date"
                                {...field}
                                data-testid="textarea-extraction-fields"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  {/* Named Entity Recognition */}
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="enableNER"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-ner"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Enable Named Entity Recognition</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Identify and extract entities (persons, organizations, locations)
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    {form.watch("enableNER") && (
                      <FormField
                        control={form.control}
                        name="nerModel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>NER Model</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="dbmdz/bert-large-cased-finetuned-conll03-english"
                                {...field}
                                data-testid="input-ner-model"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  {/* Summarization */}
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="enableSummarization"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              data-testid="checkbox-summarization"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Enable Document Summarization</FormLabel>
                            <p className="text-sm text-muted-foreground">
                              Generate document summaries
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    {form.watch("enableSummarization") && (
                      <FormField
                        control={form.control}
                        name="summaryLength"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Summary Length (words)</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="150"
                                {...field}
                                data-testid="input-summary-length"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}
                  </div>

                  {/* Custom Rules */}
                  <FormField
                    control={form.control}
                    name="customRules"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Custom Processing Rules</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Add custom rules or pipeline configurations..."
                            rows={4}
                            {...field}
                            data-testid="textarea-custom-rules"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex items-center justify-center space-x-4 pt-4">
                    <Button 
                      type="button"
                      variant="outline" 
                      onClick={previousStep}
                      data-testid="button-previous"
                    >
                      <ArrowLeft className="mr-2" size={16} />
                      Previous
                    </Button>
                    <Button type="submit" data-testid="button-next">
                      Next Step
                      <ArrowRight className="ml-2" size={16} />
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        {/* Source-Specific Features */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Tag className="mr-2" size={20} />
                {sourceFeatures.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground mb-4">
                  Specialized features for {pipelineConfig.sourceType} documents:
                </p>
                <ul className="space-y-2 text-sm">
                  {sourceFeatures.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
