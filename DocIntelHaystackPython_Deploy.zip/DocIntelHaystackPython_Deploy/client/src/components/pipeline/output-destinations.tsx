import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { usePipelineStore } from "@/hooks/use-pipeline-store";
import { ArrowLeft, ArrowRight, Database, Search, FileText, Cloud } from "lucide-react";

const outputDestinationsSchema = z.object({
  enableVectorStore: z.boolean().default(false),
  vectorStoreUrl: z.string().optional(),
  vectorStoreCollection: z.string().optional(),
  enableDatabase: z.boolean().default(false),
  databaseUrl: z.string().optional(),
  databaseTable: z.string().optional(),
  enableFileStorage: z.boolean().default(false),
  fileStoragePath: z.string().optional(),
  enableApi: z.boolean().default(false),
  apiWebhookUrl: z.string().optional(),
});

type OutputDestinationsForm = z.infer<typeof outputDestinationsSchema>;

export default function OutputDestinations() {
  const { pipelineConfig, updateOutputDestinations, nextStep, previousStep } = usePipelineStore();

  const form = useForm<OutputDestinationsForm>({
    resolver: zodResolver(outputDestinationsSchema),
    defaultValues: {
      enableVectorStore: pipelineConfig.outputDestinations?.enableVectorStore || false,
      vectorStoreUrl: pipelineConfig.outputDestinations?.vectorStoreUrl || "",
      vectorStoreCollection: pipelineConfig.outputDestinations?.vectorStoreCollection || "",
      enableDatabase: pipelineConfig.outputDestinations?.enableDatabase || false,
      databaseUrl: pipelineConfig.outputDestinations?.databaseUrl || "",
      databaseTable: pipelineConfig.outputDestinations?.databaseTable || "",
      enableFileStorage: pipelineConfig.outputDestinations?.enableFileStorage || false,
      fileStoragePath: pipelineConfig.outputDestinations?.fileStoragePath || "",
      enableApi: pipelineConfig.outputDestinations?.enableApi || false,
      apiWebhookUrl: pipelineConfig.outputDestinations?.apiWebhookUrl || "",
    },
  });

  const onSubmit = (data: OutputDestinationsForm) => {
    updateOutputDestinations(data);
    nextStep();
  };

  return (
    <div className="fade-in max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-2">Define Output Destinations</h2>
        <p className="text-muted-foreground">
          Configure where processed documents and extracted data will be stored
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Output Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              
              {/* Vector Store */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="enableVectorStore"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-vector-store"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="flex items-center">
                          <Search className="mr-2" size={16} />
                          Vector Store (Qdrant)
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Store document embeddings for semantic search
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                {form.watch("enableVectorStore") && (
                  <div className="space-y-4 ml-6">
                    <FormField
                      control={form.control}
                      name="vectorStoreUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Qdrant URL</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="http://localhost:6333"
                              {...field}
                              data-testid="input-vector-store-url"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="vectorStoreCollection"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Collection Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="documents"
                              {...field}
                              data-testid="input-vector-collection"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
              </div>

              {/* Database */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="enableDatabase"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-database"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="flex items-center">
                          <Database className="mr-2" size={16} />
                          Database Storage
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Store extracted data in a relational database
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                {form.watch("enableDatabase") && (
                  <div className="space-y-4 ml-6">
                    <FormField
                      control={form.control}
                      name="databaseUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Database URL</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="postgresql://user:pass@localhost:5432/db"
                              {...field}
                              data-testid="input-database-url"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="databaseTable"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Table Name</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="processed_documents"
                              {...field}
                              data-testid="input-database-table"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
              </div>

              {/* File Storage */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="enableFileStorage"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-file-storage"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="flex items-center">
                          <FileText className="mr-2" size={16} />
                          File Storage
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Save processed files to a directory
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                {form.watch("enableFileStorage") && (
                  <div className="ml-6">
                    <FormField
                      control={form.control}
                      name="fileStoragePath"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Storage Path</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="/output/processed-documents"
                              {...field}
                              data-testid="input-file-storage-path"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
              </div>

              {/* API Webhook */}
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="enableApi"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-api"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="flex items-center">
                          <Cloud className="mr-2" size={16} />
                          API Webhook
                        </FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Send processed data to an external API
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                {form.watch("enableApi") && (
                  <div className="ml-6">
                    <FormField
                      control={form.control}
                      name="apiWebhookUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Webhook URL</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="https://api.example.com/webhook"
                              {...field}
                              data-testid="input-api-webhook-url"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center justify-center space-x-4 pt-4">
                <Button 
                  type="button"
                  variant="outline" 
                  onClick={previousStep}
                  data-testid="button-previous"
                >
                  <ArrowLeft className="mr-2" size={16} />
                  Previous
                </Button>
                <Button type="submit" data-testid="button-next">
                  Next Step
                  <ArrowRight className="ml-2" size={16} />
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
