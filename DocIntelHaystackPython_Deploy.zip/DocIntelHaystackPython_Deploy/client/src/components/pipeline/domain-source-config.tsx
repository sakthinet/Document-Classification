import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Building2, 
  Database, 
  Cloud, 
  HardDrive, 
  Network, 
  Share2,
  Users,
  FileText,
  Lock,
  Shield,
  ChevronRight,
  CheckCircle,
  AlertTriangle,
  Settings,
  Key,
  Globe
} from "lucide-react";
import { 
  SOURCE_TYPES, 
  BFSI_SOURCE_TYPES, 
  HR_SOURCE_TYPES, 
  GENERIC_SOURCE_TYPES,
  HR_DOCUMENT_TYPES,
  SECURITY_CLASSIFICATIONS,
  OUTPUT_DESTINATIONS
} from "@shared/schema";
import { usePipelineStore } from "@/hooks/use-pipeline-store";

interface DomainSourceConfigProps {
  sourceType: string;
  onComplete: (config: any) => void;
  onCancel: () => void;
}

export default function DomainSourceConfig({ sourceType, onComplete, onCancel }: DomainSourceConfigProps) {
  const [activeTab, setActiveTab] = useState("basic");
  const [config, setConfig] = useState({
    basicInfo: {
      sourceName: "",
      description: "",
      classificationLevels: [] as string[],
      specificSourceType: ""
    },
    connection: {
      provider: "",
      // Azure Blob Storage
      azureAccountName: "",
      azureAccountKey: "",
      azureContainerName: "",
      azureEndpoint: "",
      azureKeyVault: "",
      // AWS S3
      awsAccessKey: "",
      awsSecretKey: "",
      awsBucketName: "",
      awsRegion: "us-east-1",
      awsEndpoint: "",
      // Google Cloud Storage
      gcpProjectId: "",
      gcpServiceAccountKey: "",
      gcpBucketName: "",
      gcpRegion: "",
      gcpEndpoint: "",
      // Database
      dbConnectionString: "",
      dbHost: "",
      dbPort: "",
      dbName: "",
      dbUsername: "",
      dbPassword: "",
      // SharePoint
      sharePointUrl: "",
      sharePointClientId: "",
      sharePointClientSecret: "",
      sharePointTenantId: "",
      // Network Folder
      networkPath: "",
      networkUsername: "",
      networkPassword: "",
      // FTP/SFTP
      ftpHost: "",
      ftpPort: "21",
      ftpUsername: "",
      ftpPassword: "",
      ftpProtocol: "ftp",
      // Advanced Settings
      pollingInterval: "15",
      timeout: "30",
      maxRetryAttempts: "3",
      enableRetry: true,
      enableSSL: true
    },
    documentTypes: {},
    compliance: {
      // Processing Rules
      enableOCR: true,
      enablePII: true,
      requireEncryption: false,
      enableAIClassification: true,
      enableComplianceCheck: true,
      
      // Data Retention
      dataRetentionPeriod: "",
      
      // BFSI Compliance Frameworks
      sarbanesOxley: false,
      antiMoneyLaundering: false,
      fairCreditReporting: false,
      usaPatriot: false,
      securitiesExchange: false,
      foreignAssetsControl: false,
      accountingPrinciples: false,
      fairLending: false,
      recordKeeping: false,
      stateTaxRegulations: false,
      bankSecrecy: false,
      grammLeachBliley: false,
      truthInLending: false,
      financialCrimesNetwork: false,
      financialRegulatory: false,
      publicAccountingOversight: false,
      hipaa: false,
      securitiesAct1933: false,
      stateInsurance: false,
      internalRevenue: false,
      
      // HR Compliance Frameworks
      equalEmployment: false,
      familyMedicalLeave: false,
      occupationalSafety: false,
      fairLaborStandards: false,
      workersCompensation: false,
      employmentEligibility: false,
      cobraInsurance: false,
      employeeRetirement: false,
      americansDisabilities: false,
      ageDiscrimination: false,
      
      // Legacy fields
      retention: "",
      encryption: true,
      auditLogging: true,
      accessControl: true
    }
  });

  const getSourceTypeConfig = () => {
    switch (sourceType) {
      case SOURCE_TYPES.BFSI:
        return {
          title: "Add New BFSI Data Source",
          color: "text-green-600",
          iconBg: "bg-green-100",
          sources: [
            { id: BFSI_SOURCE_TYPES.CORE_BANKING, name: "Core Banking System", desc: "Connect to core banking databases and APIs", icon: Building2 },
            { id: BFSI_SOURCE_TYPES.LOAN_MANAGEMENT, name: "Loan Management System", desc: "Loan origination and management systems", icon: FileText },
            { id: BFSI_SOURCE_TYPES.SHAREPOINT_ONLINE, name: "SharePoint Online", desc: "Microsoft SharePoint document libraries", icon: Share2 },
            { id: BFSI_SOURCE_TYPES.NETWORK_FOLDER, name: "Network Folder", desc: "Local network file shares and folders", icon: HardDrive },
            { id: BFSI_SOURCE_TYPES.DATABASE, name: "Database", desc: "Direct database connections", icon: Database },
            { id: BFSI_SOURCE_TYPES.CLOUD_STORAGE, name: "Cloud Storage", desc: "Cloud storage services", icon: Cloud },
            { id: BFSI_SOURCE_TYPES.FTP_SFTP, name: "FTP/SFTP", desc: "FTP and SFTP file servers", icon: Network }
          ]
        };
      case SOURCE_TYPES.HR:
        return {
          title: "Configure HR Document Source",
          color: "text-purple-600",
          iconBg: "bg-purple-100",
          sources: [
            { id: HR_SOURCE_TYPES.NETWORK_FOLDER, name: "Network Folder", desc: "Local network file shares and folders", icon: HardDrive },
            { id: HR_SOURCE_TYPES.SHAREPOINT_HR, name: "SharePoint HR", desc: "SharePoint HR document libraries", icon: Share2 },
            { id: HR_SOURCE_TYPES.HRMS_SYSTEM, name: "HRMS System", desc: "Human Resource Management Systems", icon: Users },
            { id: HR_SOURCE_TYPES.DATABASE, name: "Database", desc: "Direct database connections", icon: Database },
            { id: HR_SOURCE_TYPES.CLOUD_STORAGE, name: "Cloud Storage", desc: "Cloud storage services", icon: Cloud }
          ]
        };
      default:
        return {
          title: "Configure Generic Document Source",
          color: "text-blue-600", 
          iconBg: "bg-blue-100",
          sources: [
            { id: GENERIC_SOURCE_TYPES.NETWORK_FOLDER, name: "Network Folder", desc: "Windows/Linux file shares", icon: HardDrive },
            { id: GENERIC_SOURCE_TYPES.SHAREPOINT, name: "SharePoint", desc: "Microsoft 365 Integration", icon: Share2 },
            { id: GENERIC_SOURCE_TYPES.DATABASE, name: "Database", desc: "SQL Server, PostgreSQL, MySQL", icon: Database },
            { id: GENERIC_SOURCE_TYPES.CLOUD_STORAGE, name: "Cloud Storage", desc: "Azure Blob, AWS S3, Google Cloud", icon: Cloud },
            { id: GENERIC_SOURCE_TYPES.FTP_SFTP, name: "FTP/SFTP", desc: "File transfer protocol", icon: Network },
            { id: GENERIC_SOURCE_TYPES.ON_PREMISES, name: "On-Premises File System", desc: "Direct file system access", icon: HardDrive }
          ]
        };
    }
  };

  const sourceConfig = getSourceTypeConfig();

  const updateConfig = (section: string, field: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [field]: value
      }
    }));
  };

  const updateClassificationLevels = (level: string, checked: boolean) => {
    setConfig(prev => ({
      ...prev,
      basicInfo: {
        ...prev.basicInfo,
        classificationLevels: checked 
          ? [...prev.basicInfo.classificationLevels, level]
          : prev.basicInfo.classificationLevels.filter(l => l !== level)
      }
    }));
  };

  const getClassificationColor = (classification: string) => {
    switch (classification) {
      case SECURITY_CLASSIFICATIONS.CONFIDENTIAL:
        return "text-red-600 bg-red-100";
      case SECURITY_CLASSIFICATIONS.RESTRICTED:
        return "text-orange-600 bg-orange-100";
      case SECURITY_CLASSIFICATIONS.INTERNAL:
        return "text-blue-600 bg-blue-100";
      case SECURITY_CLASSIFICATIONS.PUBLIC:
        return "text-green-600 bg-green-100";
      default:
        return "text-gray-600 bg-gray-100";
    }
  };

  const renderHRDocumentMapping = () => {
    const documentTypes = Object.entries(HR_DOCUMENT_TYPES);
    const mockCounts = { CONTRACTS: 45, PAYROLL: 78, REVIEWS: 123, POLICIES: 246, TRAINING: 89 };
    
    return (
      <div className="space-y-4">
        <div className="flex items-center space-x-2 mb-4">
          <FileText className="text-purple-600" size={20} />
          <h3 className="text-lg font-semibold">HR Document Type Mapping</h3>
        </div>
        
        {documentTypes.map(([key, docType]) => (
          <Card key={key} className="border-l-4 border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <input 
                      type="checkbox" 
                      defaultChecked 
                      className="w-4 h-4 text-purple-600"
                      data-testid={`checkbox-${key.toLowerCase()}`}
                    />
                    <Users className="text-purple-600" size={16} />
                    <div>
                      <div className="font-medium">Folder: "{docType.folder}"</div>
                      <div className="text-sm text-muted-foreground">{docType.name}</div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className={getClassificationColor(docType.classification)}>
                    {docType.classification.toUpperCase()}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    ~{mockCounts[key as keyof typeof mockCounts]} docs
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start space-x-3">
          <AlertTriangle className="text-yellow-600 flex-shrink-0" size={20} />
          <p className="text-sm text-yellow-800">
            Document classifications will determine access controls and storage routing. Review carefully before proceeding.
          </p>
        </div>
      </div>
    );
  };

  const renderConnectionConfiguration = () => {
    const selectedSourceType = config.basicInfo.specificSourceType;
    
    // Cloud Storage Configuration
    if (selectedSourceType === 'cloud_storage') {
      return (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Cloud className="text-blue-600" size={20} />
                <span>Cloud Storage Provider</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { id: 'azure', name: 'Azure Blob Storage', icon: Cloud },
                  { id: 'aws', name: 'AWS S3', icon: Cloud },
                  { id: 'gcp', name: 'Google Cloud Storage', icon: Cloud }
                ].map(provider => {
                  const Icon = provider.icon;
                  return (
                    <Card 
                      key={provider.id}
                      className={`cursor-pointer transition-colors ${
                        config.connection.provider === provider.id 
                          ? 'border-blue-500 bg-blue-50' 
                          : 'hover:bg-muted/50'
                      }`}
                      onClick={() => updateConfig('connection', 'provider', provider.id)}
                      data-testid={`provider-${provider.id}`}
                    >
                      <CardContent className="p-4 text-center">
                        <Icon className="mx-auto mb-2 text-blue-600" size={24} />
                        <div className="text-sm font-medium">{provider.name}</div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {config.connection.provider === 'azure' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="text-blue-600" size={20} />
                  <span>Azure Blob Storage Configuration</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="azureAccountName">Storage Account Name *</Label>
                    <Input 
                      id="azureAccountName"
                      placeholder="mystorageaccount"
                      value={config.connection.azureAccountName}
                      onChange={(e) => updateConfig('connection', 'azureAccountName', e.target.value)}
                      data-testid="input-azure-account-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="azureContainerName">Container Name *</Label>
                    <Input 
                      id="azureContainerName"
                      placeholder="my-documents-container"
                      value={config.connection.azureContainerName}
                      onChange={(e) => updateConfig('connection', 'azureContainerName', e.target.value)}
                      data-testid="input-azure-container-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="azureAccountKey">Access Key *</Label>
                    <Input 
                      id="azureAccountKey"
                      type="password"
                      placeholder="••••••••••••••••••••"
                      value={config.connection.azureAccountKey}
                      onChange={(e) => updateConfig('connection', 'azureAccountKey', e.target.value)}
                      data-testid="input-azure-account-key"
                    />
                  </div>
                  <div>
                    <Label htmlFor="azureEndpoint">Custom Endpoint</Label>
                    <Input 
                      id="azureEndpoint"
                      placeholder="https://mystorageaccount.blob.core.windows.net/"
                      value={config.connection.azureEndpoint}
                      onChange={(e) => updateConfig('connection', 'azureEndpoint', e.target.value)}
                      data-testid="input-azure-endpoint"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="azureKeyVault">Azure Key Vault (Optional)</Label>
                    <Input 
                      id="azureKeyVault"
                      placeholder="https://myvault.vault.azure.net/"
                      value={config.connection.azureKeyVault}
                      onChange={(e) => updateConfig('connection', 'azureKeyVault', e.target.value)}
                      data-testid="input-azure-keyvault"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {config.connection.provider === 'aws' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="text-orange-600" size={20} />
                  <span>AWS S3 Configuration</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="awsBucketName">Bucket Name *</Label>
                    <Input 
                      id="awsBucketName"
                      placeholder="my-documents-bucket"
                      value={config.connection.awsBucketName}
                      onChange={(e) => updateConfig('connection', 'awsBucketName', e.target.value)}
                      data-testid="input-aws-bucket-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="awsRegion">Region *</Label>
                    <Select
                      value={config.connection.awsRegion}
                      onValueChange={(value) => updateConfig('connection', 'awsRegion', value)}
                    >
                      <SelectTrigger data-testid="select-aws-region">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                        <SelectItem value="us-west-1">US West (N. California)</SelectItem>
                        <SelectItem value="us-west-2">US West (Oregon)</SelectItem>
                        <SelectItem value="eu-west-1">Europe (Ireland)</SelectItem>
                        <SelectItem value="eu-central-1">Europe (Frankfurt)</SelectItem>
                        <SelectItem value="ap-southeast-1">Asia Pacific (Singapore)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="awsAccessKey">Access Key ID *</Label>
                    <Input 
                      id="awsAccessKey"
                      placeholder="AKIAIOSFODNN7EXAMPLE"
                      value={config.connection.awsAccessKey}
                      onChange={(e) => updateConfig('connection', 'awsAccessKey', e.target.value)}
                      data-testid="input-aws-access-key"
                    />
                  </div>
                  <div>
                    <Label htmlFor="awsSecretKey">Secret Access Key *</Label>
                    <Input 
                      id="awsSecretKey"
                      type="password"
                      placeholder="••••••••••••••••••••"
                      value={config.connection.awsSecretKey}
                      onChange={(e) => updateConfig('connection', 'awsSecretKey', e.target.value)}
                      data-testid="input-aws-secret-key"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="awsEndpoint">Custom Endpoint (Optional)</Label>
                    <Input 
                      id="awsEndpoint"
                      placeholder="https://s3.amazonaws.com"
                      value={config.connection.awsEndpoint}
                      onChange={(e) => updateConfig('connection', 'awsEndpoint', e.target.value)}
                      data-testid="input-aws-endpoint"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {config.connection.provider === 'gcp' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Key className="text-green-600" size={20} />
                  <span>Google Cloud Storage Configuration</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="gcpBucketName">Bucket Name *</Label>
                    <Input 
                      id="gcpBucketName"
                      placeholder="my-documents-bucket"
                      value={config.connection.gcpBucketName}
                      onChange={(e) => updateConfig('connection', 'gcpBucketName', e.target.value)}
                      data-testid="input-gcp-bucket-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="gcpProjectId">Project ID *</Label>
                    <Input 
                      id="gcpProjectId"
                      placeholder="my-project-id"
                      value={config.connection.gcpProjectId}
                      onChange={(e) => updateConfig('connection', 'gcpProjectId', e.target.value)}
                      data-testid="input-gcp-project-id"
                    />
                  </div>
                  <div>
                    <Label htmlFor="gcpRegion">Region</Label>
                    <Select
                      value={config.connection.gcpRegion}
                      onValueChange={(value) => updateConfig('connection', 'gcpRegion', value)}
                    >
                      <SelectTrigger data-testid="select-gcp-region">
                        <SelectValue placeholder="Select region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us-central1">US Central 1</SelectItem>
                        <SelectItem value="us-east1">US East 1</SelectItem>
                        <SelectItem value="europe-west1">Europe West 1</SelectItem>
                        <SelectItem value="asia-southeast1">Asia Southeast 1</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="gcpEndpoint">Custom Endpoint</Label>
                    <Input 
                      id="gcpEndpoint"
                      placeholder="https://storage.googleapis.com"
                      value={config.connection.gcpEndpoint}
                      onChange={(e) => updateConfig('connection', 'gcpEndpoint', e.target.value)}
                      data-testid="input-gcp-endpoint"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="gcpServiceAccountKey">Service Account Key (JSON) *</Label>
                    <Textarea 
                      id="gcpServiceAccountKey"
                      placeholder="Paste your service account JSON key here..."
                      value={config.connection.gcpServiceAccountKey}
                      onChange={(e) => updateConfig('connection', 'gcpServiceAccountKey', e.target.value)}
                      data-testid="textarea-gcp-service-key"
                      rows={4}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      );
    }

    // Database Configuration
    if (selectedSourceType === 'database') {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="text-blue-600" size={20} />
              <span>Database Connection</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="dbHost">Host/Server *</Label>
                <Input 
                  id="dbHost"
                  placeholder="localhost or server.database.windows.net"
                  value={config.connection.dbHost}
                  onChange={(e) => updateConfig('connection', 'dbHost', e.target.value)}
                  data-testid="input-db-host"
                />
              </div>
              <div>
                <Label htmlFor="dbPort">Port</Label>
                <Input 
                  id="dbPort"
                  placeholder="1433, 5432, 3306"
                  value={config.connection.dbPort}
                  onChange={(e) => updateConfig('connection', 'dbPort', e.target.value)}
                  data-testid="input-db-port"
                />
              </div>
              <div>
                <Label htmlFor="dbName">Database Name *</Label>
                <Input 
                  id="dbName"
                  placeholder="mydatabase"
                  value={config.connection.dbName}
                  onChange={(e) => updateConfig('connection', 'dbName', e.target.value)}
                  data-testid="input-db-name"
                />
              </div>
              <div>
                <Label htmlFor="dbUsername">Username *</Label>
                <Input 
                  id="dbUsername"
                  placeholder="dbuser"
                  value={config.connection.dbUsername}
                  onChange={(e) => updateConfig('connection', 'dbUsername', e.target.value)}
                  data-testid="input-db-username"
                />
              </div>
              <div>
                <Label htmlFor="dbPassword">Password *</Label>
                <Input 
                  id="dbPassword"
                  type="password"
                  placeholder="••••••••••••"
                  value={config.connection.dbPassword}
                  onChange={(e) => updateConfig('connection', 'dbPassword', e.target.value)}
                  data-testid="input-db-password"
                />
              </div>
              <div>
                <Label htmlFor="enableSSL">SSL Connection</Label>
                <div className="flex items-center space-x-2 mt-2">
                  <Switch 
                    checked={config.connection.enableSSL}
                    onCheckedChange={(checked) => updateConfig('connection', 'enableSSL', checked)}
                    data-testid="switch-ssl"
                  />
                  <Label>Enable SSL/TLS</Label>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="dbConnectionString">Connection String (Alternative)</Label>
              <Textarea 
                id="dbConnectionString"
                placeholder="Server=server.database.windows.net;Database=mydatabase;User Id=myuser;Password=mypassword;"
                value={config.connection.dbConnectionString}
                onChange={(e) => updateConfig('connection', 'dbConnectionString', e.target.value)}
                data-testid="textarea-connection-string"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>
      );
    }

    // SharePoint Configuration
    if (selectedSourceType === 'sharepoint_online' || selectedSourceType === 'sharepoint_hr' || selectedSourceType === 'sharepoint') {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Share2 className="text-blue-600" size={20} />
              <span>SharePoint Online Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="sharePointUrl">SharePoint Site URL *</Label>
                <Input 
                  id="sharePointUrl"
                  placeholder="https://company.sharepoint.com/sites/sitename"
                  value={config.connection.sharePointUrl}
                  onChange={(e) => updateConfig('connection', 'sharePointUrl', e.target.value)}
                  data-testid="input-sharepoint-url"
                />
              </div>
              <div>
                <Label htmlFor="sharePointTenantId">Tenant ID *</Label>
                <Input 
                  id="sharePointTenantId"
                  placeholder="12345678-1234-1234-1234-123456789abc"
                  value={config.connection.sharePointTenantId}
                  onChange={(e) => updateConfig('connection', 'sharePointTenantId', e.target.value)}
                  data-testid="input-sharepoint-tenant-id"
                />
              </div>
              <div>
                <Label htmlFor="sharePointClientId">Client ID *</Label>
                <Input 
                  id="sharePointClientId"
                  placeholder="12345678-1234-1234-1234-123456789abc"
                  value={config.connection.sharePointClientId}
                  onChange={(e) => updateConfig('connection', 'sharePointClientId', e.target.value)}
                  data-testid="input-sharepoint-client-id"
                />
              </div>
              <div>
                <Label htmlFor="sharePointClientSecret">Client Secret *</Label>
                <Input 
                  id="sharePointClientSecret"
                  type="password"
                  placeholder="••••••••••••••••••••"
                  value={config.connection.sharePointClientSecret}
                  onChange={(e) => updateConfig('connection', 'sharePointClientSecret', e.target.value)}
                  data-testid="input-sharepoint-client-secret"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    // Network Folder Configuration
    if (selectedSourceType === 'network_folder') {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <HardDrive className="text-blue-600" size={20} />
              <span>Network Folder Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label htmlFor="networkPath">Network Path *</Label>
                <Input 
                  id="networkPath"
                  placeholder="\\server\share\folder or /mnt/shared/documents"
                  value={config.connection.networkPath}
                  onChange={(e) => updateConfig('connection', 'networkPath', e.target.value)}
                  data-testid="input-network-path"
                />
              </div>
              <div>
                <Label htmlFor="networkUsername">Username</Label>
                <Input 
                  id="networkUsername"
                  placeholder="domain\user or user"
                  value={config.connection.networkUsername}
                  onChange={(e) => updateConfig('connection', 'networkUsername', e.target.value)}
                  data-testid="input-network-username"
                />
              </div>
              <div>
                <Label htmlFor="networkPassword">Password</Label>
                <Input 
                  id="networkPassword"
                  type="password"
                  placeholder="••••••••••••"
                  value={config.connection.networkPassword}
                  onChange={(e) => updateConfig('connection', 'networkPassword', e.target.value)}
                  data-testid="input-network-password"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    // FTP/SFTP Configuration
    if (selectedSourceType === 'ftp_sftp') {
      return (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Network className="text-blue-600" size={20} />
              <span>FTP/SFTP Configuration</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="ftpHost">Host/Server *</Label>
                <Input 
                  id="ftpHost"
                  placeholder="ftp.example.com"
                  value={config.connection.ftpHost}
                  onChange={(e) => updateConfig('connection', 'ftpHost', e.target.value)}
                  data-testid="input-ftp-host"
                />
              </div>
              <div>
                <Label htmlFor="ftpPort">Port *</Label>
                <Input 
                  id="ftpPort"
                  placeholder="21 for FTP, 22 for SFTP"
                  value={config.connection.ftpPort}
                  onChange={(e) => updateConfig('connection', 'ftpPort', e.target.value)}
                  data-testid="input-ftp-port"
                />
              </div>
              <div>
                <Label htmlFor="ftpUsername">Username *</Label>
                <Input 
                  id="ftpUsername"
                  placeholder="ftpuser"
                  value={config.connection.ftpUsername}
                  onChange={(e) => updateConfig('connection', 'ftpUsername', e.target.value)}
                  data-testid="input-ftp-username"
                />
              </div>
              <div>
                <Label htmlFor="ftpPassword">Password *</Label>
                <Input 
                  id="ftpPassword"
                  type="password"
                  placeholder="••••••••••••"
                  value={config.connection.ftpPassword}
                  onChange={(e) => updateConfig('connection', 'ftpPassword', e.target.value)}
                  data-testid="input-ftp-password"
                />
              </div>
              <div>
                <Label htmlFor="ftpProtocol">Protocol</Label>
                <Select
                  value={config.connection.ftpProtocol}
                  onValueChange={(value) => updateConfig('connection', 'ftpProtocol', value)}
                >
                  <SelectTrigger data-testid="select-ftp-protocol">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ftp">FTP</SelectItem>
                    <SelectItem value="ftps">FTPS</SelectItem>
                    <SelectItem value="sftp">SFTP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    // Default generic configuration
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Settings className="mx-auto mb-4 text-muted-foreground" size={48} />
          <h3 className="text-lg font-medium mb-2">Select a Source Type</h3>
          <p className="text-muted-foreground">Please select a specific source type in the Basic Info tab to configure connection settings.</p>
        </CardContent>
      </Card>
    );
  };

  const renderComplianceSettings = () => {
    const getBFSICompliances = () => [
      { key: 'sarbanesOxley', label: 'Sarbanes-Oxley Act', description: 'Financial reporting and corporate governance' },
      { key: 'antiMoneyLaundering', label: 'Anti-Money Laundering', description: 'Money laundering prevention' },
      { key: 'fairCreditReporting', label: 'Fair Credit Reporting Act', description: 'Credit reporting accuracy and privacy' },
      { key: 'usaPatriot', label: 'USA PATRIOT Act', description: 'Terrorism financing prevention' },
      { key: 'securitiesExchange', label: 'Securities and Exchange Commission', description: 'Securities regulation' },
      { key: 'foreignAssetsControl', label: 'Office of Foreign Assets Control', description: 'Economic sanctions enforcement' },
      { key: 'accountingPrinciples', label: 'Generally Accepted Accounting Principles', description: 'Accounting standards' },
      { key: 'fairLending', label: 'Fair Lending Act', description: 'Equal credit opportunity' },
      { key: 'recordKeeping', label: 'Record Keeping Requirements', description: 'Document retention obligations' },
      { key: 'stateTaxRegulations', label: 'State Tax Regulations', description: 'State taxation compliance' },
      { key: 'bankSecrecy', label: 'Bank Secrecy Act', description: 'Anti-money laundering requirements' },
      { key: 'grammLeachBliley', label: 'Gramm-Leach-Bliley Act', description: 'Financial privacy protection' },
      { key: 'truthInLending', label: 'Truth in Lending Act', description: 'Credit terms disclosure' },
      { key: 'financialCrimesNetwork', label: 'Financial Crimes Enforcement Network', description: 'Financial intelligence reporting' },
      { key: 'financialRegulatory', label: 'Financial Industry Regulatory Authority', description: 'Broker-dealer regulation' },
      { key: 'publicAccountingOversight', label: 'Public Company Accounting Oversight Board', description: 'Audit oversight' },
      { key: 'hipaa', label: 'Health Insurance Portability and Accountability Act', description: 'Healthcare privacy (for insurance)' },
      { key: 'securitiesAct1933', label: 'Securities Act of 1933', description: 'Securities registration and disclosure' },
      { key: 'stateInsurance', label: 'State Insurance Regulations', description: 'State-level insurance oversight' },
      { key: 'internalRevenue', label: 'Internal Revenue Service', description: 'Federal tax compliance' }
    ];

    const getHRCompliances = () => [
      { key: 'equalEmployment', label: 'Equal Employment Opportunity', description: 'Anti-discrimination in employment' },
      { key: 'familyMedicalLeave', label: 'Family and Medical Leave Act', description: 'Employee leave entitlements' },
      { key: 'occupationalSafety', label: 'Occupational Safety and Health Act', description: 'Workplace safety standards' },
      { key: 'fairLaborStandards', label: 'Fair Labor Standards Act', description: 'Minimum wage and overtime regulations' },
      { key: 'workersCompensation', label: 'Workers\' Compensation', description: 'Employee injury compensation' },
      { key: 'employmentEligibility', label: 'Employment Eligibility Verification', description: 'I-9 form compliance' },
      { key: 'cobraInsurance', label: 'COBRA Insurance', description: 'Continued health coverage rights' },
      { key: 'employeeRetirement', label: 'Employee Retirement Income Security Act', description: 'Retirement plan standards' },
      { key: 'americansDisabilities', label: 'Americans with Disabilities Act', description: 'Disability accommodation requirements' },
      { key: 'ageDiscrimination', label: 'Age Discrimination in Employment Act', description: 'Age-based employment protection' },
      { key: 'hipaa', label: 'Health Insurance Portability and Accountability Act', description: 'Healthcare privacy protection' }
    ];

    const availableCompliances = sourceType === SOURCE_TYPES.BFSI ? getBFSICompliances() : 
                                 sourceType === SOURCE_TYPES.HR ? getHRCompliances() : 
                                 [...getBFSICompliances(), ...getHRCompliances()];

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="text-green-600" size={20} />
              <span>Compliance & Security Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Processing Rules */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Processing Rules</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="enableOCR">Enable OCR Processing</Label>
                  <Switch 
                    id="enableOCR"
                    checked={config.compliance.enableOCR}
                    onCheckedChange={(checked) => updateConfig('compliance', 'enableOCR', checked)}
                    data-testid="switch-enable-ocr"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="enableAI">Enable AI Classification</Label>
                  <Switch 
                    id="enableAI"
                    checked={config.compliance.enableAIClassification}
                    onCheckedChange={(checked) => updateConfig('compliance', 'enableAIClassification', checked)}
                    data-testid="switch-enable-ai"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="enablePII">Enable PII Detection</Label>
                  <Switch 
                    id="enablePII"
                    checked={config.compliance.enablePII}
                    onCheckedChange={(checked) => updateConfig('compliance', 'enablePII', checked)}
                    data-testid="switch-enable-pii"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="enableCompliance">Enable Compliance Check</Label>
                  <Switch 
                    id="enableCompliance"
                    checked={config.compliance.enableComplianceCheck}
                    onCheckedChange={(checked) => updateConfig('compliance', 'enableComplianceCheck', checked)}
                    data-testid="switch-enable-compliance"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="requireEncryption">Require Encryption</Label>
                  <Switch 
                    id="requireEncryption"
                    checked={config.compliance.requireEncryption}
                    onCheckedChange={(checked) => updateConfig('compliance', 'requireEncryption', checked)}
                    data-testid="switch-require-encryption"
                  />
                </div>
              </div>
            </div>

            {/* Applicable Compliance Frameworks */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Applicable Compliance Frameworks</h3>
              <div className="grid grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                {availableCompliances.map(compliance => (
                  <div key={compliance.key} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <Checkbox 
                      id={compliance.key}
                      checked={config.compliance[compliance.key as keyof typeof config.compliance] as boolean}
                      onCheckedChange={(checked) => updateConfig('compliance', compliance.key, checked)}
                      data-testid={`checkbox-${compliance.key}`}
                      className="mt-1"
                    />
                    <div className="flex-1 min-w-0">
                      <Label 
                        htmlFor={compliance.key} 
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {compliance.label}
                      </Label>
                      <p className="text-xs text-muted-foreground mt-1">
                        {compliance.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Data Retention Policy */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Data Retention Policy</h3>
              <div className="max-w-md">
                <Label htmlFor="dataRetention">Select retention period</Label>
                <Select
                  value={config.compliance.dataRetentionPeriod}
                  onValueChange={(value) => updateConfig('compliance', 'dataRetentionPeriod', value)}
                >
                  <SelectTrigger data-testid="select-data-retention">
                    <SelectValue placeholder="Select retention period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="90_days">90 days</SelectItem>
                    <SelectItem value="6_months">6 months</SelectItem>
                    <SelectItem value="1_year">1 year</SelectItem>
                    <SelectItem value="2_years">2 years</SelectItem>
                    <SelectItem value="3_years">3 years</SelectItem>
                    <SelectItem value="5_years">5 years</SelectItem>
                    <SelectItem value="7_years">7 years</SelectItem>
                    <SelectItem value="10_years">10 years</SelectItem>
                    <SelectItem value="indefinite">Indefinite</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderOutputRouting = () => {
    const classifications = Object.values(SECURITY_CLASSIFICATIONS);
    const destinations = Object.entries(OUTPUT_DESTINATIONS);
    
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-2 mb-4">
          <Shield className="text-blue-600" size={20} />
          <h3 className="text-lg font-semibold">Output Routing Configuration</h3>
        </div>
        
        {classifications.map(classification => (
          <div key={classification} className="space-y-3">
            <div className="flex items-center space-x-2">
              <Lock className="text-muted-foreground" size={16} />
              <h4 className="font-medium text-foreground">{classification.toUpperCase()} Documents</h4>
            </div>
            
            <div className="grid grid-cols-2 gap-4 ml-6">
              {destinations.map(([key, value]) => (
                <Card 
                  key={`${classification}-${key}`}
                  className={`cursor-pointer transition-colors ${
                    key === 'LOCAL_NAS' ? 'border-blue-500 bg-blue-50' : 'hover:bg-muted/50'
                  }`}
                  data-testid={`destination-${classification}-${key}`}
                >
                  <CardContent className="p-3">
                    <div className="flex items-center space-x-2">
                      <HardDrive className="text-blue-600" size={16} />
                      <span className="text-sm font-medium">
                        {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  const canProceedToNext = (currentTab: string) => {
    switch (currentTab) {
      case "basic":
        return config.basicInfo.sourceName && config.basicInfo.specificSourceType;
      case "connection":
        const sourceType = config.basicInfo.specificSourceType;
        if (sourceType === 'cloud_storage') {
          return config.connection.provider && (
            (config.connection.provider === 'azure' && config.connection.azureAccountName && config.connection.azureContainerName) ||
            (config.connection.provider === 'aws' && config.connection.awsBucketName && config.connection.awsAccessKey) ||
            (config.connection.provider === 'gcp' && config.connection.gcpBucketName && config.connection.gcpProjectId)
          );
        } else if (sourceType === 'database') {
          return config.connection.dbHost && config.connection.dbName;
        } else if (sourceType === 'sharepoint_online' || sourceType === 'sharepoint_hr' || sourceType === 'sharepoint') {
          return config.connection.sharePointUrl && config.connection.sharePointClientId;
        } else if (sourceType === 'network_folder') {
          return config.connection.networkPath;
        } else if (sourceType === 'ftp_sftp') {
          return config.connection.ftpHost && config.connection.ftpUsername;
        }
        return true;
      case "document_types":
        return true;
      case "compliance":
        return true;
      default:
        return false;
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <Card className="shadow-lg">
        <CardHeader className="border-b">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 ${sourceConfig.iconBg} rounded-lg flex items-center justify-center`}>
                <Building2 className={sourceConfig.color} size={20} />
              </div>
              <div>
                <CardTitle className="text-xl">{sourceConfig.title}</CardTitle>
                <p className="text-sm text-muted-foreground">Configure your document processing source</p>
              </div>
            </div>
            <Button variant="ghost" onClick={onCancel} data-testid="button-close">
              ✕
            </Button>
          </div>
        </CardHeader>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic" className="flex items-center space-x-2">
                <span className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs">
                  {activeTab !== "basic" ? <CheckCircle size={14} /> : "1"}
                </span>
                <span>Basic Info</span>
              </TabsTrigger>
              <TabsTrigger value="connection">
                <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs">2</span>
                <span>Connection</span>
              </TabsTrigger>
              <TabsTrigger value="document_types">
                <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs">3</span>
                <span>Document Types</span>
              </TabsTrigger>
              <TabsTrigger value="compliance">
                <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-xs">4</span>
                <span>Review & Create</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="sourceName">Source Name *</Label>
                      <Input 
                        id="sourceName"
                        placeholder="e.g., Main Core Banking System"
                        value={config.basicInfo.sourceName}
                        onChange={(e) => updateConfig('basicInfo', 'sourceName', e.target.value)}
                        data-testid="input-source-name"
                      />
                    </div>
                    <div>
                      <Label>Classification Level *</Label>
                      <div className="grid grid-cols-2 gap-3 mt-2">
                        {[
                          { id: 'confidential', label: 'Confidential', color: 'text-red-600' },
                          { id: 'restricted', label: 'Restricted', color: 'text-orange-600' },
                          { id: 'internal', label: 'Internal', color: 'text-blue-600' },
                          { id: 'public', label: 'Public', color: 'text-green-600' }
                        ].map(level => (
                          <div key={level.id} className="flex items-center space-x-2">
                            <Checkbox 
                              id={level.id}
                              checked={config.basicInfo.classificationLevels.includes(level.id)}
                              onCheckedChange={(checked) => updateClassificationLevels(level.id, checked as boolean)}
                              data-testid={`checkbox-${level.id}`}
                            />
                            <Label 
                              htmlFor={level.id} 
                              className={`text-sm ${level.color} font-medium`}
                            >
                              {level.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea 
                      id="description"
                      placeholder="Describe this data source and its purpose..."
                      value={config.basicInfo.description}
                      onChange={(e) => updateConfig('basicInfo', 'description', e.target.value)}
                      data-testid="textarea-description"
                    />
                  </div>
                  
                  <div>
                    <Label>Source Type *</Label>
                    <div className="grid grid-cols-2 gap-4 mt-2">
                      {sourceConfig.sources.map((source) => {
                        const Icon = source.icon;
                        return (
                          <Card 
                            key={source.id}
                            className={`cursor-pointer transition-colors ${
                              config.basicInfo.specificSourceType === source.id 
                                ? 'border-blue-500 bg-blue-50' 
                                : 'hover:bg-muted/50'
                            }`}
                            onClick={() => updateConfig('basicInfo', 'specificSourceType', source.id)}
                            data-testid={`card-source-${source.id}`}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-center space-x-3">
                                <Icon className="text-blue-600" size={20} />
                                <div>
                                  <div className="font-medium">{source.name}</div>
                                  <div className="text-sm text-muted-foreground">{source.desc}</div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="connection" className="space-y-6 mt-6">
              <div className="space-y-6">
                {renderConnectionConfiguration()}
                {config.basicInfo.specificSourceType && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Settings className="text-blue-600" size={20} />
                        <span>Advanced Connection Settings</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="pollingInterval">Polling Interval</Label>
                          <Select
                            value={config.connection.pollingInterval}
                            onValueChange={(value) => updateConfig('connection', 'pollingInterval', value)}
                          >
                            <SelectTrigger data-testid="select-polling-interval">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="15">15 seconds</SelectItem>
                              <SelectItem value="30">30 seconds</SelectItem>
                              <SelectItem value="60">1 minute</SelectItem>
                              <SelectItem value="300">5 minutes</SelectItem>
                              <SelectItem value="900">15 minutes</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label htmlFor="timeout">Connection Timeout</Label>
                          <Select
                            value={config.connection.timeout}
                            onValueChange={(value) => updateConfig('connection', 'timeout', value)}
                          >
                            <SelectTrigger data-testid="select-timeout">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="30">30 seconds</SelectItem>
                              <SelectItem value="60">60 seconds</SelectItem>
                              <SelectItem value="120">2 minutes</SelectItem>
                              <SelectItem value="300">5 minutes</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label htmlFor="maxRetry">Max Retry Attempts</Label>
                          <Select
                            value={config.connection.maxRetryAttempts}
                            onValueChange={(value) => updateConfig('connection', 'maxRetryAttempts', value)}
                          >
                            <SelectTrigger data-testid="select-max-retry">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="0">No retries</SelectItem>
                              <SelectItem value="1">1 attempt</SelectItem>
                              <SelectItem value="3">3 attempts</SelectItem>
                              <SelectItem value="5">5 attempts</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between pt-4">
                        <div className="flex items-center space-x-6">
                          <div className="flex items-center space-x-2">
                            <Switch 
                              checked={config.connection.enableRetry}
                              onCheckedChange={(checked) => updateConfig('connection', 'enableRetry', checked)}
                              data-testid="switch-enable-retry"
                            />
                            <Label>Enable automatic retry on failure</Label>
                          </div>
                        </div>
                        
                        <Button 
                          variant="outline"
                          className="flex items-center space-x-2"
                          data-testid="button-test-connection"
                        >
                          <Globe className="text-blue-600" size={16} />
                          <span>Test Connection</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            <TabsContent value="document_types" className="mt-6">
              <Card>
                <CardContent className="p-6">
                  {sourceType === SOURCE_TYPES.HR ? renderHRDocumentMapping() : (
                    <div className="text-center py-8">
                      <FileText className="mx-auto text-muted-foreground mb-4" size={48} />
                      <h3 className="text-lg font-medium mb-2">Document Type Configuration</h3>
                      <p className="text-muted-foreground">Configure document types and classifications for {sourceType.toUpperCase()} sources</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="compliance" className="mt-6">
              {renderComplianceSettings()}
            </TabsContent>
          </Tabs>

          <div className="flex justify-between mt-8">
            <Button 
              variant="outline" 
              onClick={onCancel}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            
            <div className="space-x-2">
              {activeTab !== "basic" && (
                <Button 
                  variant="outline"
                  onClick={() => {
                    const tabs = ["basic", "connection", "document_types", "compliance"];
                    const currentIndex = tabs.indexOf(activeTab);
                    if (currentIndex > 0) setActiveTab(tabs[currentIndex - 1]);
                  }}
                  data-testid="button-previous-tab"
                >
                  Previous
                </Button>
              )}
              
              {activeTab === "compliance" ? (
                <Button 
                  onClick={() => onComplete(config)}
                  disabled={!canProceedToNext(activeTab)}
                  data-testid="button-create-source"
                >
                  Create {sourceType.toUpperCase()} Source
                </Button>
              ) : (
                <Button 
                  onClick={() => {
                    const tabs = ["basic", "connection", "document_types", "compliance"];
                    const currentIndex = tabs.indexOf(activeTab);
                    if (currentIndex < tabs.length - 1) setActiveTab(tabs[currentIndex + 1]);
                  }}
                  disabled={!canProceedToNext(activeTab)}
                  data-testid="button-next-tab"
                >
                  Next
                </Button>
              )}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}