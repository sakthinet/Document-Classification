import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  FileText, 
  BarChart3, 
  Cog, 
  Search, 
  Database, 
  Brain,
  Activity,
  Users,
  Settings,
  Home,
  Workflow,
  Monitor,
  FolderCog,
  Server
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

const navigation = [
  {
    title: "Overview",
    items: [
      {
        title: "Dashboard",
        href: "/",
        icon: Home,
        description: "Main dashboard overview"
      },
      {
        title: "Microservices",
        href: "/microservices",
        icon: Server,
        description: "Service architecture and status"
      }
    ]
  },
  {
    title: "Processing",
    items: [
      {
        title: "Workflow Builder",
        href: "/pipeline-builder",
        icon: Workflow,
        description: "Create and configure workflows"
      },
      {
        title: "Configuration Management",
        href: "/config-management",
        icon: FolderCog,
        description: "Manage system configurations"
      },
      {
        title: "Management Console",
        icon: Monitor,
        description: "Monitor and manage operations",
        subItems: [
          {
            title: "Active Jobs",
            href: "/jobs",
            icon: Activity,
            description: "Monitor processing jobs"
          },
          {
            title: "Document Sources",
            href: "/sources",
            icon: Database,
            description: "Manage data sources"
          }
        ]
      }
    ]
  },
  {
    title: "AI & Analytics",
    items: [
      {
        title: "Semantic Search",
        href: "/search",
        icon: Search,
        description: "Search documents with AI"
      },
      {
        title: "Analytics",
        href: "/analytics",
        icon: BarChart3,
        description: "Performance insights"
      },
      {
        title: "Model Management",
        href: "/models",
        icon: Brain,
        description: "AI model configurations"
      }
    ]
  },
  {
    title: "System",
    items: [
      {
        title: "User Management",
        href: "/users",
        icon: Users,
        description: "Manage users and permissions"
      },
      {
        title: "System Settings",
        href: "/settings",
        icon: Settings,
        description: "Configure system settings"
      }
    ]
  }
];

export function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();

  return (
    <div className={cn("flex h-full w-64 flex-col bg-card border-r border-border", className)}>
      {/* Logo */}
      <div className="flex h-16 items-center px-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="text-primary-foreground text-lg" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">DocIntel Pro</h1>
            <p className="text-xs text-muted-foreground">Document Intelligence</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-3">
        <div className="space-y-6 py-4">
          {navigation.map((section) => (
            <div key={section.title}>
              <h3 className="px-3 mb-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                {section.title}
              </h3>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  
                  // Handle items with sub-navigation
                  if (item.subItems) {
                    return (
                      <div key={item.title} className="space-y-1">
                        <div className="px-3 py-2">
                          <div className="flex items-center space-x-3 text-muted-foreground">
                            <Icon className="h-4 w-4" />
                            <div className="flex flex-col items-start">
                              <span className="text-sm font-medium">{item.title}</span>
                              <span className="text-xs text-muted-foreground">{item.description}</span>
                            </div>
                          </div>
                        </div>
                        <div className="ml-6 space-y-1 border-l border-border pl-4">
                          {item.subItems.map((subItem) => {
                            const SubIcon = subItem.icon;
                            const isActive = location === subItem.href;
                            
                            return (
                              <Link key={subItem.href} href={subItem.href}>
                                <Button
                                  variant="ghost"
                                  className={cn(
                                    "w-full justify-start h-auto p-2 font-normal text-xs",
                                    isActive 
                                      ? "bg-primary/10 text-primary border-l-2 border-primary" 
                                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                                  )}
                                  data-testid={`nav-${subItem.href.slice(1)}`}
                                >
                                  <SubIcon className="mr-2 h-3 w-3" />
                                  <div className="flex flex-col items-start">
                                    <span className="text-xs font-medium">{subItem.title}</span>
                                  </div>
                                </Button>
                              </Link>
                            );
                          })}
                        </div>
                      </div>
                    );
                  }
                  
                  // Handle regular navigation items
                  const isActive = location === item.href;
                  return (
                    <Link key={item.href} href={item.href}>
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start h-auto p-3 font-normal",
                          isActive 
                            ? "bg-primary/10 text-primary border-l-2 border-primary" 
                            : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                        )}
                        data-testid={`nav-${item.href.slice(1) || 'dashboard'}`}
                      >
                        <Icon className="mr-3 h-4 w-4" />
                        <div className="flex flex-col items-start">
                          <span className="text-sm font-medium">{item.title}</span>
                          <span className="text-xs text-muted-foreground">{item.description}</span>
                        </div>
                      </Button>
                    </Link>
                  );
                })}
              </div>
              {section !== navigation[navigation.length - 1] && (
                <Separator className="mt-4" />
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* User section */}
      <div className="border-t border-border p-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
            <Users className="text-muted-foreground" size={16} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">Admin User</p>
            <p className="text-xs text-muted-foreground">System Administrator</p>
          </div>
          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
            <Cog size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}