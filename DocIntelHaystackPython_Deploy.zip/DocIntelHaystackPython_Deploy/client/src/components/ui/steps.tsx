import * as React from "react"
import { cn } from "@/lib/utils"

interface StepsProps {
  steps: Array<{
    title: string
    description?: string
    status: "completed" | "current" | "upcoming"
  }>
  className?: string
}

export function Steps({ steps, className }: StepsProps) {
  return (
    <div className={cn("flex items-center justify-center space-x-24 relative", className)}>
      {steps.map((step, index) => (
        <div 
          key={index}
          className={cn(
            "step-indicator flex flex-col items-center",
            step.status === "current" && "active",
            step.status === "completed" && "completed"
          )}
        >
          <div className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center font-semibold text-lg mb-3 relative z-10",
            step.status === "completed" && "bg-accent text-accent-foreground",
            step.status === "current" && "bg-primary text-primary-foreground",
            step.status === "upcoming" && "bg-muted text-muted-foreground"
          )}>
            {step.status === "completed" ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              index + 1
            )}
          </div>
          <div className="text-center">
            <p className={cn(
              "font-medium",
              step.status === "upcoming" ? "text-muted-foreground" : "text-foreground"
            )}>
              {step.title}
            </p>
            {step.description && (
              <p className="text-xs text-muted-foreground">{step.description}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}
