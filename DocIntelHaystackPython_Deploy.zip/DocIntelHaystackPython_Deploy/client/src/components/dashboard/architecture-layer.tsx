import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Monitor, Network, Layers, Workflow } from "lucide-react";

export default function ArchitectureLayer() {
  const presentationServices = [
    {
      title: "Smart Dashboard",
      features: ["Real-time processing", "Pipeline monitoring", "Document insights", "Haystack pipelines viz"]
    },
    {
      title: "Semantic Search Hub", 
      features: ["Semantic search UI", "RAG chat interface", "Faceted filters", "Multi-modal search"]
    },
    {
      title: "AI Analytics & Insights",
      features: ["Pipeline metrics", "Model performance", "Search analytics", "Vector visualizations"]
    }
  ];

  const apiMetrics = [
    { label: "Requests/second", value: "30,000-50,000" },
    { label: "Pipeline cache hit", value: "94.2%" },
    { label: "Model warm-up time", value: "< 2.5s" },
    { label: "Health status", value: "Healthy", isStatus: true }
  ];

  const businessServices = [
    {
      title: "Pipeline Configuration Service",
      description: "FastAPI + Haystack",
      features: ["Pipeline templates", "Component registry", "Model management", "Pipeline versioning", "A/B testing"]
    },
    {
      title: "Search & RAG Service", 
      description: "FastAPI + Haystack",
      features: ["Semantic search", "Hybrid search", "RAG pipelines", "Q&A systems", "Real-time indexing"]
    },
    {
      title: "Document Intelligence Service",
      description: "FastAPI + Haystack", 
      features: ["Classification", "Extraction", "Summarization", "NER/NLP", "Multi-modal analysis"]
    },
    {
      title: "Vector Store Management",
      description: "FastAPI + Haystack",
      features: ["Qdrant management", "Index optimization", "Backup/restore", "Sharding", "Replication"]
    },
    {
      title: "Model Serving Service",
      description: "FastAPI + Haystack",
      features: ["Embedding models", "LLM serving", "Model versioning", "Load balancing", "GPU management"]
    },
    {
      title: "Analytics & Monitoring",
      description: "FastAPI + Haystack", 
      features: ["Pipeline metrics", "Search analytics", "Usage tracking", "Performance optimization", "Cost monitoring"]
    }
  ];

  const orchestrationDAGs = [
    { name: "DocumentIngestionPipelineDAG", status: "Active" },
    { name: "SemanticSearchIndexingDAG", status: "Active" },
    { name: "ModelRetrainingPipelineDAG", status: "Scheduled" },
    { name: "ComplianceValidationDAG", status: "Running" }
  ];

  const integrations = {
    documentStores: "Qdrant, PostgreSQL, InMemory",
    retrievers: "Dense, Sparse, Hybrid, Multi-modal", 
    readers: "TransformersReader, FARMReader, LLMReader",
    generators: "OpenAI, Anthropic, Local LLMs"
  };

  return (
    <div className="space-y-8">
      {/* Presentation Layer */}
      <Card>
        <CardHeader>
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
              <Monitor className="text-primary text-xl" />
            </div>
            <div>
              <CardTitle>Presentation Layer</CardTitle>
              <p className="text-muted-foreground">React 18 + TypeScript + Ant Design Pro</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {presentationServices.map((service, index) => (
              <div key={index} className="pipeline-node bg-background p-4 rounded-lg border border-border">
                <h4 className="font-medium text-foreground mb-2">{service.title}</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex}>• {feature}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-4 text-sm text-muted-foreground">
            <i className="fas fa-plug text-accent mr-2"></i>
            <span>Connected to Haystack Gateway via WebSocket</span>
          </div>
        </CardContent>
      </Card>

      {/* API Gateway Layer */}
      <Card>
        <CardHeader>
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
              <Network className="text-accent text-xl" />
            </div>
            <div>
              <CardTitle>Haystack-Native API Gateway</CardTitle>
              <p className="text-muted-foreground">FastAPI + Haystack Pipeline Auto-generation</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-background p-6 rounded-lg border border-border">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-foreground mb-3">Native Haystack Routes</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <code className="text-primary font-mono">/api/pipelines/*</code>
                    <span className="text-muted-foreground">Pipeline Manager</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <code className="text-primary font-mono">/api/search/*</code>
                    <span className="text-muted-foreground">Search Pipelines</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <code className="text-primary font-mono">/api/rag/*</code>
                    <span className="text-muted-foreground">RAG Pipelines</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <code className="text-primary font-mono">/api/indexing/*</code>
                    <span className="text-muted-foreground">Document Processing</span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-3">Performance Metrics</h4>
                <div className="space-y-2 text-sm">
                  {apiMetrics.map((metric, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-muted-foreground">{metric.label}</span>
                      {metric.isStatus ? (
                        <span className="flex items-center text-accent">
                          <div className="w-2 h-2 bg-accent rounded-full mr-2"></div>
                          {metric.value}
                        </span>
                      ) : (
                        <span className="font-mono text-accent">{metric.value}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Business Services Layer */}
      <Card>
        <CardHeader>
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
              <Layers className="text-purple-600 text-xl" />
            </div>
            <div>
              <CardTitle>Haystack-Powered Business Services</CardTitle>
              <p className="text-muted-foreground">Native Haystack Microservices Architecture</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {businessServices.map((service, index) => (
              <div key={index} className="pipeline-node bg-background p-4 rounded-lg border border-border">
                <h4 className="font-medium text-foreground mb-2">{service.title}</h4>
                <p className="text-xs text-muted-foreground mb-3">{service.description}</p>
                <ul className="text-xs text-muted-foreground space-y-1">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex}>• {feature}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="p-4 bg-muted/50 rounded-lg border border-border">
            <h4 className="font-medium text-foreground mb-2">Native Haystack Integration</h4>
            <div className="grid grid-cols-2 gap-6 text-sm">
              {Object.entries(integrations).map(([key, value]) => (
                <div key={key}>
                  <span className="text-muted-foreground font-medium capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}:
                  </span>
                  <span className="ml-2 text-foreground">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Processing Orchestration Layer */}
      <Card>
        <CardHeader>
          <div className="flex items-center">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
              <Workflow className="text-orange-600 text-xl" />
            </div>
            <div>
              <CardTitle>Haystack-Native Processing Orchestration</CardTitle>
              <p className="text-muted-foreground">Apache Airflow + Haystack Pipeline Integration</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-background p-6 rounded-lg border border-border">
            <div className="grid grid-cols-2 gap-8">
              <div>
                <h4 className="font-medium text-foreground mb-4">Haystack-Native Orchestration</h4>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li className="flex items-start">
                    <i className="fas fa-cog text-primary mr-3 mt-1"></i>
                    <div>
                      <span className="font-medium text-foreground">HaystackPipelineOperator</span>
                      <p className="text-xs">Custom Airflow operator for Haystack pipelines</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-sitemap text-primary mr-3 mt-1"></i>
                    <div>
                      <span className="font-medium text-foreground">Dynamic pipeline DAG generation</span>
                      <p className="text-xs">Auto-generate DAGs from Haystack pipeline configs</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-link text-primary mr-3 mt-1"></i>
                    <div>
                      <span className="font-medium text-foreground">Pipeline dependency management</span>
                      <p className="text-xs">Handle complex pipeline dependencies</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-foreground mb-4">Core Processing DAGs</h4>
                <ul className="space-y-2 text-sm">
                  {orchestrationDAGs.map((dag, index) => (
                    <li key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                      <span className="font-mono text-foreground">{dag.name}</span>
                      <Badge 
                        variant={dag.status === "Active" || dag.status === "Running" ? "default" : "secondary"}
                        className={
                          dag.status === "Active" ? "bg-accent text-accent-foreground" :
                          dag.status === "Running" ? "bg-primary text-primary-foreground" :
                          "bg-muted text-muted-foreground"
                        }
                      >
                        {dag.status}
                      </Badge>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
