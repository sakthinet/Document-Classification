import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, Clock, AlertTriangle, TrendingUp } from "lucide-react";

export default function SystemStatus() {
  const { data: systemMetrics } = useQuery({
    queryKey: ["/api/system/metrics"],
  });

  const { data: recentActivities } = useQuery({
    queryKey: ["/api/activities/recent"],
  });

  // Fallback data for display
  const metrics = systemMetrics || {
    documentsProcessed: 1247,
    accuracyRate: 94.2,
    activePipelines: 8,
    avgProcessingTime: 2.4
  };

  const activities: any[] = recentActivities || [
    {
      id: 1,
      name: "BFSI Document Processing completed",
      description: "78 financial documents classified and indexed", 
      timestamp: "2 minutes ago",
      status: "completed"
    },
    {
      id: 2,
      name: "HR Pipeline model updated",
      description: "Employee classification model retrained with new data",
      timestamp: "15 minutes ago", 
      status: "completed"
    },
    {
      id: 3,
      name: "Vector store optimization in progress",
      description: "Qdrant index optimization running (45% complete)",
      timestamp: "1 hour ago",
      status: "running"
    }
  ];

  const getActivityIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="text-accent" size={16} />;
      case "running":
        return <Clock className="text-blue-600" size={16} />;
      case "error":
        return <AlertTriangle className="text-destructive" size={16} />;
      default:
        return <Clock className="text-muted-foreground" size={16} />;
    }
  };

  const getActivityIconBg = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-accent/20";
      case "running":
        return "bg-blue-100";
      case "error":
        return "bg-destructive/20";
      default:
        return "bg-muted";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>System Status & Metrics</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="text-center p-4 bg-background rounded-lg border border-border">
            <div className="text-2xl font-bold text-primary" data-testid="metric-documents-processed">
              {metrics.documentsProcessed.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Documents Processed</div>
            <div className="text-xs text-accent flex items-center justify-center mt-1">
              <TrendingUp size={12} className="mr-1" />
              +12% from last month
            </div>
          </div>
          
          <div className="text-center p-4 bg-background rounded-lg border border-border">
            <div className="text-2xl font-bold text-accent" data-testid="metric-accuracy-rate">
              {metrics.accuracyRate}%
            </div>
            <div className="text-sm text-muted-foreground">Classification Accuracy</div>
            <div className="text-xs text-accent flex items-center justify-center mt-1">
              <TrendingUp size={12} className="mr-1" />
              +3% improvement
            </div>
          </div>
          
          <div className="text-center p-4 bg-background rounded-lg border border-border">
            <div className="text-2xl font-bold text-purple-600" data-testid="metric-active-pipelines">
              {metrics.activePipelines}
            </div>
            <div className="text-sm text-muted-foreground">Active Pipelines</div>
            <div className="text-xs text-muted-foreground">Across 3 sources</div>
          </div>
          
          <div className="text-center p-4 bg-background rounded-lg border border-border">
            <div className="text-2xl font-bold text-orange-600" data-testid="metric-avg-processing-time">
              {metrics.avgProcessingTime}s
            </div>
            <div className="text-sm text-muted-foreground">Avg Processing Time</div>
            <div className="text-xs text-accent flex items-center justify-center mt-1">
              <TrendingUp size={12} className="mr-1" />
              -15% faster
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div>
          <h4 className="font-medium text-foreground mb-4">Recent Pipeline Activity</h4>
          <div className="space-y-3">
            {activities.map((activity) => (
              <div 
                key={activity.id}
                className="flex items-center justify-between p-3 bg-background rounded-lg border border-border"
                data-testid={`activity-${activity.id}`}
              >
                <div className="flex items-center">
                  <div className={`w-8 h-8 ${getActivityIconBg(activity.status)} rounded-full flex items-center justify-center mr-3`}>
                    {getActivityIcon(activity.status)}
                  </div>
                  <div>
                    <div className="font-medium text-foreground text-sm">
                      {activity.name}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {activity.description}
                    </div>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {activity.timestamp}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
