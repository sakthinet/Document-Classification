import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Plus, Search, BarChart3, Cog } from "lucide-react";

export default function QuickActions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Link href="/pipeline-builder">
          <Button 
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground p-4 transition-colors text-left justify-start"
            data-testid="button-new-processing-job"
          >
            <Plus className="mr-3" size={20} />
            <div>
              <div className="font-medium">New Processing Job</div>
              <div className="text-sm opacity-90">Start pipeline configuration</div>
            </div>
          </Button>
        </Link>
        
        <Button 
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground p-4 transition-colors text-left justify-start"
          data-testid="button-semantic-search"
        >
          <Search className="mr-3" size={20} />
          <div>
            <div className="font-medium">Semantic Search</div>
            <div className="text-sm opacity-90">Query document vectors</div>
          </div>
        </Button>
        
        <Button 
          variant="secondary"
          className="w-full p-4 transition-colors text-left justify-start"
          data-testid="button-view-analytics"
        >
          <BarChart3 className="mr-3" size={20} />
          <div>
            <div className="font-medium">View Analytics</div>
            <div className="text-sm text-muted-foreground">Performance metrics</div>
          </div>
        </Button>
        
        <Button 
          variant="secondary"
          className="w-full p-4 transition-colors text-left justify-start"
          data-testid="button-pipeline-templates"
        >
          <Cog className="mr-3" size={20} />
          <div>
            <div className="font-medium">Pipeline Templates</div>
            <div className="text-sm text-muted-foreground">Manage configurations</div>
          </div>
        </Button>
      </CardContent>
    </Card>
  );
}
