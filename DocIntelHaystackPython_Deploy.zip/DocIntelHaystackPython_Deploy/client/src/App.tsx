import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { MainLayout } from "@/components/layout/main-layout";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import PipelineBuilder from "@/pages/pipeline-builder";
import Jobs from "@/pages/jobs";
import SemanticSearch from "@/pages/search";
import MicroservicesPage from "@/pages/microservices";

function Router() {
  return (
    <MainLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/microservices" component={MicroservicesPage} />
        <Route path="/pipeline-builder" component={PipelineBuilder} />
        <Route path="/jobs" component={Jobs} />
        <Route path="/search" component={SemanticSearch} />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      <Router />
    </QueryClientProvider>
  );
}

export default App;
