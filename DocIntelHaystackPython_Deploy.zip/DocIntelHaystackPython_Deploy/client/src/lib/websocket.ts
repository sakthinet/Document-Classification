import { useEffect, useRef, useState } from "react";

interface WebSocketHook {
  socket: WebSocket | null;
  connectionStatus: "connecting" | "connected" | "disconnected" | "error";
  sendMessage: (message: any) => void;
}

export function useWebSocket(url?: string): WebSocketHook {
  const [connectionStatus, setConnectionStatus] = useState<WebSocketHook["connectionStatus"]>("disconnected");
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!url) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = url.startsWith("ws") ? url : `${protocol}//${window.location.host}/ws`;
    
    setConnectionStatus("connecting");
    
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;

    socket.onopen = () => {
      setConnectionStatus("connected");
    };

    socket.onclose = () => {
      setConnectionStatus("disconnected");
    };

    socket.onerror = () => {
      setConnectionStatus("error");
    };

    return () => {
      socket.close();
    };
  }, [url]);

  const sendMessage = (message: any) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(message));
    }
  };

  return {
    socket: socketRef.current,
    connectionStatus,
    sendMessage,
  };
}

export function usePipelineStatusWebSocket() {
  return useWebSocket("/ws");
}
