import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Activity, Clock, CheckCircle, AlertTriangle } from "lucide-react";

export default function Jobs() {
  const { data: jobs } = useQuery({
    queryKey: ["/api/jobs"],
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="text-accent" size={16} />;
      case "running":
        return <Clock className="text-blue-600" size={16} />;
      case "failed":
        return <AlertTriangle className="text-destructive" size={16} />;
      default:
        return <Activity className="text-muted-foreground" size={16} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "running":
        return "bg-blue-100 text-blue-800";
      case "failed":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Mock data for display
  const mockJobs = jobs || [
    {
      id: "job-1",
      pipelineId: "pipeline-1",
      status: "running",
      documentsProcessed: 45,
      documentsTotal: 100,
      startedAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      sourceType: "BFSI"
    },
    {
      id: "job-2", 
      pipelineId: "pipeline-2",
      status: "completed",
      documentsProcessed: 78,
      documentsTotal: 78,
      startedAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      completedAt: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      sourceType: "HR"
    },
    {
      id: "job-3",
      pipelineId: "pipeline-3", 
      status: "failed",
      documentsProcessed: 12,
      documentsTotal: 50,
      startedAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      errorMessage: "Connection timeout",
      sourceType: "Generic"
    }
  ];

  return (
    <div className="flex-1 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Active Jobs</h1>
          <p className="text-muted-foreground">
            Monitor and manage document processing jobs
          </p>
        </div>
        <Button data-testid="button-new-job">
          <Activity className="mr-2" size={16} />
          Start New Job
        </Button>
      </div>

      {/* Jobs List */}
      <div className="space-y-4">
        {mockJobs.map((job: any) => (
          <Card key={job.id} data-testid={`job-card-${job.id}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  {getStatusIcon(job.status)}
                  <span className="ml-2">{job.sourceType} Document Processing</span>
                </CardTitle>
                <Badge className={getStatusColor(job.status)}>
                  {job.status.toUpperCase()}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Progress</p>
                  <p className="font-medium">
                    {job.documentsProcessed} / {job.documentsTotal} documents
                  </p>
                  <div className="w-full bg-muted rounded-full h-2 mt-2">
                    <div
                      className="bg-primary h-2 rounded-full"
                      style={{
                        width: `${(job.documentsProcessed / job.documentsTotal) * 100}%`
                      }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-muted-foreground">Started</p>
                  <p className="font-medium">
                    {job.startedAt.toLocaleString()}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-muted-foreground">Duration</p>
                  <p className="font-medium">
                    {job.completedAt 
                      ? `${Math.floor((job.completedAt - job.startedAt) / (1000 * 60))} min`
                      : `${Math.floor((Date.now() - job.startedAt) / (1000 * 60))} min`
                    }
                  </p>
                </div>
              </div>
              
              {job.errorMessage && (
                <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                  <p className="text-sm text-destructive font-medium">Error: {job.errorMessage}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}