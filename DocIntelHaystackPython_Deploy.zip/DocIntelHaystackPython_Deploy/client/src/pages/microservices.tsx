// Microservices Management Page
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MicroservicesStatus, DocumentProcessor, SemanticSearch } from '@/components/microservices';
import { 
  Server, 
  FileText, 
  Search, 
  Workflow,
  BarChart3,
  Shield
} from 'lucide-react';

export default function MicroservicesPage() {
  return (
    <div className="flex-1 p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Microservices Architecture</h1>
        <p className="text-muted-foreground">
          Haystack-powered document intelligence platform with distributed AI services
        </p>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="status" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="status" className="flex items-center">
            <Server className="h-4 w-4 mr-2" />
            Service Status
          </TabsTrigger>
          <TabsTrigger value="processor" className="flex items-center">
            <FileText className="h-4 w-4 mr-2" />
            Document Processor
          </TabsTrigger>
          <TabsTrigger value="search" className="flex items-center">
            <Search className="h-4 w-4 mr-2" />
            Semantic Search
          </TabsTrigger>
          <TabsTrigger value="overview" className="flex items-center">
            <Workflow className="h-4 w-4 mr-2" />
            Architecture
          </TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="space-y-6">
          <MicroservicesStatus />
        </TabsContent>

        <TabsContent value="processor" className="space-y-6">
          <DocumentProcessor />
        </TabsContent>

        <TabsContent value="search" className="space-y-6">
          <SemanticSearch />
        </TabsContent>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6">
            {/* Architecture Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Workflow className="h-5 w-5 mr-2" />
                  Microservices Architecture Overview
                </CardTitle>
                <CardDescription>
                  DocIntel Haystack Platform - Distributed AI Document Processing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Service Diagram */}
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <Card className="border-blue-200 bg-blue-50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center">
                          <Server className="h-5 w-5 mr-2 text-blue-600" />
                          Frontend & API
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">Port 3000</p>
                        <p className="text-sm">React interface with Node.js/Express server providing unified API gateway</p>
                      </CardContent>
                    </Card>

                    <Card className="border-green-200 bg-green-50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center">
                          <Workflow className="h-5 w-5 mr-2 text-green-600" />
                          Python Gateway
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">Port 8000</p>
                        <p className="text-sm">Haystack orchestrator managing AI pipelines and microservice coordination</p>
                      </CardContent>
                    </Card>

                    <Card className="border-purple-200 bg-purple-50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center">
                          <FileText className="h-5 w-5 mr-2 text-purple-600" />
                          OCR Service
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">Port 8001</p>
                        <p className="text-sm">Document text extraction with multi-format support and confidence scoring</p>
                      </CardContent>
                    </Card>

                    <Card className="border-orange-200 bg-orange-50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center">
                          <BarChart3 className="h-5 w-5 mr-2 text-orange-600" />
                          Classification
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">Port 8002</p>
                        <p className="text-sm">BFSI document classification with risk assessment and entity extraction</p>
                      </CardContent>
                    </Card>

                    <Card className="border-cyan-200 bg-cyan-50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center">
                          <Search className="h-5 w-5 mr-2 text-cyan-600" />
                          Vector Search
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">Port 8003</p>
                        <p className="text-sm">Semantic search with sentence-transformers embeddings and similarity matching</p>
                      </CardContent>
                    </Card>

                    <Card className="border-red-200 bg-red-50">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center">
                          <Shield className="h-5 w-5 mr-2 text-red-600" />
                          PII Detection
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">Port 8004</p>
                        <p className="text-sm">Sensitive data detection with compliance frameworks and risk scoring</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Data Flow */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Document Processing Flow</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm space-x-2 overflow-x-auto">
                        <div className="flex items-center space-x-2 bg-blue-100 p-2 rounded whitespace-nowrap">
                          <FileText className="h-4 w-4" />
                          <span>Upload Document</span>
                        </div>
                        <div className="text-gray-400">→</div>
                        <div className="flex items-center space-x-2 bg-purple-100 p-2 rounded whitespace-nowrap">
                          <FileText className="h-4 w-4" />
                          <span>OCR Extraction</span>
                        </div>
                        <div className="text-gray-400">→</div>
                        <div className="flex items-center space-x-2 bg-orange-100 p-2 rounded whitespace-nowrap">
                          <BarChart3 className="h-4 w-4" />
                          <span>Classification</span>
                        </div>
                        <div className="text-gray-400">→</div>
                        <div className="flex items-center space-x-2 bg-cyan-100 p-2 rounded whitespace-nowrap">
                          <Search className="h-4 w-4" />
                          <span>Vector Indexing</span>
                        </div>
                        <div className="text-gray-400">→</div>
                        <div className="flex items-center space-x-2 bg-red-100 p-2 rounded whitespace-nowrap">
                          <Shield className="h-4 w-4" />
                          <span>PII Detection</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Technology Stack */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Technology Stack</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div>
                          <h4 className="font-semibold mb-2">AI & ML Framework</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>• Haystack 2.17.1 - AI orchestration</li>
                            <li>• Sentence Transformers - Embeddings</li>
                            <li>• FastAPI - Microservice framework</li>
                            <li>• Python 3.13.5 - Runtime</li>
                          </ul>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Frontend & Infrastructure</h4>
                          <ul className="text-sm space-y-1 text-muted-foreground">
                            <li>• React + TypeScript - UI framework</li>
                            <li>• Node.js/Express - API gateway</li>
                            <li>• Tailwind CSS - Styling</li>
                            <li>• Windows-native deployment</li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
