import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, FileText, Clock } from "lucide-react";

export default function SemanticSearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    // Simulate search
    setTimeout(() => {
      setSearchResults([
        {
          id: "doc-1",
          title: "Financial Risk Assessment Report Q3 2024",
          content: "This document contains detailed analysis of market risks and compliance requirements...",
          score: 0.94,
          metadata: {
            documentType: "financial_statement",
            category: "BFSI",
            processedAt: "2024-01-15T10:30:00Z"
          }
        },
        {
          id: "doc-2", 
          title: "Employee Handbook - Remote Work Policy",
          content: "Guidelines for remote work arrangements, productivity requirements, and compliance standards...",
          score: 0.87,
          metadata: {
            documentType: "policy_document",
            category: "HR",
            processedAt: "2024-01-10T14:20:00Z"
          }
        },
        {
          id: "doc-3",
          title: "Contract Agreement - Software Licensing",
          content: "Software licensing terms and conditions, payment schedules, and service level agreements...",
          score: 0.82,
          metadata: {
            documentType: "contract",
            category: "Generic",
            processedAt: "2024-01-08T09:45:00Z"
          }
        }
      ]);
      setIsSearching(false);
    }, 1500);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "BFSI":
        return "bg-green-100 text-green-800";
      case "HR":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-blue-100 text-blue-800";
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Semantic Search</h1>
        <p className="text-muted-foreground">
          Search through processed documents using AI-powered semantic understanding
        </p>
      </div>

      {/* Search Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="mr-2" size={20} />
            Search Documents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <div className="flex-1">
              <Input
                placeholder="Search for documents, concepts, or specific content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                data-testid="input-search-query"
              />
            </div>
            <Button onClick={handleSearch} disabled={isSearching} data-testid="button-search">
              {isSearching ? (
                <Clock className="mr-2 animate-spin" size={16} />
              ) : (
                <Search className="mr-2" size={16} />
              )}
              Search
            </Button>
            <Button variant="outline" data-testid="button-filters">
              <Filter className="mr-2" size={16} />
              Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-foreground">
              Search Results ({searchResults.length})
            </h2>
            <p className="text-sm text-muted-foreground">
              Query: "{searchQuery}"
            </p>
          </div>

          {searchResults.map((result) => (
            <Card key={result.id} data-testid={`search-result-${result.id}`}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <FileText className="text-primary" size={20} />
                      <h3 className="font-semibold text-foreground">{result.title}</h3>
                      <Badge className={getCategoryColor(result.metadata.category)}>
                        {result.metadata.category}
                      </Badge>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {result.content}
                    </p>
                    
                    <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                      <span>Type: {result.metadata.documentType}</span>
                      <span>•</span>
                      <span>Processed: {new Date(result.metadata.processedAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <div className="ml-4 text-right">
                    <div className="text-sm font-medium text-primary">
                      {Math.round(result.score * 100)}% match
                    </div>
                    <div className="w-16 bg-muted rounded-full h-2 mt-1">
                      <div
                        className="bg-primary h-2 rounded-full"
                        style={{ width: `${result.score * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* No Results State */}
      {searchQuery && searchResults.length === 0 && !isSearching && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="mx-auto text-muted-foreground mb-4" size={48} />
            <h3 className="text-lg font-medium text-foreground mb-2">No results found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search query or check the document filters
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}