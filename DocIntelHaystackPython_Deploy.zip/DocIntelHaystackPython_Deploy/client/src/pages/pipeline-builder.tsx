import { usePipelineStore } from "@/hooks/use-pipeline-store";
import { PIPELINE_STEPS } from "@shared/schema";
import StepProgress from "@/components/pipeline/step-progress";
import SourceTypeSelector from "@/components/pipeline/source-type-selector";
import ConnectionConfig from "@/components/pipeline/connection-config";
import ProcessingRules from "@/components/pipeline/processing-rules";
import OutputDestinations from "@/components/pipeline/output-destinations";
import TestSaveConfig from "@/components/pipeline/test-save-config";

export default function PipelineBuilder() {
  const { currentStep } = usePipelineStore();

  const renderStepContent = () => {
    switch (currentStep) {
      case PIPELINE_STEPS.SOURCE_TYPE:
        return <SourceTypeSelector />;
      case PIPELINE_STEPS.CONNECTION_CONFIG:
        return <ConnectionConfig />;
      case PIPELINE_STEPS.PROCESSING_RULES:
        return <ProcessingRules />;
      case PIPELINE_STEPS.OUTPUT_DESTINATIONS:
        return <OutputDestinations />;
      case PIPELINE_STEPS.TEST_SAVE:
        return <TestSaveConfig />;
      default:
        return <SourceTypeSelector />;
    }
  };

  return (
    <div className="flex-1 p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Workflow Builder</h1>
        <p className="text-muted-foreground">
          Configure your document intelligence workflow with AI-powered processing
        </p>
      </div>

      {/* Progress Indicator */}
      <div className="fade-in">
        <StepProgress />
      </div>

      {/* Step Content */}
      <div className="fade-in">
        {renderStepContent()}
      </div>
    </div>
  );
}
