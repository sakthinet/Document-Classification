import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import QuickActions from "@/components/dashboard/quick-actions";
import SystemStatus from "@/components/dashboard/system-status";
import ArchitectureLayer from "@/components/dashboard/architecture-layer";
import { MicroservicesStatus } from "@/components/microservices";
import { 
  Activity, 
  BarChart3, 
  Cog, 
  TrendingUp, 
  FileText, 
  Search, 
  Shield, 
  Server,
  ArrowRight,
  CheckCircle,
  Clock,
  AlertTriangle
} from "lucide-react";

export default function Dashboard() {
  const { data: connectionStatus } = useQuery({
    queryKey: ["/api/system/status"],
  });

  return (
    <div className="flex-1 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to DocIntel Pro - AI-powered document intelligence platform
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <div className="w-2 h-2 bg-accent rounded-full"></div>
            <span>{(connectionStatus as any)?.status || "Connected"}</span>
          </div>
          <Link href="/pipeline-builder">
            <Button data-testid="button-new-pipeline">
              <Cog className="mr-2" size={16} />
              New Pipeline
            </Button>
          </Link>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Documents Processed</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">1,284</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-accent flex items-center">
                <TrendingUp size={12} className="mr-1" />
                +12% from last month
              </span>
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vector Embeddings</CardTitle>
            <Search className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">45,231</div>
            <p className="text-xs text-muted-foreground">
              Semantic search ready
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">PII Detected</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">89</div>
            <p className="text-xs text-muted-foreground">
              Compliance monitoring active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Services Running</CardTitle>
            <Server className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent">6/6</div>
            <p className="text-xs text-muted-foreground">
              All systems operational
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Microservices Status */}
      <MicroservicesStatus />

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <QuickActions />
        </div>
        <div className="lg:col-span-2">
          <SystemStatus />
        </div>
      </div>

      {/* Architecture Overview */}
      <div>
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Haystack-Native Architecture
          </h2>
          <p className="text-muted-foreground">
            Complete document intelligence platform built on Haystack framework with microservices architecture
          </p>
        </div>
        <ArchitectureLayer />
      </div>
    </div>
  );
}
