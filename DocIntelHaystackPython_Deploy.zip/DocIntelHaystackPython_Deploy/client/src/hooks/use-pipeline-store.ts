import { create } from "zustand";
import { PIPELINE_STEPS, SOURCE_TYPES, type SourceType, type PipelineStep } from "@shared/schema";

interface PipelineConfig {
  sourceType?: SourceType;
  connectionConfig?: any;
  processingRules?: any;
  outputDestinations?: any;
}

interface PipelineStore {
  currentStep: PipelineStep;
  pipelineConfig: PipelineConfig;
  updateSourceType: (sourceType: SourceType) => void;
  updateConnectionConfig: (config: any) => void;
  updateProcessingRules: (rules: any) => void;
  updateOutputDestinations: (destinations: any) => void;
  nextStep: () => void;
  previousStep: () => void;
  resetPipeline: () => void;
}

export const usePipelineStore = create<PipelineStore>((set, get) => ({
  currentStep: PIPELINE_STEPS.SOURCE_TYPE,
  pipelineConfig: {},
  
  updateSourceType: (sourceType: SourceType) => {
    set((state) => ({
      pipelineConfig: {
        ...state.pipelineConfig,
        sourceType,
      },
    }));
  },
  
  updateConnectionConfig: (config: any) => {
    set((state) => ({
      pipelineConfig: {
        ...state.pipelineConfig,
        connectionConfig: config,
      },
    }));
  },
  
  updateProcessingRules: (rules: any) => {
    set((state) => ({
      pipelineConfig: {
        ...state.pipelineConfig,
        processingRules: rules,
      },
    }));
  },
  
  updateOutputDestinations: (destinations: any) => {
    set((state) => ({
      pipelineConfig: {
        ...state.pipelineConfig,
        outputDestinations: destinations,
      },
    }));
  },
  
  nextStep: () => {
    set((state) => ({
      currentStep: Math.min(state.currentStep + 1, PIPELINE_STEPS.TEST_SAVE) as PipelineStep,
    }));
  },
  
  previousStep: () => {
    set((state) => ({
      currentStep: Math.max(state.currentStep - 1, PIPELINE_STEPS.SOURCE_TYPE) as PipelineStep,
    }));
  },
  
  resetPipeline: () => {
    set({
      currentStep: PIPELINE_STEPS.SOURCE_TYPE,
      pipelineConfig: {},
    });
  },
}));
