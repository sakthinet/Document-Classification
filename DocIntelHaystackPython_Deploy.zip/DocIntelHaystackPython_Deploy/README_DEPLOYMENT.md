#  DocIntel Haystack AI - Deployment Package

## Quick Start (for experienced users)
1. **Extract** this package to your desired location
2. **Run**: \python quick_setup.py\ (automated setup)
3. **Start**: Follow the prompts after setup completion

## Manual Installation (detailed)
See \INSTALLATION_GUIDE.md\ for complete step-by-step instructions.

## Package Contents
- **Size**: ~1.1 MB (ultra-light deployment package)
- **Includes**: All source code, configurations, and documentation
- **Excludes**: Python environment, node_modules (installed during setup)

## Requirements
- Python 3.13+
- Node.js 18+
- 5GB free disk space
- Internet connection for package downloads

## Installation Time
- **Automated**: ~15-30 minutes (depending on internet speed)
- **Manual**: ~20-40 minutes

## Support Files
- \INSTALLATION_GUIDE.md\ - Complete manual installation guide
- \quick_setup.py\ - Automated setup script
- \ENVIRONMENT_OPTIMIZATION_SUMMARY.md\ - Technical details about optimization

---
*This package was created from an optimized 3.6GB project, reducing deployment size by 99.97%*
