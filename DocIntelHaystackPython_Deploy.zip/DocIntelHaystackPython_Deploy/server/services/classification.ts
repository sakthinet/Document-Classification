import { type IStorage } from "../storage";

export default class ClassificationService {
  constructor(private storage: IStorage) {}

  async classifyDocument(
    documentContent: string, 
    sourceType: string, 
    documentType?: string
  ): Promise<any> {
    try {
      // Get classification model based on source type
      const model = this.getClassificationModel(sourceType);
      
      // Perform classification
      const classification = await this.performClassification(
        documentContent, 
        model, 
        sourceType, 
        documentType
      );

      // Store classification metrics
      await this.storage.createSystemMetric({
        metricName: 'classification_request',
        metricValue: JSON.stringify({
          sourceType,
          confidence: classification.confidence,
          category: classification.category
        }),
        metadata: {
          documentType,
          processingTime: classification.processingTime
        }
      });

      return classification;
    } catch (error: any) {
      // Log error metric
      await this.storage.createSystemMetric({
        metricName: 'classification_error',
        metricValue: error.message,
        metadata: {
          sourceType,
          documentType
        }
      });
      throw error;
    }
  }

  private getClassificationModel(sourceType: string): string {
    switch (sourceType) {
      case 'bfsi':
        return 'bfsi-document-classifier-v1';
      case 'hr':
        return 'hr-document-classifier-v1';
      default:
        return 'generic-document-classifier-v1';
    }
  }

  private async performClassification(
    content: string, 
    model: string, 
    sourceType: string, 
    documentType?: string
  ): Promise<any> {
    const startTime = Date.now();

    // Simulate classification processing
    // In real implementation, this would call actual ML models
    
    const categories = this.getCategoriesForSourceType(sourceType);
    const selectedCategory = categories[Math.floor(Math.random() * categories.length)];
    const confidence = Math.random() * 0.3 + 0.7; // 70-100% confidence

    const processingTime = Date.now() - startTime;

    // Generate detailed classification result
    const result = {
      category: selectedCategory,
      confidence,
      model,
      sourceType,
      processingTime,
      predictions: categories.map(cat => ({
        category: cat,
        confidence: cat === selectedCategory ? confidence : Math.random() * (confidence - 0.1)
      })).sort((a, b) => b.confidence - a.confidence),
      metadata: {
        contentLength: content.length,
        documentType,
        extractedFeatures: this.extractFeatures(content, sourceType),
        complianceFlags: this.checkCompliance(content, sourceType)
      },
      timestamp: new Date().toISOString()
    };

    return result;
  }

  private getCategoriesForSourceType(sourceType: string): string[] {
    switch (sourceType) {
      case 'bfsi':
        return [
          'financial_statement',
          'loan_application', 
          'insurance_claim',
          'kyc_document',
          'regulatory_filing',
          'risk_assessment',
          'audit_report',
          'compliance_document'
        ];
      case 'hr':
        return [
          'resume',
          'job_application',
          'employee_contract',
          'policy_document',
          'performance_review',
          'training_material',
          'org_chart',
          'benefits_document'
        ];
      default:
        return [
          'contract',
          'invoice',
          'report',
          'correspondence',
          'proposal',
          'presentation',
          'manual',
          'specification'
        ];
    }
  }

  private extractFeatures(content: string, sourceType: string): any {
    // Extract relevant features based on source type
    const baseFeatures = {
      wordCount: content.split(/\s+/).length,
      sentenceCount: content.split(/[.!?]+/).length,
      hasNumbers: /\d/.test(content),
      hasEmail: /\S+@\S+\.\S+/.test(content),
      hasPhoneNumber: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/.test(content),
      hasDate: /\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b/.test(content)
    };

    switch (sourceType) {
      case 'bfsi':
        return {
          ...baseFeatures,
          hasCurrency: /[$£€¥]\d+|\d+\s*(USD|EUR|GBP|JPY)/.test(content),
          hasAccountNumber: /\b\d{8,12}\b/.test(content),
          hasSSN: /\b\d{3}-\d{2}-\d{4}\b/.test(content),
          hasRegulatory: /(SEC|FDIC|OCC|CFTC|Basel)/i.test(content),
          riskKeywords: (content.match(/\b(risk|compliance|audit|regulatory|capital)\b/gi) || []).length
        };
      case 'hr':
        return {
          ...baseFeatures,
          hasSkills: /(skill|experience|education|certification)/i.test(content),
          hasEmployment: /(employment|work|job|position|role)/i.test(content),
          hasPII: /\b\d{3}-\d{2}-\d{4}\b/.test(content), // SSN pattern
          policyKeywords: (content.match(/\b(policy|procedure|guideline|standard)\b/gi) || []).length
        };
      default:
        return baseFeatures;
    }
  }

  private checkCompliance(content: string, sourceType: string): any {
    const flags: any = {
      piiDetected: false,
      sensitiveDataFound: false,
      complianceScore: 100
    };

    // Check for PII
    if (/\b\d{3}-\d{2}-\d{4}\b/.test(content)) { // SSN
      flags.piiDetected = true;
      flags.complianceScore -= 20;
    }

    if (/\b\d{16}\b/.test(content)) { // Credit card
      flags.sensitiveDataFound = true;
      flags.complianceScore -= 30;
    }

    switch (sourceType) {
      case 'bfsi':
        // Check BFSI-specific compliance
        if (!/\b(risk|compliance|audit)\b/i.test(content)) {
          flags.complianceScore -= 10;
          flags.missingRiskDisclosure = true;
        }
        break;
      case 'hr':
        // Check HR-specific compliance
        if (flags.piiDetected) {
          flags.piiMaskingRequired = true;
        }
        break;
    }

    return flags;
  }

  async getClassificationStats(): Promise<any> {
    // Get recent classification metrics
    const metrics = await this.storage.getMetricsByName('classification_request', 100);
    
    const stats = {
      totalClassifications: metrics.length,
      avgConfidence: 0,
      categoryDistribution: {} as any,
      sourceTypeDistribution: {} as any
    };

    if (metrics.length > 0) {
      let totalConfidence = 0;
      
      metrics.forEach(metric => {
        const data = JSON.parse(metric.metricValue);
        totalConfidence += data.confidence || 0;
        
        stats.categoryDistribution[data.category] = 
          (stats.categoryDistribution[data.category] || 0) + 1;
        
        stats.sourceTypeDistribution[data.sourceType] = 
          (stats.sourceTypeDistribution[data.sourceType] || 0) + 1;
      });
      
      stats.avgConfidence = totalConfidence / metrics.length;
    }

    return stats;
  }
}
