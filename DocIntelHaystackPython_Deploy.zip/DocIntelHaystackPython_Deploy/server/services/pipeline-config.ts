import { type IStorage } from "../storage";
import { type InsertPipelineConfiguration, type PipelineConfiguration } from "@shared/schema";

export default class PipelineConfigService {
  constructor(private storage: IStorage) {}

  async getAllPipelines(): Promise<PipelineConfiguration[]> {
    return await this.storage.getAllPipelineConfigurations();
  }

  async getPipelineById(id: string): Promise<PipelineConfiguration | undefined> {
    return await this.storage.getPipelineConfigurationById(id);
  }

  async createPipeline(config: InsertPipelineConfiguration): Promise<PipelineConfiguration> {
    // Generate Haystack pipeline configuration based on the input
    const haystackConfig = this.generateHaystackConfig(config);
    
    const pipelineWithHaystack = {
      ...config,
      haystackPipelineConfig: haystackConfig
    };

    return await this.storage.createPipelineConfiguration(pipelineWithHaystack);
  }

  async updatePipeline(id: string, config: Partial<InsertPipelineConfiguration>): Promise<PipelineConfiguration | undefined> {
    // If configuration changed, regenerate Haystack config
    if (config.processingRules || config.connectionConfig || config.outputDestinations) {
      const existingConfig = await this.storage.getPipelineConfigurationById(id);
      if (existingConfig) {
        const mergedConfig = { ...existingConfig, ...config };
        config.haystackPipelineConfig = this.generateHaystackConfig(mergedConfig);
      }
    }

    return await this.storage.updatePipelineConfiguration(id, config);
  }

  async deletePipeline(id: string): Promise<boolean> {
    return await this.storage.deletePipelineConfiguration(id);
  }

  async testPipelineConfiguration(config: any): Promise<any> {
    try {
      // Validate configuration structure
      const validationResult = this.validatePipelineConfig(config);
      if (!validationResult.valid) {
        throw new Error(`Configuration validation failed: ${validationResult.errors.join(', ')}`);
      }

      // Generate Haystack pipeline for testing
      const haystackConfig = this.generateHaystackConfig(config);
      
      // Test connection if specified
      if (config.connectionConfig) {
        await this.testConnection(config.connectionConfig);
      }

      // Test output destinations if specified
      if (config.outputDestinations) {
        await this.testOutputDestinations(config.outputDestinations);
      }

      return {
        status: 'success',
        message: 'Pipeline configuration is valid',
        haystackConfig,
        timestamp: new Date().toISOString()
      };
    } catch (error: any) {
      return {
        status: 'error',
        message: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  private generateHaystackConfig(config: any): any {
    const pipeline: any = {
      name: config.name || 'DocIntel Pipeline',
      components: [],
      connections: []
    };

    // Add document converter based on source type
    const converterComponent = this.getDocumentConverter(config.sourceType);
    pipeline.components.push(converterComponent);

    // Add processing components based on rules
    if (config.processingRules) {
      if (config.processingRules.enableClassification) {
        pipeline.components.push({
          name: 'document_classifier',
          type: 'haystack.components.classifiers.TransformersDocumentClassifier',
          params: {
            model: config.processingRules.classificationModel || 'sentence-transformers/all-MiniLM-L6-v2'
          }
        });
        pipeline.connections.push(['document_converter', 'document_classifier']);
      }

      if (config.processingRules.enableExtraction) {
        pipeline.components.push({
          name: 'data_extractor',
          type: 'haystack.components.extractors.EntityExtractor',
          params: {
            model: 'dbmdz/bert-large-cased-finetuned-conll03-english',
            extraction_fields: config.processingRules.extractionFields?.split(',').map((f: string) => f.trim()) || []
          }
        });
      }

      if (config.processingRules.enableNER) {
        pipeline.components.push({
          name: 'ner_processor',
          type: 'haystack.components.extractors.NamedEntityExtractor',
          params: {
            model: config.processingRules.nerModel || 'dbmdz/bert-large-cased-finetuned-conll03-english'
          }
        });
      }

      if (config.processingRules.enableSummarization) {
        pipeline.components.push({
          name: 'summarizer',
          type: 'haystack.components.generators.HuggingFaceLocalGenerator',
          params: {
            model: 'facebook/bart-large-cnn',
            max_length: parseInt(config.processingRules.summaryLength) || 150
          }
        });
      }
    }

    // Add output components based on destinations
    if (config.outputDestinations) {
      if (config.outputDestinations.enableVectorStore) {
        pipeline.components.push({
          name: 'vector_writer',
          type: 'haystack.components.writers.DocumentWriter',
          params: {
            document_store: {
              type: 'QdrantDocumentStore',
              host: this.extractHostFromUrl(config.outputDestinations.vectorStoreUrl) || 'localhost',
              port: this.extractPortFromUrl(config.outputDestinations.vectorStoreUrl) || 6333,
              index: config.outputDestinations.vectorStoreCollection || 'documents'
            }
          }
        });
      }

      if (config.outputDestinations.enableDatabase) {
        pipeline.components.push({
          name: 'db_writer',
          type: 'haystack.components.writers.DocumentWriter',
          params: {
            document_store: {
              type: 'SqlDocumentStore',
              sql_url: config.outputDestinations.databaseUrl,
              table_name: config.outputDestinations.databaseTable || 'processed_documents'
            }
          }
        });
      }
    }

    return pipeline;
  }

  private getDocumentConverter(sourceType: string): any {
    const baseConverter = {
      name: 'document_converter',
      type: 'haystack.components.converters.PyPDFToDocument'
    };

    switch (sourceType) {
      case 'bfsi':
        return {
          ...baseConverter,
          params: {
            extraction_mode: 'financial',
            table_extraction: true,
            compliance_check: true
          }
        };
      case 'hr':
        return {
          ...baseConverter,
          params: {
            extraction_mode: 'hr',
            pii_detection: true,
            data_masking: true
          }
        };
      default:
        return {
          ...baseConverter,
          params: {
            extraction_mode: 'generic'
          }
        };
    }
  }

  private validatePipelineConfig(config: any): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!config.sourceType) {
      errors.push('Source type is required');
    }

    if (config.connectionConfig) {
      if (!config.connectionConfig.connectionType) {
        errors.push('Connection type is required');
      }

      switch (config.connectionConfig.connectionType) {
        case 'database':
          if (!config.connectionConfig.host || !config.connectionConfig.database) {
            errors.push('Database connection requires host and database name');
          }
          break;
        case 'folder':
          if (!config.connectionConfig.folderPath) {
            errors.push('Folder connection requires folder path');
          }
          break;
        case 'api':
          if (!config.connectionConfig.apiEndpoint) {
            errors.push('API connection requires endpoint URL');
          }
          break;
      }
    }

    if (config.outputDestinations) {
      const hasAtLeastOneDestination = 
        config.outputDestinations.enableVectorStore ||
        config.outputDestinations.enableDatabase ||
        config.outputDestinations.enableFileStorage ||
        config.outputDestinations.enableApi;

      if (!hasAtLeastOneDestination) {
        errors.push('At least one output destination must be enabled');
      }
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  private async testConnection(connectionConfig: any): Promise<void> {
    switch (connectionConfig.connectionType) {
      case 'database':
        // Test database connection
        break;
      case 'folder':
        // Test folder access
        break;
      case 'api':
        // Test API endpoint
        break;
    }
  }

  private async testOutputDestinations(outputConfig: any): Promise<void> {
    if (outputConfig.enableVectorStore) {
      // Test Qdrant connection
    }
    if (outputConfig.enableDatabase) {
      // Test database connection
    }
    if (outputConfig.enableApi) {
      // Test webhook endpoint
    }
  }

  private extractHostFromUrl(url: string): string | null {
    if (!url) return null;
    try {
      const urlObj = new URL(url);
      return urlObj.hostname;
    } catch {
      return url.split(':')[0];
    }
  }

  private extractPortFromUrl(url: string): number | null {
    if (!url) return null;
    try {
      const urlObj = new URL(url);
      return urlObj.port ? parseInt(urlObj.port) : null;
    } catch {
      const parts = url.split(':');
      return parts.length > 1 ? parseInt(parts[1]) : null;
    }
  }
}
