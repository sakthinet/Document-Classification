import "dotenv/config";
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { getFrontendPort } from "./port-manager";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Use dynamic port allocation with port manager integration
  const allocatedPort = await getFrontendPort();
  
  const startServer = (attemptPort: number) => {
    server.listen(attemptPort, () => {
      const actualPort = (server.address() as any)?.port || attemptPort;
      log(`✅ Frontend Server is running!`);
      log(`🌐 Local:    http://localhost:${actualPort}`);
      log(`🌐 Network:  http://127.0.0.1:${actualPort}`);
      log(`📁 Serving from: ${process.cwd()}`);
      log(`🔧 Port allocated via: Port Manager System`);
    }).on('error', (err: any) => {
      if (err.code === 'EADDRINUSE' || err.code === 'ENOTSUP') {
        const nextPort = attemptPort + 1;
        log(`⚠️  Port ${attemptPort} is in use, trying port ${nextPort}...`);
        startServer(nextPort);
      } else {
        log(`❌ Failed to start server: ${err.message}`);
        process.exit(1);
      }
    });
  };
  
  startServer(allocatedPort);
})();
