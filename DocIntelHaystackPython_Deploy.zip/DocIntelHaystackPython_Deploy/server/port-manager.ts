/**
 * Frontend Port Manager Integration
 * Integrates with the Python port manager system for consistent port allocation
 */

import { spawn } from 'child_process';
import { existsSync } from 'fs';
import path from 'path';

interface PortAllocation {
  service: string;
  port: number;
  success: boolean;
  error?: string;
}

/**
 * Allocate a port using the Python port manager
 */
export async function allocatePort(serviceName: string, preferredPort?: number): Promise<PortAllocation> {
  return new Promise((resolve) => {
    // Find the Python executable
    const pythonPaths = [
      'backend/haystack_env/Scripts/python.exe',
      'E:/Dev_Branch/DataClassification/DocIntelHaystackPython/backend/haystack_env/Scripts/python.exe'
    ];
    
    let pythonPath = 'python'; // fallback
    for (const path of pythonPaths) {
      if (existsSync(path)) {
        pythonPath = path;
        break;
      }
    }
    
    // Prepare command arguments
    const args = ['-c', `
import sys
import os
sys.path.append('shared')
try:
    from port_manager import allocate_port
    port = allocate_port('${serviceName}', ${preferredPort || 'None'})
    print(f'SUCCESS:{port}')
except Exception as e:
    print(f'ERROR:{str(e)}')
    `];
    
    const proc = spawn(pythonPath, args, {
      cwd: process.cwd(),
      stdio: 'pipe'
    });
    
    let output = '';
    
    proc.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    proc.stderr.on('data', (data) => {
      output += data.toString();
    });
    
    proc.on('close', (code) => {
      const lines = output.trim().split('\n');
      const lastLine = lines[lines.length - 1];
      
      if (lastLine.startsWith('SUCCESS:')) {
        const port = parseInt(lastLine.split(':')[1]);
        resolve({
          service: serviceName,
          port: port,
          success: true
        });
      } else if (lastLine.startsWith('ERROR:')) {
        const error = lastLine.split(':').slice(1).join(':');
        resolve({
          service: serviceName,
          port: preferredPort || 3000,
          success: false,
          error: error
        });
      } else {
        // Fallback if no clear response
        resolve({
          service: serviceName,
          port: preferredPort || 3000,
          success: false,
          error: 'Unknown response from port manager'
        });
      }
    });
    
    // Timeout after 5 seconds
    setTimeout(() => {
      proc.kill();
      resolve({
        service: serviceName,
        port: preferredPort || 3000,
        success: false,
        error: 'Port allocation timeout'
      });
    }, 5000);
  });
}

/**
 * Find an available port manually (fallback)
 */
export function findAvailablePort(startPort: number = 3000): Promise<number> {
  return new Promise((resolve, reject) => {
    import('net').then(({ default: net }) => {
      function tryPort(port: number) {
        const server = net.createServer();
        
        server.listen(port, () => {
          const address = server.address();
          const actualPort = typeof address === 'string' ? port : address?.port || port;
          server.close(() => {
            resolve(actualPort);
          });
        });
        
        server.on('error', (err: any) => {
          if (err.code === 'EADDRINUSE') {
            tryPort(port + 1);
          } else {
            reject(err);
          }
        });
      }
      
      tryPort(startPort);
    }).catch(reject);
  });
}

/**
 * Get allocated port for frontend with fallback
 */
export async function getFrontendPort(): Promise<number> {
  console.log('🔍 Allocating port for frontend...');
  
  // Try to use port manager first
  const allocation = await allocatePort('frontend', 3000);
  
  if (allocation.success) {
    console.log(`✅ Port Manager: Allocated port ${allocation.port} for frontend`);
    return allocation.port;
  } else {
    console.log(`⚠️ Port Manager failed: ${allocation.error}`);
    console.log('🔄 Using fallback port allocation...');
    
    // Fallback to manual port finding
    const port = await findAvailablePort(3000);
    console.log(`🆕 Fallback: Using port ${port} for frontend`);
    return port;
  }
}
