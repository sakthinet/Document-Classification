import { 
  type User, 
  type InsertUser, 
  type PipelineConfiguration, 
  type InsertPipelineConfiguration,
  type DocumentSource,
  type InsertDocumentSource,
  type ProcessingJob,
  type InsertProcessingJob,
  type DocumentEntity,
  type InsertDocumentEntity,
  type SystemMetric,
  type InsertSystemMetric,
  users,
  pipelineConfigurations,
  documentSources,
  processingJobs,
  documentEntities,
  systemMetrics
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, count } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Pipeline Configuration methods
  getAllPipelineConfigurations(): Promise<PipelineConfiguration[]>;
  getPipelineConfigurationById(id: string): Promise<PipelineConfiguration | undefined>;
  createPipelineConfiguration(config: InsertPipelineConfiguration): Promise<PipelineConfiguration>;
  updatePipelineConfiguration(id: string, config: Partial<InsertPipelineConfiguration>): Promise<PipelineConfiguration | undefined>;
  deletePipelineConfiguration(id: string): Promise<boolean>;

  // Document Source methods
  getAllDocumentSources(): Promise<DocumentSource[]>;
  getDocumentSourceById(id: string): Promise<DocumentSource | undefined>;
  createDocumentSource(source: InsertDocumentSource): Promise<DocumentSource>;
  updateDocumentSource(id: string, source: Partial<InsertDocumentSource>): Promise<DocumentSource | undefined>;
  deleteDocumentSource(id: string): Promise<boolean>;

  // Processing Job methods
  getAllProcessingJobs(): Promise<ProcessingJob[]>;
  getProcessingJobById(id: string): Promise<ProcessingJob | undefined>;
  createProcessingJob(job: InsertProcessingJob): Promise<ProcessingJob>;
  updateProcessingJob(id: string, job: Partial<InsertProcessingJob>): Promise<ProcessingJob | undefined>;
  deleteProcessingJob(id: string): Promise<boolean>;

  // Document Entity methods
  getAllDocumentEntities(): Promise<DocumentEntity[]>;
  getDocumentEntityById(id: string): Promise<DocumentEntity | undefined>;
  createDocumentEntity(entity: InsertDocumentEntity): Promise<DocumentEntity>;
  updateDocumentEntity(id: string, entity: Partial<InsertDocumentEntity>): Promise<DocumentEntity | undefined>;
  deleteDocumentEntity(id: string): Promise<boolean>;

  // System Metrics methods
  getAllSystemMetrics(): Promise<SystemMetric[]>;
  getSystemMetricById(id: string): Promise<SystemMetric | undefined>;
  createSystemMetric(metric: InsertSystemMetric): Promise<SystemMetric>;
  getMetricsByName(metricName: string, limit?: number): Promise<SystemMetric[]>;
  getRecentMetrics(hours?: number): Promise<SystemMetric[]>;

  // Analytics methods
  getDocumentProcessingStats(): Promise<any>;
  getPipelinePerformanceStats(): Promise<any>;
  getSystemHealthMetrics(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Pipeline Configuration methods
  async getAllPipelineConfigurations(): Promise<PipelineConfiguration[]> {
    return await db.select().from(pipelineConfigurations).orderBy(desc(pipelineConfigurations.createdAt));
  }

  async getPipelineConfigurationById(id: string): Promise<PipelineConfiguration | undefined> {
    const [config] = await db.select().from(pipelineConfigurations).where(eq(pipelineConfigurations.id, id));
    return config || undefined;
  }

  async createPipelineConfiguration(config: InsertPipelineConfiguration): Promise<PipelineConfiguration> {
    const [created] = await db.insert(pipelineConfigurations).values({
      ...config,
      updatedAt: new Date()
    }).returning();
    return created;
  }

  async updatePipelineConfiguration(id: string, config: Partial<InsertPipelineConfiguration>): Promise<PipelineConfiguration | undefined> {
    const [updated] = await db.update(pipelineConfigurations)
      .set({ ...config, updatedAt: new Date() })
      .where(eq(pipelineConfigurations.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePipelineConfiguration(id: string): Promise<boolean> {
    const result = await db.delete(pipelineConfigurations).where(eq(pipelineConfigurations.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Document Source methods
  async getAllDocumentSources(): Promise<DocumentSource[]> {
    return await db.select().from(documentSources).orderBy(desc(documentSources.createdAt));
  }

  async getDocumentSourceById(id: string): Promise<DocumentSource | undefined> {
    const [source] = await db.select().from(documentSources).where(eq(documentSources.id, id));
    return source || undefined;
  }

  async createDocumentSource(source: InsertDocumentSource): Promise<DocumentSource> {
    const [created] = await db.insert(documentSources).values(source).returning();
    return created;
  }

  async updateDocumentSource(id: string, source: Partial<InsertDocumentSource>): Promise<DocumentSource | undefined> {
    const [updated] = await db.update(documentSources)
      .set(source)
      .where(eq(documentSources.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteDocumentSource(id: string): Promise<boolean> {
    const result = await db.delete(documentSources).where(eq(documentSources.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Processing Job methods
  async getAllProcessingJobs(): Promise<ProcessingJob[]> {
    return await db.select().from(processingJobs).orderBy(desc(processingJobs.startedAt));
  }

  async getProcessingJobById(id: string): Promise<ProcessingJob | undefined> {
    const [job] = await db.select().from(processingJobs).where(eq(processingJobs.id, id));
    return job || undefined;
  }

  async createProcessingJob(job: InsertProcessingJob): Promise<ProcessingJob> {
    const [created] = await db.insert(processingJobs).values(job).returning();
    return created;
  }

  async updateProcessingJob(id: string, job: Partial<InsertProcessingJob>): Promise<ProcessingJob | undefined> {
    const [updated] = await db.update(processingJobs)
      .set(job)
      .where(eq(processingJobs.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteProcessingJob(id: string): Promise<boolean> {
    const result = await db.delete(processingJobs).where(eq(processingJobs.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Document Entity methods
  async getAllDocumentEntities(): Promise<DocumentEntity[]> {
    return await db.select().from(documentEntities).orderBy(desc(documentEntities.processedAt));
  }

  async getDocumentEntityById(id: string): Promise<DocumentEntity | undefined> {
    const [entity] = await db.select().from(documentEntities).where(eq(documentEntities.id, id));
    return entity || undefined;
  }

  async createDocumentEntity(entity: InsertDocumentEntity): Promise<DocumentEntity> {
    const [created] = await db.insert(documentEntities).values(entity).returning();
    return created;
  }

  async updateDocumentEntity(id: string, entity: Partial<InsertDocumentEntity>): Promise<DocumentEntity | undefined> {
    const [updated] = await db.update(documentEntities)
      .set(entity)
      .where(eq(documentEntities.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteDocumentEntity(id: string): Promise<boolean> {
    const result = await db.delete(documentEntities).where(eq(documentEntities.id, id));
    return (result.rowCount || 0) > 0;
  }

  // System Metrics methods
  async getAllSystemMetrics(): Promise<SystemMetric[]> {
    return await db.select().from(systemMetrics).orderBy(desc(systemMetrics.timestamp));
  }

  async getSystemMetricById(id: string): Promise<SystemMetric | undefined> {
    const [metric] = await db.select().from(systemMetrics).where(eq(systemMetrics.id, id));
    return metric || undefined;
  }

  async createSystemMetric(metric: InsertSystemMetric): Promise<SystemMetric> {
    const [created] = await db.insert(systemMetrics).values(metric).returning();
    return created;
  }

  async getMetricsByName(metricName: string, limit: number = 100): Promise<SystemMetric[]> {
    return await db.select().from(systemMetrics)
      .where(eq(systemMetrics.metricName, metricName))
      .orderBy(desc(systemMetrics.timestamp))
      .limit(limit);
  }

  async getRecentMetrics(hours: number = 24): Promise<SystemMetric[]> {
    const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);
    return await db.select().from(systemMetrics)
      .where(gte(systemMetrics.timestamp, cutoffTime))
      .orderBy(desc(systemMetrics.timestamp));
  }

  // Analytics methods
  async getDocumentProcessingStats(): Promise<any> {
    const totalDocuments = await db.select({ count: count() }).from(documentEntities);
    const recentlyProcessed = await db.select({ count: count() }).from(documentEntities)
      .where(gte(documentEntities.processedAt, new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)));

    return {
      totalDocuments: totalDocuments[0]?.count || 0,
      recentlyProcessed: recentlyProcessed[0]?.count || 0,
    };
  }

  async getPipelinePerformanceStats(): Promise<any> {
    const activePipelines = await db.select({ count: count() }).from(pipelineConfigurations)
      .where(eq(pipelineConfigurations.status, 'active'));
    
    const runningJobs = await db.select({ count: count() }).from(processingJobs)
      .where(eq(processingJobs.status, 'running'));

    return {
      activePipelines: activePipelines[0]?.count || 0,
      runningJobs: runningJobs[0]?.count || 0,
    };
  }

  async getSystemHealthMetrics(): Promise<any> {
    const recentMetrics = await this.getRecentMetrics(1); // Last hour
    
    return {
      timestamp: new Date().toISOString(),
      metricsCount: recentMetrics.length,
      status: 'healthy'
    };
  }
}

export const storage = new DatabaseStorage();
