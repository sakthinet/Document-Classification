import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { z } from "zod";
import { insertPipelineConfigurationSchema, insertProcessingJobSchema, insertSystemMetricSchema } from "@shared/schema";
import PipelineConfigService from "./services/pipeline-config";
import DocumentProcessingService from "./services/document-processing";
import ClassificationService from "./services/classification";
import VectorStoreService from "./services/vector-store";
import AnalyticsService from "./services/analytics";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize services
  const pipelineConfigService = new PipelineConfigService(storage);
  const documentProcessingService = new DocumentProcessingService(storage);
  const classificationService = new ClassificationService(storage);
  const vectorStoreService = new VectorStoreService(storage);
  const analyticsService = new AnalyticsService(storage);

  // System status and metrics endpoints
  app.get("/api/system/status", async (req, res) => {
    try {
      const status = await analyticsService.getSystemStatus();
      res.json(status);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/system/metrics", async (req, res) => {
    try {
      const metrics = await analyticsService.getSystemMetrics();
      res.json(metrics);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/activities/recent", async (req, res) => {
    try {
      const activities = await analyticsService.getRecentActivities();
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Pipeline configuration endpoints
  app.get("/api/pipelines", async (req, res) => {
    try {
      const pipelines = await pipelineConfigService.getAllPipelines();
      res.json(pipelines);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/pipelines/:id", async (req, res) => {
    try {
      const pipeline = await pipelineConfigService.getPipelineById(req.params.id);
      if (!pipeline) {
        return res.status(404).json({ error: "Pipeline not found" });
      }
      res.json(pipeline);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/pipelines", async (req, res) => {
    try {
      const validatedData = insertPipelineConfigurationSchema.parse(req.body);
      const pipeline = await pipelineConfigService.createPipeline(validatedData);
      res.status(201).json(pipeline);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid pipeline configuration", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/pipelines/:id", async (req, res) => {
    try {
      const validatedData = insertPipelineConfigurationSchema.partial().parse(req.body);
      const pipeline = await pipelineConfigService.updatePipeline(req.params.id, validatedData);
      if (!pipeline) {
        return res.status(404).json({ error: "Pipeline not found" });
      }
      res.json(pipeline);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid pipeline configuration", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/pipelines/:id", async (req, res) => {
    try {
      const success = await pipelineConfigService.deletePipeline(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Pipeline not found" });
      }
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Pipeline testing endpoint
  app.post("/api/pipelines/test", async (req, res) => {
    try {
      const testConfig = z.object({
        sourceType: z.string(),
        connectionConfig: z.any().optional(),
        processingRules: z.any().optional(),
        outputDestinations: z.any().optional(),
      }).parse(req.body);

      const testResult = await pipelineConfigService.testPipelineConfiguration(testConfig);
      res.json(testResult);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid test configuration", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Processing jobs endpoints
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await documentProcessingService.getAllJobs();
      res.json(jobs);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await documentProcessingService.getJobById(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    try {
      const validatedData = insertProcessingJobSchema.parse(req.body);
      const job = await documentProcessingService.createJob(validatedData);
      res.status(201).json(job);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid job configuration", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Document sources endpoints
  app.get("/api/sources", async (req, res) => {
    try {
      const sources = await documentProcessingService.getAllSources();
      res.json(sources);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/sources/:id", async (req, res) => {
    try {
      const source = await documentProcessingService.getSourceById(req.params.id);
      if (!source) {
        return res.status(404).json({ error: "Source not found" });
      }
      res.json(source);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Classification endpoints
  app.post("/api/classify", async (req, res) => {
    try {
      const classifyRequest = z.object({
        documentContent: z.string(),
        sourceType: z.string(),
        documentType: z.string().optional(),
      }).parse(req.body);

      const result = await classificationService.classifyDocument(
        classifyRequest.documentContent,
        classifyRequest.sourceType,
        classifyRequest.documentType
      );
      res.json(result);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid classification request", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Vector store endpoints
  app.post("/api/vectors/search", async (req, res) => {
    try {
      const searchRequest = z.object({
        query: z.string(),
        collection: z.string().optional(),
        limit: z.number().optional().default(10),
        filter: z.any().optional(),
      }).parse(req.body);

      const results = await vectorStoreService.searchSimilar(
        searchRequest.query,
        searchRequest.collection,
        searchRequest.limit,
        searchRequest.filter
      );
      res.json(results);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid search request", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/vectors/index", async (req, res) => {
    try {
      const indexRequest = z.object({
        documents: z.array(z.object({
          id: z.string(),
          content: z.string(),
          metadata: z.any().optional(),
        })),
        collection: z.string().optional(),
      }).parse(req.body);

      const result = await vectorStoreService.indexDocuments(
        indexRequest.documents,
        indexRequest.collection
      );
      res.json(result);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid indexing request", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  // Analytics endpoints
  app.get("/api/analytics/pipeline-performance", async (req, res) => {
    try {
      const performance = await analyticsService.getPipelinePerformance();
      res.json(performance);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/analytics/document-stats", async (req, res) => {
    try {
      const stats = await analyticsService.getDocumentStats();
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Metrics recording endpoint
  app.post("/api/metrics", async (req, res) => {
    try {
      const validatedData = insertSystemMetricSchema.parse(req.body);
      const metric = await analyticsService.recordMetric(validatedData);
      res.status(201).json(metric);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ error: "Invalid metric data", details: error.errors });
      }
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');

    // Send initial connection confirmation
    ws.send(JSON.stringify({
      type: 'connection',
      status: 'connected',
      message: 'Connected to DocIntel Pro'
    }));

    // Handle incoming messages
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'subscribe_pipeline':
            // Subscribe to pipeline updates
            ws.send(JSON.stringify({
              type: 'subscription',
              status: 'subscribed',
              pipelineId: data.pipelineId
            }));
            break;
            
          case 'get_system_status':
            const systemStatus = await analyticsService.getSystemStatus();
            ws.send(JSON.stringify({
              type: 'system_status',
              data: systemStatus
            }));
            break;
            
          default:
            ws.send(JSON.stringify({
              type: 'error',
              message: 'Unknown message type'
            }));
        }
      } catch (error: any) {
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  // Broadcast system updates to all connected clients
  const broadcastSystemUpdate = (update: any) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          type: 'system_update',
          data: update
        }));
      }
    });
  };

  // Simulate periodic system updates (in real implementation, this would be triggered by actual events)
  setInterval(async () => {
    try {
      const metrics = await analyticsService.getSystemMetrics();
      broadcastSystemUpdate({
        timestamp: new Date().toISOString(),
        metrics
      });
    } catch (error) {
      console.error('Error broadcasting system update:', error);
    }
  }, 30000); // Broadcast every 30 seconds

  return httpServer;
}
