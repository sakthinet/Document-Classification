# DocIntel Haystack Python Project

## Overview
A comprehensive document intelligence and classification system powered by Haystack AI framework.

## Architecture
This project follows a layered microservices architecture:

- **Layer 1**: Backend FastAPI Gateway (`backend/`)
- **Layer 2**: Haystack Pipeline Service (`haystack_service/`)
- **Layer 3**: Apache Airflow Orchestration (`airflow/`)
- **Layer 4**: Business Services (`services/`)
- **Layer 5**: Storage Integration (`storage/`)
- **Layer 6**: Frontend React Application (`client/`)
- **Layer 7**: Deployment & Configuration (`deployment/`)

## Quick Start

1. **Clone and Setup**
   ```bash
   git clone <repository-url>
   cd DocIntelHaystackPython
   ```

2. **Environment Setup**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start Services**
   ```bash
   docker-compose -f deployment/docker/docker-compose.yml up -d
   ```

4. **Access Applications**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - Airflow: http://localhost:8080
   - Qdrant: http://localhost:6333

## Directory Structure

```
├── 📱 client/                    # React Frontend
├── 🌊 backend/                   # FastAPI Gateway
├── 🔧 haystack_service/          # AI Processing
├── 🔄 airflow/                   # Orchestration
├── ⚙️ services/                  # Business Services
├── 💾 storage/                   # Storage Layer
├── 🗄️ database/                  # Database Models
├── 📊 monitoring/                # Observability
├── 🔒 security/                  # Security & Compliance
├── 🚀 deployment/                # Deployment Configs
├── 📋 tests/                     # Testing
├── 📖 docs/                      # Documentation
└── 🔧 tools/                     # Development Tools
```

## Development

### Prerequisites
- Node.js 18+
- Python 3.11+
- Docker & Docker Compose
- PostgreSQL 15+
- Redis 7+

### Backend Development
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend Development
```bash
cd client
npm install
npm run dev
```

### Haystack Service Development
```bash
cd haystack_service
pip install -r requirements.txt
python -m src.pipeline_factory
```

## Contributing
Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct and development process.

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
