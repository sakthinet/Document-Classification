import requests
import sys

services = [
    {'name': 'Python Gateway', 'port': 8000, 'status': 'Microservices orchestrator'},
    {'name': 'OCR Service', 'port': 8001, 'status': 'Document text extraction'},
    {'name': 'Classification Service', 'port': 8002, 'status': 'BFSI document classification'},
    {'name': 'Vector Search', 'port': 8003, 'status': 'Semantic search'},
    {'name': 'PII Detection', 'port': 8004, 'status': 'Sensitive data detection'}
]

print('📊 Service Health Check:')
print('=' * 70)
print(f"{'Component':<25} {'Port':<8} {'Status':<12} {'Description'}")
print('=' * 70)

for service in services:
    try:
        response = requests.get(f"http://localhost:{service['port']}/health", timeout=5)
        is_healthy = response.status_code == 200
        status_icon = '✅' if is_healthy else '❌'
        status_text = 'Running' if is_healthy else 'Down'
    except:
        status_icon = '❌'
        status_text = 'Down'
    
    print(f"{service['name']:<25} {service['port']:<8} {status_icon} {status_text:<8} {service['status']}")

print('=' * 70)
